-----------
 * Name eth0
 ** Hardware Address - 06c14efd6b3c
 ** Index - 2
 ** InetAddress - /fe80:0:0:0:4c1:4eff:fefd:6b3c%eth0
 ** InetAddress - /172.23.10.184
 ** MTU - 9001
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /0:0:0:0:0:0:0:1%lo
 ** InetAddress - /127.0.0.1
 ** MTU - 65536
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false
