Jenkins
=======

Version details
---------------

  * Version: `2.222.4`
  * Instance ID: `146640603a4aa008963e75e9772d1bc5`
  * Mode:    WAR
  * Url:     http://jenkins.aon1.tidemark.net/
  * Servlet container
      - Specification: 3.1
      - Name:          `jetty/9.4.27.v20200227`
  * Java
      - Home:           `/usr/java/jdk1.8.0_181-amd64/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0&#95;181
      - Maximum memory:   3.35 GB (3594518528)
      - Allocated memory: 1.51 GB (1625817088)
      - Free memory:      748.60 MB (784964512)
      - In-use memory:    801.90 MB (840852576)
      - GC strategy:      ParallelGC
      - Available CPUs:   4
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    Java HotSpot(TM) 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 25.181-b13
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      3.10.0-862.14.4.el7.x86&#95;64
      - Distribution: "CentOS Linux release 7.5.1804 (Core) "
      - LSB Modules:  `:core-4.1-amd64:core-4.1-noarch:cxx-4.1-amd64:cxx-4.1-noarch:desktop-4.1-amd64:desktop-4.1-noarch:languages-4.1-amd64:languages-4.1-noarch:printing-4.1-amd64:printing-4.1-noarch`
  * Process ID: 20713 (0x50e9)
  * Process started: 2020-06-17 01:14:56.718+0000
  * Process uptime: 2 min 40 sec
  * JVM startup parameters:
      - Boot classpath: `/usr/java/jdk1.8.0_181-amd64/jre/lib/resources.jar:/usr/java/jdk1.8.0_181-amd64/jre/lib/rt.jar:/usr/java/jdk1.8.0_181-amd64/jre/lib/sunrsasign.jar:/usr/java/jdk1.8.0_181-amd64/jre/lib/jsse.jar:/usr/java/jdk1.8.0_181-amd64/jre/lib/jce.jar:/usr/java/jdk1.8.0_181-amd64/jre/lib/charsets.jar:/usr/java/jdk1.8.0_181-amd64/jre/lib/jfr.jar:/usr/java/jdk1.8.0_181-amd64/jre/classes`
      - Classpath: `/usr/lib/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
      - arg[0]: `-Dcom.sun.akuma.Daemon=daemonized`
      - arg[1]: `-Dhudson.model.DirectoryBrowserSupport.CSP=`
      - arg[2]: `-Djava.awt.headless=true`
      - arg[3]: `-XX:MaxPermSize=1024m`
      - arg[4]: `-DJENKINS_HOME=/jenkins`

Important configuration
---------------

  * Security realm: `hudson.security.HudsonPrivateSecurityRealm`
  * Authorization strategy: `com.michelin.cio.hudson.plugins.rolestrategy.RoleBasedAuthorizationStrategy`
  * CSRF Protection: true
  * Initialization Milestone: Completed initialization
  * Support bundle anonymization: false

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * analysis-core:1.96 'Static Analysis Utilities'
  * ansible:1.0 'Jenkins Ansible plugin'
  * ansicolor:0.7.0 'AnsiColor'
  * ant:1.11 'Ant Plugin'
  * antisamy-markup-formatter:2.0 'OWASP Markup Formatter Plugin'
  * apache-httpcomponents-client-4-api:4.5.10-2.0 'Jenkins Apache HttpComponents Client 4.x API Plugin'
  * audit-trail:3.5 'Audit Trail'
  * authentication-tokens:1.3 'Authentication Tokens API Plugin'
  * aws-java-sdk:1.11.791 *(update available)* 'Amazon Web Services SDK'
  * batch-task:1.19 'Jenkins batch task plugin'
  * blueocean:1.23.2 'Blue Ocean'
  * blueocean-autofavorite:1.2.4 'Autofavorite for Blue Ocean'
  * blueocean-bitbucket-pipeline:1.23.2 'Bitbucket Pipeline for Blue Ocean'
  * blueocean-commons:1.23.2 'Common API for Blue Ocean'
  * blueocean-config:1.23.2 'Config API for Blue Ocean'
  * blueocean-core-js:1.23.2 'Blue Ocean Core JS'
  * blueocean-dashboard:1.23.2 'Dashboard for Blue Ocean'
  * blueocean-display-url:2.3.1 'Display URL for Blue Ocean'
  * blueocean-events:1.23.2 'Events API for Blue Ocean'
  * blueocean-git-pipeline:1.23.2 'Git Pipeline for Blue Ocean'
  * blueocean-github-pipeline:1.23.2 'GitHub Pipeline for Blue Ocean'
  * blueocean-i18n:1.23.2 'i18n for Blue Ocean'
  * blueocean-jira:1.23.2 'JIRA Integration for Blue Ocean'
  * blueocean-jwt:1.23.2 'JWT for Blue Ocean'
  * blueocean-personalization:1.23.2 'Personalization for Blue Ocean'
  * blueocean-pipeline-api-impl:1.23.2 'Pipeline implementation for Blue Ocean'
  * blueocean-pipeline-editor:1.23.2 'Blue Ocean Pipeline Editor'
  * blueocean-pipeline-scm-api:1.23.2 'Pipeline SCM API for Blue Ocean'
  * blueocean-rest:1.23.2 'REST API for Blue Ocean'
  * blueocean-rest-impl:1.23.2 'REST Implementation for Blue Ocean'
  * blueocean-web:1.23.2 'Web for Blue Ocean'
  * bouncycastle-api:2.18 'bouncycastle API Plugin'
  * branch-api:2.5.6 'Branch API Plugin'
  * build-name-setter:2.1.0 'Build Name and Description Setter'
  * build-timeout:1.20 'Build Timeout'
  * build-user-vars-plugin:1.5 'Jenkins user build vars plugin'
  * cloudbees-bitbucket-branch-source:2.8.0 'Bitbucket Branch Source Plugin'
  * cloudbees-folder:6.13 *(update available)* 'Folders Plugin'
  * command-launcher:1.4 'Command Agent Launcher Plugin'
  * conditional-buildstep:1.3.6 'Conditional BuildStep'
  * config-file-provider:3.6.3 'Config File Provider Plugin'
  * credentials:2.3.8 *(update available)* 'Credentials Plugin'
  * credentials-binding:1.23 'Credentials Binding Plugin'
  * custom-tools-plugin:0.7 'Jenkins Custom Tools Plugin'
  * dashboard-view:2.12 'Dashboard View'
  * display-url-api:2.3.2 'Display URL API'
  * docker-commons:1.16 'Docker Commons Plugin'
  * docker-workflow:1.23 'Docker Pipeline'
  * dropdown-viewstabbar-plugin:1.7 'Drop Down ViewsTabBar Plugin'
  * durable-task:1.34 'Durable Task Plugin'
  * email-ext:2.69 'Email Extension Plugin'
  * embeddable-build-status:2.0.3 'Embeddable Build Status Plugin'
  * envinject:2.3.0 'Environment Injector Plugin'
  * envinject-api:1.7 'EnvInject API Plugin'
  * extended-choice-parameter:0.78 'Extended Choice Parameter Plug-In'
  * extended-read-permission:3.2 'Jenkins Extended Read Permission Plugin'
  * external-monitor-job:1.7 'External Monitor Job Type Plugin'
  * fail-the-build-plugin:1.0 'Fail The Build Plugin'
  * favorite:2.3.2 'Favorite'
  * flexible-publish:0.15.2 'Flexible Publish Plugin'
  * gatling:1.3.0 'Gatling Jenkins Plugin'
  * git:4.2.2 'Jenkins Git plugin'
  * git-client:3.2.1 'Jenkins Git client plugin'
  * git-server:1.9 'Jenkins GIT server Plugin'
  * github:1.30.0 'GitHub plugin'
  * github-api:1.112.0 *(update available)* 'GitHub API Plugin'
  * github-branch-source:2.8.0 *(update available)* 'GitHub Branch Source Plugin'
  * gitlab-api:1.0.6 'Gitlab API Plugin'
  * gitlab-branch-source:1.5.1 'GitLab Branch Source Plugin'
  * gitlab-hook:1.4.2 'Gitlab Hook Plugin'
  * gitlab-plugin:1.5.13 'GitLab Plugin'
  * greenballs:1.15 'Green Balls'
  * handy-uri-templates-2-api:2.1.8-1.0 'Handy Uri Templates 2.x API Plugin'
  * heavy-job:1.1 'Heavy Job Plugin'
  * htmlpublisher:1.23 'HTML Publisher plugin'
  * icon-shim:2.0.3 'Icon Shim Plugin'
  * jackson2-api:2.11.0 'Jackson 2 API Plugin'
  * javadoc:1.5 'Javadoc Plugin'
  * jdk-tool:1.4 'Oracle Java SE Development Kit Installer Plugin'
  * jenkins-design-language:1.23.2 'Jenkins Design Language'
  * jira:3.0.18 *(update available)* 'Jenkins Jira plugin'
  * jobConfigHistory:2.26 'Jenkins Job Configuration History Plugin'
  * jquery:1.12.4-1 'jQuery plugin'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * jsch:0.1.55.2 'Jenkins JSch dependency plugin'
  * junit:1.29 'JUnit Plugin'
  * ldap:1.24 'LDAP Plugin'
  * mailer:1.32 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.9.0 'MapDB API Plugin'
  * matrix-auth:2.6.1 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.14 *(update available)* 'Matrix Project Plugin'
  * maven-plugin:3.6 'Maven Integration plugin'
  * mercurial:2.10 'Jenkins Mercurial plugin'
  * metrics:4.0.2.6 'Metrics Plugin'
  * node-iterator-api:1.5 'Node Iterator API Plugin'
  * nodelabelparameter:1.7.2 'Node and Label parameter plugin'
  * pam-auth:1.6 'PAM Authentication plugin'
  * parameterized-scheduler:0.8 'Parameterized Scheduler'
  * parameterized-trigger:2.36 'Jenkins Parameterized Trigger plugin'
  * pipeline-build-step:2.12 'Pipeline: Build Step'
  * pipeline-graph-analysis:1.10 'Pipeline Graph Analysis Plugin'
  * pipeline-input-step:2.11 'Pipeline: Input Step'
  * pipeline-milestone-step:1.3.1 'Pipeline: Milestone Step'
  * pipeline-model-api:1.7.0 'Pipeline: Model API'
  * pipeline-model-definition:1.7.0 'Pipeline: Declarative'
  * pipeline-model-extensions:1.7.0 'Pipeline: Declarative Extension Points API'
  * pipeline-stage-step:2.3 'Pipeline: Stage Step'
  * pipeline-stage-tags-metadata:1.7.0 'Pipeline: Stage Tags Metadata'
  * plain-credentials:1.7 'Plain Credentials Plugin'
  * publish-over:0.22 'Infrastructure plugin for Publish Over X'
  * publish-over-ssh:1.20.1 'Publish Over SSH'
  * pubsub-light:1.13 'Jenkins Pub-Sub "light" Bus'
  * read-only-configurations:1.10 'Read-only configurations'
  * rebuild:1.31 'Rebuilder'
  * resource-disposer:0.14 'Resource Disposer Plugin'
  * rich-text-publisher-plugin:1.4 'Rich Text Publisher Plugin'
  * role-strategy:3.0 'Role-based Authorization Strategy'
  * ruby-runtime:0.12 'ruby-runtime'
  * run-condition:1.3 'Run Condition Plugin'
  * sauce-ondemand:1.188 'Jenkins Sauce OnDemand plugin'
  * schedule-build:0.5.1 'Schedule Build Plugin'
  * scm-api:2.6.3 'SCM API Plugin'
  * script-security:1.73 'Script Security Plugin'
  * simple-parameterized-builds-report:1.5 'Simple Parameterized Builds Report Plugin'
  * slack:2.40 'Slack Notification Plugin'
  * slave-setup:1.10 'Jenkins Slave SetupPlugin'
  * sonar:2.11 'SonarQube Scanner for Jenkins'
  * sse-gateway:1.23 'Server Sent Events (SSE) Gateway Plugin'
  * ssh:2.6.1 'Jenkins SSH plugin'
  * ssh-credentials:1.18.1 'SSH Credentials Plugin'
  * ssh-slaves:1.31.2 'SSH Build Agents plugin'
  * structs:1.20 'Structs Plugin'
  * subversion:2.13.1 'Jenkins Subversion Plug-in'
  * support-core:2.68 'Support Core Plugin'
  * terraform:1.0.10 'Terraform Plugin'
  * test-results-analyzer:0.3.5 'Test Results Analyzer Plugin'
  * testng-plugin:1.15 'TestNG Results Plugin'
  * text-finder:1.12 *(update available)* 'Text Finder'
  * text-finder-run-condition:0.1 'Text Finder Run Condition Plugin'
  * thinBackup:1.9 'ThinBackup'
  * throttle-concurrents:2.0.2 'Jenkins Throttle Concurrent Builds Plug-in'
  * timestamper:1.11.3 'Timestamper'
  * token-macro:2.12 'Token Macro Plugin'
  * trilead-api:1.0.8 'Trilead API Plugin'
  * uno-choice:2.3 'Active Choices Plug-in'
  * validating-string-parameter:2.4 'Validating String Parameter Plugin'
  * variant:1.3 'Variant Plugin'
  * windows-slaves:1.6 'WMI Windows Agents Plugin'
  * workflow-api:2.40 'Pipeline: API'
  * workflow-basic-steps:2.20 'Pipeline: Basic Steps'
  * workflow-cps:2.80 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.16 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.35 'Pipeline: Nodes and Processes'
  * workflow-job:2.39 'Pipeline: Job'
  * workflow-multibranch:2.21 'Pipeline: Multibranch'
  * workflow-scm-step:2.11 'Pipeline: SCM Step'
  * workflow-step-api:2.22 'Pipeline: Step API'
  * workflow-support:3.4 *(update available)* 'Pipeline: Supporting APIs'
  * ws-cleanup:0.38 'Jenkins Workspace Cleanup Plugin'
