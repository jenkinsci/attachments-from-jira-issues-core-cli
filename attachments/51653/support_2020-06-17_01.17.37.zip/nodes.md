Node statistics
===============

  * Total number of nodes
      - Sample size:        4
      - Average (mean):     8.0
      - Average (median):   8.0
      - Standard deviation: 0.0
      - Minimum:            8
      - Maximum:            8
      - 95th percentile:    8.0
      - 99th percentile:    8.0
  * Total number of nodes online
      - Sample size:        4
      - Average (mean):     4.0
      - Average (median):   4.0
      - Standard deviation: 0.0
      - Minimum:            4
      - Maximum:            4
      - 95th percentile:    4.0
      - 99th percentile:    4.0
  * Total number of executors
      - Sample size:        4
      - Average (mean):     11.0
      - Average (median):   11.0
      - Standard deviation: 0.0
      - Minimum:            11
      - Maximum:            11
      - 95th percentile:    11.0
      - 99th percentile:    11.0
  * Total number of executors in use
      - Sample size:        4
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      2
      - FS root:        `/jenkins`
      - Labels:         master
      - Usage:          `EXCLUSIVE`
      - Slave Version:  4.2.1
      - Java
          + Home:           `/usr/java/jdk1.8.0_181-amd64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0&#95;181
          + Maximum memory:   3.35 GB (3594518528)
          + Allocated memory: 1.51 GB (1625817088)
          + Free memory:      688.67 MB (722122048)
          + In-use memory:    861.83 MB (903695040)
          + GC strategy:      ParallelGC
          + Available CPUs:   4
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.181-b13
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-862.14.4.el7.x86&#95;64
          + Distribution: "CentOS Linux release 7.5.1804 (Core) "
          + LSB Modules:  `:core-4.1-amd64:core-4.1-noarch:cxx-4.1-amd64:cxx-4.1-noarch:desktop-4.1-amd64:desktop-4.1-noarch:languages-4.1-amd64:languages-4.1-noarch:printing-4.1-amd64:printing-4.1-noarch`
      - Process ID: 20713 (0x50e9)
      - Process started: 2020-06-17 01:14:56.718+0000
      - Process uptime: 2 min 40 sec
      - JVM startup parameters:
          + Boot classpath: `/usr/java/jdk1.8.0_181-amd64/jre/lib/resources.jar:/usr/java/jdk1.8.0_181-amd64/jre/lib/rt.jar:/usr/java/jdk1.8.0_181-amd64/jre/lib/sunrsasign.jar:/usr/java/jdk1.8.0_181-amd64/jre/lib/jsse.jar:/usr/java/jdk1.8.0_181-amd64/jre/lib/jce.jar:/usr/java/jdk1.8.0_181-amd64/jre/lib/charsets.jar:/usr/java/jdk1.8.0_181-amd64/jre/lib/jfr.jar:/usr/java/jdk1.8.0_181-amd64/jre/classes`
          + Classpath: `/usr/lib/jenkins/jenkins.war`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Dcom.sun.akuma.Daemon=daemonized`
          + arg[1]: `-Dhudson.model.DirectoryBrowserSupport.CSP=`
          + arg[2]: `-Djava.awt.headless=true`
          + arg[3]: `-XX:MaxPermSize=1024m`
          + arg[4]: `-DJENKINS_HOME=/jenkins`

  * `AON-Devops` (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      1
      - Remote FS root: `/home/centos`
      - Labels:         Devops-AON
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        4.2.1
      - Java
          + Home:           `/usr/java/jdk1.8.0_181-amd64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0&#95;181
          + Maximum memory:   3.41 GB (3659530240)
          + Allocated memory: 236.00 MB (247463936)
          + Free memory:      189.48 MB (198683080)
          + In-use memory:    46.52 MB (48780856)
          + GC strategy:      ParallelGC
          + Available CPUs:   4
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.181-b13
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-862.14.4.el7.x86&#95;64
          + Distribution: "CentOS Linux release 7.5.1804 (Core) "
          + LSB Modules:  `:core-4.1-amd64:core-4.1-noarch:cxx-4.1-amd64:cxx-4.1-noarch:desktop-4.1-amd64:desktop-4.1-noarch:languages-4.1-amd64:languages-4.1-noarch:printing-4.1-amd64:printing-4.1-noarch`
      - Process ID: 15144 (0x3b28)
      - Process started: 2020-06-17 01:15:20.226+0000
      - Process uptime: 2 min 17 sec
      - JVM startup parameters:
          + Boot classpath: `/usr/java/jdk1.8.0_181-amd64/jre/lib/resources.jar:/usr/java/jdk1.8.0_181-amd64/jre/lib/rt.jar:/usr/java/jdk1.8.0_181-amd64/jre/lib/sunrsasign.jar:/usr/java/jdk1.8.0_181-amd64/jre/lib/jsse.jar:/usr/java/jdk1.8.0_181-amd64/jre/lib/jce.jar:/usr/java/jdk1.8.0_181-amd64/jre/lib/charsets.jar:/usr/java/jdk1.8.0_181-amd64/jre/lib/jfr.jar:/usr/java/jdk1.8.0_181-amd64/jre/classes`
          + Classpath: `remoting.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * `qe-jenkins-slave1` (`hudson.slaves.DumbSlave`)
      - Description:    _ (proferi user here can push/pull to our git repos)_
      - Executors:      4
      - Remote FS root: `/jenkins`
      - Labels:         new perf-slave
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        4.2.1
      - Java
          + Home:           `/usr/java/jdk1.8.0_181-amd64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0&#95;181
          + Maximum memory:   3.35 GB (3594518528)
          + Allocated memory: 232.00 MB (243269632)
          + Free memory:      188.08 MB (197217168)
          + In-use memory:    43.92 MB (46052464)
          + GC strategy:      ParallelGC
          + Available CPUs:   4
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.181-b13
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-862.14.4.el7.x86&#95;64
          + Distribution: "CentOS Linux release 7.5.1804 (Core) "
          + LSB Modules:  `:core-4.1-amd64:core-4.1-noarch:cxx-4.1-amd64:cxx-4.1-noarch:desktop-4.1-amd64:desktop-4.1-noarch:languages-4.1-amd64:languages-4.1-noarch:printing-4.1-amd64:printing-4.1-noarch`
      - Process ID: 10167 (0x27b7)
      - Process started: 2020-06-17 01:15:20.042+0000
      - Process uptime: 2 min 17 sec
      - JVM startup parameters:
          + Boot classpath: `/usr/java/jdk1.8.0_181-amd64/jre/lib/resources.jar:/usr/java/jdk1.8.0_181-amd64/jre/lib/rt.jar:/usr/java/jdk1.8.0_181-amd64/jre/lib/sunrsasign.jar:/usr/java/jdk1.8.0_181-amd64/jre/lib/jsse.jar:/usr/java/jdk1.8.0_181-amd64/jre/lib/jce.jar:/usr/java/jdk1.8.0_181-amd64/jre/lib/charsets.jar:/usr/java/jdk1.8.0_181-amd64/jre/lib/jfr.jar:/usr/java/jdk1.8.0_181-amd64/jre/classes`
          + Classpath: `remoting.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * `qe-jenkins-slave2` (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      4
      - Remote FS root: `/jenkins`
      - Labels:         new perf-slave
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        4.2.1
      - Java
          + Home:           `/usr/java/jdk1.8.0_181-amd64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0&#95;181
          + Maximum memory:   3.35 GB (3594518528)
          + Allocated memory: 232.00 MB (243269632)
          + Free memory:      216.31 MB (226814504)
          + In-use memory:    15.69 MB (16455128)
          + GC strategy:      ParallelGC
          + Available CPUs:   4
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.181-b13
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-862.14.4.el7.x86&#95;64
          + Distribution: "CentOS Linux release 7.5.1804 (Core) "
          + LSB Modules:  `:core-4.1-amd64:core-4.1-noarch:cxx-4.1-amd64:cxx-4.1-noarch:desktop-4.1-amd64:desktop-4.1-noarch:languages-4.1-amd64:languages-4.1-noarch:printing-4.1-amd64:printing-4.1-noarch`
      - Process ID: 5785 (0x1699)
      - Process started: 2020-06-17 01:15:19.856+0000
      - Process uptime: 2 min 18 sec
      - JVM startup parameters:
          + Boot classpath: `/usr/java/jdk1.8.0_181-amd64/jre/lib/resources.jar:/usr/java/jdk1.8.0_181-amd64/jre/lib/rt.jar:/usr/java/jdk1.8.0_181-amd64/jre/lib/sunrsasign.jar:/usr/java/jdk1.8.0_181-amd64/jre/lib/jsse.jar:/usr/java/jdk1.8.0_181-amd64/jre/lib/jce.jar:/usr/java/jdk1.8.0_181-amd64/jre/lib/charsets.jar:/usr/java/jdk1.8.0_181-amd64/jre/lib/jfr.jar:/usr/java/jdk1.8.0_181-amd64/jre/classes`
          + Classpath: `remoting.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * `qe-jenkins-slave3` (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      4
      - Remote FS root: `/jenkins`
      - Labels:         new perf-slave agent3
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        4.2.1
      - Java
          + Home:           `/usr/java/jdk1.8.0_181-amd64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0&#95;181
          + Maximum memory:   3.35 GB (3594518528)
          + Allocated memory: 232.00 MB (243269632)
          + Free memory:      188.82 MB (197989360)
          + In-use memory:    43.18 MB (45280272)
          + GC strategy:      ParallelGC
          + Available CPUs:   4
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.181-b13
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-862.14.4.el7.x86&#95;64
          + Distribution: "CentOS Linux release 7.5.1804 (Core) "
          + LSB Modules:  `:core-4.1-amd64:core-4.1-noarch:cxx-4.1-amd64:cxx-4.1-noarch:desktop-4.1-amd64:desktop-4.1-noarch:languages-4.1-amd64:languages-4.1-noarch:printing-4.1-amd64:printing-4.1-noarch`
      - Process ID: 19721 (0x4d09)
      - Process started: 2020-06-17 01:15:19.908+0000
      - Process uptime: 2 min 18 sec
      - JVM startup parameters:
          + Boot classpath: `/usr/java/jdk1.8.0_181-amd64/jre/lib/resources.jar:/usr/java/jdk1.8.0_181-amd64/jre/lib/rt.jar:/usr/java/jdk1.8.0_181-amd64/jre/lib/sunrsasign.jar:/usr/java/jdk1.8.0_181-amd64/jre/lib/jsse.jar:/usr/java/jdk1.8.0_181-amd64/jre/lib/jce.jar:/usr/java/jdk1.8.0_181-amd64/jre/lib/charsets.jar:/usr/java/jdk1.8.0_181-amd64/jre/lib/jfr.jar:/usr/java/jdk1.8.0_181-amd64/jre/classes`
          + Classpath: `remoting.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * `qe-jenkins-slave4` (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      4
      - Remote FS root: `/jenkins`
      - Labels:         new perf-slave
      - Usage:          `NORMAL`
      - Launch method:  `org.jenkinsci.plugins.slave_setup.SetupSlaveLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Demand`
      - Status:         off-line

  * `qe-jenkins-slave5` (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      4
      - Remote FS root: `/jenkins`
      - Labels:         new perf-slave
      - Usage:          `NORMAL`
      - Launch method:  `org.jenkinsci.plugins.slave_setup.SetupSlaveLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Demand`
      - Status:         off-line

  * `qe-jenkins-slave6` (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      4
      - Remote FS root: `/jenkins`
      - Labels:         new perf-slave test
      - Usage:          `NORMAL`
      - Launch method:  `org.jenkinsci.plugins.slave_setup.SetupSlaveLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Demand`
      - Status:         off-line

