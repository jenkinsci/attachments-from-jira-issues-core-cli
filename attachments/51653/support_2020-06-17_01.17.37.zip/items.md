Item statistics
===============

  * `hudson.maven.MavenModuleSet`
    - Number of items: 2
    - Number of builds per job: 1.0 [n=2, s=0.0]
    - Number of items per container: 0.0 [n=2, s=0.0]
  * `hudson.model.FreeStyleProject`
    - Number of items: 239
    - Number of builds per job: 11.564853556485355 [n=239, s=97.0]
  * `org.jenkinsci.plugins.workflow.job.WorkflowJob`
    - Number of items: 7
    - Number of builds per job: 3.7142857142857144 [n=7, s=4.0]
  * `org.jenkinsci.plugins.workflow.multibranch.WorkflowMultiBranchProject`
    - Number of items: 1
    - Number of items per container: 6 [n=1]

Total job statistics
======================

  * Number of jobs: 248
  * Number of builds per job: 11.258064516129032 [n=248, s=95.0]
