Support Bundle Manifest
=======================

Generated on 2020-06-17 01:17:37.207+0000

Requested components:

  * About browser

      - `browser.md`

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `identity.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `nodes/slave/AON-Devops/checksums.md5`

      - `nodes/slave/qe-jenkins-slave1/checksums.md5`

      - `nodes/slave/qe-jenkins-slave2/checksums.md5`

      - `nodes/slave/qe-jenkins-slave3/checksums.md5`

      - `nodes/slave/qe-jenkins-slave4/checksums.md5`

      - `nodes/slave/qe-jenkins-slave5/checksums.md5`

      - `nodes/slave/qe-jenkins-slave6/checksums.md5`

      - `plugins/active.txt`

      - `plugins/backup.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * About user (basic authentication details only)

      - `user.md`

  * Administrative monitors

      - `admin-monitors.md`

  * Agent Protocols

      - `agent-protocols.md`

  * Build queue

      - `buildqueue.md`

  * Dump agent export tables (could reveal some memory leaks)

      - `nodes/slave/AON-Devops/exportTable.txt`

      - `nodes/slave/qe-jenkins-slave1/exportTable.txt`

      - `nodes/slave/qe-jenkins-slave2/exportTable.txt`

      - `nodes/slave/qe-jenkins-slave3/exportTable.txt`

      - `nodes/slave/qe-jenkins-slave4/exportTable.txt`

      - `nodes/slave/qe-jenkins-slave5/exportTable.txt`

      - `nodes/slave/qe-jenkins-slave6/exportTable.txt`

  * Environment variables

      - `nodes/master/environment.txt`

      - `nodes/slave/AON-Devops/environment.txt`

      - `nodes/slave/qe-jenkins-slave1/environment.txt`

      - `nodes/slave/qe-jenkins-slave2/environment.txt`

      - `nodes/slave/qe-jenkins-slave3/environment.txt`

      - `nodes/slave/qe-jenkins-slave4/environment.txt`

      - `nodes/slave/qe-jenkins-slave5/environment.txt`

      - `nodes/slave/qe-jenkins-slave6/environment.txt`

  * File descriptors (Unix only)

      - `nodes/master/file-descriptors.txt`

      - `nodes/slave/AON-Devops/file-descriptors.txt`

      - `nodes/slave/qe-jenkins-slave1/file-descriptors.txt`

      - `nodes/slave/qe-jenkins-slave2/file-descriptors.txt`

      - `nodes/slave/qe-jenkins-slave3/file-descriptors.txt`

  * Items Content (Computationally expensive)

      - `items.md`

  * Master JVM process system metrics (Linux only)

      - `nodes/master/proc/meminfo.txt`

      - `nodes/master/proc/self/cmdline`

      - `nodes/master/proc/self/environ`

      - `nodes/master/proc/self/limits.txt`

      - `nodes/master/proc/self/mountstats.txt`

      - `nodes/master/proc/self/status.txt`

  * Master Log Recorders

      - `nodes/master/logs/all_2020-06-17_01.16.34.log`

      - `nodes/master/logs/all_memory_buffer.log`

      - `nodes/master/logs/jenkins.log`

      - `other-logs/Connection Activity monitoring to agents.log`

      - `other-logs/Connection Activity monitoring to agents.log.1`

      - `other-logs/Connection Activity monitoring to agents.log.2`

      - `other-logs/Connection Activity monitoring to agents.log.3`

      - `other-logs/Connection Activity monitoring to agents.log.4`

      - `other-logs/Connection Activity monitoring to agents.log.5`

      - `other-logs/Download metadata.log`

      - `other-logs/Download metadata.log.1`

      - `other-logs/Download metadata.log.2`

      - `other-logs/Download metadata.log.3`

      - `other-logs/Download metadata.log.4`

      - `other-logs/Download metadata.log.5`

      - `other-logs/EC2 alive slaves monitor.log`

      - `other-logs/EC2 alive slaves monitor.log.1`

      - `other-logs/EC2 alive slaves monitor.log.2`

      - `other-logs/EC2 alive slaves monitor.log.3`

      - `other-logs/EC2 alive slaves monitor.log.4`

      - `other-logs/EC2 alive slaves monitor.log.5`

      - `other-logs/Fingerprint cleanup.log`

      - `other-logs/Fingerprint cleanup.log.1`

      - `other-logs/Fingerprint cleanup.log.2`

      - `other-logs/Fingerprint cleanup.log.3`

      - `other-logs/Fingerprint cleanup.log.4`

      - `other-logs/Fingerprint cleanup.log.5`

      - `other-logs/Periodic background build discarder.log`

      - `other-logs/Periodic background build discarder.log.1`

      - `other-logs/Periodic background build discarder.log.2`

      - `other-logs/Periodic background build discarder.log.3`

      - `other-logs/Periodic background build discarder.log.4`

      - `other-logs/Workspace clean-up.log`

      - `other-logs/Workspace clean-up.log.1`

      - `other-logs/Workspace clean-up.log.2`

      - `other-logs/Workspace clean-up.log.3`

      - `other-logs/Workspace clean-up.log.4`

      - `other-logs/Workspace clean-up.log.5`

      - `other-logs/health-checker.log`

      - `other-logs/jenkins.branch.MultiBranchProject.log`

      - `other-logs/jenkins.branch.OrganizationFolder.log`

      - `other-logs/jobAnalytics.log`

      - `other-logs/jobAnalytics.log.1`

      - `other-logs/jobAnalytics.log.2`

      - `other-logs/telemetry collection.log`

      - `other-logs/telemetry collection.log.1`

      - `other-logs/telemetry collection.log.2`

  * Load Statistics

      - `load-stats/label/AON-Devops/gnuplot`

      - `load-stats/label/AON-Devops/hour.csv`

      - `load-stats/label/AON-Devops/min.csv`

      - `load-stats/label/AON-Devops/sec10.csv`

      - `load-stats/label/Devops-AON/gnuplot`

      - `load-stats/label/Devops-AON/hour.csv`

      - `load-stats/label/Devops-AON/min.csv`

      - `load-stats/label/Devops-AON/sec10.csv`

      - `load-stats/label/agent3/gnuplot`

      - `load-stats/label/agent3/hour.csv`

      - `load-stats/label/agent3/min.csv`

      - `load-stats/label/agent3/sec10.csv`

      - `load-stats/label/master/gnuplot`

      - `load-stats/label/master/hour.csv`

      - `load-stats/label/master/min.csv`

      - `load-stats/label/master/sec10.csv`

      - `load-stats/label/new/gnuplot`

      - `load-stats/label/new/hour.csv`

      - `load-stats/label/new/min.csv`

      - `load-stats/label/new/sec10.csv`

      - `load-stats/label/perf-slave/gnuplot`

      - `load-stats/label/perf-slave/hour.csv`

      - `load-stats/label/perf-slave/min.csv`

      - `load-stats/label/perf-slave/sec10.csv`

      - `load-stats/label/qe-jenkins-slave1/gnuplot`

      - `load-stats/label/qe-jenkins-slave1/hour.csv`

      - `load-stats/label/qe-jenkins-slave1/min.csv`

      - `load-stats/label/qe-jenkins-slave1/sec10.csv`

      - `load-stats/label/qe-jenkins-slave2/gnuplot`

      - `load-stats/label/qe-jenkins-slave2/hour.csv`

      - `load-stats/label/qe-jenkins-slave2/min.csv`

      - `load-stats/label/qe-jenkins-slave2/sec10.csv`

      - `load-stats/label/qe-jenkins-slave3/gnuplot`

      - `load-stats/label/qe-jenkins-slave3/hour.csv`

      - `load-stats/label/qe-jenkins-slave3/min.csv`

      - `load-stats/label/qe-jenkins-slave3/sec10.csv`

      - `load-stats/label/qe-jenkins-slave4/gnuplot`

      - `load-stats/label/qe-jenkins-slave4/hour.csv`

      - `load-stats/label/qe-jenkins-slave4/min.csv`

      - `load-stats/label/qe-jenkins-slave4/sec10.csv`

      - `load-stats/label/qe-jenkins-slave5/gnuplot`

      - `load-stats/label/qe-jenkins-slave5/hour.csv`

      - `load-stats/label/qe-jenkins-slave5/min.csv`

      - `load-stats/label/qe-jenkins-slave5/sec10.csv`

      - `load-stats/label/qe-jenkins-slave6/gnuplot`

      - `load-stats/label/qe-jenkins-slave6/hour.csv`

      - `load-stats/label/qe-jenkins-slave6/min.csv`

      - `load-stats/label/qe-jenkins-slave6/sec10.csv`

      - `load-stats/label/test/gnuplot`

      - `load-stats/label/test/hour.csv`

      - `load-stats/label/test/min.csv`

      - `load-stats/label/test/sec10.csv`

      - `load-stats/no-label/gnuplot`

      - `load-stats/no-label/hour.csv`

      - `load-stats/no-label/min.csv`

      - `load-stats/no-label/sec10.csv`

      - `load-stats/overall/gnuplot`

      - `load-stats/overall/hour.csv`

      - `load-stats/overall/min.csv`

      - `load-stats/overall/sec10.csv`

  * All loggers currently enabled.

      - `loggers.md`

  * Metrics

      - `nodes/master/metrics.json`

  * Networking Interface

      - `nodes/master/networkInterface.md`

      - `nodes/slave/AON-Devops/networkInterface.md`

      - `nodes/slave/qe-jenkins-slave1/networkInterface.md`

      - `nodes/slave/qe-jenkins-slave2/networkInterface.md`

      - `nodes/slave/qe-jenkins-slave3/networkInterface.md`

      - `nodes/slave/qe-jenkins-slave4/networkInterface.md`

      - `nodes/slave/qe-jenkins-slave5/networkInterface.md`

      - `nodes/slave/qe-jenkins-slave6/networkInterface.md`

  * Node monitors

      - `node-monitors.md`

  * Reverse Proxy

      - `reverse-proxy.md`

  * Running Builds

      - `running-builds.txt`

  * Agent Command Statistics

  * Master system configuration (Linux only)

      - `nodes/master/dmesg.txt`

      - `nodes/master/dmi.txt`

      - `nodes/master/proc/cpuinfo.txt`

      - `nodes/master/proc/mounts.txt`

      - `nodes/master/proc/net/rpc/nfs.txt`

      - `nodes/master/proc/net/rpc/nfsd.txt`

      - `nodes/master/proc/swaps.txt`

      - `nodes/master/proc/system-uptime.txt`

      - `nodes/master/sysctl.txt`

      - `nodes/master/userid.txt`

  * System properties

      - `nodes/master/system.properties`

      - `nodes/slave/AON-Devops/system.properties`

      - `nodes/slave/qe-jenkins-slave1/system.properties`

      - `nodes/slave/qe-jenkins-slave2/system.properties`

      - `nodes/slave/qe-jenkins-slave3/system.properties`

      - `nodes/slave/qe-jenkins-slave4/system.properties`

      - `nodes/slave/qe-jenkins-slave5/system.properties`

      - `nodes/slave/qe-jenkins-slave6/system.properties`

  * Thread dumps

      - `nodes/master/thread-dump.txt`

      - `nodes/slave/AON-Devops/thread-dump.txt`

      - `nodes/slave/qe-jenkins-slave1/thread-dump.txt`

      - `nodes/slave/qe-jenkins-slave2/thread-dump.txt`

      - `nodes/slave/qe-jenkins-slave3/thread-dump.txt`

      - `nodes/slave/qe-jenkins-slave4/thread-dump.txt`

      - `nodes/slave/qe-jenkins-slave5/thread-dump.txt`

      - `nodes/slave/qe-jenkins-slave6/thread-dump.txt`

  * Update Center

      - `update-center.md`

  * Slow Request Records

  * Deadlock Records

  * Timing data about recently completed Pipeline builds

      - `nodes/master/pipeline-timings.txt`

  * Thread dumps of running Pipeline builds

      - `nodes/master/pipeline-thread-dump.txt`

