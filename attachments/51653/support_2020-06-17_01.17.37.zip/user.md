User
====

Authentication
--------------

  * Authenticated: true
  * Name: ataylor
  * Authorities 
      - `authenticated`
  * Raw: `org.acegisecurity.providers.UsernamePasswordAuthenticationToken@915df55d: Username: hudson.security.HudsonPrivateSecurityRealm$Details@a8675b3; Password: [PROTECTED]; Authenticated: true; Details: org.acegisecurity.ui.WebAuthenticationDetails@0: RemoteIpAddress: 172.22.12.15; SessionId: node01dgpec6uy3m3i1iq17mdgijk1e0; Granted Authorities: authenticated`

