Node monitors
=============
Architecture
----
 - Is Ignored: false
 - Computers:
   * master: Linux (amd64)
   * AON-Devops: Linux (amd64)
   * qe-jenkins-slave1: Linux (amd64)
   * qe-jenkins-slave2: Linux (amd64)
   * qe-jenkins-slave3: Linux (amd64)
   * qe-jenkins-slave4: null
   * qe-jenkins-slave5: null
   * qe-jenkins-slave6: null
Clock Difference
----
 - Is Ignored: false
 - Computers:
   * master: In sync
   * AON-Devops: In sync
   * qe-jenkins-slave1: In sync
   * qe-jenkins-slave2: In sync
   * qe-jenkins-slave3: In sync
   * qe-jenkins-slave4: null
   * qe-jenkins-slave5: null
   * qe-jenkins-slave6: null
Free Disk Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: 600.536GB left on /jenkins.
   * AON-Devops: 141.195GB left on /home/centos.
   * qe-jenkins-slave1: 442.467GB left on /jenkins.
   * qe-jenkins-slave2: 409.198GB left on /jenkins.
   * qe-jenkins-slave3: 440.558GB left on /jenkins.
   * qe-jenkins-slave4: null
   * qe-jenkins-slave5: null
   * qe-jenkins-slave6: null
Free Swap Space
----
 - Is Ignored: false
 - Computers:
   * master: Memory:4288/15421MB  Swap:20353/20479MB
   * AON-Devops: Memory:754/15699MB  Swap:0/0MB
   * qe-jenkins-slave1: Memory:8100/15421MB  Swap:20385/20479MB
   * qe-jenkins-slave2: Memory:10663/15421MB  Swap:20262/20479MB
   * qe-jenkins-slave3: Memory:10113/15421MB  Swap:20088/20479MB
   * qe-jenkins-slave4: null
   * qe-jenkins-slave5: null
   * qe-jenkins-slave6: null
Free Temp Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: 17.282GB left on /tmp.
   * AON-Devops: 141.195GB left on /tmp.
   * qe-jenkins-slave1: Disk space is too low. Only 0.086GB left on /tmp.
   * qe-jenkins-slave2: 2.246GB left on /tmp.
   * qe-jenkins-slave3: 14.859GB left on /tmp.
   * qe-jenkins-slave4: null
   * qe-jenkins-slave5: null
   * qe-jenkins-slave6: null
Response Time
----
 - Is Ignored: false
 - Computers:
   * master: 0ms
   * AON-Devops: 62ms
   * qe-jenkins-slave1: 61ms
   * qe-jenkins-slave2: 180ms
   * qe-jenkins-slave3: 61ms
   * qe-jenkins-slave4: null
   * qe-jenkins-slave5: null
   * qe-jenkins-slave6: null
