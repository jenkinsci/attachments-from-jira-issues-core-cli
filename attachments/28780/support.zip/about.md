Jenkins
=======

Version details
---------------

  * Version: `1.580.2`
  * Mode:    WAR
  * Servlet container
      - Specification: 3.0
      - Name:          `jetty/winstone-2.8`
  * Java
      - Home:           `/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.75.x86_64/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.7.0_75
      - Maximum memory:   877.75 MB (920387584)
      - Allocated memory: 182.36 MB (191213568)
      - Free memory:      23.51 MB (24651216)
      - In-use memory:    158.85 MB (166562352)
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.7
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.7
  * JVM Implementation
      - Name:    OpenJDK 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 24.75-b04
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      2.6.32-279.22.1.el6.x86_64
  * Process ID: 12481 (0x30c1)
  * Process started: 2015-03-19 08:03:20.791-0400
  * Process uptime: 4 hr 27 min
  * JVM startup parameters:
      - Boot classpath: `/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.75.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.75.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.75.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.75.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.75.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.75.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.75.x86_64/jre/lib/rhino.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.75.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.75.x86_64/jre/classes`
      - Classpath: `jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

Important configuration
---------------

  * Security realm: `hudson.security.LDAPSecurityRealm`
  * Authorization strategy: `hudson.security.FullControlOnceLoggedInAuthorizationStrategy`

Active Plugins
--------------

  * analysis-core:1.67 'Static Analysis Utilities'
  * ant:1.2 'Ant Plugin'
  * antisamy-markup-formatter:1.1 *(update available)* 'OWASP Markup Formatter Plugin'
  * checkstyle:3.41 'Checkstyle Plug-in'
  * cloudbees-folder:4.7 'CloudBees Folders Plugin'
  * config-file-provider:2.7.5 'Config File Provider Plugin'
  * copyartifact:1.34 'Copy Artifact Plugin'
  * credentials:1.21 'Credentials Plugin'
  * cvs:2.11 *(update available)* 'Jenkins CVS Plug-in'
  * dry:2.41 'Duplicate Code Scanner Plug-in'
  * ec2:1.25 'Amazon EC2 plugin'
  * email-ext:2.39 'Email Extension Plugin'
  * envinject:1.90 'Environment Injector Plugin'
  * external-monitor-job:1.2 *(update available)* 'External Monitor Job Type Plugin'
  * findbugs:4.58 'FindBugs Plug-in'
  * gerrit-trigger:2.12.0 'Gerrit Trigger'
  * git:2.3.4 'Jenkins GIT plugin'
  * git-client:1.15.0 'Jenkins GIT client plugin'
  * groovy:1.24 'Hudson Groovy builder'
  * htmlpublisher:1.3 'HTML Publisher plugin'
  * javadoc:1.1 *(update available)* 'Javadoc Plugin'
  * jbehave-jenkins-plugin:3.7 'JBehave Jenkins Plugin'
  * jira:1.39 'Jenkins JIRA plugin'
  * job-dsl:1.28 'Job DSL'
  * junit:1.0 *(update available)* 'JUnit Plugin'
  * ldap:1.6 *(update available)* 'LDAP Plugin'
  * mailer:1.13 'Jenkins Mailer Plugin'
  * matrix-auth:1.1 *(update available)* 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.4 'Matrix Project Plugin'
  * maven-plugin:2.5 *(update available)* 'Maven Integration plugin'
  * metrics:3.0.9 'Metrics Plugin'
  * node-iterator-api:1.5 'Node Iterator API Plugin'
  * openid:2.1.1 'openid'
  * openid4java:0.9.8.0 'OpenID4Java API'
  * pam-auth:1.1 *(update available)* 'PAM Authentication plugin'
  * parameterized-trigger:2.25 'Jenkins Parameterized Trigger plugin'
  * pmd:3.40 'PMD Plug-in'
  * port-allocator:1.8 'Jenkins Port Allocator Plug-in'
  * promoted-builds:2.19 'Jenkins promoted builds plugin'
  * qubell:2.5 'Qubell Plugin'
  * rebuild:1.22 'Rebuilder'
  * scm-api:0.2 'SCM API Plugin'
  * script-security:1.12 'Script Security Plugin'
  * sonar:2.1 'Jenkins Sonar Plugin'
  * ssh-agent:1.5 'SSH Agent Plugin'
  * ssh-credentials:1.10 'SSH Credentials Plugin'
  * ssh-slaves:1.8 *(update available)* 'Jenkins SSH Slaves plugin'
  * subversion:1.54 *(update available)* 'Jenkins Subversion Plug-in'
  * support-core:2.20 'Support Core Plugin'
  * token-macro:1.10 'Token Macro Plugin'
  * windows-slaves:1.0 'Windows Slaves Plugin'
  * xunit:1.89 *(update available)* 'xUnit plugin'
