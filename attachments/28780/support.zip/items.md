Item statistics
===============

  * `com.cloudbees.hudson.plugins.folder.Folder`
    - Number of items: 5
    - Number of items per container: 6.8 [n=5, s=2.0]
  * `hudson.model.FreeStyleProject`
    - Number of items: 36
    - Number of builds per job: 4.861111111111111 [n=36, s=7.0]

Total job statistics
======================

  * Number of jobs: 36
  * Number of builds per job: 4.861111111111111 [n=36, s=7.0]
