package io.jenkins.plugins;

import com.sun.jna.Native;
import com.sun.jna.StringArray;
import hudson.Extension;
import hudson.lifecycle.Lifecycle;
import static hudson.util.jna.GNUCLibrary.*;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import jenkins.model.Jenkins;


@Extension
public class CustomRestartLifecycle extends Lifecycle {
    private static final Logger LOGGER = Logger.getLogger(CustomRestartLifecycle.class.getName());

    private String customCommand = "/usr/bin/touch /opt/jetty/webapps/mardyn.xml";

    public CustomRestartLifecycle() {
    }

    @Override
    public void restart() throws IOException, InterruptedException {
        Jenkins jenkins = Jenkins.getInstanceOrNull();  // guard against repeated concurrent calls to restart

        // first do cleanUp of Jenkins
        try {
            if (jenkins != null) {
                jenkins.cleanUp();
            }
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Failed to clean up. Restart will continue.", e);
        }

        // close all files upon exec, except stdin, stdout, and stderr
        // you will need an exec-family call afterwards!
        int sz = LIBC.getdtablesize();
        for(int i=3; i<sz; i++) {
            int flags = LIBC.fcntl(i, F_GETFD);
            if(flags<0) continue;
            LIBC.fcntl(i, F_SETFD,flags| FD_CLOEXEC);
        }

        LOGGER.log(Level.INFO, "executing custom restart command: " + customCommand);

        // start new process with custom command
        String exe = customCommand.split(" ")[0];
        LIBC.execvp(exe, new StringArray(customCommand.split(" ")));
        throw new IOException("Failed to exec '"+exe+"' "+LIBC.strerror(Native.getLastError()));
        // Runtime.getRuntime().exec(customCommand.split(" "));
    }
}