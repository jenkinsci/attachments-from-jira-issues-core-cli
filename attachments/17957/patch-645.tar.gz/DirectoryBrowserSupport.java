### Eclipse Workspace Patch 1.0
#P hudson-core
Index: src/main/java/hudson/model/DirectoryBrowserSupport.java
===================================================================
RCS file: /cvs/hudson/hudson/main/core/src/main/java/hudson/model/DirectoryBrowserSupport.java,v
retrieving revision 1.6
diff -u -r1.6 DirectoryBrowserSupport.java
--- src/main/java/hudson/model/DirectoryBrowserSupport.java	14 Jul 2007 19:11:27 -0000	1.6
+++ src/main/java/hudson/model/DirectoryBrowserSupport.java	27 Jul 2007 23:08:58 -0000
@@ -75,6 +75,15 @@
             f = f.getParent();
             isFingerprint = true;
         }
+
+        boolean view = false;
+        if (f.getName().equals("*view*")) {
+            // f.name == ".../ws/.../<filename>/*view*/"
+        	// set f to point to the real file
+        	f = f.getParent();
+        	view = true;
+        }
+
         if(f.getParent().getName().equals("*zip*")) {
             // the expected syntax is foo/bar/*zip*/bar.zip
             // the last 'bar.zip' portion is to causes browses to set a good default file name 
@@ -116,8 +125,18 @@
         } else {
             ContentInfo ci = f.act(new ContentInfo());
 
-            InputStream in = f.read();
-            rsp.serveFile(req, in, ci.lastModified, -1, ci.contentLength, f.getName() );
+            InputStream in = f.read();            
+        	if (view) {
+        		// for binary files, provide the file name for download
+        		rsp.setHeader("Content-Disposition", "inline; filename=" + f.getName());
+        		
+				// pseudo file name to let the Stapler set the correct response content type
+				String pseudoFileName = "plain.txt";
+				rsp.serveFile(req, in, ci.lastModified, -1, ci.contentLength,	pseudoFileName);
+			} else {
+        		rsp.serveFile(req, in, ci.lastModified, -1, ci.contentLength, f.getName() );	
+        	}
+
             in.close();
         }
     }
