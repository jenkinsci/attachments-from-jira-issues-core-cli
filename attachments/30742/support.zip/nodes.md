Node statistics
===============

  * Total number of nodes
      - Sample size:        8
      - Average (mean):     2.0
      - Average (median):   2.0
      - Standard deviation: 0.0
      - Minimum:            2
      - Maximum:            2
      - 95th percentile:    2.0
      - 99th percentile:    2.0
  * Total number of nodes online
      - Sample size:        8
      - Average (mean):     1.5
      - Average (median):   1.5
      - Standard deviation: 0.5345224838248488
      - Minimum:            1
      - Maximum:            2
      - 95th percentile:    2.0
      - 99th percentile:    2.0
  * Total number of executors
      - Sample size:        8
      - Average (mean):     2.5
      - Average (median):   2.5
      - Standard deviation: 0.5345224838248488
      - Minimum:            2
      - Maximum:            3
      - 95th percentile:    3.0
      - 99th percentile:    3.0
  * Total number of executors in use
      - Sample size:        8
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      2
      - FS root:        `/var/lib/jenkins`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Java
          + Home:           `/usr/lib/jvm/java-6-openjdk-amd64/jre`
          + Vendor:           Sun Microsystems Inc.
          + Version:          1.6.0_36
          + Maximum memory:   592.00 MB (620756992)
          + Allocated memory: 267.25 MB (280231936)
          + Free memory:      136.06 MB (142670376)
          + In-use memory:    131.19 MB (137561560)
          + PermGen used:     65.62 MB (68807152)
          + PermGen max:      166.00 MB (174063616)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.6
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.0
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Sun Microsystems Inc.
          + Version: 23.25-b01
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.2.0-90-generic
          + Distribution: Ubuntu 12.04.5 LTS
      - Process ID: 10083 (0x2763)
      - Process started: 2015-09-25 14:51:05.104+0100
      - Process uptime: 2 min 6 sec
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-6-openjdk-amd64/jre/lib/resources.jar:/usr/lib/jvm/java-6-openjdk-amd64/jre/lib/rt.jar:/usr/lib/jvm/java-6-openjdk-amd64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-6-openjdk-amd64/jre/lib/jsse.jar:/usr/lib/jvm/java-6-openjdk-amd64/jre/lib/jce.jar:/usr/lib/jvm/java-6-openjdk-amd64/jre/lib/charsets.jar:/usr/lib/jvm/java-6-openjdk-amd64/jre/lib/jfr.jar:/usr/lib/jvm/java-6-openjdk-amd64/jre/lib/netx.jar:/usr/lib/jvm/java-6-openjdk-amd64/jre/lib/plugin.jar:/usr/lib/jvm/java-6-openjdk-amd64/jre/lib/rhino.jar:/usr/lib/jvm/java-6-openjdk-amd64/jre/classes`
          + Classpath: `/usr/share/jenkins/jenkins.war`
          + Library path: `/usr/lib/jvm/java-6-openjdk-amd64/jre/lib/amd64/server:/usr/lib/jvm/java-6-openjdk-amd64/jre/lib/amd64:/usr/lib/jvm/java-6-openjdk-amd64/jre/../lib/amd64:/usr/java/packages/lib/amd64:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`
          + arg[0]: `-Dhudson.DNSMultiCast.disabled=true`

  * st130 (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      1
      - Remote FS root: `c:\Users\jenkins`
      - Labels:         2nd one
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.52
      - Java
          + Home:           `C:\Program Files\Java\jre7`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_07
          + Maximum memory:   910.25 MB (954466304)
          + Allocated memory: 376.19 MB (394461184)
          + Free memory:      200.32 MB (210047056)
          + In-use memory:    175.87 MB (184414128)
          + PermGen used:     23.67 MB (24824960)
          + PermGen max:      82.00 MB (85983232)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 23.3-b01
      - Operating system
          + Name:         Windows 7
          + Architecture: amd64
          + Version:      6.1
      - Process ID: 968 (0x3c8)
      - Process started: 2015-09-25 14:44:15.116+0100
      - Process uptime: 8 min 56 sec
      - JVM startup parameters:
          + Boot classpath: `C:\Program Files\Java\jre7\lib\resources.jar;C:\Program Files\Java\jre7\lib\rt.jar;C:\Program Files\Java\jre7\lib\sunrsasign.jar;C:\Program Files\Java\jre7\lib\jsse.jar;C:\Program Files\Java\jre7\lib\jce.jar;C:\Program Files\Java\jre7\lib\charsets.jar;C:\Program Files\Java\jre7\lib\jfr.jar;C:\Program Files\Java\jre7\classes;C:\\Program Files\\Java\\jre7\\lib\\javaws.jar;C:\\Program Files\\Java\\jre7\\lib\\deploy.jar;C:\\Program Files\\Java\\jre7\\lib\\plugin.jar`
          + Classpath: `C:\\Program Files\\Java\\jre7\\lib\\deploy.jar`
          + Library path: `C:\Program Files\Java\jre7\bin;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;C:\Program Files\Java\jre7\bin;C:\BLAHH;C:\temp\agent\python\Lib\site-packages\pywin32_system32;C:\temp\agent\python;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;C:\cygwin64\bin;C:\Program Files\Java\jre7\bin;C:\Program Files\Microsoft SDKs\Windows\v7.1\Bin;c:\python27;C:\Program Files\Microsoft SQL Server\110\Tools\Binn\;C:\Program Files (x86)\Microsoft SDKs\TypeScript\1.0\;C:\Program Files\Microsoft SQL Server\120\Tools\Binn\;C:\Program Files (x86)\MSBuild\12.0\Bin;C:\Program Files (x86)\CMake\bin;"C:\Program Files\Java\jre7\bin";.`
          + arg[0]: `-Djava.security.policy=file:C:\\Program Files\\Java\\jre7\\lib\\security\\javaws.policy`
          + arg[1]: `-DtrustProxy=true`
          + arg[2]: `-Xverify:remote`
          + arg[3]: `-Djnlpx.home=C:\\Program Files\\Java\\jre7\\bin`
          + arg[4]: `-Djnlpx.origFilenameArg=C:\Users\jenkins\Downloads\slave-agent.jnlp`
          + arg[5]: `-Djnlpx.remove=true`
          + arg[6]: `-Dsun.awt.warmup=true`
          + arg[7]: `-Xbootclasspath/a:C:\\Program Files\\Java\\jre7\\lib\\javaws.jar;C:\\Program Files\\Java\\jre7\\lib\\deploy.jar;C:\\Program Files\\Java\\jre7\\lib\\plugin.jar`
          + arg[8]: `-Djnlpx.splashport=49404`
          + arg[9]: `-Djnlpx.jvm=C:\\Program Files\\Java\\jre7\\bin\\javaw.exe`

