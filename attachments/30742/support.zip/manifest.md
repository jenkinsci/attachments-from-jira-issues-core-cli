Support Bundle Manifest
=======================

Generated on 2015-09-25 14:53:10.217+0100

Requested components:

  * Log Recorders

      - `nodes/master/logs/all_2015-09-25_13.50.54.log`

      - `nodes/master/logs/all_2015-09-25_13.51.09.log`

      - `nodes/master/logs/all_memory_buffer.log`

      - `nodes/master/logs/jenkins.log`

      - `nodes/slave/st130/jenkins.log`

      - `nodes/slave/st130/launchLogs/slave.log`

      - `nodes/slave/st130/launchLogs/slave.log.1`

      - `nodes/slave/st130/launchLogs/slave.log.2`

      - `nodes/slave/st130/launchLogs/slave.log.3`

      - `nodes/slave/st130/launchLogs/slave.log.4`

      - `nodes/slave/st130/launchLogs/slave.log.5`

      - `nodes/slave/st130/launchLogs/slave.log.6`

      - `nodes/slave/st130/launchLogs/slave.log.7`

      - `nodes/slave/st130/launchLogs/slave.log.8`

      - `nodes/slave/st130/logs/all_2015-09-25_13.52.16.log`

      - `nodes/slave/st130/logs/all_memory_buffer.log`

      - `other-logs/Fingerprint cleanup.log`

      - `other-logs/Out of order build detection.log`

      - `other-logs/Workspace clean-up.log`

      - `other-logs/jenkins.metrics.api.Metrics$HealthChecker.log`

  * About browser

      - `browser.md`

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `items.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `nodes/slave/st130/checksums.md5`

      - `plugins/active.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * About user (basic authentication details only)

      - `user.md`

  * Administrative monitors

      - `admin-monitors.md`

  * Build queue

      - `buildqueue.md`

  * Environment variables

      - `nodes/master/environment.txt`

      - `nodes/slave/st130/environment.txt`

  * File descriptors (Unix only)

      - `nodes/master/file-descriptors.txt`

  * Load Statistics

      - `load-stats/label/2nd/gnuplot`

      - `load-stats/label/2nd/hour.csv`

      - `load-stats/label/2nd/min.csv`

      - `load-stats/label/2nd/sec10.csv`

      - `load-stats/label/master/gnuplot`

      - `load-stats/label/master/hour.csv`

      - `load-stats/label/master/min.csv`

      - `load-stats/label/master/sec10.csv`

      - `load-stats/label/one/gnuplot`

      - `load-stats/label/one/hour.csv`

      - `load-stats/label/one/min.csv`

      - `load-stats/label/one/sec10.csv`

      - `load-stats/label/st130/gnuplot`

      - `load-stats/label/st130/hour.csv`

      - `load-stats/label/st130/min.csv`

      - `load-stats/label/st130/sec10.csv`

      - `load-stats/no-label/gnuplot`

      - `load-stats/no-label/hour.csv`

      - `load-stats/no-label/min.csv`

      - `load-stats/no-label/sec10.csv`

      - `load-stats/overall/gnuplot`

      - `load-stats/overall/hour.csv`

      - `load-stats/overall/min.csv`

      - `load-stats/overall/sec10.csv`

  * Metrics

      - `nodes/master/metrics.json`

      - `nodes/slave/st130/metrics.json`

  * System properties

      - `nodes/master/system.properties`

      - `nodes/slave/st130/system.properties`

  * Slow Request Records

  * Deadlock Records

  * Thread dumps

      - `nodes/master/thread-dump.txt`

      - `nodes/slave/st130/thread-dump.txt`

