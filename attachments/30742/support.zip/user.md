User
====

Authentication
--------------

  * Authenticated: true
  * Name: jw
  * Authorities 
      - `VPN_SSL_Default`
      - `ROLE_REVIEWBOARD_USERS`
      - `Operational Security`
      - `ROLE_JENKINS-ADMIN`
      - `iTop Service Manager`
      - `ROLE_VPN_SSL_DEFAULT`
      - `ROLE_CONFLUENCE-ADMINISTRATORS`
      - `iTop Change Approver`
      - `ROLE_ITOP CHANGE APPROVER`
      - `Technical Operations`
      - `ROLE_ITOP HOSTMASTER`
      - `iTop Configuration Manager`
      - `ROLE_ITOP CHANGE SUPERVISOR`
      - `Services Team`
      - `iTop Problem Manager`
      - `Staff`
      - `Crucible-Users`
      - `ROLE_ITOP SUPPORT AGENT`
      - `ROLE_CONFLUENCE-USERS`
      - `ROLE_TECHNICAL OPERATIONS`
      - `ROLE_OPERATIONAL SECURITY`
      - `ROLE_ITOP PROBLEM MANAGER`
      - `confluence-users`
      - `Jenkins-admin`
      - `ROLE_ITOP AGENT`
      - `ROLE_ITOP CONFIGURATION MANAGER`
      - `ROLE_STAFF`
      - `Systems`
      - `ROLE_TESTDISTROGROUP`
      - `iTop Change Implementor`
      - `ROLE_ITOP CHANGE IMPLEMENTOR`
      - `FW_Admin`
      - `ROLE_FW_ADMIN`
      - `ROLE_ITOP DOCUMENT AUTHOR`
      - `iTop Agent`
      - `ROLE_SERVICES TEAM`
      - `ROLE_SYSTEMS`
      - `iTop Hostmaster`
      - `confluence-administrators`
      - `ROLE_ITOP SERVICE MANAGER`
      - `ROLE_SCCM-ADMINS`
      - `iTop Document Author`
      - `Company Mobiles`
      - `authenticated`
      - `SCCM-Admins`
      - `ReviewBoard_Users`
      - `testdistrogroup`
      - `iTop Change Supervisor`
      - `ROLE_COMPANY MOBILES`
      - `iTop Support Agent`
      - `ROLE_CRUCIBLE-USERS`
  * Raw: `org.acegisecurity.providers.UsernamePasswordAuthenticationToken@ee0803d8: Username: org.acegisecurity.userdetails.ldap.LdapUserDetailsImpl@d7689f9; Password: [PROTECTED]; Authenticated: true; Details: org.acegisecurity.ui.WebAuthenticationDetails@0: RemoteIpAddress: 10.10.13.142; SessionId: 13zqv4m57r7a31t1uc2vbdhf9v; Granted Authorities: VPN_SSL_Default, ROLE_REVIEWBOARD_USERS, Operational Security, ROLE_JENKINS-ADMIN, iTop Service Manager, ROLE_VPN_SSL_DEFAULT, ROLE_CONFLUENCE-ADMINISTRATORS, iTop Change Approver, ROLE_ITOP CHANGE APPROVER, Technical Operations, ROLE_ITOP HOSTMASTER, iTop Configuration Manager, ROLE_ITOP CHANGE SUPERVISOR, Services Team, iTop Problem Manager, Staff, Crucible-Users, ROLE_ITOP SUPPORT AGENT, ROLE_CONFLUENCE-USERS, ROLE_TECHNICAL OPERATIONS, ROLE_OPERATIONAL SECURITY, ROLE_ITOP PROBLEM MANAGER, confluence-users, Jenkins-admin, ROLE_ITOP AGENT, ROLE_ITOP CONFIGURATION MANAGER, ROLE_STAFF, Systems, ROLE_TESTDISTROGROUP, iTop Change Implementor, ROLE_ITOP CHANGE IMPLEMENTOR, FW_Admin, ROLE_FW_ADMIN, ROLE_ITOP DOCUMENT AUTHOR, iTop Agent, ROLE_SERVICES TEAM, ROLE_SYSTEMS, iTop Hostmaster, confluence-administrators, ROLE_ITOP SERVICE MANAGER, ROLE_SCCM-ADMINS, iTop Document Author, Company Mobiles, authenticated, SCCM-Admins, ReviewBoard_Users, testdistrogroup, iTop Change Supervisor, ROLE_COMPANY MOBILES, iTop Support Agent, ROLE_CRUCIBLE-USERS`

