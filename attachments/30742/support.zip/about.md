Jenkins
=======

Version details
---------------

  * Version: `1.609.3`
  * Mode:    WAR
  * Servlet container
      - Specification: 3.0
      - Name:          `jetty/winstone-2.8`
  * Java
      - Home:           `/usr/lib/jvm/java-6-openjdk-amd64/jre`
      - Vendor:           Sun Microsystems Inc.
      - Version:          1.6.0_36
      - Maximum memory:   592.00 MB (620756992)
      - Allocated memory: 267.25 MB (280231936)
      - Free memory:      137.94 MB (144637824)
      - In-use memory:    129.31 MB (135594112)
      - PermGen used:     65.62 MB (68805112)
      - PermGen max:      166.00 MB (174063616)
      - GC strategy:      ParallelGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Sun Microsystems Inc.
      - Version: 1.6
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Sun Microsystems Inc.
      - Version: 1.0
  * JVM Implementation
      - Name:    OpenJDK 64-Bit Server VM
      - Vendor:  Sun Microsystems Inc.
      - Version: 23.25-b01
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      3.2.0-90-generic
      - Distribution: Ubuntu 12.04.5 LTS
  * Process ID: 10083 (0x2763)
  * Process started: 2015-09-25 14:51:05.104+0100
  * Process uptime: 2 min 6 sec
  * JVM startup parameters:
      - Boot classpath: `/usr/lib/jvm/java-6-openjdk-amd64/jre/lib/resources.jar:/usr/lib/jvm/java-6-openjdk-amd64/jre/lib/rt.jar:/usr/lib/jvm/java-6-openjdk-amd64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-6-openjdk-amd64/jre/lib/jsse.jar:/usr/lib/jvm/java-6-openjdk-amd64/jre/lib/jce.jar:/usr/lib/jvm/java-6-openjdk-amd64/jre/lib/charsets.jar:/usr/lib/jvm/java-6-openjdk-amd64/jre/lib/jfr.jar:/usr/lib/jvm/java-6-openjdk-amd64/jre/lib/netx.jar:/usr/lib/jvm/java-6-openjdk-amd64/jre/lib/plugin.jar:/usr/lib/jvm/java-6-openjdk-amd64/jre/lib/rhino.jar:/usr/lib/jvm/java-6-openjdk-amd64/jre/classes`
      - Classpath: `/usr/share/jenkins/jenkins.war`
      - Library path: `/usr/lib/jvm/java-6-openjdk-amd64/jre/lib/amd64/server:/usr/lib/jvm/java-6-openjdk-amd64/jre/lib/amd64:/usr/lib/jvm/java-6-openjdk-amd64/jre/../lib/amd64:/usr/java/packages/lib/amd64:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`
      - arg[0]: `-Dhudson.DNSMultiCast.disabled=true`

Important configuration
---------------

  * Security realm: `hudson.security.LDAPSecurityRealm`
  * Authorization strategy: `hudson.security.GlobalMatrixAuthorizationStrategy`

Active Plugins
--------------

  * active-directory:1.39 'Jenkins Active Directory plugin'
  * analysis-core:1.71 'Static Analysis Utilities'
  * android-emulator:2.13.1 'Android Emulator Plugin'
  * ant:1.2 'Ant Plugin'
  * antisamy-markup-formatter:1.2 *(update available)* 'OWASP Markup Formatter Plugin'
  * artifactory:2.2.3 *(update available)* 'Jenkins Artifactory Plugin'
  * build-pipeline-plugin:1.4.7 'Build Pipeline Plugin'
  * build-timeout:1.14 *(update available)* 'Jenkins build timeout plugin'
  * changelog-history:1.3 'Change Log History'
  * conditional-buildstep:1.3.3 'conditional-buildstep'
  * copyartifact:1.35.1 'Copy Artifact Plugin'
  * credentials:1.22 'Credentials Plugin'
  * cvs:2.12 'Jenkins CVS Plug-in'
  * dependency-check-jenkins-plugin:1.2.10 *(update available)* 'OWASP Dependency-Check Plugin'
  * depgraph-view:0.11 'Dependency Graph Viewer Plugin'
  * description-setter:1.10 'Jenkins description setter plugin'
  * email-ext:2.38.1 *(update available)* 'Email Extension Plugin'
  * emma:1.29 'Jenkins Emma plugin'
  * external-monitor-job:1.4 'External Monitor Job Type Plugin'
  * git:2.3.5 'Jenkins GIT plugin'
  * git-client:1.17.1 'Jenkins GIT client plugin'
  * javadoc:1.3 'Javadoc Plugin'
  * jgitplugin:1.0-SNAPSHOT (private-05/16/2013 11:24-ajc) 'Pure-java Git plugin (EXPERIMENTAL)'
  * jobConfigHistory:2.8 *(update available)* 'Jenkins Job Configuration History Plugin'
  * jquery:1.7.2-1 *(update available)* 'Jenkins jQuery plugin'
  * jquery-ui:1.0.2 'Jenkins jQuery UI plugin'
  * junit:1.6 'JUnit Plugin'
  * ldap:1.11 'LDAP Plugin'
  * log-parser:1.0.8 'Log Parser Plugin'
  * mailer:1.9 *(update available)* 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.1.0 *(update available)* 'MapDB API Plugin'
  * matrix-auth:1.2 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.6 'Matrix Project Plugin'
  * matrixtieparent:1.2 'Matrix Tie Parent plugin'
  * maven-plugin:2.8 *(update available)* 'Maven Integration plugin'
  * mercurial:1.50 *(update available)* 'Jenkins Mercurial plugin'
  * metrics:3.0.10 'Metrics Plugin'
  * monitoring:1.56.0 'Monitoring'
  * mstest:0.18 'MSTest plugin'
  * multiple-scms:0.3 *(update available)* 'Jenkins Multiple SCMs plugin'
  * nested-view:1.14 'Nested View Plugin'
  * pam-auth:1.2 'PAM Authentication plugin'
  * parameterized-trigger:2.26 'Jenkins Parameterized Trigger plugin'
  * performance:1.10 *(update available)* 'Performance plugin'
  * plot:1.9 'Plot plugin'
  * port-allocator:1.8 'Jenkins Port Allocator Plug-in'
  * postbuildscript:0.16 *(update available)* 'Jenkins Post-Build Script Plug-in'
  * run-condition:1.0 'Run Condition Plugin'
  * sbt:1.5 'Jenkins sbt plugin'
  * scm-api:0.2 'SCM API Plugin'
  * script-security:1.13 *(update available)* 'Script Security Plugin'
  * ssh-credentials:1.7.1 *(update available)* 'SSH Credentials Plugin'
  * ssh-slaves:1.9 'Jenkins SSH Slaves plugin'
  * subversion:2.5 'Jenkins Subversion Plug-in'
  * support-core:2.22 'Support Core Plugin'
  * threadfix:1.4.2 *(update available)* 'ThreadFix Plugin'
  * throttle-concurrents:1.8.4 'Jenkins Throttle Concurrent Builds Plug-in'
  * token-macro:1.10 'Token Macro Plugin'
  * translation:1.12 'Jenkins Translation Assistance plugin'
  * view-job-filters:1.26 'View Job Filters'
  * violations:0.7.11 'Jenkins Violations plugin'
  * windows-slaves:1.0 'Windows Slaves Plugin'
  * xunit:1.95 'xUnit plugin'
  * xvnc:1.17 *(update available)* 'Jenkins Xvnc plugin'
