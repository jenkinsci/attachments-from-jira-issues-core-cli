Item statistics
===============

  * `hudson.model.FreeStyleProject`
    - Number of items: 1
    - Number of builds per job: 5 [n=1]

Total job statistics
======================

  * Number of jobs: 1
  * Number of builds per job: 5 [n=1]
