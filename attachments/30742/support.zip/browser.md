Browser
=======

  * Screen size: 1920x1080
  * User Agent
      - Type:     Browser
      - Name:     Firefox
      - Family:   FIREFOX
      - Producer: Mozilla Foundation
      - Version:  40.0
      - Raw:      `Mozilla/5.0 (Windows NT 10.0; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0`
  * Operating System
      - Name:     Windows
      - Family:   WINDOWS
      - Producer: Microsoft Corporation.
      - Version:  10.0

