Jenkins
=======

Version details
---------------

  * Version: `1.596.2`
  * Mode:    WAR
  * Servlet container
      - Specification: 3.0
      - Name:          `jetty/winstone-2.8`
  * Java
      - Home:           `/usr/java/jdk1.8.0_31/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0_31
      - Maximum memory:   1.71 GB (1836580864)
      - Allocated memory: 730.00 MB (765460480)
      - Free memory:      543.97 MB (570392464)
      - In-use memory:    186.03 MB (195068016)
      - GC strategy:      ParallelGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    Java HotSpot(TM) 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 25.31-b07
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      2.6.32-504.12.2.el6.x86_64
  * Process ID: 2217 (0x8a9)
  * Process started: 2015-05-27 14:04:53.983+0000
  * Process uptime: 21 min
  * JVM startup parameters:
      - Boot classpath: `/usr/java/jdk1.8.0_31/jre/lib/resources.jar:/usr/java/jdk1.8.0_31/jre/lib/rt.jar:/usr/java/jdk1.8.0_31/jre/lib/sunrsasign.jar:/usr/java/jdk1.8.0_31/jre/lib/jsse.jar:/usr/java/jdk1.8.0_31/jre/lib/jce.jar:/usr/java/jdk1.8.0_31/jre/lib/charsets.jar:/usr/java/jdk1.8.0_31/jre/lib/jfr.jar:/usr/java/jdk1.8.0_31/jre/classes`
      - Classpath: `jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

Important configuration
---------------

  * Security realm: `hudson.plugins.active_directory.ActiveDirectorySecurityRealm`
  * Authorization strategy: `com.michelin.cio.hudson.plugins.rolestrategy.RoleBasedAuthorizationStrategy`

Active Plugins
--------------

  * active-directory:1.39 'Jenkins Active Directory plugin'
  * ant:1.2 'Ant Plugin'
  * antisamy-markup-formatter:1.3 'OWASP Markup Formatter Plugin'
  * build-flow-plugin:0.17 'CloudBees Build Flow plugin'
  * build-user-vars-plugin:1.4 'Jenkins user build vars plugin'
  * credentials:1.22 'Credentials Plugin'
  * credentials-binding:1.4 'Credentials Binding Plugin'
  * cvs:2.12 'Jenkins CVS Plug-in'
  * email-ext:2.40.3 *(update available)* 'Email Extension Plugin'
  * external-monitor-job:1.4 'External Monitor Job Type Plugin'
  * git:2.3.5 'Jenkins GIT plugin'
  * git-client:1.17.1 'Jenkins GIT client plugin'
  * groovy:1.25 'Hudson Groovy builder'
  * javadoc:1.3 'Javadoc Plugin'
  * junit:1.6 'JUnit Plugin'
  * ldap:1.11 'LDAP Plugin'
  * mailer:1.15 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.6.0 'MapDB API Plugin'
  * matrix-auth:1.2 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.4.1 'Matrix Project Plugin'
  * maven-plugin:2.9 'Maven Integration plugin'
  * metrics:3.0.10 'Metrics Plugin'
  * next-build-number:1.1 'Next Build Number Plugin'
  * pam-auth:1.2 'PAM Authentication plugin'
  * plain-credentials:1.1 'Plain Credentials Plugin'
  * role-strategy:2.2.0 'Role-based Authorization Strategy'
  * scm-api:0.2 'SCM API Plugin'
  * scm-sync-configuration:0.0.8 'SCM Sync Configuration Plugin'
  * script-security:1.14 'Script Security Plugin'
  * ssh-credentials:1.11 'SSH Credentials Plugin'
  * ssh-slaves:1.9 'Jenkins SSH Slaves plugin'
  * subversion:2.5 'Jenkins Subversion Plug-in'
  * support-core:2.22 'Support Core Plugin'
  * token-macro:1.10 'Token Macro Plugin'
  * translation:1.12 'Jenkins Translation Assistance plugin'
  * view-job-filters:1.26 'View Job Filters'
  * windows-slaves:1.0 'Windows Slaves Plugin'
  * workflow-step-api:1.6 'Workflow: Step API'
