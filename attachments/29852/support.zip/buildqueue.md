Current build queue has 1 item(s).
---------------
 * Name of item: ken-migration-tests-dropwizard-common
    - In queue for: 1 hr 35 min
    - Is blocked: false
    - Why in queue: Waiting for next available executor
    - Current queue trigger cause: Started by an SCM change

