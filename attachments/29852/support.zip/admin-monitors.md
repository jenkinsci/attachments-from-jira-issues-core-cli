Monitors
========

`OldData`
--------------
  * Problematic object: `hudson.maven.MavenModuleSet@217d886f[ken-migration-tests-dropwizard-common]`
    - CannotResolveClassException: jenkins.plugins.slack.SlackNotifier$SlackJobProperty

`hudson.model.UpdateCenter$CoreUpdateMonitor`
--------------
(active and enabled)
