Support Bundle Manifest
=======================

Generated on 2015-05-27 14:25:54.114+0000

Requested components:

  * Log Recorders

      - `nodes/master/logs/all_2015-05-27_11.47.57.log`

      - `nodes/master/logs/all_2015-05-27_12.04.33.log`

      - `nodes/master/logs/all_2015-05-27_12.34.50.log`

      - `nodes/master/logs/all_2015-05-27_12.45.54.log`

      - `nodes/master/logs/all_2015-05-27_13.34.36.log`

      - `nodes/master/logs/all_2015-05-27_14.04.58.log`

      - `nodes/master/logs/all_memory_buffer.log`

      - `nodes/master/logs/jenkins.log`

      - `other-logs/Fingerprint cleanup.log`

      - `other-logs/Out of order build detection.log`

      - `other-logs/Workspace clean-up.log`

      - `other-logs/jenkins.metrics.api.Metrics$HealthChecker.log`

      - `other-logs/scm-sync-configuration.success.log`

  * About browser

      - `browser.md`

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `items.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `plugins/active.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * Administrative monitors

      - `admin-monitors.md`

  * Build queue

      - `buildqueue.md`

  * Environment variables

      - `nodes/master/environment.txt`

  * File descriptors (Unix only)

      - `nodes/master/file-descriptors.txt`

  * Load Statistics

      - `load-stats/label/master/gnuplot`

      - `load-stats/label/master/hour.csv`

      - `load-stats/label/master/min.csv`

      - `load-stats/label/master/sec10.csv`

      - `load-stats/no-label/gnuplot`

      - `load-stats/no-label/hour.csv`

      - `load-stats/no-label/min.csv`

      - `load-stats/no-label/sec10.csv`

      - `load-stats/overall/gnuplot`

      - `load-stats/overall/hour.csv`

      - `load-stats/overall/min.csv`

      - `load-stats/overall/sec10.csv`

  * Metrics

      - `nodes/master/metrics.json`

  * System properties

      - `nodes/master/system.properties`

  * Slow Request Records

  * Deadlock Records

  * Thread dumps

      - `nodes/master/thread-dump.txt`

