Item statistics
===============

  * `com.cloudbees.plugins.flow.BuildFlow`
    - Number of items: 1
    - Number of builds per job: 12 [n=1]
  * `hudson.maven.MavenModuleSet`
    - Number of items: 2
    - Number of builds per job: 5.0 [n=2, s=7.0]
    - Number of items per container: 0.0 [n=2, s=0.0]
  * `hudson.model.FreeStyleProject`
    - Number of items: 2
    - Number of builds per job: 24.5 [n=2, s=30.0]

Total job statistics
======================

  * Number of jobs: 5
  * Number of builds per job: 14.2 [n=5, s=20.0]
