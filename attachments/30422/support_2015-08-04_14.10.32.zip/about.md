Jenkins
=======

Version details
---------------

  * Version: `1.596.2`
  * Mode:    Webapp Directory
  * Java
      - Home:           `/project/jenkins/tool_share/jdk/jdk1.7.0_25/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.7.0_25
      - Maximum memory:   9.81 GB (10531438592)
      - Allocated memory: 9.81 GB (10531438592)
      - Free memory:      6.39 GB (6855897000)
      - In-use memory:    3.42 GB (3675541592)
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.7
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.7
  * JVM Implementation
      - Name:    Java HotSpot(TM) 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 23.25-b01
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      2.6.32-358.18.1.el6.x86_64
      - Distribution: "Red Hat Enterprise Linux Server release 6.4 (Santiago)"
      - LSB Modules:  `:base-4.0-amd64:base-4.0-noarch:core-4.0-amd64:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-noarch`
  * Process ID: 6568 (0x19a8)
  * Process started: 2015-07-18 10:28:48.884-0700
  * Process uptime: 16 days
  * JVM startup parameters:
      - Boot classpath: `/project/jenkins/tool_share/jdk/jdk1.7.0_25/jre/lib/resources.jar:/project/jenkins/tool_share/jdk/jdk1.7.0_25/jre/lib/rt.jar:/project/jenkins/tool_share/jdk/jdk1.7.0_25/jre/lib/sunrsasign.jar:/project/jenkins/tool_share/jdk/jdk1.7.0_25/jre/lib/jsse.jar:/project/jenkins/tool_share/jdk/jdk1.7.0_25/jre/lib/jce.jar:/project/jenkins/tool_share/jdk/jdk1.7.0_25/jre/lib/charsets.jar:/project/jenkins/tool_share/jdk/jdk1.7.0_25/jre/lib/jfr.jar:/project/jenkins/tool_share/jdk/jdk1.7.0_25/jre/classes`
      - Classpath: `/project/jenkins/tool_share/apache-tomcat/apache-tomcat-7.0.59/bin/bootstrap.jar:/project/jenkins/tool_share/apache-tomcat/apache-tomcat-7.0.59/bin/tomcat-juli.jar`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
      - arg[0]: `-Djava.util.logging.config.file=/project/jenkins/prod/eis-jenkins-ip-os/apache-tomcat/conf/logging.properties`
      - arg[1]: `-Djava.util.logging.manager=org.apache.juli.ClassLoaderLogManager`
      - arg[2]: `-DHTTPPORT=8080`
      - arg[3]: `-DWEBAPP=/project/jenkins/prod/eis-jenkins-ip-os/conf/jenkins-1.596.2-lts.war`
      - arg[4]: `-DWEBDOCDIR=/project/jenkins/prod/eis-jenkins-ip-os/apache-tomcat/root`
      - arg[5]: `-DWEBLOGDIR=/project/jenkins/prod/eis-jenkins-ip-os/apache-tomcat`
      - arg[6]: `-XX:+HeapDumpOnOutOfMemoryError`
      - arg[7]: `-XX:HeapDumpPath=/project/jenkins/prod/eis-jenkins-ip-os/2015-07-09_21:21:36_onOutOfMemory.hprof`
      - arg[8]: `-Xms10g`
      - arg[9]: `-Xmx10g`
      - arg[10]: `-XX:PermSize=256m`
      - arg[11]: `-XX:MaxPermSize=512m`
      - arg[12]: `-XX:+PrintGCDetails`
      - arg[13]: `-XX:+PrintGCDateStamps`
      - arg[14]: `-Dhudson.TcpSlaveAgentListener.hostName=eussjvlx2102.sj.us.am.ericsson.se`
      - arg[15]: `-Dfile.encoding=UTF-8`
      - arg[16]: `-Dhudson.plugins.active_directory.ActiveDirectorySecurityRealm.forceLdaps=true`
      - arg[17]: `-Dcom.sun.management.jmxremote`
      - arg[18]: `-Dcom.sun.management.jmxremote.port=8084`
      - arg[19]: `-Dcom.sun.management.jmxremote.authenticate=false`
      - arg[20]: `-Dcom.sun.management.jmxremote.ssl=false`
      - arg[21]: `-Xdebug`
      - arg[22]: `-agentlib:jdwp=transport=dt_socket,server=y,suspend=n,address=127.0.0.1:8085`
      - arg[23]: `-Djava.endorsed.dirs=/project/jenkins/tool_share/apache-tomcat/apache-tomcat-7.0.59/endorsed`
      - arg[24]: `-Dcatalina.base=/project/jenkins/prod/eis-jenkins-ip-os/apache-tomcat`
      - arg[25]: `-Dcatalina.home=/project/jenkins/tool_share/apache-tomcat/apache-tomcat-7.0.59`
      - arg[26]: `-Djava.io.tmpdir=/project/jenkins/prod/eis-jenkins-ip-os/apache-tomcat/temp`

Important configuration
---------------

  * Security realm: `hudson.plugins.active_directory.ActiveDirectorySecurityRealm`
  * Authorization strategy: `hudson.security.ProjectMatrixAuthorizationStrategy`

Active Plugins
--------------

  * active-directory:1.39 'Jenkins Active Directory plugin'
  * analysis-core:1.71 *(update available)* 'Static Analysis Utilities'
  * ant:1.2 'Ant Plugin'
  * antisamy-markup-formatter:1.1 *(update available)* 'OWASP Markup Formatter Plugin'
  * artifactdeployer:0.33 'Jenkins Artifact Deployer Plug-in'
  * artifactory:2.2.7 *(update available)* 'Jenkins Artifactory Plugin'
  * async-http-client:1.7.8 'Async Http Client'
  * audit-trail:2.1 'Audit Trail'
  * build-failure-analyzer:1.13.0 'Build Failure Analyzer'
  * build-flow-extensions-plugin:0.1.1 'Build Flow Extensions'
  * build-flow-plugin:0.17 *(update available)* 'CloudBees Build Flow plugin'
  * build-name-setter:1.3 'build-name-setter'
  * build-pipeline-plugin:1.4.7 'Build Pipeline Plugin'
  * build-publisher:1.20 *(update available)* 'Hudson Build-Publisher plugin'
  * build-timeout:1.14.1 *(update available)* 'Jenkins build timeout plugin'
  * buildgraph-view:1.1.1 'buildgraph-view'
  * built-on-column:1.1 'built-on-column'
  * bulk-builder:1.5 'Bulk Builder'
  * changelog-history:1.3 'Change Log History'
  * claim:2.6 *(update available)* 'Jenkins Claim Plugin'
  * cloudbees-folder:4.8 *(update available)* 'CloudBees Folders Plugin'
  * cobertura:1.9.7 'Jenkins Cobertura Plugin'
  * compact-columns:1.10 'Compact Columns'
  * conditional-buildstep:1.3.3 'conditional-buildstep'
  * config-file-provider:2.7.5 *(update available)* 'Config File Provider Plugin'
  * configurationslicing:1.41 'Configuration Slicing plugin'
  * configure-job-column-plugin:1.0 'Configure Job Column Plugin'
  * copy-data-to-workspace-plugin:1.0 'Copy data to workspace plugin'
  * copy-to-slave:1.4.4 'Copy To Slave Plugin'
  * copyartifact:1.35 *(update available)* 'Copy Artifact Plugin'
  * coverity:1.5.0 *(update available)* 'Coverity plugin'
  * create-fingerprint:1.2 'Fingerprint Plugin'
  * credentials:1.18 *(update available)* 'Credentials Plugin'
  * cron_column:1.4 'Cron Column Plugin'
  * cvs:2.11 *(update available)* 'Jenkins CVS Plug-in'
  * dashboard-view:2.9.4 *(update available)* 'Dashboard View'
  * description-column-plugin:1.3 'Description Column Plugin'
  * description-setter:1.10 'Jenkins description setter plugin'
  * downstream-ext:1.8 'Downstream-Ext'
  * doxygen:0.16 'Jenkins Doxygen Plug-in'
  * dumpinfo-buildwrapper-plugin:1.1 'Dump Info BuildWrapper Plugin'
  * eiffel-core:2.0.2 *(update available)* 'eiffel-core'
  * email-ext:2.39 *(update available)* 'Email Extension Plugin'
  * envinject:1.91.1 *(update available)* 'Environment Injector Plugin'
  * extended-choice-parameter:0.38 *(update available)* 'Extended Choice Parameter Plug-In'
  * extended-read-permission:1.0 'Hudson Extended Read Permission Plugin'
  * external-monitor-job:1.4 'External Monitor Job Type Plugin'
  * extra-columns:1.15 'Extra Columns Plugin'
  * file-leak-detector:1.3 *(update available)* 'CloudBees File Leak Detector Plugin'
  * files-found-trigger:1.3.1 'Files Found Trigger'
  * fstrigger:0.39 'Jenkins Filesystem Trigger Plug-in'
  * gerrit-trigger:2.13.0 'Gerrit Trigger'
  * git:2.3.5 'Jenkins GIT plugin'
  * git-client:1.16.1 *(update available)* 'Jenkins GIT client plugin'
  * git-parameter:0.4.0 'Git Parameter Plug-In'
  * git-server:1.6 'Git server plugin'
  * github:1.11.3 *(update available)* 'GitHub plugin'
  * github-api:1.67 *(update available)* 'GitHub API Plugin'
  * gradle:1.24 'Jenkins Gradle plugin'
  * gravatar:2.1 'Jenkins Gravatar plugin'
  * greenballs:1.14 'Green Balls'
  * groovy:1.24 *(update available)* 'Hudson Groovy builder'
  * groovy-postbuild:2.2 'Groovy Postbuild'
  * htmlpublisher:1.3 *(update available)* 'HTML Publisher plugin'
  * ivy:1.24 'Ivy Plugin'
  * javadoc:1.1 'Javadoc Plugin'
  * jira:1.39 *(update available)* 'Jenkins JIRA plugin'
  * job-exporter:0.4 'export dynamic job data'
  * jobConfigHistory:2.10 *(update available)* 'Jenkins Job Configuration History Plugin'
  * jobrevision:0.6 'Job Revision Plugin'
  * jobtype-column:1.3 'Job Type Column'
  * join:1.15 *(update available)* 'Join plugin'
  * jquery:1.7.2-1 *(update available)* 'Jenkins jQuery plugin'
  * junit:1.2-beta-4 *(update available)* 'JUnit Plugin'
  * keepSlaveOffline:1.0 'Unnamed - hudson.plugins.keepSlaveOffline:keepSlaveOffline:hpi:1.0'
  * lastfailureversioncolumn:1.1 'Last Failure Version Column'
  * lastsuccessdescriptioncolumn:1.0 'Last Success Description Column'
  * lastsuccessversioncolumn:1.1 'Last Success Version Column'
  * ldap:1.6 *(update available)* 'LDAP Plugin'
  * locks-and-latches:0.6 'Hudson Locks and Latches plugin'
  * log-parser:1.0.8 'Log Parser Plugin'
  * mailer:1.11 *(update available)* 'Jenkins Mailer Plugin'
  * managed-scripts:1.1.1 *(update available)* 'Managed Scripts'
  * mapdb-api:1.0.6.0 'MapDB API Plugin'
  * mask-passwords:2.7.2 *(update available)* 'Mask Passwords Plugin'
  * matrix-auth:1.1 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.4.1 'Matrix Project Plugin'
  * matrixtieparent:1.2 'Matrix Tie Parent plugin'
  * maven-deployment-linker:1.5.1 'Maven Deployment Linker'
  * maven-plugin:2.7.1 *(update available)* 'Maven Integration plugin'
  * maven-repo-cleaner:1.2 'Maven Repository Scheduled Cleanup Plugin'
  * metrics:3.0.9 *(update available)* 'Metrics Plugin'
  * monitoring:1.55.0 *(update available)* 'Monitoring'
  * multi-slave-config-plugin:1.2.0 'Multi slave config plugin'
  * multiple-scms:0.4 'Jenkins Multiple SCMs plugin'
  * naginator:1.15 'Naginator'
  * nested-view:1.14 'Nested View Plugin'
  * next-build-number:1.1 'Next Build Number Plugin'
  * next-executions:1.0.10 'next-executions'
  * nodelabelparameter:1.5.1 'Node and Label parameter plugin'
  * nodenamecolumn:1.2 'Node Name Column'
  * pam-auth:1.1 *(update available)* 'PAM Authentication plugin'
  * parameterized-trigger:2.26 'Jenkins Parameterized Trigger plugin'
  * pathignore:0.6 'Pathignore Plugin'
  * performance:1.13 'Performance plugin'
  * platformlabeler:1.1 'Hudson platformlabeler plugin'
  * postbuild-task:1.8 'Hudson Post build task'
  * promoted-builds:2.21 'Jenkins promoted builds plugin'
  * publish-over-ftp:1.11 'Publish Over FTP'
  * publish-over-ssh:1.12 *(update available)* 'Publish Over SSH'
  * python:1.2 'Python Plugin'
  * rake:1.8.0 'Jenkins Rake plugin'
  * rebuild:1.24 'Rebuilder'
  * release:2.5.3 'Jenkins Release Plugin'
  * role-strategy:2.2.0 'Role-based Authorization Strategy'
  * ruby-runtime:0.12 'ruby-runtime'
  * rubyMetrics:1.6.3 'RubyMetrics plugin for Jenkins'
  * run-condition:1.0 'Run Condition Plugin'
  * saferestart:0.3 'Safe Restart Plugin'
  * scm-api:0.2 'SCM API Plugin'
  * scoring-load-balancer:1.0.1 'Scoring Load Balancer'
  * script-security:1.13 *(update available)* 'Script Security Plugin'
  * scriptler:2.7 'Scriptler'
  * shared-objects:0.44 'Shared Objects Plugin'
  * shelve-project-plugin:1.5 'Shelve Project Plugin'
  * show-build-parameters:1.0 'Show Build Parameters plugin'
  * simpleclearcase:1.2.2 'Simple Dynamic ClearCase'
  * slave-setup:1.8 *(update available)* 'Jenkins Slave SetupPlugin'
  * sonar:2.2.1 'Jenkins SonarQube Plugin'
  * ssh-agent:1.5 *(update available)* 'SSH Agent Plugin'
  * ssh-credentials:1.10 *(update available)* 'SSH Credentials Plugin'
  * ssh-slaves:1.9 'Jenkins SSH Slaves plugin'
  * subversion:1.54 'Jenkins Subversion Plug-in'
  * support-core:2.20 *(update available)* 'Support Core Plugin'
  * systemloadaverage-monitor:1.2 'Slave Monitor for system load average'
  * testng-plugin:1.10 'TestNG Results Plugin'
  * text-finder:1.10 'Jenkins TextFinder plugin'
  * throttle-concurrents:1.8.4 'Jenkins Throttle Concurrent Builds Plug-in'
  * timestamper:1.6 'Timestamper'
  * token-macro:1.10 'Token Macro Plugin'
  * toolenv:1.1 'Tool Environment plugin'
  * translation:1.10 *(update available)* 'Jenkins Translation Assistance plugin'
  * valgrind:0.24 *(update available)* 'Jenkins Valgrind Plug-in'
  * validating-string-parameter:2.3 'Validating String Parameter Plugin'
  * versioncolumn:0.2 'Jenkins Version Column plugin'
  * violations:0.7.11 'Jenkins Violations plugin'
  * warnings:4.47 *(update available)* 'Warnings Plug-in'
  * windows-slaves:1.0 'Windows Slaves Plugin'
  * ws-cleanup:0.25 'Jenkins Workspace Cleanup Plugin'
  * xunit:1.94 *(update available)* 'xUnit plugin'
  * xvnc:1.21 *(update available)* 'Jenkins Xvnc plugin'
