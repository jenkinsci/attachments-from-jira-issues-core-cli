Item statistics
===============

  * `com.cloudbees.plugins.flow.BuildFlow`
    - Number of items: 4
    - Number of builds per job: 494.0 [n=4, s=600.0]
  * `hudson.maven.MavenModule`
    - Number of items: 2
    - Number of builds per job: 16.5 [n=2, s=20.0]
  * `hudson.maven.MavenModuleSet`
    - Number of items: 2
    - Number of builds per job: 16.5 [n=2, s=20.0]
    - Number of items per container: 1.0 [n=2, s=0.0]
  * `hudson.model.FreeStyleProject`
    - Number of items: 283
    - Number of builds per job: 317.6148409893993 [n=283, s=2500.0]

Total job statistics
======================

  * Number of jobs: 291
  * Number of builds per job: 315.9003436426117 [n=291, s=2500.0]
