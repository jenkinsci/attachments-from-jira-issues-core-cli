Node statistics
===============

  * Total number of nodes
      - Sample size:        97125
      - Average (mean):     29.0
      - Average (median):   29.0
      - Standard deviation: 0.0
      - Minimum:            29
      - Maximum:            29
      - 95th percentile:    29.0
      - 99th percentile:    29.0
  * Total number of nodes online
      - Sample size:        97125
      - Average (mean):     25.785992217898833
      - Average (median):   26.0
      - Standard deviation: 0.4103318626728665
      - Minimum:            25
      - Maximum:            26
      - 95th percentile:    26.0
      - 99th percentile:    26.0
  * Total number of executors
      - Sample size:        97125
      - Average (mean):     175.92996108949416
      - Average (median):   177.0
      - Standard deviation: 2.0516593133642766
      - Minimum:            172
      - Maximum:            177
      - 95th percentile:    177.0
      - 99th percentile:    177.0
  * Total number of executors in use
      - Sample size:        97125
      - Average (mean):     57.311284046692606
      - Average (median):   57.0
      - Standard deviation: 3.7593621018611314
      - Minimum:            45
      - Maximum:            68
      - 95th percentile:    63.0
      - 99th percentile:    65.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      0
      - FS root:        `/project/jenkins/prod/eis-jenkins-ip-os/jenkins_home`
      - Labels:         ForMaster
      - Usage:          `EXCLUSIVE`
      - Java
          + Home:           `/project/jenkins/tool_share/jdk/jdk1.7.0_25/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_25
          + Maximum memory:   9.81 GB (10531438592)
          + Allocated memory: 9.81 GB (10531438592)
          + Free memory:      6.06 GB (6510482088)
          + In-use memory:    3.74 GB (4020956504)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 23.25-b01
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-358.18.1.el6.x86_64
          + Distribution: "Red Hat Enterprise Linux Server release 6.4 (Santiago)"
          + LSB Modules:  `:base-4.0-amd64:base-4.0-noarch:core-4.0-amd64:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-noarch`
      - Process ID: 6568 (0x19a8)
      - Process started: 2015-07-18 10:28:48.884-0700
      - Process uptime: 16 days
      - JVM startup parameters:
          + Boot classpath: `/project/jenkins/tool_share/jdk/jdk1.7.0_25/jre/lib/resources.jar:/project/jenkins/tool_share/jdk/jdk1.7.0_25/jre/lib/rt.jar:/project/jenkins/tool_share/jdk/jdk1.7.0_25/jre/lib/sunrsasign.jar:/project/jenkins/tool_share/jdk/jdk1.7.0_25/jre/lib/jsse.jar:/project/jenkins/tool_share/jdk/jdk1.7.0_25/jre/lib/jce.jar:/project/jenkins/tool_share/jdk/jdk1.7.0_25/jre/lib/charsets.jar:/project/jenkins/tool_share/jdk/jdk1.7.0_25/jre/lib/jfr.jar:/project/jenkins/tool_share/jdk/jdk1.7.0_25/jre/classes`
          + Classpath: `/project/jenkins/tool_share/apache-tomcat/apache-tomcat-7.0.59/bin/bootstrap.jar:/project/jenkins/tool_share/apache-tomcat/apache-tomcat-7.0.59/bin/tomcat-juli.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Djava.util.logging.config.file=/project/jenkins/prod/eis-jenkins-ip-os/apache-tomcat/conf/logging.properties`
          + arg[1]: `-Djava.util.logging.manager=org.apache.juli.ClassLoaderLogManager`
          + arg[2]: `-DHTTPPORT=8080`
          + arg[3]: `-DWEBAPP=/project/jenkins/prod/eis-jenkins-ip-os/conf/jenkins-1.596.2-lts.war`
          + arg[4]: `-DWEBDOCDIR=/project/jenkins/prod/eis-jenkins-ip-os/apache-tomcat/root`
          + arg[5]: `-DWEBLOGDIR=/project/jenkins/prod/eis-jenkins-ip-os/apache-tomcat`
          + arg[6]: `-XX:+HeapDumpOnOutOfMemoryError`
          + arg[7]: `-XX:HeapDumpPath=/project/jenkins/prod/eis-jenkins-ip-os/2015-07-09_21:21:36_onOutOfMemory.hprof`
          + arg[8]: `-Xms10g`
          + arg[9]: `-Xmx10g`
          + arg[10]: `-XX:PermSize=256m`
          + arg[11]: `-XX:MaxPermSize=512m`
          + arg[12]: `-XX:+PrintGCDetails`
          + arg[13]: `-XX:+PrintGCDateStamps`
          + arg[14]: `-Dhudson.TcpSlaveAgentListener.hostName=eussjvlx2102.sj.us.am.ericsson.se`
          + arg[15]: `-Dfile.encoding=UTF-8`
          + arg[16]: `-Dhudson.plugins.active_directory.ActiveDirectorySecurityRealm.forceLdaps=true`
          + arg[17]: `-Dcom.sun.management.jmxremote`
          + arg[18]: `-Dcom.sun.management.jmxremote.port=8084`
          + arg[19]: `-Dcom.sun.management.jmxremote.authenticate=false`
          + arg[20]: `-Dcom.sun.management.jmxremote.ssl=false`
          + arg[21]: `-Xdebug`
          + arg[22]: `-agentlib:jdwp=transport=dt_socket,server=y,suspend=n,address=127.0.0.1:8085`
          + arg[23]: `-Djava.endorsed.dirs=/project/jenkins/tool_share/apache-tomcat/apache-tomcat-7.0.59/endorsed`
          + arg[24]: `-Dcatalina.base=/project/jenkins/prod/eis-jenkins-ip-os/apache-tomcat`
          + arg[25]: `-Dcatalina.home=/project/jenkins/tool_share/apache-tomcat/apache-tomcat-7.0.59`
          + arg[26]: `-Djava.io.tmpdir=/project/jenkins/prod/eis-jenkins-ip-os/apache-tomcat/temp`

  * ipswops-gm04 (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      5
      - Remote FS root: `/scratch/5/sysbuild/eis-jenkins-ip-os/ipswops-gm04`
      - Labels:         RHEL5 ipswops-gmake
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.49
      - Java
          + Home:           `/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre`
          + Vendor:           Sun Microsystems Inc.
          + Version:          1.6.0_30
          + Maximum memory:   1.97 GB (2111700992)
          + Allocated memory: 1.97 GB (2111700992)
          + Free memory:      1.64 GB (1758621288)
          + In-use memory:    336.72 MB (353079704)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.6
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.0
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Sun Microsystems Inc.
          + Version: 20.5-b03
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.18-274.3.1.el5
          + Distribution: "Red Hat Enterprise Linux Server release 5.7 (Tikanga)"
          + LSB Modules:  `:core-4.0-amd64:core-4.0-ia32:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-ia32:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-ia32:printing-4.0-noarch`
      - Process ID: 6004 (0x1774)
      - Process started: 2015-07-18 10:29:57.813-0700
      - Process uptime: 16 days
      - JVM startup parameters:
          + Boot classpath: `/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/resources.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/rt.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/sunrsasign.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/jsse.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/jce.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/charsets.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/modules/jdk.boot.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/amd64/server:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/amd64:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/../lib/amd64:/usr/lib:/usr/ast54/lib:/tools/swdev/lib/compat:/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Xmx2024m`
          + arg[1]: `-Xms2024m`
          + arg[2]: `-XX:MaxPermSize=512m`

  * ipswops-xen203 (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      5
      - Remote FS root: `/scratch/swbuild5/sysbuild/jenkins/ipswops-xen203`
      - Labels:         LMWP3
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * ipswops-lx3128 (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      5
      - Remote FS root: `/project/swbuild5/sysbuild/jenkins/ipswops-lx3128`
      - Labels:         SUSE LMWP3
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.SimpleScheduledRetentionStrategy`
      - Status:         on-line
      - Version:        2.49
      - Java
          + Home:           `/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre`
          + Vendor:           Sun Microsystems Inc.
          + Version:          1.6.0_30
          + Maximum memory:   1.89 GB (2033909760)
          + Allocated memory: 1.89 GB (2033909760)
          + Free memory:      1.63 GB (1747394040)
          + In-use memory:    273.24 MB (286515720)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.6
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.0
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Sun Microsystems Inc.
          + Version: 20.5-b03
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.0.13-0.27-default
          + Distribution: "SUSE Linux Enterprise Server 11 (x86_64)"
          + LSB Modules:  `core-2.0-noarch:core-3.2-noarch:core-4.0-noarch:core-2.0-x86_64:core-3.2-x86_64:core-4.0-x86_64:desktop-4.0-amd64:desktop-4.0-noarch:graphics-2.0-amd64:graphics-2.0-noarch:graphics-3.2-amd64:graphics-3.2-noarch:graphics-4.0-amd64:graphics-4.0-noarch`
      - Process ID: 45789 (0xb2dd)
      - Process started: 2015-08-04 05:17:42.882-0700
      - Process uptime: 53 min
      - JVM startup parameters:
          + Boot classpath: `/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/resources.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/rt.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/sunrsasign.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/jsse.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/jce.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/charsets.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/modules/jdk.boot.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/amd64/server:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/amd64:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/../lib/amd64:/usr/lib:/usr/ast54/lib:/tools/swdev/lib/compat:/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Xmx2024m`
          + arg[1]: `-Xms2024m`
          + arg[2]: `-XX:MaxPermSize=512m`

  * ipswops-gm03 (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      5
      - Remote FS root: `/scratch/5/sysbuild/eis-jenkins-managed/ipswops-gm03`
      - Labels:         RHEL5 ipswops-gmake
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.49
      - Java
          + Home:           `/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre`
          + Vendor:           Sun Microsystems Inc.
          + Version:          1.6.0_30
          + Maximum memory:   1.97 GB (2110455808)
          + Allocated memory: 1.97 GB (2110455808)
          + Free memory:      1.82 GB (1958614616)
          + In-use memory:    144.81 MB (151841192)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.6
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.0
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Sun Microsystems Inc.
          + Version: 20.5-b03
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.18-274.3.1.el5
          + Distribution: "Red Hat Enterprise Linux Server release 5.7 (Tikanga)"
          + LSB Modules:  `:core-4.0-amd64:core-4.0-ia32:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-ia32:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-ia32:printing-4.0-noarch`
      - Process ID: 6165 (0x1815)
      - Process started: 2015-07-18 10:29:58.020-0700
      - Process uptime: 16 days
      - JVM startup parameters:
          + Boot classpath: `/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/resources.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/rt.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/sunrsasign.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/jsse.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/jce.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/charsets.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/modules/jdk.boot.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/amd64/server:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/amd64:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/../lib/amd64:/usr/lib:/usr/ast54/lib:/tools/swdev/lib/compat:/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Xmx2024m`
          + arg[1]: `-Xms2024m`
          + arg[2]: `-XX:MaxPermSize=512m`

  * ipswops-gmake02 (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      7
      - Remote FS root: `/scratch/5/sysbuild/eis-jenkins-managed/ipswops-gmake02`
      - Labels:         RHEL5 ipswops-gmake
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.49
      - Java
          + Home:           `/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre`
          + Vendor:           Sun Microsystems Inc.
          + Version:          1.6.0_30
          + Maximum memory:   1.95 GB (2091581440)
          + Allocated memory: 1.95 GB (2091581440)
          + Free memory:      1.30 GB (1396346752)
          + In-use memory:    663.03 MB (695234688)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.6
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.0
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Sun Microsystems Inc.
          + Version: 20.5-b03
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.18-274.3.1.el5
          + Distribution: "Red Hat Enterprise Linux Server release 5.7 (Tikanga)"
          + LSB Modules:  `:core-4.0-amd64:core-4.0-ia32:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-ia32:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-ia32:printing-4.0-noarch`
      - Process ID: 24608 (0x6020)
      - Process started: 2015-07-18 10:29:58.472-0700
      - Process uptime: 16 days
      - JVM startup parameters:
          + Boot classpath: `/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/resources.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/rt.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/sunrsasign.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/jsse.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/jce.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/charsets.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/modules/jdk.boot.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/amd64/server:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/amd64:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/../lib/amd64:/usr/lib:/usr/ast54/lib:/tools/swdev/lib/compat:/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Xmx2024m`
          + arg[1]: `-Xms2024m`
          + arg[2]: `-XX:MaxPermSize=512m`

  * ipswops-gm01-eforge (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      5
      - Remote FS root: `/scratch/5/sysbuild/eis-jenkins-managed/ipswops-gm01-eforge`
      - Labels:         RHEL5
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.49
      - Java
          + Home:           `/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre`
          + Vendor:           Sun Microsystems Inc.
          + Version:          1.6.0_30
          + Maximum memory:   1.97 GB (2110849024)
          + Allocated memory: 1.97 GB (2110849024)
          + Free memory:      1.75 GB (1879738912)
          + In-use memory:    220.40 MB (231110112)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.6
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.0
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Sun Microsystems Inc.
          + Version: 20.5-b03
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.18-274.3.1.el5
          + Distribution: "Red Hat Enterprise Linux Server release 5.7 (Tikanga)"
          + LSB Modules:  `:core-4.0-amd64:core-4.0-ia32:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-ia32:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-ia32:printing-4.0-noarch`
      - Process ID: 15926 (0x3e36)
      - Process started: 2015-07-19 15:08:46.314-0700
      - Process uptime: 15 days
      - JVM startup parameters:
          + Boot classpath: `/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/resources.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/rt.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/sunrsasign.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/jsse.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/jce.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/charsets.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/modules/jdk.boot.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/amd64/server:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/amd64:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/../lib/amd64:/usr/lib:/usr/ast54/lib:/tools/swdev/lib/compat:/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Xmx2024m`
          + arg[1]: `-Xms2024m`
          + arg[2]: `-XX:MaxPermSize=512m`

  * ipswops-gm01 (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      5
      - Remote FS root: `/scratch/5/sysbuild/eis-jenkins-ip-os/ipswops-gm01`
      - Labels:         RHEL5 ipswops-gmake
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.49
      - Java
          + Home:           `/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre`
          + Vendor:           Sun Microsystems Inc.
          + Version:          1.6.0_30
          + Maximum memory:   1.97 GB (2110652416)
          + Allocated memory: 1.97 GB (2110652416)
          + Free memory:      1.61 GB (1732993856)
          + In-use memory:    360.16 MB (377658560)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.6
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.0
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Sun Microsystems Inc.
          + Version: 20.5-b03
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.18-274.3.1.el5
          + Distribution: "Red Hat Enterprise Linux Server release 5.7 (Tikanga)"
          + LSB Modules:  `:core-4.0-amd64:core-4.0-ia32:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-ia32:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-ia32:printing-4.0-noarch`
      - Process ID: 17877 (0x45d5)
      - Process started: 2015-07-18 10:29:58.920-0700
      - Process uptime: 16 days
      - JVM startup parameters:
          + Boot classpath: `/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/resources.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/rt.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/sunrsasign.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/jsse.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/jce.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/charsets.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/modules/jdk.boot.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/amd64/server:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/amd64:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/../lib/amd64:/usr/lib:/usr/ast54/lib:/tools/swdev/lib/compat:/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Xmx2024m`
          + arg[1]: `-Xms2024m`
          + arg[2]: `-XX:MaxPermSize=512m`

  * itte-eussjvlx1304 (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      2
      - Remote FS root: `/home/jnkutil/slaves/eis-jenkins-ip-os.sj/itte-eussjvlx1304`
      - Labels:         RHEL6
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.49
      - Java
          + Home:           `/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.75.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_75
          + Maximum memory:   1.96 GB (2109210624)
          + Allocated memory: 1.96 GB (2109210624)
          + Free memory:      1.52 GB (1627249400)
          + In-use memory:    459.63 MB (481961224)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.75-b04
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-358.23.2.el6.x86_64
          + Distribution: "Red Hat Enterprise Linux Server release 6.4 (Santiago)"
          + LSB Modules:  `:base-4.0-amd64:base-4.0-noarch:core-4.0-amd64:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-noarch`
      - Process ID: 3419 (0xd5b)
      - Process started: 2015-07-18 10:29:57.639-0700
      - Process uptime: 16 days
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.75.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.75.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.75.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.75.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.75.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.75.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.75.x86_64/jre/lib/rhino.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.75.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.75.x86_64/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Xmx2024m`
          + arg[1]: `-Xms2024m`
          + arg[2]: `-XX:MaxPermSize=512m`

  * ipswops-gm01-jvm (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      5
      - Remote FS root: `/scratch/5/sysbuild/eis-jenkins-ip-os/ipswops-gm01`
      - Labels:         RHEL5 ipswops-gmake
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.49
      - Java
          + Home:           `/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre`
          + Vendor:           Sun Microsystems Inc.
          + Version:          1.6.0_30
          + Maximum memory:   1.97 GB (2111504384)
          + Allocated memory: 1.97 GB (2111504384)
          + Free memory:      1.78 GB (1916108376)
          + In-use memory:    186.34 MB (195396008)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.6
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.0
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Sun Microsystems Inc.
          + Version: 20.5-b03
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.18-274.3.1.el5
          + Distribution: "Red Hat Enterprise Linux Server release 5.7 (Tikanga)"
          + LSB Modules:  `:core-4.0-amd64:core-4.0-ia32:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-ia32:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-ia32:printing-4.0-noarch`
      - Process ID: 17891 (0x45e3)
      - Process started: 2015-07-18 10:29:58.965-0700
      - Process uptime: 16 days
      - JVM startup parameters:
          + Boot classpath: `/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/resources.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/rt.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/sunrsasign.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/jsse.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/jce.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/charsets.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/modules/jdk.boot.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/amd64/server:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/amd64:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/../lib/amd64:/usr/lib:/usr/ast54/lib:/tools/swdev/lib/compat:/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Xmx2024m`
          + arg[1]: `-Xms2024m`
          + arg[2]: `-XX:MaxPermSize=512m`

  * emahdil-ipswops-gm01-eforge (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      5
      - Remote FS root: `/scratch/5/sysbuild/eis-jenkins-ip-os/emahdil-ipswops-gm01-eforge`
      - Labels:         RHEL5
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * gmake02-nonsysbuild (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      5
      - Remote FS root: `/scratch/5/sysbuild/eis-jenkins-managed/ipswops-gmake02`
      - Labels:         RHEL5 ipswops-gmake
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.49
      - Java
          + Home:           `/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre`
          + Vendor:           Sun Microsystems Inc.
          + Version:          1.6.0_30
          + Maximum memory:   1.96 GB (2105475072)
          + Allocated memory: 1.96 GB (2105475072)
          + Free memory:      1.41 GB (1517014200)
          + In-use memory:    561.20 MB (588460872)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.6
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.0
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Sun Microsystems Inc.
          + Version: 20.5-b03
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.18-274.3.1.el5
          + Distribution: "Red Hat Enterprise Linux Server release 5.7 (Tikanga)"
          + LSB Modules:  `:core-4.0-amd64:core-4.0-ia32:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-ia32:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-ia32:printing-4.0-noarch`
      - Process ID: 27580 (0x6bbc)
      - Process started: 2015-07-18 10:30:40.986-0700
      - Process uptime: 16 days
      - JVM startup parameters:
          + Boot classpath: `/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/resources.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/rt.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/sunrsasign.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/jsse.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/jce.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/charsets.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/modules/jdk.boot.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/amd64/server:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/amd64:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/../lib/amd64:/usr/lib:/usr/ast54/lib:/tools/swdev/lib/compat:/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Xmx2024m`
          + arg[1]: `-Xms2024m`
          + arg[2]: `-XX:MaxPermSize=512m`

  * ipswops-gm02-authcheck (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      5
      - Remote FS root: `/scratch/98/iposretest`
      - Labels:         RHEL5
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.49
      - Java
          + Home:           `/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre`
          + Vendor:           Sun Microsystems Inc.
          + Version:          1.6.0_30
          + Maximum memory:   1.97 GB (2110980096)
          + Allocated memory: 1.97 GB (2110980096)
          + Free memory:      1.72 GB (1842810656)
          + In-use memory:    255.75 MB (268169440)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.6
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.0
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Sun Microsystems Inc.
          + Version: 20.5-b03
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.18-274.3.1.el5
          + Distribution: "Red Hat Enterprise Linux Server release 5.7 (Tikanga)"
          + LSB Modules:  `:core-4.0-amd64:core-4.0-ia32:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-ia32:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-ia32:printing-4.0-noarch`
      - Process ID: 24678 (0x6066)
      - Process started: 2015-07-18 10:29:58.823-0700
      - Process uptime: 16 days
      - JVM startup parameters:
          + Boot classpath: `/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/resources.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/rt.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/sunrsasign.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/jsse.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/jce.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/charsets.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/modules/jdk.boot.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/amd64/server:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/amd64:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/../lib/amd64:/app/openmotif/2.3.1/lib:/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Xmx2024m`
          + arg[1]: `-Xms2024m`
          + arg[2]: `-XX:MaxPermSize=512m`

  * iposbuild-gitts-eussjlx9042 (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      9
      - Remote FS root: `/workspace/git/iposbuild/jenkins-ws`
      - Labels:         IPOS_BUILD
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.49
      - Java
          + Home:           `/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre`
          + Vendor:           Sun Microsystems Inc.
          + Version:          1.6.0_30
          + Maximum memory:   1.95 GB (2090991616)
          + Allocated memory: 1.95 GB (2090991616)
          + Free memory:      759.12 MB (795994408)
          + In-use memory:    1.21 GB (1294997208)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.6
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.0
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Sun Microsystems Inc.
          + Version: 20.5-b03
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-358.6.2.el6.x86_64
          + Distribution: "Red Hat Enterprise Linux Server release 6.4 (Santiago)"
          + LSB Modules:  `:base-4.0-amd64:base-4.0-ia32:base-4.0-noarch:core-4.0-amd64:core-4.0-ia32:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-ia32:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-ia32:printing-4.0-noarch`
      - Process ID: 383585 (0x5da61)
      - Process started: 2015-07-18 10:29:58.428-0700
      - Process uptime: 16 days
      - JVM startup parameters:
          + Boot classpath: `/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/resources.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/rt.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/sunrsasign.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/jsse.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/jce.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/charsets.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/modules/jdk.boot.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/amd64/server:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/amd64:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/../lib/amd64:/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Xmx2024m`
          + arg[1]: `-Xms2024m`
          + arg[2]: `-XX:MaxPermSize=512m`

  * ipush-gitts-eussjlx9043 (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      12
      - Remote FS root: `/workspace/git/iposretest/jenkins_workspace`
      - Labels:         ipush IPUSH_BUILD_FLOW IPUSH_TEST
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.49
      - Java
          + Home:           `/afs/sunrise.ericsson.se/us/app/jdk/.sys/@sys/1.7.0_25/LMWP3/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_25
          + Maximum memory:   1.96 GB (2103377920)
          + Allocated memory: 1.96 GB (2103377920)
          + Free memory:      1.70 GB (1829867184)
          + In-use memory:    260.84 MB (273510736)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 23.25-b01
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-358.6.2.el6.x86_64
          + Distribution: "Red Hat Enterprise Linux Server release 6.4 (Santiago)"
          + LSB Modules:  `:base-4.0-amd64:base-4.0-ia32:base-4.0-noarch:core-4.0-amd64:core-4.0-ia32:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-ia32:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-ia32:printing-4.0-noarch`
      - Process ID: 546832 (0x85810)
      - Process started: 2015-07-18 10:29:58.302-0700
      - Process uptime: 16 days
      - JVM startup parameters:
          + Boot classpath: `/afs/sunrise.ericsson.se/us/app/jdk/.sys/@sys/1.7.0_25/LMWP3/jre/lib/resources.jar:/afs/sunrise.ericsson.se/us/app/jdk/.sys/@sys/1.7.0_25/LMWP3/jre/lib/rt.jar:/afs/sunrise.ericsson.se/us/app/jdk/.sys/@sys/1.7.0_25/LMWP3/jre/lib/sunrsasign.jar:/afs/sunrise.ericsson.se/us/app/jdk/.sys/@sys/1.7.0_25/LMWP3/jre/lib/jsse.jar:/afs/sunrise.ericsson.se/us/app/jdk/.sys/@sys/1.7.0_25/LMWP3/jre/lib/jce.jar:/afs/sunrise.ericsson.se/us/app/jdk/.sys/@sys/1.7.0_25/LMWP3/jre/lib/charsets.jar:/afs/sunrise.ericsson.se/us/app/jdk/.sys/@sys/1.7.0_25/LMWP3/jre/lib/jfr.jar:/afs/sunrise.ericsson.se/us/app/jdk/.sys/@sys/1.7.0_25/LMWP3/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Xmx2024m`
          + arg[1]: `-Xms2024m`
          + arg[2]: `-XX:MaxPermSize=512m`

  * lxapp-1 (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      5
      - Remote FS root: `/project/swbuild-1/sysbuild`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.49
      - Java
          + Home:           `/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre`
          + Vendor:           Sun Microsystems Inc.
          + Version:          1.6.0_30
          + Maximum memory:   1.95 GB (2089549824)
          + Allocated memory: 1.95 GB (2089549824)
          + Free memory:      1.80 GB (1934498928)
          + In-use memory:    147.87 MB (155050896)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.6
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.0
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Sun Microsystems Inc.
          + Version: 20.5-b03
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.18-92.el5
      - Process ID: 798 (0x31e)
      - Process started: 2015-07-18 10:30:40.853-0700
      - Process uptime: 16 days
      - JVM startup parameters:
          + Boot classpath: `/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/resources.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/rt.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/sunrsasign.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/jsse.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/jce.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/charsets.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/modules/jdk.boot.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/amd64/server:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/amd64:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/../lib/amd64:/usr/lib:/usr/ast54/lib:/tools/swdev/lib/compat:/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Xmx2024m`
          + arg[1]: `-Xms2024m`
          + arg[2]: `-XX:MaxPermSize=512m`

  * rbos-pc-10 (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      2
      - Remote FS root: `/project/swbuild-1/sysbuild`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        N/A
      - Java
          + Home:           `/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre`
          + Vendor:           Sun Microsystems Inc.
          + Version:          1.6.0_30
          + Maximum memory:   1.97 GB (2114125824)
          + Allocated memory: 1.97 GB (2114125824)
          + Free memory:      1.66 GB (1786643656)
          + In-use memory:    312.31 MB (327482168)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.6
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.0
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Sun Microsystems Inc.
          + Version: 20.5-b03
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.35-32-server
          + Distribution: Ubuntu 10.10
      - Process ID: 1953 (0x7a1)
      - Process started: 2015-07-18 10:29:57.476-0700
      - Process uptime: 16 days
      - JVM startup parameters:
          + Boot classpath: `/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/resources.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/rt.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/sunrsasign.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/jsse.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/jce.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/charsets.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/modules/jdk.boot.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/amd64/server:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/amd64:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/../lib/amd64:/usr/lib:/usr/ast54/lib:/tools/swdev/lib/compat:/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Xmx2024m`
          + arg[1]: `-Xms2024m`
          + arg[2]: `-XX:MaxPermSize=512m`

  * iposbuild-gmake02 (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      5
      - Remote FS root: `/scratch/98/iposbuild/jenkins-ws`
      - Labels:         (none)
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.49
      - Java
          + Home:           `/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre`
          + Vendor:           Sun Microsystems Inc.
          + Version:          1.6.0_30
          + Maximum memory:   1.97 GB (2111504384)
          + Allocated memory: 1.97 GB (2111504384)
          + Free memory:      1.79 GB (1925626896)
          + In-use memory:    177.27 MB (185877488)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.6
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.0
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Sun Microsystems Inc.
          + Version: 20.5-b03
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.18-274.3.1.el5
          + Distribution: "Red Hat Enterprise Linux Server release 5.7 (Tikanga)"
          + LSB Modules:  `:core-4.0-amd64:core-4.0-ia32:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-ia32:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-ia32:printing-4.0-noarch`
      - Process ID: 24750 (0x60ae)
      - Process started: 2015-07-18 10:29:59.212-0700
      - Process uptime: 16 days
      - JVM startup parameters:
          + Boot classpath: `/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/resources.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/rt.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/sunrsasign.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/jsse.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/jce.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/charsets.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/modules/jdk.boot.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/amd64/server:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/amd64:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/../lib/amd64:/app/openmotif/2.3.1/lib:/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Xmx2024m`
          + arg[1]: `-Xms2024m`
          + arg[2]: `-XX:MaxPermSize=512m`

  * iposretest-gitts-eussjlx9042 (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      5
      - Remote FS root: `/workspace/git/iposbuild/jenkins-ws-iposretest`
      - Labels:         (none)
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.49
      - Java
          + Home:           `/afs/sunrise.ericsson.se/us/app/jdk/.sys/@sys/1.7.0_25/LMWP3/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_25
          + Maximum memory:   1.97 GB (2114715648)
          + Allocated memory: 1.97 GB (2114715648)
          + Free memory:      1.49 GB (1600449600)
          + In-use memory:    490.44 MB (514266048)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 23.25-b01
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-358.6.2.el6.x86_64
          + Distribution: "Red Hat Enterprise Linux Server release 6.4 (Santiago)"
          + LSB Modules:  `:base-4.0-amd64:base-4.0-ia32:base-4.0-noarch:core-4.0-amd64:core-4.0-ia32:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-ia32:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-ia32:printing-4.0-noarch`
      - Process ID: 383623 (0x5da87)
      - Process started: 2015-07-18 10:29:59.034-0700
      - Process uptime: 16 days
      - JVM startup parameters:
          + Boot classpath: `/afs/sunrise.ericsson.se/us/app/jdk/.sys/@sys/1.7.0_25/LMWP3/jre/lib/resources.jar:/afs/sunrise.ericsson.se/us/app/jdk/.sys/@sys/1.7.0_25/LMWP3/jre/lib/rt.jar:/afs/sunrise.ericsson.se/us/app/jdk/.sys/@sys/1.7.0_25/LMWP3/jre/lib/sunrsasign.jar:/afs/sunrise.ericsson.se/us/app/jdk/.sys/@sys/1.7.0_25/LMWP3/jre/lib/jsse.jar:/afs/sunrise.ericsson.se/us/app/jdk/.sys/@sys/1.7.0_25/LMWP3/jre/lib/jce.jar:/afs/sunrise.ericsson.se/us/app/jdk/.sys/@sys/1.7.0_25/LMWP3/jre/lib/charsets.jar:/afs/sunrise.ericsson.se/us/app/jdk/.sys/@sys/1.7.0_25/LMWP3/jre/lib/jfr.jar:/afs/sunrise.ericsson.se/us/app/jdk/.sys/@sys/1.7.0_25/LMWP3/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Xmx2024m`
          + arg[1]: `-Xms2024m`
          + arg[2]: `-XX:MaxPermSize=512m`

  * rndopsblr (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      5
      - Remote FS root: `/workspace/git/eprases/iposbuild/jenkins-ws`
      - Labels:         (none)
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.49
      - Java
          + Home:           `/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre`
          + Vendor:           Sun Microsystems Inc.
          + Version:          1.6.0_30
          + Maximum memory:   1.96 GB (2106064896)
          + Allocated memory: 1.96 GB (2106064896)
          + Free memory:      1.93 GB (2067608432)
          + In-use memory:    36.67 MB (38456464)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.6
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.0
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Sun Microsystems Inc.
          + Version: 20.5-b03
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-358.6.2.el6.x86_64
          + Distribution: "Red Hat Enterprise Linux Server release 6.4 (Santiago)"
          + LSB Modules:  `:base-4.0-amd64:base-4.0-ia32:base-4.0-noarch:core-4.0-amd64:core-4.0-ia32:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-ia32:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-ia32:printing-4.0-noarch`
      - Process ID: 739657 (0xb4949)
      - Process started: 2015-08-03 01:50:42.524-0700
      - Process uptime: 1 day 5 hr
      - JVM startup parameters:
          + Boot classpath: `/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/resources.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/rt.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/sunrsasign.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/jsse.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/jce.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/charsets.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/modules/jdk.boot.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/amd64/server:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/amd64:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/../lib/amd64:/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Xmx2024m`
          + arg[1]: `-Xms2024m`
          + arg[2]: `-XX:MaxPermSize=512m`

  * iposretest-ipush-eussjblx1033 (`hudson.slaves.DumbSlave`)
      - Description:    _server dedicated to support ipush work flow_
      - Executors:      15
      - Remote FS root: `/workspace/git/iposretest/jenkins_ws`
      - Labels:         IPUSH
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.49
      - Java
          + Home:           `/afs/sunrise.ericsson.se/us/app/jdk/.sys/@sys/1.7.0_25/LMWP3/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_25
          + Maximum memory:   1.97 GB (2117337088)
          + Allocated memory: 1.97 GB (2117337088)
          + Free memory:      1.48 GB (1592586544)
          + In-use memory:    500.44 MB (524750544)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 23.25-b01
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-358.el6.x86_64
          + Distribution: "Red Hat Enterprise Linux Server release 6.4 (Santiago)"
          + LSB Modules:  `:base-4.0-amd64:base-4.0-ia32:base-4.0-noarch:core-4.0-amd64:core-4.0-ia32:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-ia32:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-ia32:printing-4.0-noarch`
      - Process ID: 740809 (0xb4dc9)
      - Process started: 2015-07-18 10:29:57.873-0700
      - Process uptime: 16 days
      - JVM startup parameters:
          + Boot classpath: `/afs/sunrise.ericsson.se/us/app/jdk/.sys/@sys/1.7.0_25/LMWP3/jre/lib/resources.jar:/afs/sunrise.ericsson.se/us/app/jdk/.sys/@sys/1.7.0_25/LMWP3/jre/lib/rt.jar:/afs/sunrise.ericsson.se/us/app/jdk/.sys/@sys/1.7.0_25/LMWP3/jre/lib/sunrsasign.jar:/afs/sunrise.ericsson.se/us/app/jdk/.sys/@sys/1.7.0_25/LMWP3/jre/lib/jsse.jar:/afs/sunrise.ericsson.se/us/app/jdk/.sys/@sys/1.7.0_25/LMWP3/jre/lib/jce.jar:/afs/sunrise.ericsson.se/us/app/jdk/.sys/@sys/1.7.0_25/LMWP3/jre/lib/charsets.jar:/afs/sunrise.ericsson.se/us/app/jdk/.sys/@sys/1.7.0_25/LMWP3/jre/lib/jfr.jar:/afs/sunrise.ericsson.se/us/app/jdk/.sys/@sys/1.7.0_25/LMWP3/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Xmx2024m`
          + arg[1]: `-Xms2024m`
          + arg[2]: `-XX:MaxPermSize=512m`

  * iposretest-ipush-eussjblx1034 (`hudson.slaves.DumbSlave`)
      - Description:    _server dedicated to support ipush work flow_
      - Executors:      15
      - Remote FS root: `/workspace/git/iposretest/jenkins_ws`
      - Labels:         IPUSH
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.49
      - Java
          + Home:           `/afs/sunrise.ericsson.se/us/app/jdk/.sys/@sys/1.7.0_25/LMWP3/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_25
          + Maximum memory:   1.97 GB (2113536000)
          + Allocated memory: 1.97 GB (2113536000)
          + Free memory:      1.53 GB (1637705408)
          + In-use memory:    453.79 MB (475830592)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 23.25-b01
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-358.el6.x86_64
          + Distribution: "Red Hat Enterprise Linux Server release 6.4 (Santiago)"
          + LSB Modules:  `:base-4.0-amd64:base-4.0-ia32:base-4.0-noarch:core-4.0-amd64:core-4.0-ia32:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-ia32:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-ia32:printing-4.0-noarch`
      - Process ID: 348475 (0x5513b)
      - Process started: 2015-07-18 10:29:57.482-0700
      - Process uptime: 16 days
      - JVM startup parameters:
          + Boot classpath: `/afs/sunrise.ericsson.se/us/app/jdk/.sys/@sys/1.7.0_25/LMWP3/jre/lib/resources.jar:/afs/sunrise.ericsson.se/us/app/jdk/.sys/@sys/1.7.0_25/LMWP3/jre/lib/rt.jar:/afs/sunrise.ericsson.se/us/app/jdk/.sys/@sys/1.7.0_25/LMWP3/jre/lib/sunrsasign.jar:/afs/sunrise.ericsson.se/us/app/jdk/.sys/@sys/1.7.0_25/LMWP3/jre/lib/jsse.jar:/afs/sunrise.ericsson.se/us/app/jdk/.sys/@sys/1.7.0_25/LMWP3/jre/lib/jce.jar:/afs/sunrise.ericsson.se/us/app/jdk/.sys/@sys/1.7.0_25/LMWP3/jre/lib/charsets.jar:/afs/sunrise.ericsson.se/us/app/jdk/.sys/@sys/1.7.0_25/LMWP3/jre/lib/jfr.jar:/afs/sunrise.ericsson.se/us/app/jdk/.sys/@sys/1.7.0_25/LMWP3/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Xmx2024m`
          + arg[1]: `-Xms2024m`
          + arg[2]: `-XX:MaxPermSize=512m`

  * iposretest-ipush-eussjblx1035 (`hudson.slaves.DumbSlave`)
      - Description:    _server dedicated to support ipush work flow_
      - Executors:      15
      - Remote FS root: `/workspace/git/iposretest/jenkins_ws`
      - Labels:         IPUSH
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.49
      - Java
          + Home:           `/afs/sunrise.ericsson.se/us/app/jdk/.sys/@sys/1.7.0_25/LMWP3/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_25
          + Maximum memory:   1.97 GB (2118582272)
          + Allocated memory: 1.97 GB (2118582272)
          + Free memory:      1.14 GB (1224282032)
          + In-use memory:    852.87 MB (894300240)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 23.25-b01
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-358.el6.x86_64
          + Distribution: "Red Hat Enterprise Linux Server release 6.4 (Santiago)"
          + LSB Modules:  `:base-4.0-amd64:base-4.0-ia32:base-4.0-noarch:core-4.0-amd64:core-4.0-ia32:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-ia32:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-ia32:printing-4.0-noarch`
      - Process ID: 97459 (0x17cb3)
      - Process started: 2015-07-18 10:29:58.014-0700
      - Process uptime: 16 days
      - JVM startup parameters:
          + Boot classpath: `/afs/sunrise.ericsson.se/us/app/jdk/.sys/@sys/1.7.0_25/LMWP3/jre/lib/resources.jar:/afs/sunrise.ericsson.se/us/app/jdk/.sys/@sys/1.7.0_25/LMWP3/jre/lib/rt.jar:/afs/sunrise.ericsson.se/us/app/jdk/.sys/@sys/1.7.0_25/LMWP3/jre/lib/sunrsasign.jar:/afs/sunrise.ericsson.se/us/app/jdk/.sys/@sys/1.7.0_25/LMWP3/jre/lib/jsse.jar:/afs/sunrise.ericsson.se/us/app/jdk/.sys/@sys/1.7.0_25/LMWP3/jre/lib/jce.jar:/afs/sunrise.ericsson.se/us/app/jdk/.sys/@sys/1.7.0_25/LMWP3/jre/lib/charsets.jar:/afs/sunrise.ericsson.se/us/app/jdk/.sys/@sys/1.7.0_25/LMWP3/jre/lib/jfr.jar:/afs/sunrise.ericsson.se/us/app/jdk/.sys/@sys/1.7.0_25/LMWP3/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Xmx2024m`
          + arg[1]: `-Xms2024m`
          + arg[2]: `-XX:MaxPermSize=512m`

  * iposretest-eselnts1183 (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      12
      - Remote FS root: `/home/iposretest/jenkins_iposretest`
      - Labels:         SELN IPUSH_TEST
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.49
      - Java
          + Home:           `/afs/sunrise.ericsson.se/se/app/vbuild/RHEL6-x86_64/jdk/1.7.0_76/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_76
          + Maximum memory:   910.50 MB (954728448)
          + Allocated memory: 733.00 MB (768606208)
          + Free memory:      666.41 MB (698784072)
          + In-use memory:    66.59 MB (69822136)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.76-b04
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-358.14.1.el6.x86_64
          + Distribution: "Red Hat Enterprise Linux Server release 6.4 (Santiago)"
          + LSB Modules:  `:base-4.0-amd64:base-4.0-ia32:base-4.0-noarch:core-4.0-amd64:core-4.0-ia32:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-ia32:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-ia32:printing-4.0-noarch`
      - Process ID: 64736 (0xfce0)
      - Process started: 2015-07-20 21:02:09.525+0200
      - Process uptime: 14 days
      - JVM startup parameters:
          + Boot classpath: `/afs/sunrise.ericsson.se/se/app/vbuild/RHEL6-x86_64/jdk/1.7.0_76/jre/lib/resources.jar:/afs/sunrise.ericsson.se/se/app/vbuild/RHEL6-x86_64/jdk/1.7.0_76/jre/lib/rt.jar:/afs/sunrise.ericsson.se/se/app/vbuild/RHEL6-x86_64/jdk/1.7.0_76/jre/lib/sunrsasign.jar:/afs/sunrise.ericsson.se/se/app/vbuild/RHEL6-x86_64/jdk/1.7.0_76/jre/lib/jsse.jar:/afs/sunrise.ericsson.se/se/app/vbuild/RHEL6-x86_64/jdk/1.7.0_76/jre/lib/jce.jar:/afs/sunrise.ericsson.se/se/app/vbuild/RHEL6-x86_64/jdk/1.7.0_76/jre/lib/charsets.jar:/afs/sunrise.ericsson.se/se/app/vbuild/RHEL6-x86_64/jdk/1.7.0_76/jre/lib/jfr.jar:/afs/sunrise.ericsson.se/se/app/vbuild/RHEL6-x86_64/jdk/1.7.0_76/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Xmx1024m`
          + arg[1]: `-XX:MaxPermSize=1024m`
          + arg[2]: `-Djava.awt.headless=true`

  * iposarts-lxapp-6 (`hudson.slaves.DumbSlave`)
      - Description:    _only used for IPUSH statatic VM, touch use it for other purpose_
      - Executors:      2
      - Remote FS root: `/home/iposarts/eis-jenkins/workspace`
      - Labels:         LXAPP_Server
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.49
      - Java
          + Home:           `/home/iposarts/eis-jenkins/workspace/jdk/jre`
          + Vendor:           Sun Microsystems Inc.
          + Version:          1.6.0_45
          + Maximum memory:   15.72 GB (16879779840)
          + Allocated memory: 809.00 MB (848297984)
          + Free memory:      789.23 MB (827563400)
          + In-use memory:    19.77 MB (20734584)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.6
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.0
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Sun Microsystems Inc.
          + Version: 20.45-b01
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.18-92.el5
      - Process ID: 13447 (0x3487)
      - Process started: 2015-07-27 01:37:08.050-0700
      - Process uptime: 8 days 5 hr
      - JVM startup parameters:
          + Boot classpath: `/home/iposarts/eis-jenkins/workspace/jdk/jre/lib/resources.jar:/home/iposarts/eis-jenkins/workspace/jdk/jre/lib/rt.jar:/home/iposarts/eis-jenkins/workspace/jdk/jre/lib/sunrsasign.jar:/home/iposarts/eis-jenkins/workspace/jdk/jre/lib/jsse.jar:/home/iposarts/eis-jenkins/workspace/jdk/jre/lib/jce.jar:/home/iposarts/eis-jenkins/workspace/jdk/jre/lib/charsets.jar:/home/iposarts/eis-jenkins/workspace/jdk/jre/lib/modules/jdk.boot.jar:/home/iposarts/eis-jenkins/workspace/jdk/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/home/iposarts/eis-jenkins/workspace/jdk/jre/lib/amd64/server:/home/iposarts/eis-jenkins/workspace/jdk/jre/lib/amd64:/home/iposarts/eis-jenkins/workspace/jdk/jre/../lib/amd64:/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * iposretest-lxapp-1 (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      15
      - Remote FS root: `/home/iposretest/jenkins-ws`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.49
      - Java
          + Home:           `/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre`
          + Vendor:           Sun Microsystems Inc.
          + Version:          1.6.0_30
          + Maximum memory:   1.97 GB (2111242240)
          + Allocated memory: 1.97 GB (2111242240)
          + Free memory:      1.30 GB (1398059392)
          + In-use memory:    680.14 MB (713182848)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.6
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.0
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Sun Microsystems Inc.
          + Version: 20.5-b03
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.18-92.el5
      - Process ID: 32756 (0x7ff4)
      - Process started: 2015-07-18 10:29:57.820-0700
      - Process uptime: 16 days
      - JVM startup parameters:
          + Boot classpath: `/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/resources.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/rt.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/sunrsasign.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/jsse.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/jce.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/charsets.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/modules/jdk.boot.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/amd64/server:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/amd64:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/../lib/amd64:/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Xmx2024m`
          + arg[1]: `-Xms2024m`
          + arg[2]: `-XX:MaxPermSize=512m`

  * iposretest-goth-eselnlx1830 (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      5
      - Remote FS root: `/local/scratch/iposretest`
      - Labels:         (none)
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.49
      - Java
          + Home:           `/afs/sunrise.ericsson.se/se/app/vbuild/RHEL6-x86_64/jdk/1.7.0_76/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_76
          + Maximum memory:   910.50 MB (954728448)
          + Allocated memory: 777.00 MB (814743552)
          + Free memory:      685.98 MB (719302296)
          + In-use memory:    91.02 MB (95441256)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.76-b04
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-358.23.2.el6.x86_64
          + Distribution: "Red Hat Enterprise Linux Server release 6.4 (Santiago)"
          + LSB Modules:  `:base-4.0-amd64:base-4.0-ia32:base-4.0-noarch:core-4.0-amd64:core-4.0-ia32:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-ia32:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-ia32:printing-4.0-noarch`
      - Process ID: 878730 (0xd688a)
      - Process started: 2015-07-21 11:34:49.892+0200
      - Process uptime: 14 days
      - JVM startup parameters:
          + Boot classpath: `/afs/sunrise.ericsson.se/se/app/vbuild/RHEL6-x86_64/jdk/1.7.0_76/jre/lib/resources.jar:/afs/sunrise.ericsson.se/se/app/vbuild/RHEL6-x86_64/jdk/1.7.0_76/jre/lib/rt.jar:/afs/sunrise.ericsson.se/se/app/vbuild/RHEL6-x86_64/jdk/1.7.0_76/jre/lib/sunrsasign.jar:/afs/sunrise.ericsson.se/se/app/vbuild/RHEL6-x86_64/jdk/1.7.0_76/jre/lib/jsse.jar:/afs/sunrise.ericsson.se/se/app/vbuild/RHEL6-x86_64/jdk/1.7.0_76/jre/lib/jce.jar:/afs/sunrise.ericsson.se/se/app/vbuild/RHEL6-x86_64/jdk/1.7.0_76/jre/lib/charsets.jar:/afs/sunrise.ericsson.se/se/app/vbuild/RHEL6-x86_64/jdk/1.7.0_76/jre/lib/jfr.jar:/afs/sunrise.ericsson.se/se/app/vbuild/RHEL6-x86_64/jdk/1.7.0_76/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Xmx1024m`
          + arg[1]: `-XX:MaxPermSize=1024m`
          + arg[2]: `-Djava.awt.headless=true`

  * emicwhe-gitts-eussjlx9023 (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      5
      - Remote FS root: `/workspace/git/emicwhe/jenkins-ws`
      - Labels:         (none)
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.49
      - Java
          + Home:           `/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre`
          + Vendor:           Sun Microsystems Inc.
          + Version:          1.6.0_30
          + Maximum memory:   1.96 GB (2108030976)
          + Allocated memory: 1.96 GB (2108030976)
          + Free memory:      1.76 GB (1892912704)
          + In-use memory:    205.15 MB (215118272)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.6
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.0
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Sun Microsystems Inc.
          + Version: 20.5-b03
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-358.6.2.el6.x86_64
          + Distribution: "Red Hat Enterprise Linux Server release 6.4 (Santiago)"
          + LSB Modules:  `:base-4.0-amd64:base-4.0-ia32:base-4.0-noarch:core-4.0-amd64:core-4.0-ia32:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-ia32:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-ia32:printing-4.0-noarch`
      - Process ID: 365626 (0x5943a)
      - Process started: 2015-07-18 10:29:57.410-0700
      - Process uptime: 16 days
      - JVM startup parameters:
          + Boot classpath: `/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/resources.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/rt.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/sunrsasign.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/jsse.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/jce.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/charsets.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/modules/jdk.boot.jar:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/amd64/server:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/lib/amd64:/tools/swdev/packages/jdk/jdk1.6.0_30-64bit/jre/../lib/amd64:/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Xmx2024m`
          + arg[1]: `-Xms2024m`
          + arg[2]: `-XX:MaxPermSize=512m`

  * iposretest-goth-eselnlx1838 (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      1
      - Remote FS root: `/home/iposretest/jenkins-esmakan`
      - Labels:         (none)
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        N/A
      - Java
          + Home:           `/afs/sunrise.ericsson.se/se/app/vbuild/RHEL6-x86_64/jdk/1.7.0_76/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_76
          + Maximum memory:   910.50 MB (954728448)
          + Allocated memory: 765.50 MB (802684928)
          + Free memory:      694.71 MB (728460224)
          + In-use memory:    70.79 MB (74224704)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.76-b04
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-358.23.2.el6.x86_64
          + Distribution: "Red Hat Enterprise Linux Server release 6.4 (Santiago)"
          + LSB Modules:  `:base-4.0-amd64:base-4.0-ia32:base-4.0-noarch:core-4.0-amd64:core-4.0-ia32:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-ia32:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-ia32:printing-4.0-noarch`
      - Process ID: 826469 (0xc9c65)
      - Process started: 2015-07-18 19:30:06.738+0200
      - Process uptime: 16 days
      - JVM startup parameters:
          + Boot classpath: `/afs/sunrise.ericsson.se/se/app/vbuild/RHEL6-x86_64/jdk/1.7.0_76/jre/lib/resources.jar:/afs/sunrise.ericsson.se/se/app/vbuild/RHEL6-x86_64/jdk/1.7.0_76/jre/lib/rt.jar:/afs/sunrise.ericsson.se/se/app/vbuild/RHEL6-x86_64/jdk/1.7.0_76/jre/lib/sunrsasign.jar:/afs/sunrise.ericsson.se/se/app/vbuild/RHEL6-x86_64/jdk/1.7.0_76/jre/lib/jsse.jar:/afs/sunrise.ericsson.se/se/app/vbuild/RHEL6-x86_64/jdk/1.7.0_76/jre/lib/jce.jar:/afs/sunrise.ericsson.se/se/app/vbuild/RHEL6-x86_64/jdk/1.7.0_76/jre/lib/charsets.jar:/afs/sunrise.ericsson.se/se/app/vbuild/RHEL6-x86_64/jdk/1.7.0_76/jre/lib/jfr.jar:/afs/sunrise.ericsson.se/se/app/vbuild/RHEL6-x86_64/jdk/1.7.0_76/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Xmx1024m`
          + arg[1]: `-XX:MaxPermSize=1024m`
          + arg[2]: `-Djava.awt.headless=true`

  * iposretest-goth-eselnlx1839 (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      1
      - Remote FS root: `/home/iposretest/jenkins-esmakan`
      - Labels:         (none)
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

