Monitors
========

`hudson.model.UpdateCenter$CoreUpdateMonitor`
--------------
(active and enabled)

`hudson.triggers.SCMTrigger$AdministrativeMonitorImpl`
--------------
(active and enabled)
