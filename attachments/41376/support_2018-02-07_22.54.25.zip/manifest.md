Support Bundle Manifest
=======================

Generated on 2018-02-07 22:54:25.742+0000

Requested components:

  * Master Log Recorders

      - `nodes/master/logs/all_2017-01-18_22.23.07.log`

      - `nodes/master/logs/all_2017-01-18_22.39.04.log`

      - `nodes/master/logs/all_2017-01-18_22.50.58.log`

      - `nodes/master/logs/all_2017-01-18_22.53.47.log`

      - `nodes/master/logs/all_2017-01-18_22.55.34.log`

      - `nodes/master/logs/all_2018-02-06_03.42.02.log`

      - `nodes/master/logs/all_2018-02-06_03.42.28.log`

      - `nodes/master/logs/all_2018-02-06_22.46.47.log`

      - `nodes/master/logs/all_memory_buffer.log`

      - `nodes/master/logs/custom/Githubwebhook.log`

      - `nodes/master/logs/custom/JenkinsJSExtensions.log`

      - `nodes/master/logs/custom/github.log`

      - `nodes/master/logs/jenkins.log`

      - `other-logs/Connection Activity monitoring to agents.log`

      - `other-logs/Connection Activity monitoring to agents.log.1`

      - `other-logs/Connection Activity monitoring to agents.log.2`

      - `other-logs/Connection Activity monitoring to agents.log.3`

      - `other-logs/Connection Activity monitoring to agents.log.4`

      - `other-logs/Connection Activity monitoring to agents.log.5`

      - `other-logs/Connection Activity monitoring to slaves.log`

      - `other-logs/Connection Activity monitoring to slaves.log.1`

      - `other-logs/Download metadata.log`

      - `other-logs/Download metadata.log.1`

      - `other-logs/Download metadata.log.2`

      - `other-logs/Download metadata.log.3`

      - `other-logs/Download metadata.log.4`

      - `other-logs/Download metadata.log.5`

      - `other-logs/Fingerprint cleanup.log`

      - `other-logs/Fingerprint cleanup.log.1`

      - `other-logs/Fingerprint cleanup.log.2`

      - `other-logs/Fingerprint cleanup.log.3`

      - `other-logs/Fingerprint cleanup.log.4`

      - `other-logs/Fingerprint cleanup.log.5`

      - `other-logs/Gravatar periodic lookup.log`

      - `other-logs/Gravatar periodic lookup.log.1`

      - `other-logs/Gravatar periodic lookup.log.2`

      - `other-logs/Gravatar periodic lookup.log.3`

      - `other-logs/Gravatar periodic lookup.log.4`

      - `other-logs/Gravatar periodic lookup.log.5`

      - `other-logs/Workspace clean-up.log`

      - `other-logs/Workspace clean-up.log.1`

      - `other-logs/Workspace clean-up.log.2`

      - `other-logs/Workspace clean-up.log.3`

      - `other-logs/Workspace clean-up.log.4`

      - `other-logs/Workspace clean-up.log.5`

      - `other-logs/copy_reference_file.log`

      - `other-logs/health-checker.log`

      - `other-logs/jenkins.branch.MultiBranchProject.log`

      - `other-logs/jenkins.branch.MultiBranchProject.log.1`

      - `other-logs/jenkins.branch.MultiBranchProject.log.2`

      - `other-logs/jenkins.branch.MultiBranchProject.log.3`

      - `other-logs/jenkins.branch.MultiBranchProject.log.4`

      - `other-logs/jenkins.branch.MultiBranchProject.log.5`

      - `other-logs/jenkins.branch.OrganizationFolder.log`

      - `other-logs/jenkins.branch.OrganizationFolder.log.1`

      - `other-logs/jenkins.branch.OrganizationFolder.log.2`

      - `other-logs/jenkins.branch.OrganizationFolder.log.3`

      - `other-logs/jenkins.branch.OrganizationFolder.log.4`

      - `other-logs/jenkins.branch.OrganizationFolder.log.5`

      - `other-logs/jenkins.metrics.api.Metrics$HealthChecker.log`

      - `other-logs/jobAnalytics.log`

      - `other-logs/jobAnalytics.log.1`

      - `other-logs/jobAnalytics.log.2`

      - `other-logs/jobAnalytics.log.3`

      - `other-logs/jobAnalytics.log.4`

      - `other-logs/jobAnalytics.log.5`

  * Garbage Collection Logs

  * About browser

      - `browser.md`

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `items.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `nodes/slave/slave-01/checksums.md5`

      - `nodes/slave/slave-02/checksums.md5`

      - `nodes/slave/slave-03/checksums.md5`

      - `nodes/slave/slave-04/checksums.md5`

      - `nodes/slave/slave-05/checksums.md5`

      - `plugins/active.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * About user (basic authentication details only)

      - `user.md`

  * Administrative monitors

      - `admin-monitors.md`

  * Build queue

      - `buildqueue.md`

  * Dump agent export tables (could reveal some memory leaks)

      - `nodes/slave/slave-01/exportTable.txt`

      - `nodes/slave/slave-02/exportTable.txt`

      - `nodes/slave/slave-03/exportTable.txt`

      - `nodes/slave/slave-04/exportTable.txt`

      - `nodes/slave/slave-05/exportTable.txt`

  * Environment variables

      - `nodes/master/environment.txt`

      - `nodes/slave/slave-01/environment.txt`

      - `nodes/slave/slave-02/environment.txt`

      - `nodes/slave/slave-03/environment.txt`

      - `nodes/slave/slave-04/environment.txt`

      - `nodes/slave/slave-05/environment.txt`

  * File descriptors (Unix only)

      - `nodes/master/file-descriptors.txt`

      - `nodes/slave/slave-01/file-descriptors.txt`

      - `nodes/slave/slave-02/file-descriptors.txt`

      - `nodes/slave/slave-03/file-descriptors.txt`

      - `nodes/slave/slave-04/file-descriptors.txt`

      - `nodes/slave/slave-05/file-descriptors.txt`

  * Master Heap Histogram

      - `nodes/master/heap-histogram.txt`

  * JVM process system metrics (Linux only)

      - `nodes/master/proc/meminfo.txt`

      - `nodes/master/proc/self/cmdline`

      - `nodes/master/proc/self/environ`

      - `nodes/master/proc/self/limits.txt`

      - `nodes/master/proc/self/mountstats.txt`

      - `nodes/master/proc/self/status.txt`

      - `nodes/slave/slave-01/proc/meminfo.txt`

      - `nodes/slave/slave-01/proc/self/cmdline`

      - `nodes/slave/slave-01/proc/self/environ`

      - `nodes/slave/slave-01/proc/self/limits.txt`

      - `nodes/slave/slave-01/proc/self/mountstats.txt`

      - `nodes/slave/slave-01/proc/self/status.txt`

      - `nodes/slave/slave-02/proc/meminfo.txt`

      - `nodes/slave/slave-02/proc/self/cmdline`

      - `nodes/slave/slave-02/proc/self/environ`

      - `nodes/slave/slave-02/proc/self/limits.txt`

      - `nodes/slave/slave-02/proc/self/mountstats.txt`

      - `nodes/slave/slave-02/proc/self/status.txt`

      - `nodes/slave/slave-03/proc/meminfo.txt`

      - `nodes/slave/slave-03/proc/self/cmdline`

      - `nodes/slave/slave-03/proc/self/environ`

      - `nodes/slave/slave-03/proc/self/limits.txt`

      - `nodes/slave/slave-03/proc/self/mountstats.txt`

      - `nodes/slave/slave-03/proc/self/status.txt`

      - `nodes/slave/slave-04/proc/meminfo.txt`

      - `nodes/slave/slave-04/proc/self/cmdline`

      - `nodes/slave/slave-04/proc/self/environ`

      - `nodes/slave/slave-04/proc/self/limits.txt`

      - `nodes/slave/slave-04/proc/self/mountstats.txt`

      - `nodes/slave/slave-04/proc/self/status.txt`

      - `nodes/slave/slave-05/proc/meminfo.txt`

      - `nodes/slave/slave-05/proc/self/cmdline`

      - `nodes/slave/slave-05/proc/self/environ`

      - `nodes/slave/slave-05/proc/self/limits.txt`

      - `nodes/slave/slave-05/proc/self/mountstats.txt`

      - `nodes/slave/slave-05/proc/self/status.txt`

  * Load Statistics

      - `load-stats/label/docker/gnuplot`

      - `load-stats/label/docker/hour.csv`

      - `load-stats/label/docker/min.csv`

      - `load-stats/label/docker/sec10.csv`

      - `load-stats/label/master/gnuplot`

      - `load-stats/label/master/hour.csv`

      - `load-stats/label/master/min.csv`

      - `load-stats/label/master/sec10.csv`

      - `load-stats/label/slave-01/gnuplot`

      - `load-stats/label/slave-01/hour.csv`

      - `load-stats/label/slave-01/min.csv`

      - `load-stats/label/slave-01/sec10.csv`

      - `load-stats/label/slave-02/gnuplot`

      - `load-stats/label/slave-02/hour.csv`

      - `load-stats/label/slave-02/min.csv`

      - `load-stats/label/slave-02/sec10.csv`

      - `load-stats/label/slave-03/gnuplot`

      - `load-stats/label/slave-03/hour.csv`

      - `load-stats/label/slave-03/min.csv`

      - `load-stats/label/slave-03/sec10.csv`

      - `load-stats/label/slave-04/gnuplot`

      - `load-stats/label/slave-04/hour.csv`

      - `load-stats/label/slave-04/min.csv`

      - `load-stats/label/slave-04/sec10.csv`

      - `load-stats/label/slave-05/gnuplot`

      - `load-stats/label/slave-05/hour.csv`

      - `load-stats/label/slave-05/min.csv`

      - `load-stats/label/slave-05/sec10.csv`

      - `load-stats/no-label/gnuplot`

      - `load-stats/no-label/hour.csv`

      - `load-stats/no-label/min.csv`

      - `load-stats/no-label/sec10.csv`

      - `load-stats/overall/gnuplot`

      - `load-stats/overall/hour.csv`

      - `load-stats/overall/min.csv`

      - `load-stats/overall/sec10.csv`

  * All loggers currently enabled.

      - `loggers.md`

  * Metrics

      - `nodes/master/metrics.json`

      - `nodes/slave/slave-01/metrics.json`

      - `nodes/slave/slave-02/metrics.json`

      - `nodes/slave/slave-03/metrics.json`

      - `nodes/slave/slave-04/metrics.json`

      - `nodes/slave/slave-05/metrics.json`

  * Networking Interface

      - `nodes/master/networkInterface.md`

      - `nodes/slave/slave-01/networkInterface.md`

      - `nodes/slave/slave-02/networkInterface.md`

      - `nodes/slave/slave-03/networkInterface.md`

      - `nodes/slave/slave-04/networkInterface.md`

      - `nodes/slave/slave-05/networkInterface.md`

  * Node monitors

      - `node-monitors.md`

  * System configuration (Linux only)

      - `nodes/master/dmesg.txt`

      - `nodes/master/dmi.txt`

      - `nodes/master/proc/cpuinfo.txt`

      - `nodes/master/proc/mounts.txt`

      - `nodes/master/proc/net/rpc/nfs.txt`

      - `nodes/master/proc/net/rpc/nfsd.txt`

      - `nodes/master/proc/swaps.txt`

      - `nodes/master/proc/system-uptime.txt`

      - `nodes/master/sysctl.txt`

      - `nodes/master/userid.txt`

      - `nodes/slave/slave-01/dmesg.txt`

      - `nodes/slave/slave-01/dmi.txt`

      - `nodes/slave/slave-01/proc/cpuinfo.txt`

      - `nodes/slave/slave-01/proc/mounts.txt`

      - `nodes/slave/slave-01/proc/net/rpc/nfs.txt`

      - `nodes/slave/slave-01/proc/net/rpc/nfsd.txt`

      - `nodes/slave/slave-01/proc/swaps.txt`

      - `nodes/slave/slave-01/proc/system-uptime.txt`

      - `nodes/slave/slave-01/sysctl.txt`

      - `nodes/slave/slave-01/userid.txt`

      - `nodes/slave/slave-02/dmesg.txt`

      - `nodes/slave/slave-02/dmi.txt`

      - `nodes/slave/slave-02/proc/cpuinfo.txt`

      - `nodes/slave/slave-02/proc/mounts.txt`

      - `nodes/slave/slave-02/proc/net/rpc/nfs.txt`

      - `nodes/slave/slave-02/proc/net/rpc/nfsd.txt`

      - `nodes/slave/slave-02/proc/swaps.txt`

      - `nodes/slave/slave-02/proc/system-uptime.txt`

      - `nodes/slave/slave-02/sysctl.txt`

      - `nodes/slave/slave-02/userid.txt`

      - `nodes/slave/slave-03/dmesg.txt`

      - `nodes/slave/slave-03/dmi.txt`

      - `nodes/slave/slave-03/proc/cpuinfo.txt`

      - `nodes/slave/slave-03/proc/mounts.txt`

      - `nodes/slave/slave-03/proc/net/rpc/nfs.txt`

      - `nodes/slave/slave-03/proc/net/rpc/nfsd.txt`

      - `nodes/slave/slave-03/proc/swaps.txt`

      - `nodes/slave/slave-03/proc/system-uptime.txt`

      - `nodes/slave/slave-03/sysctl.txt`

      - `nodes/slave/slave-03/userid.txt`

      - `nodes/slave/slave-04/dmesg.txt`

      - `nodes/slave/slave-04/dmi.txt`

      - `nodes/slave/slave-04/proc/cpuinfo.txt`

      - `nodes/slave/slave-04/proc/mounts.txt`

      - `nodes/slave/slave-04/proc/net/rpc/nfs.txt`

      - `nodes/slave/slave-04/proc/net/rpc/nfsd.txt`

      - `nodes/slave/slave-04/proc/swaps.txt`

      - `nodes/slave/slave-04/proc/system-uptime.txt`

      - `nodes/slave/slave-04/sysctl.txt`

      - `nodes/slave/slave-04/userid.txt`

      - `nodes/slave/slave-05/dmesg.txt`

      - `nodes/slave/slave-05/dmi.txt`

      - `nodes/slave/slave-05/proc/cpuinfo.txt`

      - `nodes/slave/slave-05/proc/mounts.txt`

      - `nodes/slave/slave-05/proc/net/rpc/nfs.txt`

      - `nodes/slave/slave-05/proc/net/rpc/nfsd.txt`

      - `nodes/slave/slave-05/proc/swaps.txt`

      - `nodes/slave/slave-05/proc/system-uptime.txt`

      - `nodes/slave/slave-05/sysctl.txt`

      - `nodes/slave/slave-05/userid.txt`

  * System properties

      - `nodes/master/system.properties`

      - `nodes/slave/slave-01/system.properties`

      - `nodes/slave/slave-02/system.properties`

      - `nodes/slave/slave-03/system.properties`

      - `nodes/slave/slave-04/system.properties`

      - `nodes/slave/slave-05/system.properties`

  * Update Center

      - `update-center.md`

  * Slow Request Records

      - `slow-requests/20161020-230923.553.txt`

      - `slow-requests/20161020-230929.553.txt`

      - `slow-requests/20161020-230935.554.txt`

      - `slow-requests/20161020-230941.554.txt`

      - `slow-requests/20161020-230947.553.txt`

      - `slow-requests/20161020-231047.554.txt`

      - `slow-requests/20161020-231053.554.txt`

      - `slow-requests/20161020-231059.553.txt`

      - `slow-requests/20161020-231105.554.txt`

      - `slow-requests/20161020-231111.553.txt`

      - `slow-requests/20161020-231117.553.txt`

      - `slow-requests/20161115-163911.167.txt`

      - `slow-requests/20161116-043411.184.txt`

      - `slow-requests/20161117-200519.282.txt`

      - `slow-requests/20161118-025129.324.txt`

      - `slow-requests/20161118-025135.324.txt`

      - `slow-requests/20161118-025141.324.txt`

      - `slow-requests/20161118-025144.324.txt`

      - `slow-requests/20161118-025153.324.txt`

      - `slow-requests/20161118-025217.324.txt`

      - `slow-requests/20161118-025223.324.txt`

      - `slow-requests/20161118-025229.324.txt`

      - `slow-requests/20161118-025235.324.txt`

      - `slow-requests/20161118-025241.324.txt`

      - `slow-requests/20161118-025244.324.txt`

      - `slow-requests/20161123-100223.434.txt`

      - `slow-requests/20161130-224031.591.txt`

      - `slow-requests/20161207-205449.768.txt`

      - `slow-requests/20161216-002619.698.txt`

      - `slow-requests/20161216-154955.698.txt`

      - `slow-requests/20161216-155004.698.txt`

      - `slow-requests/20161221-094826.906.txt`

      - `slow-requests/20161222-021216.811.txt`

      - `slow-requests/20161224-214101.944.txt`

      - `slow-requests/20161230-141351.831.txt`

      - `slow-requests/20170103-091247.820.txt`

      - `slow-requests/20170104-022959.396.txt`

      - `slow-requests/20170106-102202.517.txt`

      - `slow-requests/20170113-151624.823.txt`

      - `slow-requests/20170113-154345.823.txt`

      - `slow-requests/20170116-193617.892.txt`

      - `slow-requests/20170117-051721.175.txt`

      - `slow-requests/20170117-051736.175.txt`

      - `slow-requests/20170117-144521.175.txt`

      - `slow-requests/20170117-150015.175.txt`

      - `slow-requests/20170117-172424.175.txt`

      - `slow-requests/20170118-072607.352.txt`

      - `slow-requests/20170118-084919.352.txt`

      - `slow-requests/20170118-180552.352.txt`

      - `slow-requests/20170118-215055.352.txt`

  * Deadlock Records

  * Timing data about recently completed Pipeline builds

      - `nodes/master/pipeline-timings.txt`

  * Thread dumps of running Pipeline builds

      - `nodes/master/pipeline-thread-dump.txt`

  * Thread dumps

      - `nodes/master/thread-dump.txt`

      - `nodes/slave/slave-01/thread-dump.txt`

      - `nodes/slave/slave-02/thread-dump.txt`

      - `nodes/slave/slave-03/thread-dump.txt`

      - `nodes/slave/slave-04/thread-dump.txt`

      - `nodes/slave/slave-05/thread-dump.txt`

