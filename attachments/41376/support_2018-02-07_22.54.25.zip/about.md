Jenkins
=======

Version details
---------------

  * Version: `2.89.3`
  * Mode:    WAR
  * Url:     https://ci.blueocean.io/
  * Servlet container
      - Specification: 3.1
      - Name:          `jetty/9.4.z-SNAPSHOT`
  * Java
      - Home:           `/usr/lib/jvm/java-8-openjdk-amd64/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0_111
      - Maximum memory:   1.73 GB (1860698112)
      - Allocated memory: 947.00 MB (993001472)
      - Free memory:      502.67 MB (527092184)
      - In-use memory:    444.33 MB (465909288)
      - GC strategy:      ParallelGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    OpenJDK 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 25.111-b14
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      4.4.0-1048-aws
  * Process ID: 6 (0x6)
  * Process started: 2018-02-06 22:46:41.547+0000
  * Process uptime: 1 day 0 hr
  * JVM startup parameters:
      - Boot classpath: `/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/resources.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/rt.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jsse.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jce.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/charsets.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jfr.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/classes`
      - Classpath: `/usr/share/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`
      - arg[0]: `-DBLUEOCEAN_ROLLBAR_ENABLED=true`

Important configuration
---------------

  * Security realm: `org.jenkinsci.plugins.GithubSecurityRealm`
  * Authorization strategy: `org.jenkinsci.plugins.GithubAuthorizationStrategy`
  * CSRF Protection: false
  * Initialization Milestone: Completed initialization

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * ant:1.8 'Ant Plugin'
  * antisamy-markup-formatter:1.5 'OWASP Markup Formatter Plugin'
  * apache-httpcomponents-client-4-api:4.5.3-2.1 'Jenkins Apache HttpComponents Client 4.x API Plugin'
  * authentication-tokens:1.3 'Authentication Tokens API Plugin'
  * blueocean:1.5.0-beta-1-SNAPSHOT (private-db25209b-bouser) 'Blue Ocean'
  * blueocean-autofavorite:1.2.1 'Autofavorite for Blue Ocean'
  * blueocean-bitbucket-pipeline:1.5.0-beta-1-SNAPSHOT (private-db25209b-bouser) 'Bitbucket Pipeline for Blue Ocean'
  * blueocean-commons:1.5.0-beta-1-SNAPSHOT (private-db25209b-bouser) 'Common API for Blue Ocean'
  * blueocean-config:1.5.0-beta-1-SNAPSHOT (private-db25209b-bouser) 'Config API for Blue Ocean'
  * blueocean-core-js:1.5.0-beta-1-SNAPSHOT (private-db25209b-bouser) 'Blue Ocean Core JS'
  * blueocean-dashboard:1.5.0-beta-1-SNAPSHOT (private-db25209b-bouser) 'Dashboard for Blue Ocean'
  * blueocean-display-url:2.2.0 'Display URL for Blue Ocean'
  * blueocean-events:1.5.0-beta-1-SNAPSHOT (private-db25209b-bouser) 'Events API for Blue Ocean'
  * blueocean-git-pipeline:1.5.0-beta-1-SNAPSHOT (private-db25209b-bouser) 'Git Pipeline for Blue Ocean'
  * blueocean-github-pipeline:1.5.0-beta-1-SNAPSHOT (private-db25209b-bouser) 'GitHub Pipeline for Blue Ocean'
  * blueocean-i18n:1.5.0-beta-1-SNAPSHOT (private-db25209b-bouser) 'i18n for Blue Ocean'
  * blueocean-jira:1.5.0-beta-1-SNAPSHOT (private-db25209b-bouser) 'JIRA Integration for Blue Ocean'
  * blueocean-jwt:1.5.0-beta-1-SNAPSHOT (private-db25209b-bouser) 'JWT for Blue Ocean'
  * blueocean-personalization:1.5.0-beta-1-SNAPSHOT (private-db25209b-bouser) 'Personalization for Blue Ocean'
  * blueocean-pipeline-api:1.1.0-beta-3-SNAPSHOT (private-b895f127-jenkins) 'Pipeline REST API for Blue Ocean'
  * blueocean-pipeline-api-impl:1.5.0-beta-1-SNAPSHOT (private-db25209b-bouser) 'Pipeline implementation for Blue Ocean'
  * blueocean-pipeline-editor:1.5.0-beta-1-SNAPSHOT (private-db25209b-bouser) 'Blue Ocean Pipeline Editor'
  * blueocean-pipeline-scm-api:1.5.0-beta-1-SNAPSHOT (private-db25209b-bouser) 'Pipeline SCM API for Blue Ocean'
  * blueocean-rest:1.5.0-beta-1-SNAPSHOT (private-db25209b-bouser) 'REST API for Blue Ocean'
  * blueocean-rest-impl:1.5.0-beta-1-SNAPSHOT (private-db25209b-bouser) 'REST Implementation for Blue Ocean'
  * blueocean-web:1.5.0-beta-1-SNAPSHOT (private-db25209b-bouser) 'Web for Blue Ocean'
  * bouncycastle-api:2.16.0 *(update available)* 'bouncycastle API Plugin'
  * branch-api:2.0.18 'Branch API Plugin'
  * cloudbees-bitbucket-branch-source:2.2.9 'Bitbucket Branch Source Plugin'
  * cloudbees-disk-usage-simple:0.9 'CloudBees Disk Usage Simple Plugin'
  * cloudbees-folder:6.3 'Folders Plugin'
  * command-launcher:1.0 *(update available)* 'Command Agent Launcher Plugin'
  * config-file-provider:2.17 'Config File Provider Plugin'
  * copyartifact:1.39 'Copy Artifact Plugin'
  * credentials:2.1.16 'Credentials Plugin'
  * credentials-binding:1.14 *(update available)* 'Credentials Binding Plugin'
  * cvs:2.13 'Jenkins CVS Plug-in'
  * display-url-api:2.2.0 'Display URL API'
  * docker-build-publish:1.3.2 'CloudBees Docker Build and Publish plugin'
  * docker-commons:1.11 'Docker Commons Plugin'
  * docker-workflow:1.15 'Docker Pipeline'
  * durable-task:1.17 'Durable Task Plugin'
  * envinject:2.1.5 'Environment Injector Plugin'
  * envinject-api:1.5 'EnvInject API Plugin'
  * external-monitor-job:1.7 'External Monitor Job Type Plugin'
  * favorite:2.3.1 'Favorite'
  * git:3.7.0 'Jenkins Git plugin'
  * git-client:2.7.1 'Jenkins Git client plugin'
  * git-server:1.7 'Jenkins GIT server Plugin'
  * github:1.29.0 'GitHub plugin'
  * github-api:1.90 'GitHub API Plugin'
  * github-branch-source:2.3.2 'GitHub Branch Source Plugin'
  * github-oauth:0.29 'GitHub Authentication plugin'
  * github-organization-folder:1.6 'GitHub Organization Folder Plugin'
  * handlebars:1.1.1 'JavaScript GUI Lib: Handlebars bundle plugin'
  * handy-uri-templates-2-api:2.1.6-1.0 'Handy Uri Templates 2.x API Plugin'
  * hipchat:2.1.1 'Jenkins HipChat Plugin'
  * htmlpublisher:1.14 'HTML Publisher plugin'
  * icon-shim:2.0.3 'Icon Shim Plugin'
  * jackson2-api:2.8.10.1 'Jackson 2 API Plugin'
  * javadoc:1.4 'Javadoc Plugin'
  * jenkins-design-language:1.5.0-beta-1-SNAPSHOT (private-db25209b-bouser) 'Jenkins Design Language'
  * jira:2.5.1 'Jenkins JIRA plugin'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * jsch:0.1.54.1 'Jenkins JSch dependency plugin'
  * junit:1.23 *(update available)* 'JUnit Plugin'
  * ldap:1.19 'LDAP Plugin'
  * mailer:1.20 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.9.0 'MapDB API Plugin'
  * matrix-auth:2.2 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.12 'Matrix Project Plugin'
  * maven-plugin:3.1 'Maven Integration plugin'
  * mercurial:2.2 'Jenkins Mercurial plugin'
  * metrics:3.1.2.10 'Metrics Plugin'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * pam-auth:1.3 'PAM Authentication plugin'
  * pipeline-build-step:2.7 'Pipeline: Build Step'
  * pipeline-github-lib:1.0 'Pipeline: GitHub Groovy Libraries'
  * pipeline-graph-analysis:1.6 'Pipeline Graph Analysis Plugin'
  * pipeline-input-step:2.8 'Pipeline: Input Step'
  * pipeline-milestone-step:1.3.1 'Pipeline: Milestone Step'
  * pipeline-model-api:1.2.7 'Pipeline: Model API'
  * pipeline-model-declarative-agent:1.1.1 'Pipeline: Declarative Agent API'
  * pipeline-model-definition:1.2.7 'Pipeline: Declarative'
  * pipeline-model-extensions:1.2.7 'Pipeline: Declarative Extension Points API'
  * pipeline-rest-api:2.9 'Pipeline: REST API Plugin'
  * pipeline-stage-step:2.3 'Pipeline: Stage Step'
  * pipeline-stage-tags-metadata:1.2.7 'Pipeline: Stage Tags Metadata'
  * pipeline-stage-view:2.9 'Pipeline: Stage View Plugin'
  * plain-credentials:1.4 'Plain Credentials Plugin'
  * project-description-setter:1.2 'Project Description Setter'
  * pubsub-light:1.12 'Jenkins Pub-Sub "light" Bus'
  * scm-api:2.2.6 'SCM API Plugin'
  * script-security:1.40 'Script Security Plugin'
  * sse-gateway:1.15 'Server Sent Events (SSE) Gateway Plugin'
  * ssh-credentials:1.13 'SSH Credentials Plugin'
  * ssh-slaves:1.25.1 'Jenkins SSH Slaves plugin'
  * structs:1.13 'Structs Plugin'
  * subversion:2.10.2 'Jenkins Subversion Plug-in'
  * support-core:2.44 'Support Core Plugin'
  * token-macro:2.3 'Token Macro Plugin'
  * translation:1.16 'Jenkins Translation Assistance plugin'
  * variant:1.1 'Variant Plugin'
  * windows-slaves:1.3.1 'Windows Slaves Plugin'
  * workflow-aggregator:2.5 'Pipeline'
  * workflow-api:2.25 'Pipeline: API'
  * workflow-basic-steps:2.6 'Pipeline: Basic Steps'
  * workflow-cps:2.44 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.9 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.18 'Pipeline: Nodes and Processes'
  * workflow-job:2.17 'Pipeline: Job'
  * workflow-multibranch:2.17 'Pipeline: Multibranch'
  * workflow-scm-step:2.6 'Pipeline: SCM Step'
  * workflow-step-api:2.14 'Pipeline: Step API'
  * workflow-support:2.17 *(update available)* 'Pipeline: Supporting APIs'
