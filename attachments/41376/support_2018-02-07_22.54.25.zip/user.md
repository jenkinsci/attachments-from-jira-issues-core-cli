User
====

Authentication
--------------

  * Authenticated: true
  * Name: michaelneale
  * Authorities 
      - `authenticated`
      - `jenkinsci`
      - `jenkinsci*declarative-rfc-reviewers`
      - `jenkinsci*plumber-plugin Developers`
      - `jenkinsci*docker`
      - `jenkinsci*blueocean-acceptance-test Developers`
      - `jenkinsci*blueocean-display-url-plugin Developers`
      - `jenkinsci*display-url-api-plugin Developers`
      - `jenkinsci*jenkins-design-language Developers`
      - `jenkinsci*blueocean-autofavorite-plugin Developers`
      - `jenkinsci*blueocean-pipeline-editor-plugin Developers`
      - `jenkinsci*Everyone`
      - `jenkinsci*simple-build-for-pipeline-plugin Developers`
      - `jenkinsci*favorite-plugin Developers`
      - `jenkinsci*blueocean-rfc Developers`
      - `jenkinsci*react-material-icons Developers`
      - `jenkinsci*literate-cli Developers`
      - `jenkinsci*jenkins-lifx-notifier-plugin Developers`
      - `jenkinsci*email-aliases-plugin Developers`
      - `jenkinsci*blueocean-plugin Developers`
      - `jenkinsci*simple-travis-runner-plugin Developers`
      - `jenkinsci*blueocean-executor-info-plugin Developers`
      - `jenkinsci*blueocean-test-ssh-server Developers`
      - `jenkinsci*lifx-notifier-plugin Developers`
      - `jenkinsci*pipeline-editor-plugin Developers`
      - `jenkinsci*Core`
      - `jenkinsci*docker-build-publish-plugin Developers`
      - `jitisoft`
      - `jitisoft*CloudBees`
      - `cloudbeers`
      - `cloudbeers*Core`
      - `radalert`
      - `radalert*dodgybrothers`
      - `radalert*Owners`
      - `CloudBees-community`
      - `CloudBees-community*owners-team`
      - `CloudBees-community*lein`
      - `cloudbees`
      - `cloudbees*team-infra-engineering-senior`
      - `cloudbees*Jenkins Enterprise`
      - `cloudbees*cloudbees-blueocean-ux`
      - `cloudbees*team-cdx`
      - `cloudbees*team-infra-cloudbees-employees`
  * Raw: `org.jenkinsci.plugins.GithubAuthenticationToken@cffd2c0f: Username: michaelneale; Password: [PROTECTED]; Authenticated: true; Details: null; Granted Authorities: authenticated, jenkinsci, jenkinsci*declarative-rfc-reviewers, jenkinsci*plumber-plugin Developers, jenkinsci*docker, jenkinsci*blueocean-acceptance-test Developers, jenkinsci*blueocean-display-url-plugin Developers, jenkinsci*display-url-api-plugin Developers, jenkinsci*jenkins-design-language Developers, jenkinsci*blueocean-autofavorite-plugin Developers, jenkinsci*blueocean-pipeline-editor-plugin Developers, jenkinsci*Everyone, jenkinsci*simple-build-for-pipeline-plugin Developers, jenkinsci*favorite-plugin Developers, jenkinsci*blueocean-rfc Developers, jenkinsci*react-material-icons Developers, jenkinsci*literate-cli Developers, jenkinsci*jenkins-lifx-notifier-plugin Developers, jenkinsci*email-aliases-plugin Developers, jenkinsci*blueocean-plugin Developers, jenkinsci*simple-travis-runner-plugin Developers, jenkinsci*blueocean-executor-info-plugin Developers, jenkinsci*blueocean-test-ssh-server Developers, jenkinsci*lifx-notifier-plugin Developers, jenkinsci*pipeline-editor-plugin Developers, jenkinsci*Core, jenkinsci*docker-build-publish-plugin Developers, jitisoft, jitisoft*CloudBees, cloudbeers, cloudbeers*Core, radalert, radalert*dodgybrothers, radalert*Owners, CloudBees-community, CloudBees-community*owners-team, CloudBees-community*lein, cloudbees, cloudbees*team-infra-engineering-senior, cloudbees*Jenkins Enterprise, cloudbees*cloudbees-blueocean-ux, cloudbees*team-cdx, cloudbees*team-infra-cloudbees-employees`

