Node monitors
=============
Architecture
----
 - Is Ignored: false
 - Computers:
   * master: Linux (amd64)
   * slave-01: Linux (amd64)
   * slave-02: Linux (amd64)
   * slave-03: Linux (amd64)
   * slave-04: Linux (amd64)
   * slave-05: Linux (amd64)
Clock Difference
----
 - Is Ignored: false
 - Computers:
   * master: In sync
   * slave-01: In sync
   * slave-02: In sync
   * slave-03: In sync
   * slave-04: In sync
   * slave-05: In sync
Free Disk Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 123.620GB left on /var/jenkins_home.
   * slave-01: Disk space is too low. Only 22.942GB left on /home/jenkins/slave.
   * slave-02: Disk space is too low. Only 22.521GB left on /home/jenkins/slave.
   * slave-03: Disk space is too low. Only 25.273GB left on /home/jenkins/slave.
   * slave-04: Disk space is too low. Only 21.574GB left on /home/jenkins/slave.
   * slave-05: Disk space is too low. Only 25.753GB left on /home/jenkins/slave.
Free Temp Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 24.764GB left on /tmp.
   * slave-01: Disk space is too low. Only 22.942GB left on /tmp.
   * slave-02: Disk space is too low. Only 22.521GB left on /tmp.
   * slave-03: Disk space is too low. Only 25.273GB left on /tmp.
   * slave-04: Disk space is too low. Only 21.574GB left on /tmp.
   * slave-05: Disk space is too low. Only 25.753GB left on /tmp.
Response Time
----
 - Is Ignored: false
 - Computers:
   * master: 0ms
   * slave-01: 3ms
   * slave-02: 4ms
   * slave-03: 3ms
   * slave-04: 3ms
   * slave-05: 3ms
Free Swap Space
----
 - Is Ignored: true
