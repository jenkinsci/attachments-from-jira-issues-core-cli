Item statistics
===============

  * `com.cloudbees.hudson.plugins.folder.Folder`
    - Number of items: 11
    - Number of items per container: 4.909090909090909 [n=11, s=7.0]
  * `hudson.matrix.MatrixConfiguration`
    - Number of items: 3
    - Number of builds per job: 0.6666666666666666 [n=3, s=0.6]
  * `hudson.matrix.MatrixProject`
    - Number of items: 2
    - Number of builds per job: 0.5 [n=2, s=0.7]
    - Number of items per container: 1.5 [n=2, s=0.7]
  * `hudson.maven.MavenModuleSet`
    - Number of items: 1
    - Number of builds per job: 0 [n=1]
    - Number of items per container: 0 [n=1]
  * `hudson.model.FreeStyleProject`
    - Number of items: 7
    - Number of builds per job: 139.85714285714286 [n=7, s=300.0]
  * `jenkins.branch.OrganizationFolder`
    - Number of items: 4
    - Number of items per container: 0.75 [n=4, s=1.0]
  * `org.jenkinsci.plugins.workflow.job.WorkflowJob`
    - Number of items: 294
    - Number of builds per job: 8.758503401360544 [n=294, s=48.0]
  * `org.jenkinsci.plugins.workflow.multibranch.WorkflowMultiBranchProject`
    - Number of items: 22
    - Number of items per container: 11.681818181818182 [n=22, s=30.0]

Total job statistics
======================

  * Number of jobs: 307
  * Number of builds per job: 11.586319218241043 [n=307, s=65.0]
