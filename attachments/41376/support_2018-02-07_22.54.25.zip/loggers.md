Loggers currently enabled
=========================
org.jenkinsci.plugins.github_branch_source - ALL
org.apache.sshd - WARNING
com.cloudbees.jenkins.GitHubWebHook - FINEST
io.jenkins.blueocean.jsextensions.JenkinsJSExtensions - FINEST
winstone - INFO
 - INFO
