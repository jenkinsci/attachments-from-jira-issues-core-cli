-----------
 * Name veth45b9045
 ** Hardware Address - 02a7e14c6e92
 ** Index - 91
 ** InetAddress - /fe80:0:0:0:a7:e1ff:fe4c:6e92%veth45b9045
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name docker0
 ** Hardware Address - 024216998a6f
 ** Index - 3
 ** InetAddress - /fe80:0:0:0:42:16ff:fe99:8a6f%docker0
 ** InetAddress - /172.17.0.1
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name eth0
 ** Hardware Address - 0a6c08cf9b50
 ** Index - 2
 ** InetAddress - /fe80:0:0:0:86c:8ff:fecf:9b50%eth0
 ** InetAddress - /172.18.128.160
 ** MTU - 9001
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /0:0:0:0:0:0:0:1%lo
 ** InetAddress - /127.0.0.1
 ** MTU - 65536
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false
