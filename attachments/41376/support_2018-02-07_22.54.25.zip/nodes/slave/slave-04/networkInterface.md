-----------
 * Name veth013a35b
 ** Hardware Address - a61653cef246
 ** Index - 61
 ** InetAddress - /fe80:0:0:0:a416:53ff:fece:f246%veth013a35b
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name docker0
 ** Hardware Address - 0242d828d3c2
 ** Index - 3
 ** InetAddress - /fe80:0:0:0:42:d8ff:fe28:d3c2%docker0
 ** InetAddress - /172.17.0.1
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name eth0
 ** Hardware Address - 0a77b5052c56
 ** Index - 2
 ** InetAddress - /fe80:0:0:0:877:b5ff:fe05:2c56%eth0
 ** InetAddress - /172.18.128.54
 ** MTU - 9001
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /0:0:0:0:0:0:0:1%lo
 ** InetAddress - /127.0.0.1
 ** MTU - 65536
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false
