-----------
 * Name vethae2f63b
 ** Hardware Address - 6a8e226d4940
 ** Index - 83
 ** InetAddress - /fe80:0:0:0:688e:22ff:fe6d:4940%vethae2f63b
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name docker0
 ** Hardware Address - 024264d6eb19
 ** Index - 3
 ** InetAddress - /fe80:0:0:0:42:64ff:fed6:eb19%docker0
 ** InetAddress - /172.17.0.1
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name eth0
 ** Hardware Address - 0ab64a1f72da
 ** Index - 2
 ** InetAddress - /fe80:0:0:0:8b6:4aff:fe1f:72da%eth0
 ** InetAddress - /172.18.128.59
 ** MTU - 9001
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /0:0:0:0:0:0:0:1%lo
 ** InetAddress - /127.0.0.1
 ** MTU - 65536
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false
