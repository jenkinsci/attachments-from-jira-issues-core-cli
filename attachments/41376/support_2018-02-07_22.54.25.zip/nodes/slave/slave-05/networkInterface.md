-----------
 * Name vethc75024d
 ** Hardware Address - 666156d01b75
 ** Index - 203
 ** InetAddress - /fe80:0:0:0:6461:56ff:fed0:1b75%vethc75024d
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name docker0
 ** Hardware Address - 024273adc64b
 ** Index - 3
 ** InetAddress - /fe80:0:0:0:42:73ff:fead:c64b%docker0
 ** InetAddress - /172.17.0.1
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name eth0
 ** Hardware Address - 0aaa7ca8f8e8
 ** Index - 2
 ** InetAddress - /fe80:0:0:0:8aa:7cff:fea8:f8e8%eth0
 ** InetAddress - /172.18.128.14
 ** MTU - 9001
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /0:0:0:0:0:0:0:1%lo
 ** InetAddress - /127.0.0.1
 ** MTU - 65536
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false
