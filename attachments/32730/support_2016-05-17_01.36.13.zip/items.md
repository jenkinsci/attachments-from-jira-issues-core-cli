Item statistics
===============

  * `com.tikal.jenkins.plugins.multijob.MultiJobProject`
    - Number of items: 1
    - Number of builds per job: 5 [n=1]
  * `hudson.matrix.MatrixConfiguration`
    - Number of items: 44
    - Number of builds per job: 4.886363636363637 [n=44, s=5.0]
  * `hudson.matrix.MatrixProject`
    - Number of items: 30
    - Number of builds per job: 4.9 [n=30, s=4.0]
    - Number of items per container: 1.4666666666666666 [n=30, s=2.0]
  * `hudson.model.FreeStyleProject`
    - Number of items: 5
    - Number of builds per job: 2.4 [n=5, s=2.0]

Total job statistics
======================

  * Number of jobs: 80
  * Number of builds per job: 4.7375 [n=80, s=4.0]
