User
====

Authentication
--------------

  * Authenticated: true
  * Name: xrobau
  * Authorities 
      - `authenticated`
      - `Developers-TOS`
      - `Schmoozecom Developers`
      - `Software Engineering`
      - `Software Engineering Team`
      - `administrators`
      - `admins`
      - `bot-controllers`
      - `confluence-administrators`
      - `confluence-users`
      - `crowd-administrators`
      - `developers`
      - `jira-administrators`
      - `jira-users`
      - `schmooze-employees`
      - `users`
      - `weblate-administrators`
      - `weblate-users`
  * Raw: `de.theit.jenkins.crowd.CrowdAuthenticationToken@b8d94d0d: Username: de.theit.jenkins.crowd.CrowdUser@4709ca29; Password: [PROTECTED]; Authenticated: true; Details: null; Granted Authorities: authenticated, Developers-TOS, Schmoozecom Developers, Software Engineering, Software Engineering Team, administrators, admins, bot-controllers, confluence-administrators, confluence-users, crowd-administrators, developers, jira-administrators, jira-users, schmooze-employees, users, weblate-administrators, weblate-users`

