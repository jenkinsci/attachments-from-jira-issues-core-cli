Loggers currently enabled
=========================
winstone - 5
org.apache.sshd - WARNING
 - INFO
