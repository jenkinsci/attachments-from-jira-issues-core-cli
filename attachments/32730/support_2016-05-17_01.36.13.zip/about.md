Jenkins
=======

Version details
---------------

  * Version: `2.4`
  * Mode:    WAR
  * Url:     http://199.102.239.20:8080/
  * Servlet container
      - Specification: 3.1
      - Name:          `jetty/9.2.z-SNAPSHOT`
  * Java
      - Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.91-0.b14.el7_2.x86_64/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0_91
      - Maximum memory:   1.70 GB (1823473664)
      - Allocated memory: 735.50 MB (771227648)
      - Free memory:      192.10 MB (201431688)
      - In-use memory:    543.40 MB (569795960)
      - GC strategy:      ParallelGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    OpenJDK 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 25.91-b14
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      3.10.0-327.18.2.el7.x86_64
  * Process ID: 15295 (0x3bbf)
  * Process started: 2016-05-16 21:35:01.409-0400
  * Process uptime: 1 min 12 sec
  * JVM startup parameters:
      - Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.91-0.b14.el7_2.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.91-0.b14.el7_2.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.91-0.b14.el7_2.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.91-0.b14.el7_2.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.91-0.b14.el7_2.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.91-0.b14.el7_2.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.91-0.b14.el7_2.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.91-0.b14.el7_2.x86_64/jre/classes`
      - Classpath: `/usr/lib/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
      - arg[0]: `-Djava.awt.headless=true`
      - arg[1]: `-DJENKINS_HOME=/var/lib/jenkins`

Important configuration
---------------

  * Security realm: `de.theit.jenkins.crowd.CrowdSecurityRealm`
  * Authorization strategy: `hudson.security.ProjectMatrixAuthorizationStrategy`
  * CSRF Protection: false

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * ant:1.3 'Ant Plugin'
  * antisamy-markup-formatter:1.3 'OWASP Markup Formatter Plugin'
  * bitbucket:1.1.5 'Jenkins Bitbucket Plugin'
  * branch-api:1.8 'Branch API Plugin'
  * cloudbees-folder:5.10 'Folders Plugin'
  * conditional-buildstep:1.3.3 'conditional-buildstep'
  * credentials:1.28 'Credentials Plugin'
  * crowd2:1.8 'Crowd 2 Integration'
  * durable-task:1.9 'Durable Task Plugin'
  * envinject:1.92.1 'Environment Injector Plugin'
  * external-monitor-job:1.4 'External Monitor Job Type Plugin'
  * git:2.4.4 'Jenkins Git plugin'
  * git-changelog:1.23 'Git Changelog'
  * git-client:1.19.6 'Jenkins Git client plugin'
  * git-server:1.6 'Git server plugin'
  * github:1.19.1 'GitHub plugin'
  * github-api:1.75 'GitHub API Plugin'
  * github-branch-source:1.7 'GitHub Branch Source Plugin'
  * handlebars:1.1.1 'JavaScript GUI Lib: Handlebars bundle plugin'
  * icon-shim:2.0.3 'Icon Shim Plugin'
  * jackson2-api:2.7.3 'Jackson 2 API Plugin'
  * javadoc:1.3 'Javadoc Plugin'
  * jenkins-multijob-plugin:1.21 'Jenkins Multijob plugin'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * junit:1.13 'JUnit Plugin'
  * ldap:1.12 'LDAP Plugin'
  * mailer:1.17 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.6.0 'MapDB API Plugin'
  * matrix-auth:1.3.2 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.6 'Matrix Project Plugin'
  * maven-plugin:2.12.1 'Maven Integration plugin'
  * mercurial:1.54 'Jenkins Mercurial plugin'
  * metrics:3.1.2.7 'Metrics Plugin'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * pam-auth:1.2 'PAM Authentication plugin'
  * parameterized-trigger:2.30 'Jenkins Parameterized Trigger plugin'
  * pipeline-build-step:2.0 'Pipeline: Build Step'
  * pipeline-input-step:2.0 'Pipeline: Input Step'
  * pipeline-rest-api:1.4 'Pipeline: REST API Plugin'
  * pipeline-stage-step:2.1 'Pipeline: Stage Step'
  * pipeline-stage-view:1.4 'Pipeline: Stage View Plugin'
  * plain-credentials:1.1 'Plain Credentials Plugin'
  * publish-over-ssh:1.14 'Publish Over SSH'
  * run-condition:1.0 'Run Condition Plugin'
  * scm-api:1.2 'SCM API Plugin'
  * scm-sync-configuration:0.0.9 'SCM Sync Configuration Plugin'
  * script-security:1.19 'Script Security Plugin'
  * ssh-agent:1.10 'SSH Agent Plugin'
  * ssh-credentials:1.12 'SSH Credentials Plugin'
  * ssh-slaves:1.11 'Jenkins SSH Slaves plugin'
  * stashNotifier:1.10.4 'Stash Notifier'
  * structs:1.1 'Structs Plugin'
  * subversion:2.5.7 'Jenkins Subversion Plug-in'
  * support-core:2.32 'Support Core Plugin'
  * token-macro:1.12.1 'Token Macro Plugin'
  * translation:1.14 'Jenkins Translation Assistance plugin'
  * windows-slaves:1.1 'Windows Slaves Plugin'
  * workflow-aggregator:2.1 'Pipeline'
  * workflow-api:2.0 'Pipeline: API'
  * workflow-basic-steps:2.0 'Pipeline: Basic Steps'
  * workflow-cps:2.2 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.0 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.0 'Pipeline: Nodes and Processes'
  * workflow-job:2.1 'Pipeline: Job'
  * workflow-multibranch:2.3 'Pipeline: Multibranch'
  * workflow-scm-step:2.0 'Pipeline: SCM Step'
  * workflow-step-api:2.0 'Pipeline: Step API'
  * workflow-support:2.0 'Pipeline: Supporting APIs'
