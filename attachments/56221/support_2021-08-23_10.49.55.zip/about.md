Jenkins
=======

Version details
---------------

  * Version: `2.307`
  * Instance ID: `b06c5ba974c3562ee3da878e7f679a58`
  * Mode:    WAR
  * Url:     https://jenkins.rulex.io/
  * Servlet container
      - Specification: 3.1
      - Name:          `jetty/9.4.43.v20210629`
  * Java
      - Home:           `/usr/lib/jvm/java-11-openjdk-amd64`
      - Vendor:           Ubuntu
      - Version:          11.0.11
      - Maximum memory:   1.95 GB (2088763392)
      - Allocated memory: 1.95 GB (2088763392)
      - Free memory:      1.37 GB (1475671848)
      - In-use memory:    584.69 MB (613091544)
      - GC strategy:      G1
      - Available CPUs:   2
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 11
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 11
  * JVM Implementation
      - Name:    OpenJDK 64-Bit Server VM
      - Vendor:  Ubuntu
      - Version: 11.0.11+9-Ubuntu-0ubuntu2.20.04
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      5.8.0-1040-azure
      - Distribution: Ubuntu 20.04.3 LTS
  * Process ID: 1195 (0x4ab)
  * Process started: 2021-08-23 10:37:51.551+0000
  * Process uptime: 12 min
  * JVM startup parameters:
      - Classpath: `/usr/share/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`
      - arg[0]: `-Dmail.smtp.starttls.enable=true`

Remoting details
---------------

  * Embedded Version: `4.10`
  * Minimum Supported Version: `3.14`

Important configuration
---------------

  * Security realm: `com.microsoft.jenkins.azuread.AzureSecurityRealm`
  * Authorization strategy: `com.microsoft.jenkins.azuread.AzureAdMatrixAuthorizationStrategy`
  * CSRF Protection: true
  * Initialization Milestone: Completed initialization
  * Support bundle anonymization: true

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * antisamy-markup-formatter:2.1 'OWASP Markup Formatter Plugin'
  * apache-httpcomponents-client-4-api:4.5.13-1.0 'Jenkins Apache HttpComponents Client 4.x API Plugin'
  * authentication-tokens:1.4 'Authentication Tokens API Plugin'
  * azure-ad:179.vf6841393099e 'Azure AD Plugin'
  * azure-artifact-manager:94.vcb8b76839313 'Azure Artifact Manager plugin'
  * azure-commons:1.1.3 'Azure Commons Plugin'
  * azure-credentials:182.v3ccd4a755864 'Azure Credentials'
  * azure-keyvault:123.v1aba71c2d365 'Azure Key Vault Plugin'
  * azure-sdk:30.vf3165534d6e8 'Azure SDK API Plugin'
  * blueocean-commons:1.24.8 'Common API for Blue Ocean'
  * blueocean-rest:1.24.8 'REST API for Blue Ocean'
  * bootstrap4-api:4.6.0-3 'Bootstrap 4 API Plugin'
  * bootstrap5-api:5.1.0-1 'Bootstrap 5 API Plugin'
  * bouncycastle-api:2.23 'bouncycastle API Plugin'
  * branch-api:2.6.5 'Branch API Plugin'
  * build-pipeline-plugin:1.5.8 'Build Pipeline Plugin'
  * build-timestamp:1.0.3 'Build Timestamp Plugin'
  * caffeine-api:2.9.2-29.v717aac953ff3 'Caffeine API Plugin'
  * checks-api:1.7.2 'Checks API plugin'
  * cloudbees-folder:6.16 'Folders Plugin'
  * command-launcher:1.6 'Command Agent Launcher Plugin'
  * conditional-buildstep:1.4.1 'Conditional BuildStep'
  * config-file-provider:3.8.1 'Config File Provider Plugin'
  * copyartifact:1.46.1 'Copy Artifact Plugin'
  * credentials:2.5 'Credentials Plugin'
  * credentials-binding:1.27 'Credentials Binding Plugin'
  * display-url-api:2.3.5 'Display URL API'
  * durable-task:1.39 'Durable Task Plugin'
  * echarts-api:5.1.2-9 'ECharts API Plugin'
  * favorite:2.3.3 'Favorite'
  * font-awesome-api:5.15.3-4 'Font Awesome API Plugin'
  * git:4.8.2 'Jenkins Git plugin'
  * git-client:3.9.0 'Jenkins Git client plugin'
  * git-parameter:0.9.13 'Git Parameter Plug-In'
  * git-server:1.10 'Jenkins GIT server Plugin'
  * github:1.34.0 'GitHub plugin'
  * github-api:1.123 'GitHub API Plugin'
  * github-branch-source:2.11.2 'GitHub Branch Source Plugin'
  * handlebars:3.0.8 'JavaScript GUI Lib: Handlebars bundle plugin'
  * handy-uri-templates-2-api:2.1.8-1.0 'Handy Uri Templates 2.x API Plugin'
  * htmlpublisher:1.25 'HTML Publisher plugin'
  * jackson2-api:2.12.4 'Jackson 2 API Plugin'
  * javadoc:1.6 'Javadoc Plugin'
  * jaxb:2.3.0.1 'JAXB plugin'
  * jdk-tool:1.5 'Oracle Java SE Development Kit Installer Plugin'
  * jjwt-api:0.11.2-9.c8b45b8bb173 'Java JSON Web Token (JJWT) Plugin'
  * jquery:1.12.4-1 'jQuery plugin'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * jquery3-api:3.6.0-2 'JQuery3 API Plugin'
  * jsch:0.1.55.2 'Jenkins JSch dependency plugin'
  * junit:1.52 'JUnit Plugin'
  * ldap:2.7 'LDAP Plugin'
  * lockable-resources:2.11 'Lockable Resources plugin'
  * mailer:1.34 'Jenkins Mailer Plugin'
  * matrix-auth:2.6.8 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.19 'Matrix Project Plugin'
  * maven-plugin:3.12 'Maven Integration plugin'
  * metrics:4.0.2.8 'Metrics Plugin'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * msbuild:1.30 'Jenkins MSBuild Plugin'
  * oic-auth:1.8 'OpenId Connect Authentication Plugin'
  * okhttp-api:3.14.9 'OkHttp Plugin'
  * parameterized-trigger:2.41 'Jenkins Parameterized Trigger plugin'
  * pipeline-build-step:2.15 'Pipeline: Build Step'
  * pipeline-graph-analysis:1.11 'Pipeline Graph Analysis Plugin'
  * pipeline-input-step:2.12 'Pipeline: Input Step'
  * pipeline-milestone-step:1.3.2 'Pipeline: Milestone Step'
  * pipeline-model-api:1.9.1 'Pipeline: Model API'
  * pipeline-model-definition:1.9.1 'Pipeline: Declarative'
  * pipeline-model-extensions:1.9.1 'Pipeline: Declarative Extension Points API'
  * pipeline-multibranch-defaults:2.1 'Pipeline: Multibranch with defaults'
  * pipeline-rest-api:2.19 'Pipeline: REST API Plugin'
  * pipeline-stage-step:2.5 'Pipeline: Stage Step'
  * pipeline-stage-tags-metadata:1.9.1 'Pipeline: Stage Tags Metadata'
  * pipeline-stage-view:2.19 'Pipeline: Stage View Plugin'
  * pipeline-utility-steps:2.8.0 'Pipeline Utility Steps'
  * plain-credentials:1.7 'Plain Credentials Plugin'
  * plugin-util-api:2.4.0 'Plugin Utilities API Plugin'
  * popper-api:1.16.1-2 'Popper.js API Plugin'
  * popper2-api:2.9.3-1 'Popper.js 2 API Plugin'
  * powershell:1.5 'Jenkins PowerShell plugin'
  * purge-job-history:1.6 'Purge Job History Plugin'
  * resource-disposer:0.16 'Resource Disposer Plugin'
  * run-condition:1.5 'Run Condition Plugin'
  * saml:2.0.7 'SAML Plugin'
  * scm-api:2.6.5 'SCM API Plugin'
  * script-security:1.78 'Script Security Plugin'
  * snakeyaml-api:1.29.1 'Snakeyaml API Plugin'
  * ssh-credentials:1.19 'SSH Credentials Plugin'
  * sshd:3.1.0 'SSH server'
  * structs:1.23 'Structs Plugin'
  * support-core:2.74 'Support Core Plugin'
  * token-macro:266.v44a80cf277fd 'Token Macro Plugin'
  * trilead-api:1.0.13 'Trilead API Plugin'
  * uno-choice:2.5.6 'Active Choices Plug-in'
  * variant:1.4 'Variant Plugin'
  * windows-azure-storage:359.v09573e5ff73f 'Azure Storage plugin'
  * workflow-aggregator:2.6 'Pipeline'
  * workflow-api:2.46 'Pipeline: API'
  * workflow-basic-steps:2.24 'Pipeline: Basic Steps'
  * workflow-cps:2.93 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.21 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.39 'Pipeline: Nodes and Processes'
  * workflow-job:2.41 'Pipeline: Job'
  * workflow-multibranch:2.26 'Pipeline: Multibranch'
  * workflow-scm-step:2.13 'Pipeline: SCM Step'
  * workflow-step-api:2.24 'Pipeline: Step API'
  * workflow-support:3.8 'Pipeline: Supporting APIs'
  * ws-cleanup:0.39 'Jenkins Workspace Cleanup Plugin'
