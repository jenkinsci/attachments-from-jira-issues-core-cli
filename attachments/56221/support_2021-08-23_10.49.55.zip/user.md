User
====

Authentication
--------------

  * Authenticated: true
  * Name: user_assertive_lip
  * Authorities 
      - `GRP_SERVICEDESK_USER`
      - `0c89b211-04f3-4745-b219-270707fa5a8a`
      - `GRP_JENKINS_ADMIN`
      - `d1ba661d-55ad-40f5-b41a-ac72540227bd`
      - `GRP_CONFLUENCE_ADMIN`
      - `9a6c3f21-d5b1-4cd6-938e-df0cb942bc75`
      - `webmaster@rulexrdc.com`
      - `05f10d3a-afe5-48da-81c7-a67fb93bd439`
      - `GRP_USR_COMPANY_RIL`
      - `2a33c03e-a524-48a7-9356-8be2240fdb5f`
      - `GRP_JIRA_POWERUSER`
      - `58d6b04a-3372-4df0-9cda-9bcf8a2cf7f0`
      - `GRP_AZURE_ADMIN`
      - `a025d24c-1ba5-45a6-83ff-0c67ea7bde66`
      - `GRP_LICENSE_DYNAMICS365CEP`
      - `702b7952-daeb-439b-9884-917a70f8cf9b`
      - `Amazon Web Services`
      - `0ab5ae52-c98a-4adb-820a-1728951cc2c7`
      - `Informal - ITA`
      - `8fb90856-8feb-4443-ac2f-5ff3e7388f52`
      - `GRP_USR_ALL`
      - `2f9f825c-7788-453f-9452-22e283645597`
      - `GRP_USR_CC_IT`
      - `1882da6a-236b-49ce-8661-45fc1200bfde`
      - `All Users`
      - `86361472-83a9-48c4-8666-456b656899a7`
      - `Release`
      - `cfb76f7e-d335-41d9-8b39-4817558e6d04`
      - `GRP_SERVICEDESK_ADMIN`
      - `048ef583-e7fc-490c-a50e-c11abc94b659`
      - `GRP_AWS_ADMIN`
      - `4f0cba84-7422-4136-b73f-ff23b7293d42`
      - `OldEmployeeData`
      - `9ea36d8b-2fba-4fca-8587-75e853b7baef`
      - `GDPR`
      - `d1af018c-88b6-433a-b4fb-2dc73e19d4ee`
      - `IT Team`
      - `f2ea1a93-73c7-4abd-8623-a7c845587c33`
      - `hostmaster@roboticdatacorrection.com`
      - `75342a95-420b-45bf-9a00-cf1311227268`
      - `GRP_JIRA_ADMIN`
      - `bce34998-5918-40f4-a28e-1bfc68931b4b`
      - `Rulex Support System`
      - `80869498-503b-46f4-9d3d-bfa1536a88e7`
      - `Rulex All`
      - `4a923b9b-5e01-443f-aa48-e0bf0507cfc5`
      - `Privacy`
      - `df5df59d-5e86-4adf-8565-511b1e5f7ed7`
      - `GRP_OPSGENIE_ADMIN`
      - `601be5a5-9517-45c4-9449-4f9a2ffac8fd`
      - `Data Exchange`
      - `f78f79a6-134a-44d5-ba9d-c3d361f6fe59`
      - `GFT`
      - `a7a508ad-96ad-41e8-99dd-7c1dd907bf89`
      - `GRP_USR_ROLE_EMPLOYEE`
      - `3f4d93b7-b241-460f-ab5e-2b713154e2bd`
      - `GRP_RIGHT_AKS-CLUSTER_USER`
      - `a0311ad0-e4f2-4ba4-8ed8-38a42278de6e`
      - `GRP_LICENSE_M365BUSINESS`
      - `c3d067d6-226e-48bf-93d8-66dcfe6235d4`
      - `WindowsBuilds`
      - `5a731bd8-6cb2-4723-b85e-eed8426fe8b9`
      - `Postmaster rulex.ai`
      - `9077beda-86b1-4c1b-8b00-3ea04c2590bb`
      - `Rulex Innovation Labs (corporate)`
      - `ff541ce0-df8e-4366-9720-e655d07b6328`
      - `Postmaster rulex.io`
      - `03f3ace1-f428-4bf8-99b3-14bef85ca1b9`
      - `Heads' Committee`
      - `3068b8e7-c4c3-45c5-b93a-3df41a3eebb2`
      - `GRP_DEVOPS_ADMIN`
      - `3c7833e8-05b9-47f1-b6ce-f0e592979f6f`
      - `GRP_RIGHT_AKS-CLUSTER_MANAGER`
      - `8a015efb-4572-4a42-b513-65a2b4c3a00c`
      - `GRP_USR_LOC_GENOVA`
      - `c04812ff-1072-4eb1-9195-c5904fa8f7e9`
      - `GRP_CONFLUENCE_POWERUSER`
      - `e29ec9ff-d089-4eaf-a603-c07bd954d43b`
      - `authenticated`
      - `09e3681a-72e0-4427-b1b6-e4bd6589aeac`

