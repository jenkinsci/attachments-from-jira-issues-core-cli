Item statistics
===============

  * `org.jenkinsci.plugins.workflow.job.WorkflowJob`
    - Number of items: 16
    - Number of builds per job: 7.4375 [n=16, s=10.0]

Total job statistics
======================

  * Number of jobs: 16
  * Number of builds per job: 7.4375 [n=16, s=10.0]
