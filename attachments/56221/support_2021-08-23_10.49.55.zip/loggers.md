Loggers currently enabled
=========================
 - WARNING
winstone - WARNING
org.apache.sshd - WARNING
