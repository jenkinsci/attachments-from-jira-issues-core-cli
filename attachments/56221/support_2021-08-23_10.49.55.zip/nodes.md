Node statistics
===============

  * Total number of nodes
      - Sample size:        47
      - Average (mean):     1.0
      - Average (median):   1.0
      - Standard deviation: 0.0
      - Minimum:            1
      - Maximum:            1
      - 95th percentile:    1.0
      - 99th percentile:    1.0
  * Total number of nodes online
      - Sample size:        47
      - Average (mean):     0.9999935538070635
      - Average (median):   1.0
      - Standard deviation: 0.002538927211007724
      - Minimum:            0
      - Maximum:            1
      - 95th percentile:    1.0
      - 99th percentile:    1.0
  * Total number of executors
      - Sample size:        47
      - Average (mean):     1.9999871076141276
      - Average (median):   2.0
      - Standard deviation: 0.005077854422015449
      - Minimum:            0
      - Maximum:            2
      - 95th percentile:    2.0
      - 99th percentile:    2.0
  * Total number of executors in use
      - Sample size:        47
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the Jenkins controller's computer&#95;open&#95;engagement_
      - Executors:      0
      - FS root:        `/var/lib/jenkins`
      - Labels:         master
      - Usage:          `EXCLUSIVE`
      - Slave Version:  4.10
      - Java
          + Home:           `/usr/lib/jvm/java-11-openjdk-amd64`
          + Vendor:           Ubuntu
          + Version:          11.0.11
          + Maximum memory:   1.95 GB (2088763392)
          + Allocated memory: 1.95 GB (2088763392)
          + Free memory:      1.37 GB (1470377464)
          + In-use memory:    589.74 MB (618385928)
          + GC strategy:      G1
          + Available CPUs:   2
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 11
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 11
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Ubuntu
          + Version: 11.0.11+9-Ubuntu-0ubuntu2.20.04
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      5.8.0-1040-azure
          + Distribution: Ubuntu 20.04.3 LTS
      - Process ID: 1195 (0x4ab)
      - Process started: 2021-08-23 10:37:51.551+0000
      - Process uptime: 12 min
      - JVM startup parameters:
          + Classpath: `/usr/share/jenkins/jenkins.war`
          + Library path: `/usr/java/packages/lib:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`
          + arg[0]: `-Dmail.smtp.starttls.enable=true`

  * `computer_hot_law` (`hudson.slaves.DumbSlave`)
      - Description:    _Windows 10 Pro (4 vCPU, 8Gb RAM)_
      - Executors:      2
      - Remote FS root: `c:\jenkins`
      - Labels:         windows
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - WebSocket:      false
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        4.10
      - Java
          + Home:           `C:\Program Files\Java\jre1.8.0_291`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0&#95;291
          + Maximum memory:   1.78 GB (1908932608)
          + Allocated memory: 123.00 MB (128974848)
          + Free memory:      96.04 MB (100700072)
          + In-use memory:    26.96 MB (28274776)
          + GC strategy:      ParallelGC
          + Available CPUs:   4
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit item_full_history VM
          + Vendor:  Oracle Corporation
          + Version: 25.291-b10
      - Operating system
          + Name:         Windows 10
          + Architecture: amd64
          + Version:      10.0
      - Process ID: 6460 (0x193c)
      - Process started: 2021-08-23 10:38:15.458+0000
      - Process uptime: 11 min
      - JVM startup parameters:
          + Boot classpath: `C:\Program Files\Java\jre1.8.0_291\lib\resources.jar;C:\Program Files\Java\jre1.8.0_291\lib\rt.jar;C:\Program Files\Java\jre1.8.0_291\lib\sunrsasign.jar;C:\Program Files\Java\jre1.8.0_291\lib\jsse.jar;C:\Program Files\Java\jre1.8.0_291\lib\jce.jar;C:\Program Files\Java\jre1.8.0_291\lib\charsets.jar;C:\Program Files\Java\jre1.8.0_291\lib\jfr.jar;C:\Program Files\Java\jre1.8.0_291\classes`
          + Classpath: `c:\jenkins\slave.jar`
          + Library path: `C:\Program Files\Java\jre1.8.0_291\bin;C:\WINDOWS\Sun\Java\bin;C:\WINDOWS\system32;C:\WINDOWS;C:\Program Files (x86)\Microsoft SDKs\VSTS\CLI\wbin;C:\ProgramData\Oracle\Java\javapath;C:\Python27\;C:\Python27\Scripts;C:\Program Files (x86)\Common Files\Oracle\Java\javapath;C:\WINDOWS\system32;C:\WINDOWS;C:\WINDOWS\System32\Wbem;C:\WINDOWS\System32\WindowsPowerShell\v1.0\;C:\WINDOWS\System32\OpenSSH\;C:\Program Files\CMake\bin;C:\Program Files\Microsoft SQL item_full_history\110\Tools\Binn\;C:\Program Files (x86)\Windows Kits\10\App Certification Kit;C:\Program Files\dotnet\;C:\Program Files\Git\cmd;C:\Program Files\Docker\Docker\resources\bin;C:\ProgramData\DockerDesktop\version-bin;C:\WINDOWS\system32\config\systemprofile\AppData\Local\Microsoft\WindowsApps;.`
          + arg[0]: `-Xrs`

