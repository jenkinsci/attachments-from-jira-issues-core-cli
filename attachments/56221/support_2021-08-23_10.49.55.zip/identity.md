Public Key
---------------
-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAoaHoeDkk8m2xvQI0K89J
SKBOmPpT4+0F1hZNIfpmC+9ndhi63JFgGVBMUtiqKVTn5gQXQF4BQrQBIo0cObu7
nhAchjlIsB2YT8EtRn6Ps+rUoU3b5Q8cngj7FOYUfn1j+04+lvwAGIjD5cGi05fp
CnYdW3zOE0riakHj//vIYRMM50zaUuHz7m5leI0gIe6oBhDK/aN2yPnTKYcp062H
U0zJOg2tT3ISB1Js/jeEuH44i9heD9zmHPBlNPA00cHfqPfE/7HKMwI9znfPuOTV
oRwNhRIKR2joxktm9GlPFxRu+BCW34IEvdDDZ9SKUNBmjKBgD8o+HzvJQPPTspnU
hQIDAQAB
-----END PUBLIC KEY-----


Fingerprint
---------------
ip_necessary_simplicity:ip_green_affinity
