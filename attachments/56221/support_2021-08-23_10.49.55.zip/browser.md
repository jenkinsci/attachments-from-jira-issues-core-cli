Browser
=======

  * Screen size: 2560x1440
  * User Agent
      - Type:     Browser
      - Name:     Chrome
      - Family:   CHROME
      - Producer: Google Inc.
      - Version:  92.0.4515.159
      - Raw:      `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.159 Safari/537.36 Edg/92.0.902.78`
  * Operating System
      - Name:     Windows
      - Family:   WINDOWS
      - Producer: Microsoft Corporation.
      - Version:  10.0

