Support Bundle Manifest
=======================

Generated on 2021-08-23 10:49:55.148+0000

Requested components:

  * About browser

      - `browser.md`

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `identity.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `nodes/slave/computer_hot_law/checksums.md5`

      - `plugins/active.txt`

      - `plugins/backup.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * About user (basic authentication details only)

      - `user.md`

  * Administrative monitors

      - `admin-monitors.md`

  * Agent Protocols

      - `agent-protocols.md`

  * Build queue

      - `buildqueue.md`

  * Controller Custom Log Recorders

      - `nodes/master/logs/custom/Azure VM Agent (Auto).log`

  * Dump agent export tables (could reveal some memory leaks)

      - `nodes/slave/computer_hot_law/exportTable.txt`

  * Environment variables

      - `nodes/master/environment.txt`

      - `nodes/slave/computer_hot_law/environment.txt`

  * File descriptors (Unix only)

      - `nodes/master/file-descriptors.txt`

  * Items Content (Computationally expensive)

      - `items.md`

  * Controller JVM process system metrics (Linux only)

      - `nodes/master/proc/meminfo.txt`

      - `nodes/master/proc/self/cmdline`

      - `nodes/master/proc/self/environ`

      - `nodes/master/proc/self/limits.txt`

      - `nodes/master/proc/self/mountstats.txt`

      - `nodes/master/proc/self/status.txt`

  * Controller Log Recorders

      - `nodes/master/logs/all_2021-08-23_10.37.55.log`

      - `nodes/master/logs/all_memory_buffer.log`

      - `nodes/master/logs/jenkins.log`

  * Load Statistics

      - `load-stats/label/computer_hot_law/gnuplot`

      - `load-stats/label/computer_hot_law/hour.csv`

      - `load-stats/label/computer_hot_law/min.csv`

      - `load-stats/label/computer_hot_law/sec10.csv`

      - `load-stats/label/label_secular_palace/gnuplot`

      - `load-stats/label/label_secular_palace/hour.csv`

      - `load-stats/label/label_secular_palace/min.csv`

      - `load-stats/label/label_secular_palace/sec10.csv`

      - `load-stats/label/master/gnuplot`

      - `load-stats/label/master/hour.csv`

      - `load-stats/label/master/min.csv`

      - `load-stats/label/master/sec10.csv`

      - `load-stats/label/windows/gnuplot`

      - `load-stats/label/windows/hour.csv`

      - `load-stats/label/windows/min.csv`

      - `load-stats/label/windows/sec10.csv`

      - `load-stats/no-label/gnuplot`

      - `load-stats/no-label/hour.csv`

      - `load-stats/no-label/min.csv`

      - `load-stats/no-label/sec10.csv`

      - `load-stats/overall/gnuplot`

      - `load-stats/overall/hour.csv`

      - `load-stats/overall/min.csv`

      - `load-stats/overall/sec10.csv`

  * All loggers currently enabled

      - `loggers.md`

  * Metrics

      - `nodes/master/metrics.json`

  * Networking Interface

      - `nodes/master/networkInterface.md`

      - `nodes/slave/computer_hot_law/networkInterface.md`

  * Node monitors

      - `node-monitors.md`

  * Reverse Proxy

      - `reverse-proxy.md`

  * Running Builds

      - `running-builds.txt`

  * Agent Command Statistics

      - `nodes/slave/computer_hot_law/command-stats.md`

  * Controller system configuration (Linux only)

      - `nodes/master/dmesg.txt`

      - `nodes/master/dmi.txt`

      - `nodes/master/proc/cpuinfo.txt`

      - `nodes/master/proc/mounts.txt`

      - `nodes/master/proc/net/rpc/nfs.txt`

      - `nodes/master/proc/net/rpc/nfsd.txt`

      - `nodes/master/proc/swaps.txt`

      - `nodes/master/proc/system-uptime.txt`

      - `nodes/master/sysctl.txt`

      - `nodes/master/userid.txt`

  * System properties

      - `nodes/master/system.properties`

      - `nodes/slave/computer_hot_law/system.properties`

  * Controller Task Log Recorders

      - `task-logs/ACI Period Clean Task.log`

      - `task-logs/ACI Period Clean Task.log.1`

      - `task-logs/ACI Period Clean Task.log.2`

      - `task-logs/ACI Period Clean Task.log.3`

      - `task-logs/ACI Period Clean Task.log.4`

      - `task-logs/ACI Period Clean Task.log.5`

      - `task-logs/Azure VM Agents Clean Task.log`

      - `task-logs/Azure VM Agents Clean Task.log.1`

      - `task-logs/Azure VM Agents Clean Task.log.2`

      - `task-logs/Azure VM Agents Clean Task.log.3`

      - `task-logs/Azure VM Agents Clean Task.log.4`

      - `task-logs/Azure VM Agents Clean Task.log.5`

      - `task-logs/Azure VM Maintainer Pool Size.log`

      - `task-logs/Azure VM Maintainer Pool Size.log.1`

      - `task-logs/Azure VM Maintainer Pool Size.log.2`

      - `task-logs/Azure VM Maintainer Pool Size.log.3`

      - `task-logs/Azure VM Maintainer Pool Size.log.4`

      - `task-logs/Azure VM Maintainer Pool Size.log.5`

      - `task-logs/Azure VM Verification Task.log`

      - `task-logs/Azure VM Verification Task.log.1`

      - `task-logs/Azure VM Verification Task.log.2`

      - `task-logs/Azure VM Verification Task.log.3`

      - `task-logs/Azure VM Verification Task.log.4`

      - `task-logs/Azure VM Verification Task.log.5`

      - `task-logs/Connection Activity monitoring to agents.log`

      - `task-logs/Connection Activity monitoring to agents.log.1`

      - `task-logs/Connection Activity monitoring to agents.log.2`

      - `task-logs/Connection Activity monitoring to agents.log.3`

      - `task-logs/Connection Activity monitoring to agents.log.4`

      - `task-logs/Connection Activity monitoring to agents.log.5`

      - `task-logs/DockerContainerWatchdog Asynchronous Periodic Work.log`

      - `task-logs/DockerContainerWatchdog Asynchronous Periodic Work.log.1`

      - `task-logs/DockerContainerWatchdog Asynchronous Periodic Work.log.2`

      - `task-logs/DockerContainerWatchdog Asynchronous Periodic Work.log.3`

      - `task-logs/DockerContainerWatchdog Asynchronous Periodic Work.log.4`

      - `task-logs/DockerContainerWatchdog Asynchronous Periodic Work.log.5`

      - `task-logs/Download metadata.log`

      - `task-logs/Download metadata.log.1`

      - `task-logs/Download metadata.log.2`

      - `task-logs/Download metadata.log.3`

      - `task-logs/Download metadata.log.4`

      - `task-logs/Download metadata.log.5`

      - `task-logs/Fingerprint cleanup.log`

      - `task-logs/Fingerprint cleanup.log.1`

      - `task-logs/Fingerprint cleanup.log.2`

      - `task-logs/Fingerprint cleanup.log.3`

      - `task-logs/Fingerprint cleanup.log.4`

      - `task-logs/Fingerprint cleanup.log.5`

      - `task-logs/LibraryCachingCleanup.log`

      - `task-logs/LibraryCachingCleanup.log.1`

      - `task-logs/LibraryCachingCleanup.log.2`

      - `task-logs/LibraryCachingCleanup.log.3`

      - `task-logs/LibraryCachingCleanup.log.4`

      - `task-logs/LibraryCachingCleanup.log.5`

      - `task-logs/Periodic background build discarder.log`

      - `task-logs/Periodic background build discarder.log.1`

      - `task-logs/Periodic background build discarder.log.2`

      - `task-logs/Periodic background build discarder.log.3`

      - `task-logs/Periodic background build discarder.log.4`

      - `task-logs/Periodic background build discarder.log.5`

      - `task-logs/Update IdP Metadata from URL PeriodicWork.log`

      - `task-logs/Update IdP Metadata from URL PeriodicWork.log.1`

      - `task-logs/Update IdP Metadata from URL PeriodicWork.log.2`

      - `task-logs/Update IdP Metadata from URL PeriodicWork.log.3`

      - `task-logs/Update IdP Metadata from URL PeriodicWork.log.4`

      - `task-logs/Update IdP Metadata from URL PeriodicWork.log.5`

      - `task-logs/Workspace clean-up.log`

      - `task-logs/Workspace clean-up.log.1`

      - `task-logs/Workspace clean-up.log.2`

      - `task-logs/Workspace clean-up.log.3`

      - `task-logs/Workspace clean-up.log.4`

      - `task-logs/Workspace clean-up.log.5`

      - `task-logs/health-checker.log`

      - `task-logs/jobAnalytics.log`

      - `task-logs/jobAnalytics.log.1`

      - `task-logs/jobAnalytics.log.2`

      - `task-logs/jobAnalytics.log.3`

      - `task-logs/jobAnalytics.log.4`

      - `task-logs/jobAnalytics.log.5`

      - `task-logs/telemetry collection.log`

      - `task-logs/telemetry collection.log.1`

      - `task-logs/telemetry collection.log.2`

      - `task-logs/telemetry collection.log.3`

      - `task-logs/telemetry collection.log.4`

      - `task-logs/telemetry collection.log.5`

  * Thread dumps

      - `nodes/master/thread-dump.txt`

      - `nodes/slave/computer_hot_law/thread-dump.txt`

  * Update Center

      - `update-center.md`

  * User Count

      - `/users/count.md`

  * Slow Request Records

      - `slow-requests/20210823-104127.316.txt`

      - `slow-requests/20210823-104930.316.txt`

  * Thread dumps on high CPU usage

  * Deadlock Records

  * Timing data about recently completed Pipeline builds

      - `nodes/master/pipeline-timings.txt`

  * Thread dumps of running Pipeline builds

      - `nodes/master/pipeline-thread-dump.txt`

