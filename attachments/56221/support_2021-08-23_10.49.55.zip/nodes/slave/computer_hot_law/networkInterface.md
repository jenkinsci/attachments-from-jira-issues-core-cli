-----------
 * Name Software Loopback Interface 1
 ** Index - 1
 ** InetAddress - /ip_consistent_contemporary
 ** InetAddress - /ip_geological_writer
 ** MTU - -1
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Microsoft 6to4 Adapter
 ** Index - 2
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Microsoft IP-HTTPS Platform Adapter
 ** Index - 3
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name WAN Miniport (SSTP)
 ** Index - 4
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Microsoft Hyper-V Network Adapter
 ** Hardware Address - 000d3a441b9b
 ** Index - 5
 ** InetAddress - /ip_vain_glow
 ** InetAddress - /ip_restricted_neighbourhood%eth0
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Microsoft Kernel Debug Network Adapter
 ** Index - 6
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Hyper-V Virtual Switch Extension Adapter
 ** Index - 7
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name WAN Miniport (IP)
 ** Index - 8
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Microsoft Teredo Tunneling Adapter
 ** Index - 9
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Hyper-V Virtual Switch Extension Adapter-Microsoft NDIS Capture-0000
 ** Index - 10
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Microsoft Hyper-V Network Adapter-Microsoft NDIS Capture-0000
 ** Index - 11
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name WAN Miniport (Network Monitor)
 ** Index - 12
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name WAN Miniport (IKEv2)
 ** Index - 13
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name WAN Miniport (PPPOE)
 ** Index - 14
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name WAN Miniport (IPv6)
 ** Index - 15
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name WAN Miniport (PPTP)
 ** Index - 16
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Hyper-V Virtual Switch Extension Adapter-Hyper-V Virtual Switch Extension Filter-0000
 ** Index - 17
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name WAN Miniport (L2TP)
 ** Index - 18
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Microsoft Hyper-V Network Adapter-Microsoft NDIS Capture-0001
 ** Index - 19
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Hyper-V Virtual Switch Extension Adapter-Microsoft NDIS Capture-0002
 ** Index - 20
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Microsoft Hyper-V Network Adapter-WFP Native MAC Layer LightWeight Filter-0000
 ** Index - 21
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Hyper-V Virtual Ethernet Adapter
 ** Hardware Address - 00155d36e452
 ** Index - 22
 ** InetAddress - /ip_minimum_sausage
 ** InetAddress - /ip_frozen_weekend%eth12
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Hyper-V Virtual Ethernet Adapter-Microsoft NDIS Capture-0000
 ** Index - 23
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Microsoft Hyper-V Network Adapter-QoS Packet Scheduler-0000
 ** Index - 24
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Hyper-V Virtual Ethernet Adapter-WFP Native MAC Layer LightWeight Filter-0000
 ** Index - 25
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Hyper-V Virtual Ethernet Adapter-Microsoft NDIS Capture-0001
 ** Index - 26
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Microsoft Hyper-V Network Adapter-WFP 802.3 MAC Layer LightWeight Filter-0000
 ** Index - 27
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Hyper-V Virtual Ethernet Adapter-QoS Packet Scheduler-0000
 ** Index - 28
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Hyper-V Virtual Ethernet Adapter-Microsoft NDIS Capture-0003
 ** Index - 29
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name WAN Miniport (IP)-WFP Native MAC Layer LightWeight Filter-0000
 ** Index - 30
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name WAN Miniport (IP)-QoS Packet Scheduler-0000
 ** Index - 31
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name WAN Miniport (IPv6)-WFP Native MAC Layer LightWeight Filter-0000
 ** Index - 32
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name WAN Miniport (IPv6)-QoS Packet Scheduler-0000
 ** Index - 33
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name WAN Miniport (Network Monitor)-WFP Native MAC Layer LightWeight Filter-0000
 ** Index - 34
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name WAN Miniport (Network Monitor)-QoS Packet Scheduler-0000
 ** Index - 35
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Microsoft Hyper-V Network Adapter-Microsoft NDIS Capture-0003
 ** Index - 36
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Microsoft Hyper-V Network Adapter-Microsoft NDIS Capture-0004
 ** Index - 37
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Hyper-V Virtual Ethernet Adapter-WFP 802.3 MAC Layer LightWeight Filter-0000
 ** Index - 38
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Hyper-V Virtual Ethernet Adapter-Microsoft NDIS Capture-0004
 ** Index - 39
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Hyper-V Virtual Switch Extension Adapter #2
 ** Index - 40
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Hyper-V Virtual Switch Extension Adapter #2-Microsoft NDIS Capture-0000
 ** Index - 41
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Hyper-V Virtual Switch Extension Adapter #2-Hyper-V Virtual Switch Extension Filter-0000
 ** Index - 42
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Hyper-V Virtual Switch Extension Adapter #2-Microsoft NDIS Capture-0002
 ** Index - 43
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Hyper-V Virtual Ethernet Adapter #2
 ** Hardware Address - 00155d7f99dd
 ** Index - 44
 ** InetAddress - /ip_competitive_compensation
 ** InetAddress - /ip_unlike_front%eth34
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Hyper-V Virtual Ethernet Adapter #2-Microsoft NDIS Capture-0000
 ** Index - 45
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Hyper-V Virtual Ethernet Adapter #2-WFP Native MAC Layer LightWeight Filter-0000
 ** Index - 46
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Hyper-V Virtual Ethernet Adapter #2-Microsoft NDIS Capture-0001
 ** Index - 47
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Hyper-V Virtual Ethernet Adapter #2-QoS Packet Scheduler-0000
 ** Index - 48
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Hyper-V Virtual Ethernet Adapter #2-Microsoft NDIS Capture-0003
 ** Index - 49
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Hyper-V Virtual Ethernet Adapter #2-WFP 802.3 MAC Layer LightWeight Filter-0000
 ** Index - 50
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Hyper-V Virtual Ethernet Adapter #2-Microsoft NDIS Capture-0004
 ** Index - 51
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
