# Totals
* Writes: 419
  * sent 1.4Mb
* Reads: 637
  * received 1.2Mb
* Responses: 45
  * waited 5.4 sec

# Commands sent
* `Pipe.Chunk`: 56
  * sent 0.5Mb
* `ProxyOutputStream.Ack`: 44
  * sent 0.0Mb
* `ProxyOutputStream.Unexport`: 1
  * sent 0.0Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 201
  * sent 0.6Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch[java.lang.String]`: 1
  * sent 0.0Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 6
  * sent 0.0Mb
* `Response:UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 16
  * sent 0.0Mb
* `Response:UserRequest:UserRPCRequest:hudson.remoting.JarLoader.writeJarTo[long,long,java.io.OutputStream]`: 1
  * sent 0.0Mb
* `Response:UserRequest:hudson.remoting.PingThread$Ping`: 3
  * sent 0.0Mb
* `Unexport`: 45
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 1
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 1
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetAgentDigest`: 2
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetAgentVersion`: 2
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 2
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 2
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 2
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 1
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 2
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 1
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 2
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$CallableWith`: 2
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Digest`: 1
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Exists`: 2
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$IsDirectory`: 1
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$IsUnix`: 1
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Read`: 3
  * sent 0.0Mb
* `UserRequest:hudson.logging.LogRecorder$SetLevel`: 1
  * sent 0.0Mb
* `UserRequest:hudson.model.Slave$GetClockDifference1`: 1
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 1
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 1
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 1
  * sent 0.0Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 3
  * sent 0.0Mb
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 1
  * sent 0.0Mb
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 1
  * sent 0.0Mb
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 1
  * sent 0.0Mb
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 1
  * sent 0.0Mb
* `UserRequest:jenkins.util.SystemProperties$AgentCopier$CopySystemProperties`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.upstart_slave_installer.SlaveInstallerFactoryImpl$HasUpstart`: 1
  * sent 0.0Mb

# Commands received
* `Pipe.Chunk`: 44
  * received 0.4Mb
* `ProxyOutputStream.Ack`: 56
  * received 0.0Mb
* `ProxyOutputStream.EOF`: 3
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 201
  * received 0.1Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch[java.lang.String]`: 1
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 6
  * received 0.0Mb
* `Response`: 45
  * received 0.2Mb
* `Unexport`: 261
  * received 0.4Mb
* `UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 16
  * received 0.1Mb
* `UserRequest:UserRPCRequest:hudson.remoting.JarLoader.writeJarTo[long,long,java.io.OutputStream]`: 1
  * received 0.0Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 3
  * received 0.0Mb

# Responses received
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 1
  * waited 3 ms
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 1
  * waited 0.97 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetAgentDigest`: 2
  * waited 96 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetAgentVersion`: 2
  * waited 94 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 2
  * waited 94 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 2
  * waited 18 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 2
  * waited 0.98 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 1
  * waited 0.2 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 2
  * waited 56 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 1
  * waited 16 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 2
  * waited 0.16 sec
* `UserRequest:hudson.FilePath$CallableWith`: 2
  * waited 0.28 sec
* `UserRequest:hudson.FilePath$Digest`: 1
  * waited 89 ms
* `UserRequest:hudson.FilePath$Exists`: 2
  * waited 0.78 sec
* `UserRequest:hudson.FilePath$IsDirectory`: 1
  * waited 6 ms
* `UserRequest:hudson.FilePath$IsUnix`: 1
  * waited 5 ms
* `UserRequest:hudson.FilePath$Read`: 3
  * waited 74 ms
* `UserRequest:hudson.logging.LogRecorder$SetLevel`: 1
  * waited 44 ms
* `UserRequest:hudson.model.Slave$GetClockDifference1`: 1
  * waited 65 ms
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 1
  * waited 21 ms
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 1
  * waited 0.11 sec
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 1
  * waited 0.39 sec
* `UserRequest:hudson.remoting.PingThread$Ping`: 3
  * waited 39 ms
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 1
  * waited 53 ms
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 1
  * waited 11 ms
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 1
  * waited 29 ms
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 1
  * waited 0.51 sec
* `UserRequest:jenkins.util.SystemProperties$AgentCopier$CopySystemProperties`: 1
  * waited 19 ms
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 1
  * waited 14 ms
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 1
  * waited 0.1 sec
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 1
  * waited 22 ms
* `UserRequest:org.jenkinsci.modules.upstart_slave_installer.SlaveInstallerFactoryImpl$HasUpstart`: 1
  * waited 32 ms

# JARs sent
* `support-core.jar`: 455001b
