-----------
 * Name eth0
 ** Hardware Address - 000d3a3a16e6
 ** Index - 2
 ** InetAddress - /ip_rural_official%eth0
 ** InetAddress - /ip_moral_series
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /ip_geological_writer%lo
 ** InetAddress - /ip_consistent_contemporary
 ** MTU - 65536
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false
