Node monitors
=============
Architecture
----
 - Is Ignored: false
 - Computers:
   * computer_open_engagement: Linux (amd64)
   * computer_hot_law: Windows 10 (amd64)
Clock Difference
----
 - Is Ignored: false
 - Computers:
   * computer_open_engagement: In sync
   * computer_hot_law: In sync
Free Disk Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * computer_open_engagement: 110.595GB left on /var/lib/jenkins.
   * computer_hot_law: 181.941GB left on C:\jenkins.
Free Swap Space
----
 - Is Ignored: false
 - Computers:
   * computer_open_engagement: Memory:6168/7961MB  Swap:0/0MB
   * computer_hot_law: Memory:3138/8191MB  Swap:4665/11821MB
Free Temp Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * computer_open_engagement: 110.595GB left on /tmp.
   * computer_hot_law: 181.941GB left on C:\Windows\Temp.
Response Time
----
 - Is Ignored: false
 - Computers:
   * computer_open_engagement: 0ms
   * computer_hot_law: 115ms
