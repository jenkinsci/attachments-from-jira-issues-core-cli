Current build queue has 3 item(s).
---------------
 * Name of item: journey_tests » execution-pipeline
    - In queue for: 1 hr 43 min
    - Is blocked: true
    - Why in queue: Build #895 is already in progress (ETA:N/A)
    - Current queue trigger cause: Started by upstream project "TestRail/Planner" build number 232
  * Task Dispatcher: com.cloudbees.hudson.plugins.folder.computed.ThrottleComputationQueueTaskDispatcher@2d97010f
    - Can run: null
  * Task Dispatcher: com.sonyericsson.hudson.plugins.gerrit.trigger.dependency.DependencyQueueTaskDispatcher@4bfe6df1
    - Can run: null
  * Task Dispatcher: com.sonyericsson.hudson.plugins.gerrit.trigger.replication.ReplicationQueueTaskDispatcher@43609961
    - Can run: null
  * Task Dispatcher: jenkins.branch.RateLimitBranchProperty$QueueTaskDispatcherImpl@4775659f
    - Can run: null
  * Task Dispatcher: org.jenkins.plugins.lockableresources.queue.LockableResourcesQueueTaskDispatcher@52ff8b07
    - Can run: null
  * Task Dispatcher: org.jenkinsci.plugins.durabletask.executors.ContinuedTask$Scheduler@6a56f54c
    - Can run: null
----

 * Name of item: part of nydus » parasite-gerrit #107
    - In queue for: 22 sec
    - Is blocked: false
    - Why in queue: Jenkins is reserved for jobs with matching label expression; jenkins-fw-01 is reserved for jobs with matching label expression; testops-w1 is reserved for jobs with matching label expression; testops-w3 is reserved for jobs with matching label expression
  * Task Dispatcher: com.cloudbees.hudson.plugins.folder.computed.ThrottleComputationQueueTaskDispatcher@2d97010f
    - Can run: null
  * Task Dispatcher: com.sonyericsson.hudson.plugins.gerrit.trigger.dependency.DependencyQueueTaskDispatcher@4bfe6df1
    - Can run: null
  * Task Dispatcher: com.sonyericsson.hudson.plugins.gerrit.trigger.replication.ReplicationQueueTaskDispatcher@43609961
    - Can run: null
  * Task Dispatcher: jenkins.branch.RateLimitBranchProperty$QueueTaskDispatcherImpl@4775659f
    - Can run: null
  * Task Dispatcher: org.jenkins.plugins.lockableresources.queue.LockableResourcesQueueTaskDispatcher@52ff8b07
    - Can run: null
  * Task Dispatcher: org.jenkinsci.plugins.durabletask.executors.ContinuedTask$Scheduler@6a56f54c
    - Can run: null
----

 * Name of item: F5 Meta Load Balancer (stream.cradlepointecm.com)
    - In queue for: 27 sec
    - Is blocked: false
    - Why in queue: Jenkins is reserved for jobs with matching label expression; jenkins-fw-01 is reserved for jobs with matching label expression; testops-w1 is reserved for jobs with matching label expression; testops-w3 is reserved for jobs with matching label expression
    - Current queue trigger cause: Started by timer
  * Task Dispatcher: com.cloudbees.hudson.plugins.folder.computed.ThrottleComputationQueueTaskDispatcher@2d97010f
    - Can run: null
  * Task Dispatcher: com.sonyericsson.hudson.plugins.gerrit.trigger.dependency.DependencyQueueTaskDispatcher@4bfe6df1
    - Can run: null
  * Task Dispatcher: com.sonyericsson.hudson.plugins.gerrit.trigger.replication.ReplicationQueueTaskDispatcher@43609961
    - Can run: null
  * Task Dispatcher: jenkins.branch.RateLimitBranchProperty$QueueTaskDispatcherImpl@4775659f
    - Can run: null
  * Task Dispatcher: org.jenkins.plugins.lockableresources.queue.LockableResourcesQueueTaskDispatcher@52ff8b07
    - Can run: null
  * Task Dispatcher: org.jenkinsci.plugins.durabletask.executors.ContinuedTask$Scheduler@6a56f54c
    - Can run: null
----

Is quieting down: false
