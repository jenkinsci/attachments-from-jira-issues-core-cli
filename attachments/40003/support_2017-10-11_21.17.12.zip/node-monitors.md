Node monitors
=============
Architecture
----
 - Is Ignored: false
 - Computers:
   * master: Linux (amd64)
   * jenkins-fw-01: Linux (amd64)
   * jenkins-w1: Linux (amd64)
   * jenkins-w10 (jenkinsw-vm4): Linux (amd64)
   * jenkins-w11 (jenkinsw-vm5): Linux (amd64)
   * jenkins-w2: Linux (amd64)
   * jenkins-w3: Linux (amd64)
   * jenkins-w4: Linux (amd64)
   * jenkins-w5: Linux (amd64)
   * jenkins-w6: Linux (amd64)
   * jenkins-w7 (jenkinsw-vm1): Linux (amd64)
   * jenkins-w8 (jenkinsw-vm2): Linux (amd64)
   * jenkins-w9 (jenkinsw-vm3): Linux (amd64)
   * testops-w1: Linux (amd64)
   * testops-w2: Linux (amd64)
   * testops-w3: Linux (amd64)
Clock Difference
----
 - Is Ignored: false
 - Computers:
   * master: In sync
   * jenkins-fw-01: 3 sec behind
   * jenkins-w1: In sync
   * jenkins-w10 (jenkinsw-vm4): In sync
   * jenkins-w11 (jenkinsw-vm5): In sync
   * jenkins-w2: In sync
   * jenkins-w3: In sync
   * jenkins-w4: In sync
   * jenkins-w5: In sync
   * jenkins-w6: In sync
   * jenkins-w7 (jenkinsw-vm1): In sync
   * jenkins-w8 (jenkinsw-vm2): In sync
   * jenkins-w9 (jenkinsw-vm3): In sync
   * testops-w1: In sync
   * testops-w2: In sync
   * testops-w3: In sync
Free Disk Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 245.642GB left on /var/lib/jenkins.
   * jenkins-fw-01: Disk space is too low. Only 172.922GB left on /home/jenkins.
   * jenkins-w1: Disk space is too low. Only 354.302GB left on /home/jenkins.
   * jenkins-w10 (jenkinsw-vm4): Disk space is too low. Only 393.312GB left on /home/ubuntu.
   * jenkins-w11 (jenkinsw-vm5): Disk space is too low. Only 383.753GB left on /home/ubuntu.
   * jenkins-w2: Disk space is too low. Only 365.001GB left on /home/jenkins.
   * jenkins-w3: Disk space is too low. Only 55.311GB left on /home/jenkins.
   * jenkins-w4: Disk space is too low. Only 85.075GB left on /home/jenkins.
   * jenkins-w5: Disk space is too low. Only 85.644GB left on /home/jenkins.
   * jenkins-w6: Disk space is too low. Only 57.282GB left on /home/jenkins.
   * jenkins-w7 (jenkinsw-vm1): Disk space is too low. Only 400.986GB left on /home/ubuntu.
   * jenkins-w8 (jenkinsw-vm2): Disk space is too low. Only 385.224GB left on /home/ubuntu.
   * jenkins-w9 (jenkinsw-vm3): Disk space is too low. Only 395.194GB left on /home/ubuntu.
   * testops-w1: Disk space is too low. Only 2.957GB left on /home/jenkins.
   * testops-w2: Disk space is too low. Only 20.328GB left on /home/jenkins.
   * testops-w3: Disk space is too low. Only 11.952GB left on /home/jenkins.
Free Swap Space
----
 - Is Ignored: false
 - Computers:
   * master: Memory:406/16047MB  Swap:16111/16379MB
   * jenkins-fw-01: Memory:4047/15936MB  Swap:15100/16270MB
   * jenkins-w1: Memory:88/15943MB  Swap:16163/16276MB
   * jenkins-w10 (jenkinsw-vm4): Memory:15513/16048MB  Swap:16379/16379MB
   * jenkins-w11 (jenkinsw-vm5): Memory:2861/16047MB  Swap:16238/16379MB
   * jenkins-w2: Memory:13706/15936MB  Swap:16270/16270MB
   * jenkins-w3: Memory:326/15041MB  Swap:15144/15355MB
   * jenkins-w4: Memory:833/15041MB  Swap:15273/15355MB
   * jenkins-w5: Memory:5291/15021MB  Swap:15275/15336MB
   * jenkins-w6: Memory:11632/15041MB  Swap:15317/15356MB
   * jenkins-w7 (jenkinsw-vm1): Memory:8933/16048MB  Swap:16238/16379MB
   * jenkins-w8 (jenkinsw-vm2): Memory:442/16048MB  Swap:16209/16379MB
   * jenkins-w9 (jenkinsw-vm3): Memory:2005/16048MB  Swap:16314/16379MB
   * testops-w1: Memory:878/7983MB  Swap:3468/4093MB
   * testops-w2: Memory:2198/7983MB  Swap:4061/4093MB
   * testops-w3: Memory:538/7983MB  Swap:3978/4093MB
Free Temp Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 245.642GB left on /tmp.
   * jenkins-fw-01: Disk space is too low. Only 4.095GB left on /tmp.
   * jenkins-w1: Disk space is too low. Only 354.302GB left on /tmp.
   * jenkins-w10 (jenkinsw-vm4): Disk space is too low. Only 393.312GB left on /tmp.
   * jenkins-w11 (jenkinsw-vm5): Disk space is too low. Only 383.753GB left on /tmp.
   * jenkins-w2: Disk space is too low. Only 365.001GB left on /tmp.
   * jenkins-w3: Disk space is too low. Only 55.311GB left on /tmp.
   * jenkins-w4: Disk space is too low. Only 85.075GB left on /tmp.
   * jenkins-w5: Disk space is too low. Only 85.644GB left on /tmp.
   * jenkins-w6: Disk space is too low. Only 57.282GB left on /tmp.
   * jenkins-w7 (jenkinsw-vm1): Disk space is too low. Only 400.986GB left on /tmp.
   * jenkins-w8 (jenkinsw-vm2): Disk space is too low. Only 385.224GB left on /tmp.
   * jenkins-w9 (jenkinsw-vm3): Disk space is too low. Only 395.194GB left on /tmp.
   * testops-w1: Disk space is too low. Only 2.957GB left on /tmp.
   * testops-w2: Disk space is too low. Only 20.328GB left on /tmp.
   * testops-w3: Disk space is too low. Only 11.952GB left on /tmp.
Response Time
----
 - Is Ignored: false
 - Computers:
   * master: 0ms
   * jenkins-fw-01: 47ms
   * jenkins-w1: 25ms
   * jenkins-w10 (jenkinsw-vm4): 25ms
   * jenkins-w11 (jenkinsw-vm5): 46ms
   * jenkins-w2: 61ms
   * jenkins-w3: 44ms
   * jenkins-w4: 11ms
   * jenkins-w5: 11ms
   * jenkins-w6: 10ms
   * jenkins-w7 (jenkinsw-vm1): 9ms
   * jenkins-w8 (jenkinsw-vm2): 42ms
   * jenkins-w9 (jenkinsw-vm3): 42ms
   * testops-w1: 7ms
   * testops-w2: 6ms
   * testops-w3: 41ms
