Item statistics
===============

  * `com.cloudbees.hudson.plugins.folder.Folder`
    - Number of items: 41
    - Number of items per container: 6.317073170731708 [n=41, s=7.0]
  * `hudson.matrix.MatrixConfiguration`
    - Number of items: 57
    - Number of builds per job: 19.45614035087719 [n=57, s=30.0]
  * `hudson.matrix.MatrixProject`
    - Number of items: 4
    - Number of builds per job: 29.75 [n=4, s=40.0]
    - Number of items per container: 14.25 [n=4, s=5.0]
  * `hudson.model.ExternalJob`
    - Number of items: 1
    - Number of builds per job: 0 [n=1]
  * `hudson.model.FreeStyleProject`
    - Number of items: 384
    - Number of builds per job: 71.3828125 [n=384, s=380.0]
  * `org.jenkinsci.plugins.workflow.job.WorkflowJob`
    - Number of items: 115
    - Number of builds per job: 72.37391304347825 [n=115, s=430.0]

Total job statistics
======================

  * Number of jobs: 561
  * Number of builds per job: 65.88591800356507 [n=561, s=370.0]
