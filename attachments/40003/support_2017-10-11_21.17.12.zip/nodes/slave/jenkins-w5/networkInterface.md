-----------
 * Name veth5c33caa
 ** Hardware Address - 06c2fe34dcb8
 ** Index - 29620
 ** InetAddress - /fe80:0:0:0:4c2:feff:fe34:dcb8%veth5c33caa
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-111f73050c1e
 ** Hardware Address - 024250fa43ea
 ** Index - 29616
 ** InetAddress - /fe80:0:0:0:42:50ff:fefa:43ea%br-111f73050c1e
 ** InetAddress - /172.23.0.1
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-b034b7e93577
 ** Hardware Address - 024202988a0f
 ** Index - 28889
 ** InetAddress - /fe80:0:0:0:42:2ff:fe98:8a0f%br-b034b7e93577
 ** InetAddress - /172.31.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-66fdc2cebc83
 ** Hardware Address - 0242277dcebc
 ** Index - 28728
 ** InetAddress - /fe80:0:0:0:42:27ff:fe7d:cebc%br-66fdc2cebc83
 ** InetAddress - /192.168.80.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-0ef096aff070
 ** Hardware Address - 0242d028dbd8
 ** Index - 28329
 ** InetAddress - /fe80:0:0:0:42:d0ff:fe28:dbd8%br-0ef096aff070
 ** InetAddress - /172.30.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-1654d5f7f3e4
 ** Hardware Address - 024253a55e64
 ** Index - 28322
 ** InetAddress - /fe80:0:0:0:42:53ff:fea5:5e64%br-1654d5f7f3e4
 ** InetAddress - /192.168.112.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-68bb017630de
 ** Hardware Address - 02420fcc5fcf
 ** Index - 28104
 ** InetAddress - /fe80:0:0:0:42:fff:fecc:5fcf%br-68bb017630de
 ** InetAddress - /172.26.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-c2a6f22574e6
 ** Hardware Address - 0242ae0e4a30
 ** Index - 27631
 ** InetAddress - /fe80:0:0:0:42:aeff:fe0e:4a30%br-c2a6f22574e6
 ** InetAddress - /192.168.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-3be10f6552ef
 ** Hardware Address - 0242900774bb
 ** Index - 26885
 ** InetAddress - /fe80:0:0:0:42:90ff:fe07:74bb%br-3be10f6552ef
 ** InetAddress - /192.168.96.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-cdc779e10c50
 ** Hardware Address - 0242fc253c88
 ** Index - 16973
 ** InetAddress - /fe80:0:0:0:42:fcff:fe25:3c88%br-cdc779e10c50
 ** InetAddress - /192.168.32.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-e6b32d9d66bf
 ** Hardware Address - 0242b0a1f3c5
 ** Index - 15174
 ** InetAddress - /fe80:0:0:0:42:b0ff:fea1:f3c5%br-e6b32d9d66bf
 ** InetAddress - /192.168.64.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-287b641894d2
 ** Hardware Address - 024215e77725
 ** Index - 5160
 ** InetAddress - /fe80:0:0:0:42:15ff:fee7:7725%br-287b641894d2
 ** InetAddress - /192.168.48.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-6b1d2200bf7c
 ** Hardware Address - 02422f965a51
 ** Index - 2802
 ** InetAddress - /fe80:0:0:0:42:2fff:fe96:5a51%br-6b1d2200bf7c
 ** InetAddress - /172.27.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-fce047270d26
 ** Hardware Address - 0242facc57c9
 ** Index - 20
 ** InetAddress - /fe80:0:0:0:42:faff:fecc:57c9%br-fce047270d26
 ** InetAddress - /172.25.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-20dcedc07df9
 ** Hardware Address - 0242ccddfd5e
 ** Index - 17
 ** InetAddress - /172.20.33.53
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-c29cd5e5117d
 ** Hardware Address - 0242cc84107c
 ** Index - 16
 ** InetAddress - /fe80:0:0:0:42:ccff:fe84:107c%br-c29cd5e5117d
 ** InetAddress - /172.24.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-b4fbbd46f1b7
 ** Hardware Address - 0242d7a34636
 ** Index - 15
 ** InetAddress - /172.21.33.53
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-396366833e60
 ** Hardware Address - 024245926bf0
 ** Index - 14
 ** InetAddress - /fe80:0:0:0:42:45ff:fe92:6bf0%br-396366833e60
 ** InetAddress - /172.28.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name docker0
 ** Hardware Address - 0242dfd67483
 ** Index - 10
 ** InetAddress - /fe80:0:0:0:42:dfff:fed6:7483%docker0
 ** InetAddress - /172.17.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-e57663d89075
 ** Hardware Address - 0242b9856c61
 ** Index - 9
 ** InetAddress - /172.19.33.53
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-673b0967c227
 ** Hardware Address - 024271db382a
 ** Index - 7
 ** InetAddress - /172.22.33.53
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-b6b178163801
 ** Hardware Address - 02426b975fb8
 ** Index - 5
 ** InetAddress - /172.18.33.53
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-ae78ee59c9a4
 ** Hardware Address - 0242373afbcb
 ** Index - 4
 ** InetAddress - /172.29.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-7f5a0ac21b7f
 ** Hardware Address - 024241c9a833
 ** Index - 3
 ** InetAddress - /fe80:0:0:0:42:41ff:fec9:a833%br-7f5a0ac21b7f
 ** InetAddress - /192.168.16.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name eth0
 ** Hardware Address - 52540050c3d0
 ** Index - 2
 ** InetAddress - /fe80:0:0:0:5054:ff:fe50:c3d0%eth0
 ** InetAddress - /172.19.9.153
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /0:0:0:0:0:0:0:1%lo
 ** InetAddress - /127.0.0.1
 ** MTU - 65536
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false
