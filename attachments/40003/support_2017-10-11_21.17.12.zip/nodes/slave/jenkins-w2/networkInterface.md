-----------
 * Name vetha7c25da
 ** Hardware Address - f645498b35b9
 ** Index - 42
 ** InetAddress - /fe80:0:0:0:f445:49ff:fe8b:35b9%vetha7c25da
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-acf38fb4cb93
 ** Hardware Address - 0242e45173f1
 ** Index - 26
 ** InetAddress - /172.18.33.53
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-4b4a4119b8e0
 ** Hardware Address - 024274f7adc2
 ** Index - 25
 ** InetAddress - /172.28.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-3c9c70436f65
 ** Hardware Address - 0242631650d9
 ** Index - 24
 ** InetAddress - /172.19.33.53
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-1955595e95a9
 ** Hardware Address - 024255fdc2a0
 ** Index - 23
 ** InetAddress - /172.26.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-d1704b2428b2
 ** Hardware Address - 0242758b0e54
 ** Index - 22
 ** InetAddress - /172.25.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-95602cf7af73
 ** Hardware Address - 0242eeb358b8
 ** Index - 21
 ** InetAddress - /172.27.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-693d551f29df
 ** Hardware Address - 0242703cc839
 ** Index - 20
 ** InetAddress - /172.22.33.53
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-59a8fd72a493
 ** Hardware Address - 0242fb3a473c
 ** Index - 19
 ** InetAddress - /192.168.16.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-4fac91352259
 ** Hardware Address - 0242ace1a884
 ** Index - 18
 ** InetAddress - /172.29.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-0167f4420764
 ** Hardware Address - 02421695aace
 ** Index - 17
 ** InetAddress - /172.24.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-f99db34d7bd1
 ** Hardware Address - 0242047864cc
 ** Index - 16
 ** InetAddress - /172.21.33.53
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name docker0
 ** Hardware Address - 0242a39f6243
 ** Index - 15
 ** InetAddress - /fe80:0:0:0:42:a3ff:fe9f:6243%docker0
 ** InetAddress - /172.17.0.1
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-ce1c36fb6beb
 ** Hardware Address - 024257799a9f
 ** Index - 14
 ** InetAddress - /172.30.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-a63474abadbf
 ** Hardware Address - 0242d5ac8ee1
 ** Index - 13
 ** InetAddress - /192.168.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-125b026715db
 ** Hardware Address - 02423bb42915
 ** Index - 12
 ** InetAddress - /192.168.48.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-10e5db278047
 ** Hardware Address - 02422ffb8801
 ** Index - 11
 ** InetAddress - /172.31.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-0269aabee269
 ** Hardware Address - 0242e7a1fd18
 ** Index - 10
 ** InetAddress - /172.20.33.53
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-e7d913d0760c
 ** Hardware Address - 0242a5d827f2
 ** Index - 9
 ** InetAddress - /192.168.64.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-e408dc421bd5
 ** Hardware Address - 02421f937d55
 ** Index - 8
 ** InetAddress - /172.23.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-d0832e40f0d8
 ** Hardware Address - 0242d687de0b
 ** Index - 7
 ** InetAddress - /192.168.80.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-7360fa132840
 ** Hardware Address - 0242f9c7bedf
 ** Index - 6
 ** InetAddress - /192.168.96.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-48cdc9b54ad6
 ** Hardware Address - 02427a5a8ed6
 ** Index - 5
 ** InetAddress - /192.168.32.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name p2p1
 ** Hardware Address - 80ee7395cc40
 ** Index - 2
 ** InetAddress - /fe80:0:0:0:82ee:73ff:fe95:cc40%p2p1
 ** InetAddress - /172.19.10.202
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /0:0:0:0:0:0:0:1%lo
 ** InetAddress - /127.0.0.1
 ** MTU - 65536
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false
