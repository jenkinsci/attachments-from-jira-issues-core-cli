-----------
 * Name br-068df720afc2
 ** Hardware Address - 024209a69f0c
 ** Index - 22320
 ** InetAddress - /192.168.128.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-45235697f3c7
 ** Hardware Address - 02422f36a86f
 ** Index - 22213
 ** InetAddress - /172.24.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-de9a6dfcd5e4
 ** Hardware Address - 02427cde5d76
 ** Index - 22134
 ** InetAddress - /172.26.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-e9523e63d122
 ** Hardware Address - 0242ad05bdb3
 ** Index - 22127
 ** InetAddress - /172.23.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-09754008db97
 ** Hardware Address - 02421ec27cdc
 ** Index - 18677
 ** InetAddress - /192.168.112.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-51c9c76dd6d4
 ** Hardware Address - 02422b14f92d
 ** Index - 16688
 ** InetAddress - /192.168.176.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-a2c04ae65111
 ** Hardware Address - 024296c21736
 ** Index - 10854
 ** InetAddress - /192.168.64.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-d942648f23fd
 ** Hardware Address - 02422f71d206
 ** Index - 8172
 ** InetAddress - /192.168.144.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-9d4f28bdecd4
 ** Hardware Address - 0242c9f72513
 ** Index - 2891
 ** InetAddress - /172.25.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-5bfa7fccdb52
 ** Hardware Address - 024281468fd0
 ** Index - 1428
 ** InetAddress - /172.31.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-cd5eefe45306
 ** Hardware Address - 02425b12adc9
 ** Index - 24
 ** InetAddress - /172.18.33.53
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-b0a8cf2f402d
 ** Hardware Address - 024270e9f78c
 ** Index - 23
 ** InetAddress - /172.19.33.53
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-9c9d3ac9b767
 ** Hardware Address - 0242dd307687
 ** Index - 22
 ** InetAddress - /192.168.80.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-989248b3895e
 ** Hardware Address - 024286c196b0
 ** Index - 21
 ** InetAddress - /192.168.48.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-f96ed39f7212
 ** Hardware Address - 0242b2070380
 ** Index - 19
 ** InetAddress - /172.20.33.53
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-b6a270e67ad6
 ** Hardware Address - 0242496a10b2
 ** Index - 18
 ** InetAddress - /172.30.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-9eedf89cfdd5
 ** Hardware Address - 0242d1cff802
 ** Index - 17
 ** InetAddress - /172.21.33.53
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-7a440feb5638
 ** Hardware Address - 0242da3cb041
 ** Index - 15
 ** InetAddress - /172.28.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-ef20c7424a07
 ** Hardware Address - 0242e9b7c7a4
 ** Index - 14
 ** InetAddress - /192.168.96.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-d0e3c6f0dbdb
 ** Hardware Address - 02421451be09
 ** Index - 13
 ** InetAddress - /192.168.16.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-9d1a17535914
 ** Hardware Address - 02425371817c
 ** Index - 11
 ** InetAddress - /172.22.33.53
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-8c247ca4e9dd
 ** Hardware Address - 0242800a9237
 ** Index - 10
 ** InetAddress - /172.29.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name docker0
 ** Hardware Address - 02424ab6380a
 ** Index - 8
 ** InetAddress - /172.17.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-35f078df1578
 ** Hardware Address - 0242c1b378c5
 ** Index - 7
 ** InetAddress - /192.168.32.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-0c29a0704172
 ** Hardware Address - 02427d5e3a0d
 ** Index - 3
 ** InetAddress - /172.27.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name eth0
 ** Hardware Address - 005056b32b8e
 ** Index - 2
 ** InetAddress - /172.21.21.131
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /127.0.0.1
 ** MTU - 65536
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false
