-----------
 * Name br-02bff67e36eb
 ** Hardware Address - 0242c6e5b710
 ** Index - 4805
 ** InetAddress - /fe80:0:0:0:42:c6ff:fee5:b710%br-02bff67e36eb
 ** InetAddress - /172.23.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-43a2ef8fbaef
 ** Hardware Address - 02428c8bddd3
 ** Index - 11
 ** InetAddress - /172.19.33.53
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-708c7634766a
 ** Hardware Address - 0242cf960851
 ** Index - 10
 ** InetAddress - /172.18.33.53
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name docker0
 ** Hardware Address - 0242d8f92c5b
 ** Index - 9
 ** InetAddress - /fe80:0:0:0:42:d8ff:fef9:2c5b%docker0
 ** InetAddress - /172.17.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-46370de93eca
 ** Hardware Address - 0242ab7aec29
 ** Index - 8
 ** InetAddress - /fe80:0:0:0:42:abff:fe7a:ec29%br-46370de93eca
 ** InetAddress - /172.24.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-1e9fe08c9b55
 ** Hardware Address - 024257b2fe3d
 ** Index - 7
 ** InetAddress - /172.21.33.53
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-c233ecc2ed77
 ** Hardware Address - 024240b81899
 ** Index - 6
 ** InetAddress - /172.20.33.53
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-46d4c53b63a6
 ** Hardware Address - 024207a7f799
 ** Index - 4
 ** InetAddress - /172.25.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-3a9e3adf86b1
 ** Hardware Address - 02421cbd33de
 ** Index - 3
 ** InetAddress - /172.22.33.53
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name eth0
 ** Hardware Address - 5254006bae5c
 ** Index - 2
 ** InetAddress - /fe80:0:0:0:5054:ff:fe6b:ae5c%eth0
 ** InetAddress - /172.19.10.48
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /0:0:0:0:0:0:0:1%lo
 ** InetAddress - /127.0.0.1
 ** MTU - 65536
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false
