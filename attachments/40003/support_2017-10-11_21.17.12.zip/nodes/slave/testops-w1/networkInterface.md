-----------
 * Name br-b058b0d31b5b
 ** Hardware Address - 0242090579ad
 ** Index - 8369
 ** InetAddress - /fe80:0:0:0:42:9ff:fe05:79ad%br-b058b0d31b5b
 ** InetAddress - /172.23.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name docker0
 ** Hardware Address - 0242b74f71f1
 ** Index - 13
 ** InetAddress - /fe80:0:0:0:42:b7ff:fe4f:71f1%docker0
 ** InetAddress - /172.17.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-5884380428db
 ** Hardware Address - 0242160f8861
 ** Index - 12
 ** InetAddress - /172.18.33.53
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-34723b05fcd5
 ** Hardware Address - 024274dba297
 ** Index - 11
 ** InetAddress - /172.21.33.53
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-2a6abf2c014c
 ** Hardware Address - 024297aa91e8
 ** Index - 10
 ** InetAddress - /fe80:0:0:0:42:97ff:feaa:91e8%br-2a6abf2c014c
 ** InetAddress - /172.24.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-ec427bc28a10
 ** Hardware Address - 0242e0a1d936
 ** Index - 9
 ** InetAddress - /172.26.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-dd8b5814592c
 ** Hardware Address - 024256d953c7
 ** Index - 8
 ** InetAddress - /172.22.33.53
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-ccb1b6b8100d
 ** Hardware Address - 024258485139
 ** Index - 7
 ** InetAddress - /172.19.33.53
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-98d400b3798c
 ** Hardware Address - 02427be3a922
 ** Index - 5
 ** InetAddress - /172.20.33.53
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-85be8840bd56
 ** Hardware Address - 024247dccf2a
 ** Index - 4
 ** InetAddress - /172.25.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name virbr0
 ** Hardware Address - c2f1b99cdcc6
 ** Index - 3
 ** InetAddress - /192.168.122.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name eth0
 ** Hardware Address - 5254004a8e60
 ** Index - 2
 ** InetAddress - /fe80:0:0:0:5054:ff:fe4a:8e60%eth0
 ** InetAddress - /172.19.10.4
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /0:0:0:0:0:0:0:1%lo
 ** InetAddress - /127.0.0.1
 ** MTU - 65536
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false
