-----------
 * Name br-f3acc5912e6e
 ** Hardware Address - 0242c2bd6f3d
 ** Index - 35378
 ** InetAddress - /172.26.0.1
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-3c539d246345
 ** Hardware Address - 024230b7e316
 ** Index - 34835
 ** InetAddress - /192.168.128.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-9bf4b486369b
 ** Hardware Address - 0242a376577c
 ** Index - 34691
 ** InetAddress - /192.168.48.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-df130c248da3
 ** Hardware Address - 0242b2777653
 ** Index - 33507
 ** InetAddress - /172.29.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-0848f4dfd011
 ** Hardware Address - 02420551d6b6
 ** Index - 32926
 ** InetAddress - /192.168.64.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-ffce4662662a
 ** Hardware Address - 0242d7f087ba
 ** Index - 31782
 ** InetAddress - /192.168.144.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-8d0becabd438
 ** Hardware Address - 02429d57dbcf
 ** Index - 24831
 ** InetAddress - /172.31.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-ad52bf070a28
 ** Hardware Address - 0242eebd3afa
 ** Index - 23954
 ** InetAddress - /192.168.96.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-632cae8d0f2c
 ** Hardware Address - 02428b56e2f7
 ** Index - 22594
 ** InetAddress - /192.168.112.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-076aa941da21
 ** Hardware Address - 0242d9d11d5e
 ** Index - 10602
 ** InetAddress - /172.24.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-0cf2d1255b83
 ** Hardware Address - 0242a0d03716
 ** Index - 10597
 ** InetAddress - /172.23.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-c93b873af13f
 ** Hardware Address - 024223d17d89
 ** Index - 9099
 ** InetAddress - /192.168.32.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-25310b5fe934
 ** Hardware Address - 02428925e985
 ** Index - 1685
 ** InetAddress - /192.168.80.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-b97b6a21afe1
 ** Hardware Address - 024270f529d1
 ** Index - 20
 ** InetAddress - /172.28.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-a4cdb59524b5
 ** Hardware Address - 02429de5c55e
 ** Index - 19
 ** InetAddress - /172.18.33.53
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-9de5526ed8b7
 ** Hardware Address - 02429dc0b165
 ** Index - 18
 ** InetAddress - /172.19.33.53
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-ac6d7c410881
 ** Hardware Address - 024221dbf379
 ** Index - 16
 ** InetAddress - /172.20.33.53
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-abd9f613869c
 ** Hardware Address - 0242f0acdb43
 ** Index - 15
 ** InetAddress - /172.25.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-73ef65c9d477
 ** Hardware Address - 0242901bae77
 ** Index - 14
 ** InetAddress - /172.22.33.53
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name docker0
 ** Hardware Address - 02427bf1ece5
 ** Index - 12
 ** InetAddress - /172.17.42.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-fa6829a82bd3
 ** Hardware Address - 0242cc00493d
 ** Index - 11
 ** InetAddress - /192.168.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-cdde624a7032
 ** Hardware Address - 0242fe19c2e2
 ** Index - 9
 ** InetAddress - /172.21.33.53
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-853a99969edc
 ** Hardware Address - 024242265ff7
 ** Index - 7
 ** InetAddress - /172.30.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-608a6846414e
 ** Hardware Address - 0242f3c86e8b
 ** Index - 5
 ** InetAddress - /172.27.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-7c3638384a39
 ** Hardware Address - 0242c41312c5
 ** Index - 4
 ** InetAddress - /192.168.16.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name eth0
 ** Hardware Address - 52540040db93
 ** Index - 2
 ** InetAddress - /172.19.9.190
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /127.0.0.1
 ** MTU - 65536
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false
