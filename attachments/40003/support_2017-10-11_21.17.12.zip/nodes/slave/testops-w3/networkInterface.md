-----------
 * Name coco_br0
 ** Hardware Address - 5254009d59d6
 ** Index - 13
 ** InetAddress - /fe80:0:0:0:5054:ff:fe9d:59d6%coco_br0
 ** InetAddress - /172.19.9.255
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name coconut_br0
 ** Index - 12
 ** InetAddress - /fe80:0:0:0:5054:ff:fe9d:59d6%coconut_br0
 ** InetAddress - /172.19.9.255
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-9093bc38f65d
 ** Hardware Address - 024271247169
 ** Index - 11
 ** InetAddress - /172.25.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-88e8aa10613d
 ** Hardware Address - 0242da621af9
 ** Index - 10
 ** InetAddress - /172.19.33.53
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-7411ad011b11
 ** Hardware Address - 024261c66a78
 ** Index - 9
 ** InetAddress - /172.24.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-6045a63b09ea
 ** Hardware Address - 0242965898c2
 ** Index - 8
 ** InetAddress - /172.20.33.53
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-4be5f679a713
 ** Hardware Address - 02423b53a0a6
 ** Index - 7
 ** InetAddress - /172.21.33.53
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-f18e2c433993
 ** Hardware Address - 02422b9669ac
 ** Index - 6
 ** InetAddress - /172.18.33.53
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name docker0
 ** Hardware Address - 0242d5deeaa4
 ** Index - 5
 ** InetAddress - /fe80:0:0:0:42:d5ff:fede:eaa4%docker0
 ** InetAddress - /172.17.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-bfd8cfd825e5
 ** Hardware Address - 02423f63621e
 ** Index - 4
 ** InetAddress - /172.23.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-b84a52817a1c
 ** Hardware Address - 0242bf9400c0
 ** Index - 3
 ** InetAddress - /172.22.33.53
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name eth0
 ** Hardware Address - 5254009d59d6
 ** Index - 2
 ** InetAddress - /fe80:0:0:0:5054:ff:fe9d:59d6%eth0
 ** InetAddress - /172.19.9.255
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /0:0:0:0:0:0:0:1%lo
 ** InetAddress - /127.0.0.1
 ** MTU - 65536
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false
