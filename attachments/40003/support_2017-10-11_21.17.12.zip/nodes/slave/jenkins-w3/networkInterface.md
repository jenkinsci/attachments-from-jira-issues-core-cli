-----------
 * Name br-d1369e881736
 ** Hardware Address - 0242c32a31d9
 ** Index - 32586
 ** InetAddress - /192.168.80.1
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-f39887d4a0ef
 ** Hardware Address - 0242527c45bf
 ** Index - 32554
 ** InetAddress - /192.168.160.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-8f14a8b6b291
 ** Hardware Address - 02428f094215
 ** Index - 32391
 ** InetAddress - /172.23.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-032de4e2de71
 ** Hardware Address - 02426ec7775d
 ** Index - 32241
 ** InetAddress - /172.28.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-e4f74fd1e70a
 ** Hardware Address - 02426cdc0b91
 ** Index - 31968
 ** InetAddress - /172.27.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-cddf14480c17
 ** Hardware Address - 0242ed12c85c
 ** Index - 30738
 ** InetAddress - /192.168.64.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-c5fc02e2463b
 ** Hardware Address - 0242ec0f765f
 ** Index - 30403
 ** InetAddress - /192.168.128.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-3632c01c9ca9
 ** Hardware Address - 0242841ca81c
 ** Index - 26370
 ** InetAddress - /192.168.112.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-38e85afe314c
 ** Hardware Address - 0242edd07d11
 ** Index - 22771
 ** InetAddress - /172.30.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-9196dd29c62e
 ** Hardware Address - 0242315bf9c6
 ** Index - 19484
 ** InetAddress - /192.168.144.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-40e712ab06fc
 ** Hardware Address - 02423143f597
 ** Index - 14364
 ** InetAddress - /192.168.48.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-ca30e7b57c9c
 ** Hardware Address - 0242c82c48d6
 ** Index - 5276
 ** InetAddress - /192.168.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-7f0d7ea9bfeb
 ** Hardware Address - 0242d2e0435f
 ** Index - 5089
 ** InetAddress - /192.168.96.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-b8e694351eff
 ** Hardware Address - 024279548f25
 ** Index - 3709
 ** InetAddress - /172.24.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-7d8429891de7
 ** Hardware Address - 02420378d36b
 ** Index - 1038
 ** InetAddress - /192.168.32.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-73716dd351de
 ** Hardware Address - 0242084a0c52
 ** Index - 99
 ** InetAddress - /192.168.16.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-f9f96d31e5ff
 ** Hardware Address - 02423721a7a1
 ** Index - 17
 ** InetAddress - /172.25.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-f5fefebe96e3
 ** Hardware Address - 024268608fa1
 ** Index - 16
 ** InetAddress - /172.31.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-9e47d8438d1f
 ** Hardware Address - 0242b7e0cb5e
 ** Index - 15
 ** InetAddress - /172.22.33.53
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name docker0
 ** Hardware Address - 0242cff89f02
 ** Index - 14
 ** InetAddress - /172.17.42.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-384838a02a9d
 ** Hardware Address - 024269b866d1
 ** Index - 12
 ** InetAddress - /172.18.33.53
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-4b9d881127bc
 ** Hardware Address - 0242f6051cb6
 ** Index - 10
 ** InetAddress - /172.26.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-085d33125e86
 ** Hardware Address - 02421babda64
 ** Index - 9
 ** InetAddress - /172.21.33.53
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-bc96dc5aea04
 ** Hardware Address - 0242ba4f91a7
 ** Index - 8
 ** InetAddress - /172.19.33.53
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-ee179e44ebca
 ** Hardware Address - 024237ee7124
 ** Index - 5
 ** InetAddress - /172.20.33.53
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-9b86e34926e3
 ** Hardware Address - 0242a300a272
 ** Index - 4
 ** InetAddress - /172.29.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name eth0
 ** Hardware Address - 52540030c496
 ** Index - 2
 ** InetAddress - /172.19.9.76
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /127.0.0.1
 ** MTU - 65536
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false
