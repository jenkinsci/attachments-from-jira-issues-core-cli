-----------
 * Name veth27d625e
 ** Hardware Address - 362c10bed716
 ** Index - 11927
 ** InetAddress - /fe80:0:0:0:342c:10ff:febe:d716%veth27d625e
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name veth90b8659
 ** Hardware Address - 028fa9f12bb2
 ** Index - 11869
 ** InetAddress - /fe80:0:0:0:8f:a9ff:fef1:2bb2%veth90b8659
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name vethccf5792
 ** Hardware Address - 5e7bfd0fb281
 ** Index - 11917
 ** InetAddress - /fe80:0:0:0:5c7b:fdff:fe0f:b281%vethccf5792
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name vetha743653
 ** Hardware Address - 0e9cd44a5d40
 ** Index - 11865
 ** InetAddress - /fe80:0:0:0:c9c:d4ff:fe4a:5d40%vetha743653
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name veth7f85fe8
 ** Hardware Address - a26c26e01acc
 ** Index - 11871
 ** InetAddress - /fe80:0:0:0:a06c:26ff:fee0:1acc%veth7f85fe8
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name veth353d98e
 ** Hardware Address - c2d48b196b90
 ** Index - 11873
 ** InetAddress - /fe80:0:0:0:c0d4:8bff:fe19:6b90%veth353d98e
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name veth2591189
 ** Hardware Address - 16079fb97b13
 ** Index - 11855
 ** InetAddress - /fe80:0:0:0:1407:9fff:feb9:7b13%veth2591189
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name veth3dc7350
 ** Hardware Address - 761239eb671c
 ** Index - 11929
 ** InetAddress - /fe80:0:0:0:7412:39ff:feeb:671c%veth3dc7350
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name vethe1b610c
 ** Hardware Address - 0229328ddb1c
 ** Index - 11933
 ** InetAddress - /fe80:0:0:0:29:32ff:fe8d:db1c%vethe1b610c
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name veth01ec4b2
 ** Hardware Address - ea62d36f6d29
 ** Index - 11921
 ** InetAddress - /fe80:0:0:0:e862:d3ff:fe6f:6d29%veth01ec4b2
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name veth1e88df6
 ** Hardware Address - 168f395f8b57
 ** Index - 11863
 ** InetAddress - /fe80:0:0:0:148f:39ff:fe5f:8b57%veth1e88df6
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name veth742a288
 ** Hardware Address - 026e00edb873
 ** Index - 11919
 ** InetAddress - /fe80:0:0:0:6e:ff:feed:b873%veth742a288
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name veth2239abe
 ** Hardware Address - 2a6d5031f5d7
 ** Index - 11859
 ** InetAddress - /fe80:0:0:0:286d:50ff:fe31:f5d7%veth2239abe
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name veth0544c19
 ** Hardware Address - ca81a68c94c9
 ** Index - 11853
 ** InetAddress - /fe80:0:0:0:c881:a6ff:fe8c:94c9%veth0544c19
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name veth8860505
 ** Hardware Address - 6e0ae61b6ac8
 ** Index - 11923
 ** InetAddress - /fe80:0:0:0:6c0a:e6ff:fe1b:6ac8%veth8860505
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name veth7a9129d
 ** Hardware Address - 9629d90b9a40
 ** Index - 11867
 ** InetAddress - /fe80:0:0:0:9429:d9ff:fe0b:9a40%veth7a9129d
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name vethad2c518
 ** Hardware Address - 7ef5ffbc08c8
 ** Index - 11925
 ** InetAddress - /fe80:0:0:0:7cf5:ffff:febc:8c8%vethad2c518
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-19dc5e780bad
 ** Hardware Address - 0242f8782c7a
 ** Index - 11561
 ** InetAddress - /fe80:0:0:0:42:f8ff:fe78:2c7a%br-19dc5e780bad
 ** InetAddress - /172.26.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-5acb2dc1ea18
 ** Hardware Address - 02425c1e9d8d
 ** Index - 11193
 ** InetAddress - /fe80:0:0:0:42:5cff:fe1e:9d8d%br-5acb2dc1ea18
 ** InetAddress - /172.23.0.1
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-e398e6e2cac7
 ** Hardware Address - 0242fa12f138
 ** Index - 10227
 ** InetAddress - /fe80:0:0:0:42:faff:fe12:f138%br-e398e6e2cac7
 ** InetAddress - /192.168.96.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-98d612cd7b48
 ** Hardware Address - 0242308afd8a
 ** Index - 9632
 ** InetAddress - /fe80:0:0:0:42:30ff:fe8a:fd8a%br-98d612cd7b48
 ** InetAddress - /192.168.112.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-2fdd6ba8e7a6
 ** Hardware Address - 024267db6370
 ** Index - 1743
 ** InetAddress - /fe80:0:0:0:42:67ff:fedb:6370%br-2fdd6ba8e7a6
 ** InetAddress - /192.168.48.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-2f37e39b4621
 ** Hardware Address - 02425a688ca7
 ** Index - 22
 ** InetAddress - /172.30.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-1861421468ff
 ** Hardware Address - 0242ee78b03e
 ** Index - 21
 ** InetAddress - /172.28.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-cf87332ee0f4
 ** Hardware Address - 0242d2d86b0a
 ** Index - 20
 ** InetAddress - /fe80:0:0:0:42:d2ff:fed8:6b0a%br-cf87332ee0f4
 ** InetAddress - /192.168.64.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-9fef4e39029e
 ** Hardware Address - 0242dffcc733
 ** Index - 19
 ** InetAddress - /fe80:0:0:0:42:dfff:fefc:c733%br-9fef4e39029e
 ** InetAddress - /192.168.32.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-85d66cbf164f
 ** Hardware Address - 02424b4cd7ba
 ** Index - 18
 ** InetAddress - /172.20.33.53
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-4e26cdf4b3e0
 ** Hardware Address - 024293435d92
 ** Index - 16
 ** InetAddress - /172.21.33.53
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-3d1bf911846f
 ** Hardware Address - 0242fc309a1f
 ** Index - 15
 ** InetAddress - /192.168.16.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name docker0
 ** Hardware Address - 0242ce54cd36
 ** Index - 14
 ** InetAddress - /fe80:0:0:0:42:ceff:fe54:cd36%docker0
 ** InetAddress - /172.17.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-a08de646db4e
 ** Hardware Address - 024222ca8dea
 ** Index - 13
 ** InetAddress - /192.168.80.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-65d574c18f35
 ** Hardware Address - 0242c3005693
 ** Index - 12
 ** InetAddress - /172.25.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-4def3f172002
 ** Hardware Address - 024292fe3047
 ** Index - 11
 ** InetAddress - /fe80:0:0:0:42:92ff:fefe:3047%br-4def3f172002
 ** InetAddress - /172.27.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-3ebb0ffdd997
 ** Hardware Address - 0242cb39516c
 ** Index - 10
 ** InetAddress - /172.19.33.53
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-1430262156a5
 ** Hardware Address - 02422bb185d8
 ** Index - 9
 ** InetAddress - /172.18.33.53
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-5e46ee7228bd
 ** Hardware Address - 0242b0b892da
 ** Index - 7
 ** InetAddress - /fe80:0:0:0:42:b0ff:feb8:92da%br-5e46ee7228bd
 ** InetAddress - /172.29.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-2b3ebb328a95
 ** Hardware Address - 02423192c505
 ** Index - 6
 ** InetAddress - /172.22.33.53
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-928936ebfbbe
 ** Hardware Address - 02422b2de76f
 ** Index - 5
 ** InetAddress - /192.168.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-905fcce61d57
 ** Hardware Address - 024214256d94
 ** Index - 4
 ** InetAddress - /172.31.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name br-88acfa2f7216
 ** Hardware Address - 0242021dba63
 ** Index - 3
 ** InetAddress - /fe80:0:0:0:42:2ff:fe1d:ba63%br-88acfa2f7216
 ** InetAddress - /172.24.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name eth0
 ** Hardware Address - 005056b3b5d8
 ** Index - 2
 ** InetAddress - /fe80:0:0:0:250:56ff:feb3:b5d8%eth0
 ** InetAddress - /172.21.21.129
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /0:0:0:0:0:0:0:1%lo
 ** InetAddress - /127.0.0.1
 ** MTU - 65536
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false
