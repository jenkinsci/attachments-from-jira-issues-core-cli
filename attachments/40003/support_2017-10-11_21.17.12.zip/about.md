Jenkins
=======

Version details
---------------

  * Version: `2.70`
  * Mode:    WAR
  * Url:     https://jenkins.cradlepoint.com/
  * Servlet container
      - Specification: 3.1
      - Name:          `jetty/9.4.z-SNAPSHOT`
  * Java
      - Home:           `/usr/lib/jvm/java-8-oracle/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0_131
      - Maximum memory:   3.48 GB (3739746304)
      - Allocated memory: 3.14 GB (3375366144)
      - Free memory:      1.16 GB (1250674528)
      - In-use memory:    1.98 GB (2124691616)
      - GC strategy:      ParallelGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    Java HotSpot(TM) 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 25.131-b11
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      4.4.0-62-generic
      - Distribution: Ubuntu 14.04.5 LTS
  * Process ID: 16440 (0x4038)
  * Process started: 2017-08-23 18:48:52.342+0000
  * Process uptime: 1 mo 19 days
  * JVM startup parameters:
      - Boot classpath: `/usr/lib/jvm/java-8-oracle/jre/lib/resources.jar:/usr/lib/jvm/java-8-oracle/jre/lib/rt.jar:/usr/lib/jvm/java-8-oracle/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jsse.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jce.jar:/usr/lib/jvm/java-8-oracle/jre/lib/charsets.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jfr.jar:/usr/lib/jvm/java-8-oracle/jre/classes`
      - Classpath: `/usr/share/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
      - arg[0]: `-Djava.awt.headless=true`

Important configuration
---------------

  * Security realm: `hudson.security.LDAPSecurityRealm`
  * Authorization strategy: `hudson.security.ProjectMatrixAuthorizationStrategy`
  * CSRF Protection: false
  * Initialization Milestone: Completed initialization

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * ant:1.7 'Ant Plugin'
  * antisamy-markup-formatter:1.5 'OWASP Markup Formatter Plugin'
  * authentication-tokens:1.3 'Authentication Tokens API Plugin'
  * aws-credentials:1.21 *(update available)* 'CloudBees Amazon Web Services Credentials Plugin'
  * aws-java-sdk:1.11.119 'Amazon Web Services SDK'
  * bouncycastle-api:2.16.2 'bouncycastle API Plugin'
  * branch-api:2.0.11 *(update available)* 'Branch API Plugin'
  * build-pipeline-plugin:1.5.7.1 'Build Pipeline Plugin'
  * build-timeout:1.18 *(update available)* 'Jenkins build timeout plugin'
  * changes-since-last-success:0.5 'Changes since last successfull build Plugin'
  * cloudbees-folder:6.1.2 *(update available)* 'Folders Plugin'
  * cobertura:1.11 'Jenkins Cobertura Plugin'
  * conditional-buildstep:1.3.6 'Conditional BuildStep'
  * configurationslicing:1.47 'Configuration Slicing plugin'
  * copyartifact:1.38.1 'Copy Artifact Plugin'
  * credentials:2.1.14 *(update available)* 'Credentials Plugin'
  * credentials-binding:1.13 'Credentials Binding Plugin'
  * cvs:2.13 'Jenkins CVS Plug-in'
  * discard-old-build:1.05 'Discard Old Build plugin'
  * disk-usage:0.28 'Jenkins disk-usage plugin'
  * display-url-api:2.0 *(update available)* 'Display URL API'
  * docker-commons:1.8 *(update available)* 'Docker Commons Plugin'
  * docker-workflow:1.12 *(update available)* 'Docker Pipeline'
  * durable-task:1.14 'Durable Task Plugin'
  * ec2:1.36 *(update available)* 'Amazon EC2 plugin'
  * email-ext:2.58 *(update available)* 'Email Extension Plugin'
  * envinject:2.1.3 *(update available)* 'Environment Injector Plugin'
  * envinject-api:1.2 *(update available)* 'EnvInject API Plugin'
  * extended-choice-parameter:0.76 'Extended Choice Parameter Plug-In'
  * external-monitor-job:1.7 'External Monitor Job Type Plugin'
  * gerrit-trigger:2.25.0 *(update available)* 'Gerrit Trigger'
  * git:3.5.1 *(update available)* 'Jenkins Git plugin'
  * git-changelog:1.51 *(update available)* 'Git Changelog'
  * git-client:2.5.0 'Jenkins Git client plugin'
  * git-parameter:0.8.0 *(update available)* 'Git Parameter Plug-In'
  * git-server:1.7 'Jenkins GIT server Plugin'
  * gitlab-hook:1.4.2 'Gitlab Hook Plugin'
  * gitlab-merge-request-jenkins:2.0.0 'Gitlab Merge Request Builder'
  * gitlab-plugin:1.4.7 *(update available)* 'GitLab Plugin'
  * groovy-postbuild:2.3.1 'Groovy Postbuild'
  * handlebars:1.1.1 'JavaScript GUI Lib: Handlebars bundle plugin'
  * hidden-parameter:0.0.4 'Hidden Parameter plugin'
  * hipchat:2.1.1 'Jenkins HipChat Plugin'
  * icon-shim:2.0.3 'Icon Shim Plugin'
  * instant-messaging:1.35 'Jenkins instant-messaging plugin'
  * jabber:1.36 'Jenkins Jabber (XMPP) notifier and control plugin'
  * jackson2-api:2.7.3 *(update available)* 'Jackson 2 API Plugin'
  * jacoco:2.2.1 'Jenkins JaCoCo plugin'
  * javadoc:1.4 'Javadoc Plugin'
  * jira-steps:1.2.3 'JIRA Pipeline Steps'
  * job-dsl:1.64 *(update available)* 'Job DSL'
  * jobConfigHistory:2.17 *(update available)* 'Jenkins Job Configuration History Plugin'
  * jquery:1.11.2-0 *(update available)* 'Jenkins jQuery plugin'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * junit:1.21 'JUnit Plugin'
  * ldap:1.16 *(update available)* 'LDAP Plugin'
  * lockable-resources:2.0 'Lockable Resources plugin'
  * mailer:1.20 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.9.0 'MapDB API Plugin'
  * mask-passwords:2.10.1 'Mask Passwords Plugin'
  * matrix-auth:1.7 *(update available)* 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.11 *(update available)* 'Matrix Project Plugin'
  * maven-plugin:2.17 *(update available)* 'Maven Integration plugin'
  * mercurial:2.0 *(update available)* 'Jenkins Mercurial plugin'
  * metrics:3.1.2.10 'Metrics Plugin'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * multiple-scms:0.6 'Jenkins Multiple SCMs plugin'
  * naginator:1.17.2 'Naginator'
  * next-build-number:1.4 'Next Build Number Plugin'
  * node-iterator-api:1.5 'Node Iterator API Plugin'
  * pam-auth:1.3 'PAM Authentication plugin'
  * parameterized-trigger:2.35.1 *(update available)* 'Jenkins Parameterized Trigger plugin'
  * pipeline-build-step:2.5.1 'Pipeline: Build Step'
  * pipeline-graph-analysis:1.5 'Pipeline Graph Analysis Plugin'
  * pipeline-input-step:2.8 'Pipeline: Input Step'
  * pipeline-milestone-step:1.3.1 'Pipeline: Milestone Step'
  * pipeline-model-api:1.1.9 *(update available)* 'Pipeline: Model API'
  * pipeline-model-declarative-agent:1.1.1 'Pipeline: Declarative Agent API'
  * pipeline-model-definition:1.1.9 *(update available)* 'Pipeline: Model Definition'
  * pipeline-model-extensions:1.1.9 *(update available)* 'Pipeline: Declarative Extension Points API'
  * pipeline-rest-api:2.8 *(update available)* 'Pipeline: REST API Plugin'
  * pipeline-stage-step:2.2 'Pipeline: Stage Step'
  * pipeline-stage-tags-metadata:1.1.9 *(update available)* 'Pipeline: Stage Tags Metadata'
  * pipeline-stage-view:2.8 *(update available)* 'Pipeline: Stage View Plugin'
  * plain-credentials:1.4 'Plain Credentials Plugin'
  * postbuild-task:1.8 'Hudson Post build task'
  * python:1.3 'Python Plugin'
  * resource-disposer:0.7 *(update available)* 'Resource Disposer Plugin'
  * role-strategy:2.5.1 *(update available)* 'Role-based Authorization Strategy'
  * ruby-runtime:0.12 'ruby-runtime'
  * run-condition:1.0 'Run Condition Plugin'
  * scm-api:2.2.1 *(update available)* 'SCM API Plugin'
  * script-security:1.33 *(update available)* 'Script Security Plugin'
  * scriptler:2.9 'Scriptler'
  * skip-certificate-check:1.0 'skip-certificate-check'
  * ssh-credentials:1.13 'SSH Credentials Plugin'
  * ssh-slaves:1.21 'Jenkins SSH Slaves plugin'
  * structs:1.10 'Structs Plugin'
  * subversion:2.9 'Jenkins Subversion Plug-in'
  * support-core:2.41 'Support Core Plugin'
  * text-finder:1.10 'Jenkins TextFinder plugin'
  * timestamper:1.8.8 'Timestamper'
  * token-macro:2.2 *(update available)* 'Token Macro Plugin'
  * translation:1.15 'Jenkins Translation Assistance plugin'
  * uno-choice:1.5.3 'Active Choices Plug-in'
  * windows-slaves:1.3.1 'Windows Slaves Plugin'
  * workflow-aggregator:2.5 'Pipeline'
  * workflow-api:2.20 *(update available)* 'Pipeline: API'
  * workflow-basic-steps:2.6 'Pipeline: Basic Steps'
  * workflow-cps:2.39 *(update available)* 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.8 *(update available)* 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.14 *(update available)* 'Pipeline: Nodes and Processes'
  * workflow-job:2.14.1 'Pipeline: Job'
  * workflow-multibranch:2.16 'Pipeline: Multibranch'
  * workflow-scm-step:2.6 'Pipeline: SCM Step'
  * workflow-step-api:2.12 *(update available)* 'Pipeline: Step API'
  * workflow-support:2.14 *(update available)* 'Pipeline: Supporting APIs'
  * ws-cleanup:0.34 'Jenkins Workspace Cleanup Plugin'
