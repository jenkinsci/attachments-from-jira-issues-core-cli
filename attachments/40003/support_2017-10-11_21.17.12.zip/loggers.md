Loggers currently enabled
=========================
hudson.plugins.git.* - ALL
org.apache.sshd - WARNING
winstone - INFO
 - INFO
