User
====

Authentication
--------------

  * Authenticated: true
  * Name: bparker
  * Authorities 
      - `Radius`
      - `authenticated`
      - `ROLE_MAILBOX QA`
      - `ROLE_RADIUS`
      - `ROLE_KNOWBE4`
      - `ROLE_ECM_CORE`
      - `ServicesFW`
      - `ROLE_MAILBOX SUPPORT`
      - `Engineering_SaaS`
      - `Mobile Users`
      - `ROLE_MOBILE USERS`
      - `ROLE_O365 DEPLOY`
      - `Mailbox QA`
      - `O365 Deploy`
      - `ROLE_ALL_US_CRADLEPOINT`
      - `ROLE_ENGINEERING_PERSONNEL`
      - `Engineering_WPC_Dev`
      - `ROLE_ENGINEERING_WPC_DEV`
      - `KnowBe4`
      - `Engineering_Personnel`
      - `Boise_Cradlepoint`
      - `Mailbox Support`
      - `Linux Admins`
      - `RD_All`
      - `All_US_Cradlepoint`
      - `ROLE_SERVICESFW`
      - `Password Policy`
      - `ROLE_RD_ALL`
      - `ROLE_PASSWORD POLICY`
      - `ROLE_BOISE_CRADLEPOINT`
      - `ROLE_LINUX ADMINS`
      - `ROLE_ENGINEERING_SAAS`
      - `ECM_Core`
  * Raw: `org.acegisecurity.providers.UsernamePasswordAuthenticationToken@ffdff37b: Username: org.acegisecurity.userdetails.ldap.LdapUserDetailsImpl@3dcb84d6; Password: [PROTECTED]; Authenticated: true; Details: org.acegisecurity.ui.WebAuthenticationDetails@fffdaa08: RemoteIpAddress: 127.0.0.1; SessionId: node024yars7zymcm1cw5p4ljei1557025; Granted Authorities: Radius, authenticated, ROLE_MAILBOX QA, ROLE_RADIUS, ROLE_KNOWBE4, ROLE_ECM_CORE, ServicesFW, ROLE_MAILBOX SUPPORT, Engineering_SaaS, Mobile Users, ROLE_MOBILE USERS, ROLE_O365 DEPLOY, Mailbox QA, O365 Deploy, ROLE_ALL_US_CRADLEPOINT, ROLE_ENGINEERING_PERSONNEL, Engineering_WPC_Dev, ROLE_ENGINEERING_WPC_DEV, KnowBe4, Engineering_Personnel, Boise_Cradlepoint, Mailbox Support, Linux Admins, RD_All, All_US_Cradlepoint, ROLE_SERVICESFW, Password Policy, ROLE_RD_ALL, ROLE_PASSWORD POLICY, ROLE_BOISE_CRADLEPOINT, ROLE_LINUX ADMINS, ROLE_ENGINEERING_SAAS, ECM_Core`

