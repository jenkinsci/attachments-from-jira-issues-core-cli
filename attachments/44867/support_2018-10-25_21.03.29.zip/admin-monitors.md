Monitors
========

`jenkins.diagnostics.URICheckEncodingMonitor`
--------------
(active and enabled)
