Jenkins
=======

Version details
---------------

  * Version: `2.138.2`
  * Mode:    WAR
  * Url:     http://localhost:32773/
  * Servlet container
      - Specification: 3.1
      - Name:          `jetty/9.4.z-SNAPSHOT`
  * Java
      - Home:           `/usr/lib/jvm/java-8-openjdk-amd64/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0_181
      - Maximum memory:   444.50 MB (466092032)
      - Allocated memory: 256.50 MB (268959744)
      - Free memory:      155.70 MB (163267024)
      - In-use memory:    100.80 MB (105692720)
      - GC strategy:      ParallelGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    OpenJDK 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 25.181-b13
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      4.9.93-linuxkit-aufs
  * Process ID: 7 (0x7)
  * Process started: 2018-10-25 20:53:56.257+0000
  * Process uptime: 9 min 33 sec
  * JVM startup parameters:
      - Boot classpath: `/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/resources.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/rt.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jsse.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jce.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/charsets.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jfr.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/classes`
      - Classpath: `/usr/share/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`
      - arg[0]: `-Duser.home=/var/jenkins_home`

Important configuration
---------------

  * Security realm: `hudson.security.HudsonPrivateSecurityRealm`
  * Authorization strategy: `hudson.security.FullControlOnceLoggedInAuthorizationStrategy`
  * CSRF Protection: true
  * Initialization Milestone: Completed initialization
  * Support bundle anonymization: false

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * ant:1.8 'Ant Plugin'
  * antisamy-markup-formatter:1.5 'OWASP Markup Formatter Plugin'
  * apache-httpcomponents-client-4-api:4.5.5-3.0 'Jenkins Apache HttpComponents Client 4.x API Plugin'
  * authentication-tokens:1.3 'Authentication Tokens API Plugin'
  * bouncycastle-api:2.17 'bouncycastle API Plugin'
  * branch-api:2.0.20 'Branch API Plugin'
  * build-timeout:1.19 'Build Timeout'
  * cloudbees-folder:6.6 'Folders Plugin'
  * command-launcher:1.2 'Command Agent Launcher Plugin'
  * credentials:2.1.18 'Credentials Plugin'
  * credentials-binding:1.16 'Credentials Binding Plugin'
  * display-url-api:2.2.0 'Display URL API'
  * docker-commons:1.13 'Docker Commons Plugin'
  * docker-workflow:1.17 'Docker Pipeline'
  * durable-task:1.26 'Durable Task Plugin'
  * email-ext:2.63 'Email Extension Plugin'
  * git:3.9.1 'Jenkins Git plugin'
  * git-client:2.7.3 'Jenkins Git client plugin'
  * git-server:1.7 'Jenkins GIT server Plugin'
  * github:1.29.3 'GitHub plugin'
  * github-api:1.92 'GitHub API Plugin'
  * github-branch-source:2.4.1 'GitHub Branch Source Plugin'
  * gradle:1.29 'Gradle Plugin'
  * handlebars:1.1.1 'JavaScript GUI Lib: Handlebars bundle plugin'
  * jackson2-api:2.8.11.3 'Jackson 2 API Plugin'
  * jdk-tool:1.1 'JDK Tool Plugin'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * jsch:0.1.54.2 'Jenkins JSch dependency plugin'
  * junit:1.26.1 'JUnit Plugin'
  * ldap:1.20 'LDAP Plugin'
  * lockable-resources:2.3 'Lockable Resources plugin'
  * mailer:1.22 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.9.0 'MapDB API Plugin'
  * matrix-auth:2.3 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.13 'Matrix Project Plugin'
  * metrics:4.0.2.2 'Metrics Plugin'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * pam-auth:1.4 'PAM Authentication plugin'
  * pipeline-build-step:2.7 'Pipeline: Build Step'
  * pipeline-github-lib:1.0 'Pipeline: GitHub Groovy Libraries'
  * pipeline-graph-analysis:1.7 'Pipeline Graph Analysis Plugin'
  * pipeline-input-step:2.8 'Pipeline: Input Step'
  * pipeline-milestone-step:1.3.1 'Pipeline: Milestone Step'
  * pipeline-model-api:1.3.2 'Pipeline: Model API'
  * pipeline-model-declarative-agent:1.1.1 'Pipeline: Declarative Agent API'
  * pipeline-model-definition:1.3.2 'Pipeline: Declarative'
  * pipeline-model-extensions:1.3.2 'Pipeline: Declarative Extension Points API'
  * pipeline-rest-api:2.10 'Pipeline: REST API Plugin'
  * pipeline-stage-step:2.3 'Pipeline: Stage Step'
  * pipeline-stage-tags-metadata:1.3.2 'Pipeline: Stage Tags Metadata'
  * pipeline-stage-view:2.10 'Pipeline: Stage View Plugin'
  * plain-credentials:1.4 'Plain Credentials Plugin'
  * resource-disposer:0.12 'Resource Disposer Plugin'
  * scm-api:2.3.0 'SCM API Plugin'
  * script-security:1.47 'Script Security Plugin'
  * ssh-credentials:1.14 'SSH Credentials Plugin'
  * ssh-slaves:1.28.1 'Jenkins SSH Slaves plugin'
  * structs:1.17 'Structs Plugin'
  * subversion:2.12.1 'Jenkins Subversion Plug-in'
  * support-core:2.50 'Support Core Plugin'
  * timestamper:1.8.10 'Timestamper'
  * token-macro:2.5 'Token Macro Plugin'
  * variant:1.1 'Variant Plugin'
  * workflow-aggregator:2.6 'Pipeline'
  * workflow-api:2.30 'Pipeline: API'
  * workflow-basic-steps:2.11 'Pipeline: Basic Steps'
  * workflow-cps:2.59 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.12 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.25 'Pipeline: Nodes and Processes'
  * workflow-job:2.25 'Pipeline: Job'
  * workflow-multibranch:2.20 'Pipeline: Multibranch'
  * workflow-scm-step:2.7 'Pipeline: SCM Step'
  * workflow-step-api:2.16 'Pipeline: Step API'
  * workflow-support:2.21 'Pipeline: Supporting APIs'
  * ws-cleanup:0.36 'Jenkins Workspace Cleanup Plugin'
