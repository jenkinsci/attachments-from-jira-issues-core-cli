Browser
=======

  * Screen size: 1920x1080
  * User Agent
      - Type:     Browser
      - Name:     Firefox
      - Family:   FIREFOX
      - Producer: Mozilla Foundation
      - Version:  62.0
      - Raw:      `Mozilla/5.0 (Macintosh; Intel Mac OS X 10.14; rv:62.0) Gecko/20100101 Firefox/62.0`
  * Operating System
      - Name:     OS X
      - Family:   OS_X
      - Producer: Apple Computer, Inc.
      - Version:  10.14

