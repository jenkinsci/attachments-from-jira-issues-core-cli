User
====

Authentication
--------------

  * Authenticated: true
  * Name: mgrandi
  * Authorities 
      - `authenticated`
  * Raw: `org.acegisecurity.providers.UsernamePasswordAuthenticationToken@99e0f6db: Username: hudson.security.HudsonPrivateSecurityRealm$Details@22ff23a9; Password: [PROTECTED]; Authenticated: true; Details: null; Granted Authorities: authenticated`

