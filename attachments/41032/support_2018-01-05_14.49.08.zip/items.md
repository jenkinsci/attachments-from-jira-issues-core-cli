Item statistics
===============

  * `com.cloudbees.hudson.plugins.folder.Folder`
    - Number of items: 175
    - Number of items per container: 3.8285714285714287 [n=175, s=4.8]
  * `hudson.model.FreeStyleProject`
    - Number of items: 42
    - Number of builds per job: 45.404761904761905 [n=42, s=100.0]
  * `org.jenkinsci.plugins.workflow.job.WorkflowJob`
    - Number of items: 482
    - Number of builds per job: 49.5746887966805 [n=482, s=120.0]

Total job statistics
======================

  * Number of jobs: 524
  * Number of builds per job: 49.24045801526717 [n=524, s=120.0]
