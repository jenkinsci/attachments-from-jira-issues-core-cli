Node statistics
===============

  * Total number of nodes
      - Sample size:        8989
      - Average (mean):     4.0
      - Average (median):   4.0
      - Standard deviation: 0.0
      - Minimum:            4
      - Maximum:            4
      - 95th percentile:    4.0
      - 99th percentile:    4.0
  * Total number of nodes online
      - Sample size:        8989
      - Average (mean):     4.0
      - Average (median):   4.0
      - Standard deviation: 0.0
      - Minimum:            4
      - Maximum:            4
      - 95th percentile:    4.0
      - 99th percentile:    4.0
  * Total number of executors
      - Sample size:        8989
      - Average (mean):     26.0
      - Average (median):   26.0
      - Standard deviation: 0.0
      - Minimum:            26
      - Maximum:            26
      - 95th percentile:    26.0
      - 99th percentile:    26.0
  * Total number of executors in use
      - Sample size:        8989
      - Average (mean):     9.957157656323025
      - Average (median):   10.0
      - Standard deviation: 0.26847946450846966
      - Minimum:            0
      - Maximum:            14
      - 95th percentile:    10.0
      - 99th percentile:    10.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      8
      - FS root:        `/var/opt/jenkins`
      - Labels:         unix master docker
      - Usage:          `EXCLUSIVE`
      - Slave Version:  3.15
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.141-2.b16.el7_4.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_141
          + Maximum memory:   12.00 GB (12884901888)
          + Allocated memory: 8.00 GB (8589934592)
          + Free memory:      5.29 GB (5678293352)
          + In-use memory:    2.71 GB (2911641240)
          + GC strategy:      G1
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.141-b16
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-693.5.2.el7.x86_64
          + Distribution: "Red Hat Enterprise Linux Server release 7.4 (Maipo)"
          + LSB Modules:  `:core-4.1-amd64:core-4.1-noarch:cxx-4.1-amd64:cxx-4.1-noarch:desktop-4.1-amd64:desktop-4.1-noarch:languages-4.1-amd64:languages-4.1-noarch:printing-4.1-amd64:printing-4.1-noarch`
      - Process ID: 33960 (0x84a8)
      - Process started: 2018-01-04 01:21:12.318+0000
      - Process uptime: 1 day 13 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.141-2.b16.el7_4.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.141-2.b16.el7_4.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.141-2.b16.el7_4.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.141-2.b16.el7_4.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.141-2.b16.el7_4.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.141-2.b16.el7_4.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.141-2.b16.el7_4.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.141-2.b16.el7_4.x86_64/jre/classes`
          + Classpath: `/usr/lib/jenkins/jenkins.war`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Djava.awt.headless=true`
          + arg[1]: `-Xms8192m`
          + arg[2]: `-Xmx12288m`
          + arg[3]: `-XX:+UseG1GC`
          + arg[4]: `-XX:+ExplicitGCInvokesConcurrent`
          + arg[5]: `-XX:+ParallelRefProcEnabled`
          + arg[6]: `-XX:+UseStringDeduplication`
          + arg[7]: `-XX:+UnlockExperimentalVMOptions`
          + arg[8]: `-XX:G1NewSizePercent=20`
          + arg[9]: `-XX:+UnlockDiagnosticVMOptions`
          + arg[10]: `-XX:G1SummarizeRSetStatsPeriod=1`
          + arg[11]: `-Dhudson.model.DirectoryBrowserSupport.CSP=`
          + arg[12]: `-DJENKINS_HOME=/var/opt/jenkins`

  * jenkinsdockerslave12-106-47fsk-62e7455e (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 10.25.245.126 : null_
      - Executors:      6
      - Remote FS root: `/var/lib/jenkins/workspace/jenkinsdockerslave12-106-47fsk`
      - Labels:         swarm selenium docker swarm12
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        3.15
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-1.b12.el7_4.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_151
          + Maximum memory:   640.00 MB (671088640)
          + Allocated memory: 640.00 MB (671088640)
          + Free memory:      311.83 MB (326979608)
          + In-use memory:    328.17 MB (344109032)
          + GC strategy:      G1
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.151-b12
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-693.5.2.el7.x86_64
      - Process ID: 17 (0x11)
      - Process started: 2018-01-05 01:21:43.601+0000
      - Process uptime: 13 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-1.b12.el7_4.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-1.b12.el7_4.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-1.b12.el7_4.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-1.b12.el7_4.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-1.b12.el7_4.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-1.b12.el7_4.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-1.b12.el7_4.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-1.b12.el7_4.x86_64/jre/classes`
          + Classpath: `/var/lib/jenkins/slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Xms640m`
          + arg[1]: `-Xmx640m`
          + arg[2]: `-XX:+UseG1GC`
          + arg[3]: `-XX:+ExplicitGCInvokesConcurrent`
          + arg[4]: `-XX:+ParallelRefProcEnabled`
          + arg[5]: `-XX:+UseStringDeduplication`
          + arg[6]: `-XX:+UnlockExperimentalVMOptions`
          + arg[7]: `-XX:G1NewSizePercent=20`

  * jenkinsdockerslave12-106-dj10x-544f99ae (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 10.25.245.252 : null_
      - Executors:      6
      - Remote FS root: `/var/lib/jenkins/workspace/jenkinsdockerslave12-106-dj10x`
      - Labels:         swarm selenium docker swarm12
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        3.15
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-1.b12.el7_4.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_151
          + Maximum memory:   640.00 MB (671088640)
          + Allocated memory: 640.00 MB (671088640)
          + Free memory:      328.48 MB (344432104)
          + In-use memory:    311.52 MB (326656536)
          + GC strategy:      G1
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.151-b12
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-693.5.2.el7.x86_64
      - Process ID: 20 (0x14)
      - Process started: 2018-01-05 01:12:41.361+0000
      - Process uptime: 13 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-1.b12.el7_4.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-1.b12.el7_4.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-1.b12.el7_4.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-1.b12.el7_4.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-1.b12.el7_4.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-1.b12.el7_4.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-1.b12.el7_4.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-1.b12.el7_4.x86_64/jre/classes`
          + Classpath: `/var/lib/jenkins/slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Xms640m`
          + arg[1]: `-Xmx640m`
          + arg[2]: `-XX:+UseG1GC`
          + arg[3]: `-XX:+ExplicitGCInvokesConcurrent`
          + arg[4]: `-XX:+ParallelRefProcEnabled`
          + arg[5]: `-XX:+UseStringDeduplication`
          + arg[6]: `-XX:+UnlockExperimentalVMOptions`
          + arg[7]: `-XX:G1NewSizePercent=20`

  * jenkinsdockerslave12-106-f6xvz-38dc7383 (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 10.25.245.253 : null_
      - Executors:      6
      - Remote FS root: `/var/lib/jenkins/workspace/jenkinsdockerslave12-106-f6xvz`
      - Labels:         swarm selenium docker swarm12
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        3.15
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-1.b12.el7_4.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_151
          + Maximum memory:   640.00 MB (671088640)
          + Allocated memory: 640.00 MB (671088640)
          + Free memory:      288.09 MB (302082256)
          + In-use memory:    351.91 MB (369006384)
          + GC strategy:      G1
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.151-b12
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-693.5.2.el7.x86_64
      - Process ID: 25 (0x19)
      - Process started: 2018-01-05 01:21:42.233+0000
      - Process uptime: 13 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-1.b12.el7_4.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-1.b12.el7_4.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-1.b12.el7_4.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-1.b12.el7_4.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-1.b12.el7_4.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-1.b12.el7_4.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-1.b12.el7_4.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-1.b12.el7_4.x86_64/jre/classes`
          + Classpath: `/var/lib/jenkins/slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Xms640m`
          + arg[1]: `-Xmx640m`
          + arg[2]: `-XX:+UseG1GC`
          + arg[3]: `-XX:+ExplicitGCInvokesConcurrent`
          + arg[4]: `-XX:+ParallelRefProcEnabled`
          + arg[5]: `-XX:+UseStringDeduplication`
          + arg[6]: `-XX:+UnlockExperimentalVMOptions`
          + arg[7]: `-XX:G1NewSizePercent=20`

