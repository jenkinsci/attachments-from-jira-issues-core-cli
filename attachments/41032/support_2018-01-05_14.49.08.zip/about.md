Jenkins
=======

Version details
---------------

  * Version: `2.100`
  * Mode:    WAR
  * Url:     http://cwb02dacoapp02.keybank.com:8080/
  * Servlet container
      - Specification: 3.1
      - Name:          `jetty/9.4.z-SNAPSHOT`
  * Java
      - Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.141-2.b16.el7_4.x86_64/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0_141
      - Maximum memory:   12.00 GB (12884901888)
      - Allocated memory: 8.00 GB (8589934592)
      - Free memory:      5.32 GB (5708290912)
      - In-use memory:    2.68 GB (2881643680)
      - GC strategy:      G1
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    OpenJDK 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 25.141-b16
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      3.10.0-693.5.2.el7.x86_64
      - Distribution: "Red Hat Enterprise Linux Server release 7.4 (Maipo)"
      - LSB Modules:  `:core-4.1-amd64:core-4.1-noarch:cxx-4.1-amd64:cxx-4.1-noarch:desktop-4.1-amd64:desktop-4.1-noarch:languages-4.1-amd64:languages-4.1-noarch:printing-4.1-amd64:printing-4.1-noarch`
  * Process ID: 33960 (0x84a8)
  * Process started: 2018-01-04 01:21:12.318+0000
  * Process uptime: 1 day 13 hr
  * JVM startup parameters:
      - Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.141-2.b16.el7_4.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.141-2.b16.el7_4.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.141-2.b16.el7_4.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.141-2.b16.el7_4.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.141-2.b16.el7_4.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.141-2.b16.el7_4.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.141-2.b16.el7_4.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.141-2.b16.el7_4.x86_64/jre/classes`
      - Classpath: `/usr/lib/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
      - arg[0]: `-Djava.awt.headless=true`
      - arg[1]: `-Xms8192m`
      - arg[2]: `-Xmx12288m`
      - arg[3]: `-XX:+UseG1GC`
      - arg[4]: `-XX:+ExplicitGCInvokesConcurrent`
      - arg[5]: `-XX:+ParallelRefProcEnabled`
      - arg[6]: `-XX:+UseStringDeduplication`
      - arg[7]: `-XX:+UnlockExperimentalVMOptions`
      - arg[8]: `-XX:G1NewSizePercent=20`
      - arg[9]: `-XX:+UnlockDiagnosticVMOptions`
      - arg[10]: `-XX:G1SummarizeRSetStatsPeriod=1`
      - arg[11]: `-Dhudson.model.DirectoryBrowserSupport.CSP=`
      - arg[12]: `-DJENKINS_HOME=/var/opt/jenkins`

Important configuration
---------------

  * Security realm: `hudson.security.LDAPSecurityRealm`
  * Authorization strategy: `hudson.security.ProjectMatrixAuthorizationStrategy`
  * CSRF Protection: false
  * Initialization Milestone: Completed initialization

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * allure-jenkins-plugin:2.25.1 'Allure Jenkins Plugin'
  * analysis-collector:1.52 'Static Analysis Collector Plug-in'
  * analysis-core:1.93 'Static Analysis Utilities'
  * ansicolor:0.5.2 'AnsiColor'
  * ant:1.7 'Ant Plugin'
  * antisamy-markup-formatter:1.5 'OWASP Markup Formatter Plugin'
  * apache-httpcomponents-client-4-api:4.5.3-2.0 'Jenkins Apache HttpComponents Client 4.x API Plugin'
  * async-http-client:1.9.40.0 'Async Http Client'
  * authentication-tokens:1.3 'Authentication Tokens API Plugin'
  * blueocean:1.3.5 'Blue Ocean'
  * blueocean-autofavorite:1.2.1 'Autofavorite for Blue Ocean'
  * blueocean-bitbucket-pipeline:1.3.5 'Bitbucket Pipeline for Blue Ocean'
  * blueocean-commons:1.3.5 'Common API for Blue Ocean'
  * blueocean-config:1.3.5 'Config API for Blue Ocean'
  * blueocean-dashboard:1.3.5 'Dashboard for Blue Ocean'
  * blueocean-display-url:2.2.0 'Display URL for Blue Ocean'
  * blueocean-events:1.3.5 'Events API for Blue Ocean'
  * blueocean-git-pipeline:1.3.5 'Git Pipeline for Blue Ocean'
  * blueocean-github-pipeline:1.3.5 'GitHub Pipeline for Blue Ocean'
  * blueocean-i18n:1.3.5 'i18n for Blue Ocean'
  * blueocean-jira:1.3.5 'JIRA Integration for Blue Ocean'
  * blueocean-jwt:1.3.5 'JWT for Blue Ocean'
  * blueocean-personalization:1.3.5 'Personalization for Blue Ocean'
  * blueocean-pipeline-api-impl:1.3.5 'Pipeline implementation for Blue Ocean'
  * blueocean-pipeline-editor:1.3.5 'Blue Ocean Pipeline Editor'
  * blueocean-pipeline-scm-api:1.3.5 'Pipeline SCM API for Blue Ocean'
  * blueocean-rest:1.3.5 'REST API for Blue Ocean'
  * blueocean-rest-impl:1.3.5 'REST Implementation for Blue Ocean'
  * blueocean-web:1.3.5 'Web for Blue Ocean'
  * bootstrap:1.3.2 'JavaScript GUI Lib: Twitter Bootstrap bundle plugin'
  * bootstraped-multi-test-results-report:2.1.2 'bootstraped-multi-test-results-report'
  * bouncycastle-api:2.16.2 'bouncycastle API Plugin'
  * branch-api:2.0.17 'Branch API Plugin'
  * build-token-root:1.4 'Build Authorization Token Root Plugin'
  * checkstyle:3.49 'Checkstyle Plug-in'
  * chef-identity:1.0.0 'Chef Identity Plugin'
  * cloudbees-bitbucket-branch-source:2.2.8 'Bitbucket Branch Source Plugin'
  * cloudbees-disk-usage-simple:0.9 'CloudBees Disk Usage Simple Plugin'
  * cloudbees-folder:6.2.1 'Folders Plugin'
  * cobertura:1.12 'Jenkins Cobertura Plugin'
  * collabnet:2.0.4 'CollabNet Plugins'
  * command-launcher:1.2 'Command Agent Launcher Plugin'
  * conditional-buildstep:1.3.6 'Conditional BuildStep'
  * config-file-provider:2.16.4 'Config File Provider Plugin'
  * copy-to-slave:1.4.4 'Copy To Slave Plugin'
  * copyartifact:1.39 'Copy Artifact Plugin'
  * credentials:2.1.16 'Credentials Plugin'
  * credentials-binding:1.13 'Credentials Binding Plugin'
  * cvs:2.13 'Jenkins CVS Plug-in'
  * dashboard-view:2.9.11 'Dashboard View'
  * dependency-check-jenkins-plugin:3.0.2 *(update available)* 'OWASP Dependency-Check Plugin'
  * deployit-plugin:6.1.1 'XebiaLabs XL Deploy Plugin'
  * devtest_invoke:1.0 'CA DevTest Invoke'
  * display-url-api:2.2.0 'Display URL API'
  * docker-commons:1.10 *(update available)* 'Docker Commons Plugin'
  * docker-workflow:1.14 'Docker Pipeline'
  * dockerhub-notification:2.2.0 *(update available)* 'CloudBees Docker Hub/Registry Notification'
  * durable-task:1.17 'Durable Task Plugin'
  * email-ext:2.61 'Email Extension Plugin'
  * emailext-template:1.0 'Email Extension Template Plugin'
  * embeddable-build-status:1.9 'embeddable-build-status'
  * external-monitor-job:1.7 'External Monitor Job Type Plugin'
  * favorite:2.3.1 'Favorite'
  * gerrit-trigger:2.27.1 'Gerrit Trigger'
  * git:3.7.0 'Jenkins Git plugin'
  * git-changelog:1.54 'Git Changelog'
  * git-client:2.7.0 'Jenkins Git client plugin'
  * git-server:1.7 'Jenkins GIT server Plugin'
  * github:1.28.1 'GitHub plugin'
  * github-api:1.90 'GitHub API Plugin'
  * github-branch-source:2.3.2 'GitHub Branch Source Plugin'
  * github-organization-folder:1.6 'GitHub Organization Folder Plugin'
  * gitlab-hook:1.4.2 'Gitlab Hook Plugin'
  * gitlab-merge-request-jenkins:2.0.0 'Gitlab Merge Request Builder'
  * gitlab-plugin:1.5.2 'GitLab Plugin'
  * groovy:2.0 'Groovy'
  * groovy-postbuild:2.3.1 'Groovy Postbuild'
  * handlebars:1.1.1 'JavaScript GUI Lib: Handlebars bundle plugin'
  * htmlpublisher:1.14 'HTML Publisher plugin'
  * http_request:1.8.22 'HTTP Request Plugin'
  * icon-shim:2.0.3 'Icon Shim Plugin'
  * jackson2-api:2.8.10.1 'Jackson 2 API Plugin'
  * jacoco:2.2.1 'Jenkins JaCoCo plugin'
  * javadoc:1.4 'Javadoc Plugin'
  * jira:2.5 'Jenkins JIRA plugin'
  * jquery:1.12.4-0 'jQuery plugin'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * jsch:0.1.54.1 'Jenkins JSch dependency plugin'
  * junit:1.23 'JUnit Plugin'
  * kubernetes:1.1.2 'Kubernetes plugin'
  * ldap:1.12 *(update available)* 'LDAP Plugin'
  * lockable-resources:2.1 'Lockable Resources plugin'
  * mailer:1.20 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.9.0 'MapDB API Plugin'
  * mashup-portlets-plugin:1.0.8 'Mashup Portlets'
  * mask-passwords:2.10.1 'Mask Passwords Plugin'
  * matrix-auth:2.2 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.12 'Matrix Project Plugin'
  * maven-plugin:3.0 'Maven Integration plugin'
  * mercurial:2.2 'Jenkins Mercurial plugin'
  * metrics:3.1.2.10 'Metrics Plugin'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * nodejs:1.2.4 'NodeJS Plugin'
  * openshift-pipeline:1.0.53 'OpenShift Pipeline Jenkins Plugin'
  * openshift-sync:0.9.2 'OpenShift Sync'
  * packer:1.4 'packer'
  * pam-auth:1.3 'PAM Authentication plugin'
  * parallel-test-executor:1.9 *(update available)* 'Parallel Test Executor Plugin'
  * Parameterized-Remote-Trigger:2.2.2 'Parameterized Remote Trigger Plugin'
  * parameterized-trigger:2.35.2 'Jenkins Parameterized Trigger plugin'
  * pegdown-formatter:1.3 'PegDown Formatter Plugin'
  * pipeline-build-step:2.6 'Pipeline: Build Step'
  * pipeline-github-lib:1.0 'Pipeline: GitHub Groovy Libraries'
  * pipeline-graph-analysis:1.6 'Pipeline Graph Analysis Plugin'
  * pipeline-input-step:2.8 'Pipeline: Input Step'
  * pipeline-milestone-step:1.3.1 'Pipeline: Milestone Step'
  * pipeline-model-api:1.2.5 'Pipeline: Model API'
  * pipeline-model-declarative-agent:1.1.1 'Pipeline: Declarative Agent API'
  * pipeline-model-definition:1.2.5 'Pipeline: Declarative'
  * pipeline-model-extensions:1.2.5 'Pipeline: Declarative Extension Points API'
  * pipeline-rest-api:2.9 'Pipeline: REST API Plugin'
  * pipeline-stage-step:2.3 'Pipeline: Stage Step'
  * pipeline-stage-tags-metadata:1.2.5 'Pipeline: Stage Tags Metadata'
  * pipeline-stage-view:2.9 'Pipeline: Stage View Plugin'
  * plain-credentials:1.4 'Plain Credentials Plugin'
  * promoted-builds:2.31 'Jenkins promoted builds plugin'
  * pubsub-light:1.12 'Jenkins Pub-Sub "light" Bus'
  * qc:1.2.1 'Quality Center Plugin'
  * resource-disposer:0.8 'Resource Disposer Plugin'
  * ruby-runtime:0.13 'ruby-runtime'
  * run-condition:1.0 'Run Condition Plugin'
  * rvm:0.6 'Rvm'
  * scm-api:2.2.6 'SCM API Plugin'
  * script-security:1.39 'Script Security Plugin'
  * secure-requester-whitelist:1.2 'Secure Requester Whitelist Plugin'
  * slack:2.3 'Slack Notification Plugin'
  * sonar:2.6.1 'SonarQube Scanner for Jenkins'
  * sse-gateway:1.15 'Server Sent Events (SSE) Gateway Plugin'
  * ssh-agent:1.15 'SSH Agent Plugin'
  * ssh-credentials:1.13 'SSH Credentials Plugin'
  * ssh-slaves:1.24 'Jenkins SSH Slaves plugin'
  * structs:1.10 'Structs Plugin'
  * subversion:2.10.2 'Jenkins Subversion Plug-in'
  * support-core:2.44 'Support Core Plugin'
  * swarm:3.7 'Jenkins Self-Organizing Swarm Plug-in Modules'
  * TestComplete:1.9 'TestComplete support plug-in'
  * testcomplete-xunit:1.1 'Jenkins TestComplete xUnit Plugin'
  * text-finder:1.10 'Jenkins TextFinder plugin'
  * thinBackup:1.9 'ThinBackup'
  * timestamper:1.8.9 'Timestamper'
  * token-macro:2.3 'Token Macro Plugin'
  * translation:1.15 'Jenkins Translation Assistance plugin'
  * variant:1.1 'Variant Plugin'
  * veracode-jenkins-plugin:17.9.5.0 'Veracode Jenkins Plugin'
  * veracode-scanner:1.6 'veracode-scanner'
  * view-job-filters:1.27 'View Job Filters'
  * warnings:4.64 'Warnings Plug-in'
  * windows-slaves:1.3.1 'Windows Slaves Plugin'
  * workflow-aggregator:2.5 'Pipeline'
  * workflow-api:2.24 'Pipeline: API'
  * workflow-basic-steps:2.6 'Pipeline: Basic Steps'
  * workflow-cps:2.42 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.9 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.17 'Pipeline: Nodes and Processes'
  * workflow-job:2.16 'Pipeline: Job'
  * workflow-multibranch:2.16 'Pipeline: Multibranch'
  * workflow-scm-step:2.6 'Pipeline: SCM Step'
  * workflow-step-api:2.14 'Pipeline: Step API'
  * workflow-support:2.16 'Pipeline: Supporting APIs'
  * ws-cleanup:0.34 'Jenkins Workspace Cleanup Plugin'
  * xlrelease-plugin:6.1.2 'XebiaLabs XL Release Plugin'
  * xltestview-plugin:1.2.0 'XL TestView Plugin'
  * xunit:1.102 'xUnit plugin'
