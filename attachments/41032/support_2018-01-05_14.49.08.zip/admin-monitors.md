Monitors
========

`jenkins.diagnostics.URICheckEncodingMonitor`
--------------
(active and enabled)

`jenkins.security.csrf.CSRFAdministrativeMonitor`
--------------
(active and enabled)
