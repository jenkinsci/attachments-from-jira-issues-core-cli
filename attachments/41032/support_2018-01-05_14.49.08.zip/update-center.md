=== Sites ===
 - Url: http://updates.jenkins-ci.org/update-center.json
 - Connection Url: http://www.google.com/
 - Implementation Type: hudson.model.UpdateSite
======
Last updated: 36 min
=== Proxy ===
 - Host: proxy.keybank.com
 - Port: 80
 - No Proxy Hosts: 
 * *.keybank.com
 * .keybank.com
