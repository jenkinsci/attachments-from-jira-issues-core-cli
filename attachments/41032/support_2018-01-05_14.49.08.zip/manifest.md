Support Bundle Manifest
=======================

Generated on 2018-01-05 14:49:08.733+0000

Requested components:

  * About browser

      - `browser.md`

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `items.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `nodes/slave/jenkinsdockerslave12-106-47fsk-62e7455e/checksums.md5`

      - `nodes/slave/jenkinsdockerslave12-106-dj10x-544f99ae/checksums.md5`

      - `nodes/slave/jenkinsdockerslave12-106-f6xvz-38dc7383/checksums.md5`

      - `plugins/active.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * Administrative monitors

      - `admin-monitors.md`

  * Environment variables

      - `nodes/master/environment.txt`

      - `nodes/slave/jenkinsdockerslave12-106-47fsk-62e7455e/environment.txt`

      - `nodes/slave/jenkinsdockerslave12-106-dj10x-544f99ae/environment.txt`

      - `nodes/slave/jenkinsdockerslave12-106-f6xvz-38dc7383/environment.txt`

  * File descriptors (Unix only)

      - `nodes/master/file-descriptors.txt`

      - `nodes/slave/jenkinsdockerslave12-106-47fsk-62e7455e/file-descriptors.txt`

      - `nodes/slave/jenkinsdockerslave12-106-dj10x-544f99ae/file-descriptors.txt`

      - `nodes/slave/jenkinsdockerslave12-106-f6xvz-38dc7383/file-descriptors.txt`

  * System configuration (Linux only)

      - `nodes/master/dmesg.txt`

      - `nodes/master/dmi.txt`

      - `nodes/master/proc/cpuinfo.txt`

      - `nodes/master/proc/mounts.txt`

      - `nodes/master/proc/net/rpc/nfs.txt`

      - `nodes/master/proc/net/rpc/nfsd.txt`

      - `nodes/master/proc/swaps.txt`

      - `nodes/master/proc/system-uptime.txt`

      - `nodes/master/sysctl.txt`

      - `nodes/master/userid.txt`

      - `nodes/slave/jenkinsdockerslave12-106-47fsk-62e7455e/dmesg.txt`

      - `nodes/slave/jenkinsdockerslave12-106-47fsk-62e7455e/dmi.txt`

      - `nodes/slave/jenkinsdockerslave12-106-47fsk-62e7455e/proc/cpuinfo.txt`

      - `nodes/slave/jenkinsdockerslave12-106-47fsk-62e7455e/proc/mounts.txt`

      - `nodes/slave/jenkinsdockerslave12-106-47fsk-62e7455e/proc/net/rpc/nfs.txt`

      - `nodes/slave/jenkinsdockerslave12-106-47fsk-62e7455e/proc/net/rpc/nfsd.txt`

      - `nodes/slave/jenkinsdockerslave12-106-47fsk-62e7455e/proc/swaps.txt`

      - `nodes/slave/jenkinsdockerslave12-106-47fsk-62e7455e/proc/system-uptime.txt`

      - `nodes/slave/jenkinsdockerslave12-106-47fsk-62e7455e/sysctl.txt`

      - `nodes/slave/jenkinsdockerslave12-106-47fsk-62e7455e/userid.txt`

      - `nodes/slave/jenkinsdockerslave12-106-dj10x-544f99ae/dmesg.txt`

      - `nodes/slave/jenkinsdockerslave12-106-dj10x-544f99ae/dmi.txt`

      - `nodes/slave/jenkinsdockerslave12-106-dj10x-544f99ae/proc/cpuinfo.txt`

      - `nodes/slave/jenkinsdockerslave12-106-dj10x-544f99ae/proc/mounts.txt`

      - `nodes/slave/jenkinsdockerslave12-106-dj10x-544f99ae/proc/net/rpc/nfs.txt`

      - `nodes/slave/jenkinsdockerslave12-106-dj10x-544f99ae/proc/net/rpc/nfsd.txt`

      - `nodes/slave/jenkinsdockerslave12-106-dj10x-544f99ae/proc/swaps.txt`

      - `nodes/slave/jenkinsdockerslave12-106-dj10x-544f99ae/proc/system-uptime.txt`

      - `nodes/slave/jenkinsdockerslave12-106-dj10x-544f99ae/sysctl.txt`

      - `nodes/slave/jenkinsdockerslave12-106-dj10x-544f99ae/userid.txt`

      - `nodes/slave/jenkinsdockerslave12-106-f6xvz-38dc7383/dmesg.txt`

      - `nodes/slave/jenkinsdockerslave12-106-f6xvz-38dc7383/dmi.txt`

      - `nodes/slave/jenkinsdockerslave12-106-f6xvz-38dc7383/proc/cpuinfo.txt`

      - `nodes/slave/jenkinsdockerslave12-106-f6xvz-38dc7383/proc/mounts.txt`

      - `nodes/slave/jenkinsdockerslave12-106-f6xvz-38dc7383/proc/net/rpc/nfs.txt`

      - `nodes/slave/jenkinsdockerslave12-106-f6xvz-38dc7383/proc/net/rpc/nfsd.txt`

      - `nodes/slave/jenkinsdockerslave12-106-f6xvz-38dc7383/proc/swaps.txt`

      - `nodes/slave/jenkinsdockerslave12-106-f6xvz-38dc7383/proc/system-uptime.txt`

      - `nodes/slave/jenkinsdockerslave12-106-f6xvz-38dc7383/sysctl.txt`

      - `nodes/slave/jenkinsdockerslave12-106-f6xvz-38dc7383/userid.txt`

  * System properties

      - `nodes/master/system.properties`

      - `nodes/slave/jenkinsdockerslave12-106-47fsk-62e7455e/system.properties`

      - `nodes/slave/jenkinsdockerslave12-106-dj10x-544f99ae/system.properties`

      - `nodes/slave/jenkinsdockerslave12-106-f6xvz-38dc7383/system.properties`

  * Update Center

      - `update-center.md`

