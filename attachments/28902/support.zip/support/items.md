Item statistics
===============

  * `hudson.model.FreeStyleProject`
    - Number of items: 27
    - Number of builds per job: 15.074074074074074 [n=27, s=70.0]

Total job statistics
======================

  * Number of jobs: 27
  * Number of builds per job: 15.074074074074074 [n=27, s=70.0]
