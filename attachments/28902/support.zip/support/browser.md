Browser
=======

  * Screen size: 1440x900
  * User Agent
      - Type:     Browser
      - Name:     Safari
      - Family:   SAFARI
      - Producer: Apple Inc.
      - Version:  8.0.3
      - Raw:      `Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_2) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/8.0.3 Safari/600.3.18`
  * Operating System
      - Name:     OS X
      - Family:   OS_X
      - Producer: Apple Computer, Inc.
      - Version:  10.10.2

