Monitors
========

`OldData`
--------------
  * Problematic object: `hudson.model.FreeStyleProject@5db402[IEAPP-Master_Coverage]`
    - CannotResolveClassException: com.sonyericsson.jenkins.plugins.bfa.model.ScannerJobProperty, CannotResolveClassException: org.bstick12.jenkinsci.plugins.leastload.LeastLoadDisabledProperty, CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, CannotResolveClassException: hudson.plugins.warnings.WarningsPublisher, CannotResolveClassException: hudson.plugins.tasks.TasksPublisher, CannotResolveClassException: hudson.plugins.sloccount.SloccountPublisher
  * Problematic object: `hudson.model.FreeStyleProject@868731[IEAPP_JIRA]`
    - CannotResolveClassException: com.sonyericsson.jenkins.plugins.bfa.model.ScannerJobProperty, CannotResolveClassException: org.bstick12.jenkinsci.plugins.leastload.LeastLoadDisabledProperty, CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, CannotResolveClassException: org.jvnet.hudson.plugins.groovypostbuild.GroovyPostbuildRecorder, CannotResolveClassException: hudson.plugins.sloccount.SloccountPublisher

`jenkins.diagnostics.PinningIsBlockingBundledPluginMonitor`
--------------
(active and enabled)

`jenkins.diagnostics.ooom.OutOfOrderBuildMonitor`
--------------
(active and enabled)
