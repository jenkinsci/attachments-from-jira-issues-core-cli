Jenkins
=======

Version details
---------------

  * Version: `1.596.2`
  * Mode:    WAR
  * Servlet container
      - Specification: 3.0
      - Name:          `jetty/winstone-2.8`
  * Java
      - Home:           `/usr/lib/jvm/java-7-openjdk-i386/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.7.0_75
      - Maximum memory:   910.25 MB (954466304)
      - Allocated memory: 337.00 MB (353370112)
      - Free memory:      200.46 MB (210199440)
      - In-use memory:    136.54 MB (143170672)
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.7
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.7
  * JVM Implementation
      - Name:    OpenJDK Server VM
      - Vendor:  Oracle Corporation
      - Version: 24.75-b04
  * Operating system
      - Name:         Linux
      - Architecture: i386
      - Version:      3.11.0-15-generic
      - Distribution: Ubuntu 12.04.5 LTS
  * Process ID: 8852 (0x2294)
  * Process started: 2015-03-27 10:05:33.903-0700
  * Process uptime: 3 days 1 hr
  * JVM startup parameters:
      - Boot classpath: `/usr/lib/jvm/java-7-openjdk-i386/jre/lib/resources.jar:/usr/lib/jvm/java-7-openjdk-i386/jre/lib/rt.jar:/usr/lib/jvm/java-7-openjdk-i386/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-7-openjdk-i386/jre/lib/jsse.jar:/usr/lib/jvm/java-7-openjdk-i386/jre/lib/jce.jar:/usr/lib/jvm/java-7-openjdk-i386/jre/lib/charsets.jar:/usr/lib/jvm/java-7-openjdk-i386/jre/lib/rhino.jar:/usr/lib/jvm/java-7-openjdk-i386/jre/lib/jfr.jar:/usr/lib/jvm/java-7-openjdk-i386/jre/classes`
      - Classpath: `/usr/share/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/i386:/usr/lib/i386-linux-gnu/jni:/lib/i386-linux-gnu:/usr/lib/i386-linux-gnu:/usr/lib/jni:/lib:/usr/lib`
      - arg[0]: `-Djava.awt.headless=true`

Important configuration
---------------

  * Security realm: `com.pp.build.plugin.ActiveDirectorySecurityRealm`
  * Authorization strategy: `hudson.security.ProjectMatrixAuthorizationStrategy`

Active Plugins
--------------

  * analysis-collector:1.43 'Static Analysis Collector Plug-in'
  * analysis-core:1.71 'Static Analysis Utilities'
  * android-lint:2.2 'Android Lint Plugin'
  * ant:1.2 'Ant Plugin'
  * antisamy-markup-formatter:1.3 'OWASP Markup Formatter Plugin'
  * build-timeout:1.14.1 'Jenkins build timeout plugin'
  * cobertura:1.9.7 'Jenkins Cobertura Plugin'
  * credentials:1.22 'Credentials Plugin'
  * cvs:2.11 *(update available)* 'Jenkins CVS Plug-in'
  * email-ext:2.39 *(update available)* 'Email Extension Plugin'
  * envinject:1.90 *(update available)* 'Environment Injector Plugin'
  * extended-read-permission:1.0 'Hudson Extended Read Permission Plugin'
  * external-monitor-job:1.4 'External Monitor Job Type Plugin'
  * ghprb:1.17 'GitHub Pull Request Builder'
  * git:2.3.5 'Jenkins GIT plugin'
  * git-client:1.16.1 'Jenkins GIT client plugin'
  * github:1.11.1 'GitHub plugin'
  * github-api:1.66 'GitHub API Plugin'
  * gradle:1.24 'Jenkins Gradle plugin'
  * greenballs:1.14 'Green Balls'
  * htmlpublisher:1.3 'HTML Publisher plugin'
  * jacoco:1.0.18 'Jenkins JaCoCo plugin'
  * javadoc:1.1 *(update available)* 'Javadoc Plugin'
  * job-import-plugin:1.2 'Job Import Plugin'
  * jobConfigHistory:2.10 'Jenkins Job Configuration History Plugin'
  * junit:1.2-beta-4 *(update available)* 'JUnit Plugin'
  * ldap:1.6 *(update available)* 'LDAP Plugin'
  * mailer:1.15 'Jenkins Mailer Plugin'
  * mask-passwords:2.7.2 'Mask Passwords Plugin'
  * matrix-auth:1.1 *(update available)* 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.4 'Matrix Project Plugin'
  * maven-plugin:2.7.1 *(update available)* 'Maven Integration plugin'
  * metrics:3.0.9 'Metrics Plugin'
  * nested-view:1.14 'Nested View Plugin'
  * pam-auth:1.1 *(update available)* 'PAM Authentication plugin'
  * parameterized-trigger:2.25 *(update available)* 'Jenkins Parameterized Trigger plugin'
  * pmd:3.41 'PMD Plug-in'
  * postbuildscript:0.17 'Jenkins Post-Build Script Plug-in'
  * pp-active-directory:2.21.0-SNAPSHOT (private-07/01/2014 00:49-hthakkallapally) 'Fusion Active Directory plugin'
  * promoted-builds:2.20 'Jenkins promoted builds plugin'
  * rebuild:1.22 'Rebuilder'
  * reverse-proxy-auth-plugin:1.4.0 'Jenkins Reverse Proxy Auth Plugin'
  * scm-api:0.2 'SCM API Plugin'
  * script-security:1.13 'Script Security Plugin'
  * ssh-agent:1.5 'SSH Agent Plugin'
  * ssh-credentials:1.10 'SSH Credentials Plugin'
  * ssh-slaves:1.9 'Jenkins SSH Slaves plugin'
  * subversion:1.54 *(update available)* 'Jenkins Subversion Plug-in'
  * support-core:2.20 'Support Core Plugin'
  * token-macro:1.10 'Token Macro Plugin'
  * translation:1.10 *(update available)* 'Jenkins Translation Assistance plugin'
  * windows-slaves:1.0 'Windows Slaves Plugin'
