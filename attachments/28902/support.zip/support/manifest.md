Support Bundle Manifest
=======================

Generated on 2015-03-30 11:36:58 -0700

Requested components:

  * About browser

      - `browser.md`

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `items.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `plugins/active.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * Administrative monitors

      - `admin-monitors.md`

  * File descriptors (Unix only)

      - `nodes/master/file-descriptors.txt`

  * System properties

      - `nodes/master/system.properties`

  * Deadlock Records

  * Thread dumps

      - `nodes/master/thread-dump.txt`

