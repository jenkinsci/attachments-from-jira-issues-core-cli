package io.jenkins.plugins.sample;

import hudson.Extension;
import hudson.model.AbstractItem;
import hudson.model.ItemGroup;
import hudson.model.Job;
import hudson.model.TopLevelItem;
import hudson.model.TopLevelItemDescriptor;
import hudson.util.FormValidation;
import jenkins.model.Jenkins;
import org.kohsuke.stapler.QueryParameter;

import java.util.Collection;

public class TestItem extends AbstractItem implements TopLevelItem {

    private int numExecutors;

    protected TestItem(ItemGroup parent, String name) {
        super(parent, name);
    }

    public int getNumExecutors() {
        return numExecutors;
    }


    @SuppressWarnings("unused") // stapler
    public void setNumExecutors(int numExecutors) {
        this.numExecutors = numExecutors;
    }

    @Override
    public Collection<? extends Job> getAllJobs() {
        return null;
    }

    @Override
    public TopLevelItemDescriptor getDescriptor() {
        final Jenkins jenkins = Jenkins.getInstance();
        if (jenkins == null) {
            throw new AssertionError("Jenkins is missing");
        }
        return (TopLevelItemDescriptor) jenkins.getDescriptorOrDie(getClass());
    }

    @Extension
    public static class DescriptorImpl extends TopLevelItemDescriptor {

        @Override
        public TopLevelItem newInstance(ItemGroup itemGroup, String s) {
            return new TestItem(itemGroup, s);
        }

        @SuppressWarnings("unused") // stapler form validation
        public FormValidation doCheckNumExecutors(@QueryParameter String value) {
            return FormValidation.validatePositiveInteger(value);
        }
    }
}
