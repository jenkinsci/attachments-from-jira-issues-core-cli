Node monitors
=============
Architecture
----
 - Is Ignored: false
 - Computers:
   * master: label_intellectual_deadline 7 (amd64)
   * computer_basic_executive: label_intellectual_deadline 7 (amd64)
   * computer_educational_idea: label_intellectual_deadline 7 (amd64)
   * computer_hungry_monopoly: label_intellectual_deadline 7 (amd64)
   * computer_nervous_problem: null
   * computer_restless_silver: label_cheerful_date (amd64)
   * computer_ultimate_twist: label_cheerful_date (amd64)
   * computer_bland_basin: label_cheerful_date (amd64)
   * computer_elegant_constellation: label_cheerful_date (amd64)
   * computer_imperial_exile: label_cheerful_date (amd64)
   * computer_noble_ideology: label_cheerful_date (amd64)
   * computer_rich_moon: label_cheerful_date (amd64)
   * computer_uneasy_producer: label_cheerful_date (amd64)
Clock Difference
----
 - Is Ignored: false
 - Computers:
   * master: In sync
   * computer_basic_executive: In sync
   * computer_educational_idea: In sync
   * computer_hungry_monopoly: 1 sec ahead
   * computer_nervous_problem: null
   * computer_restless_silver: 1.2 sec ahead
   * computer_ultimate_twist: 1.2 sec ahead
   * computer_bland_basin: 1.2 sec ahead
   * computer_elegant_constellation: 1.2 sec ahead
   * computer_imperial_exile: 1.2 sec ahead
   * computer_noble_ideology: 1.2 sec ahead
   * computer_rich_moon: 1.2 sec ahead
   * computer_uneasy_producer: 1.2 sec ahead
Free Disk Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 205.111GB left on C:\Program Files (x86)\Jenkins.
   * computer_basic_executive: Disk space is too low. Only 257.545GB left on C:\CI.
   * computer_educational_idea: Disk space is too low. Only 257.545GB left on C:\CI2.
   * computer_hungry_monopoly: Disk space is too low. Only 257.545GB left on C:\CI3.
   * computer_nervous_problem: null
   * computer_restless_silver: Disk space is too low. Only 871.521GB left on /home/wifi/jenkins.
   * computer_ultimate_twist: Disk space is too low. Only 871.025GB left on /usr/local/OATS/jenkins.
   * computer_bland_basin: Disk space is too low. Only 870.118GB left on /home/atmel/jenkins.
   * computer_elegant_constellation: Disk space is too low. Only 873.319GB left on /usr/local/OATS/jenkins.
   * computer_imperial_exile: Disk space is too low. Only 880.144GB left on /home/wifi/jenkins.
   * computer_noble_ideology: Disk space is too low. Only 430.532GB left on /usr/local/OATS/jenkins.
   * computer_rich_moon: Disk space is too low. Only 873.319GB left on /usr/local/OATS/jenkins.
   * computer_uneasy_producer: Disk space is too low. Only 253.012GB left on /home/jenkins.
Free Swap Space
----
 - Is Ignored: false
 - Computers:
   * master: Memory:3841/16256MB  Swap:19474/32510MB
   * computer_basic_executive: Memory:3160/12207MB  Swap:14943/24413MB
   * computer_educational_idea: Memory:3160/12207MB  Swap:14943/24413MB
   * computer_hungry_monopoly: Memory:3160/12207MB  Swap:14943/24413MB
   * computer_nervous_problem: null
   * computer_restless_silver: Memory:1861/7852MB  Swap:8066/8066MB
   * computer_ultimate_twist: Memory:1437/7880MB  Swap:8070/8087MB
   * computer_bland_basin: Memory:2425/5823MB  Swap:6006/6006MB
   * computer_elegant_constellation: Memory:1604/7852MB  Swap:8066/8066MB
   * computer_imperial_exile: Memory:619/7874MB  Swap:975/975MB
   * computer_noble_ideology: Memory:886/3843MB  Swap:3733/3983MB
   * computer_rich_moon: Memory:1604/7852MB  Swap:8066/8066MB
   * computer_uneasy_producer: Memory:309/7870MB  Swap:7837/8083MB
Free Temp Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 205.111GB left on C:\label_intellectual_deadline\Temp.
   * computer_basic_executive: Disk space is too low. Only 257.545GB left on C:\Temp.
   * computer_educational_idea: Disk space is too low. Only 257.545GB left on C:\Temp.
   * computer_hungry_monopoly: Disk space is too low. Only 257.545GB left on C:\Temp.
   * computer_nervous_problem: null
   * computer_restless_silver: Disk space is too low. Only 871.521GB left on /tmp.
   * computer_ultimate_twist: Disk space is too low. Only 871.025GB left on /tmp.
   * computer_bland_basin: Disk space is too low. Only 870.118GB left on /tmp.
   * computer_elegant_constellation: Disk space is too low. Only 873.319GB left on /tmp.
   * computer_imperial_exile: Disk space is too low. Only 880.144GB left on /tmp.
   * computer_noble_ideology: Disk space is too low. Only 430.532GB left on /tmp.
   * computer_rich_moon: Disk space is too low. Only 873.319GB left on /tmp.
   * computer_uneasy_producer: Disk space is too low. Only 253.012GB left on /tmp.
Response Time
----
 - Is Ignored: false
 - Computers:
   * master: 0ms
   * computer_basic_executive: 8ms
   * computer_educational_idea: 8ms
   * computer_hungry_monopoly: 6ms
   * computer_nervous_problem: null
   * computer_restless_silver: 6ms
   * computer_ultimate_twist: 5ms
   * computer_bland_basin: 6ms
   * computer_elegant_constellation: 6ms
   * computer_imperial_exile: 3ms
   * computer_noble_ideology: 4ms
   * computer_rich_moon: 4ms
   * computer_uneasy_producer: 4ms
