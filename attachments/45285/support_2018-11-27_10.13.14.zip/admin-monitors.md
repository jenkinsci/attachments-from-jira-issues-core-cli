Monitors
========

`jenkins.diagnostics.URICheckEncodingMonitor`
--------------
(active and view_economic_stamp)
