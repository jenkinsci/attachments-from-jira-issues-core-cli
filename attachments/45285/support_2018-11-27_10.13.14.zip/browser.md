Browser
=======

  * Screen size: 1536x960
  * User Agent
      - Type:     Browser
      - Name:     Chrome
      - Family:   CHROME
      - Producer: Google Inc.
      - Version:  70.0.3538.102
      - Raw:      `Mozilla/5.0 (label_intellectual_deadline NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36`
  * Operating System
      - Name:     label_intellectual_deadline 7
      - Family:   label_intellectual_deadline
      - Producer: Microsoft Corporation.
      - Version:  6.1

