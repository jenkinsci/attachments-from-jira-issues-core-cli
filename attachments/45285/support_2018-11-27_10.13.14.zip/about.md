Jenkins
=======

Version details
---------------

  * Version: `2.138.3`
  * Mode:    WAR
  * Url:     http://ely-lt-m44068b.mchp-main.com:8080/
  * Servlet container
      - Specification: 3.1
      - Name:          `jetty/9.4.z-SNAPSHOT`
  * Java
      - Home:           `C:\Program Files\Java\jre1.8.0_181`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0_181
      - Maximum memory:   3.98 GB (4277665792)
      - Allocated memory: 3.98 GB (4277665792)
      - Free memory:      1.88 GB (2020343896)
      - In-use memory:    2.10 GB (2257321896)
      - GC strategy:      ParallelGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    Java HotSpot(TM) 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 25.181-b13
  * Operating system
      - Name:         label_intellectual_deadline 7
      - Architecture: amd64
      - Version:      6.1
  * Process ID: 5876 (0x16f4)
  * Process started: 2018-11-26 12:33:27.687+0000
  * Process uptime: 21 hr
  * JVM startup parameters:
      - Boot classpath: `C:\Program Files\Java\jre1.8.0_181\lib\resources.jar;C:\Program Files\Java\jre1.8.0_181\lib\rt.jar;C:\Program Files\Java\jre1.8.0_181\lib\sunrsasign.jar;C:\Program Files\Java\jre1.8.0_181\lib\jsse.jar;C:\Program Files\Java\jre1.8.0_181\lib\jce.jar;C:\Program Files\Java\jre1.8.0_181\lib\charsets.jar;C:\Program Files\Java\jre1.8.0_181\lib\jfr.jar;C:\Program Files\Java\jre1.8.0_181\classes`
      - Classpath: `C:\Program Files (x86)\Jenkins\jenkins.war`
rogram Files\Microsoft SQL Server\120\Tools\Binn\;C:\tools\gnuwin32\bin;C:\Program Files (x86)\Msc-generator;C:\Program Files\doxygen\bin;C:\Program Files (x86)\label_intellectual_deadline Kits\8.1\label_intellectual_deadline Performance Toolkit\;C:\Program Files\Microsoft\Web Platform Installer\;C:\Program Files\Microsoft label_intellectual_deadline Performance Toolkit\;C:\Program Files (x86)\Skype\Phone\;C:\Program Files (x86)\QuickTime\QTSystem\;C:\tools\svn1.9.3\bin;C:\Python27;C:\Program Files\Microsoft SQL Server\130\Tools\Binn\;C:\Program Files\TortoiseSVN\bin;C:\Program Files\Git\cmd;C:\Program Files\Git\mingw64\bin;C:\Program Files\Git\usr\bin;C:\Program Files (x86)\Mscgen;C:\Program Files\dotnet\;C:\Program Files\TortoiseGit\bin;;.`
      - arg[0]: `-Xrs`
      - arg[1]: `-Xms4096M`
      - arg[2]: `-Xmx4096M`
      - arg[3]: `-XX:MaxGCPauseMillis=500`
      - arg[4]: `-Dhudson.lifecycle=hudson.lifecycle.WindowsServiceLifecycle`
      - arg[5]: `-Dhudson.model.DirectoryBrowserSupport.CSP=`

Important configuration
---------------

  * Security realm: `hudson.plugins.active_directory.ActiveDirectorySecurityRealm`
  * Authorization strategy: `com.michelin.cio.hudson.plugins.rolestrategy.RoleBasedAuthorizationStrategy`
  * CSRF Protection: true
  * Initialization Milestone: Completed initialization
  * Support bundle anonymization: true

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * active-directory:2.10 'Jenkins Active Directory plugin'
  * analysis-collector:1.52 'Static Analysis Collector Plug-in'
  * analysis-core:1.95 'Static Analysis Utilities'
  * ant:1.9 'Ant Plugin'
  * antisamy-markup-formatter:1.5 'OWASP Markup Formatter Plugin'
  * any-buildstep:0.1 'Any Build Step Plugin'
  * apache-httpcomponents-client-4-api:4.5.5-3.0 'Jenkins Apache HttpComponents Client 4.x API Plugin'
  * artifactory:2.16.2 'Jenkins Artifactory Plugin'
  * audit-trail:2.3 'Audit Trail'
  * authentication-tokens:1.3 'Authentication Tokens API Plugin'
  * BlameSubversion:1.200 'Hudson Blame Subversion Plug-in'
  * blueocean-commons:1.9.0 'Common API for Blue Ocean'
  * blueocean-core-js:1.9.0 'Blue Ocean Core JS'
  * blueocean-jwt:1.9.0 'JWT for Blue Ocean'
  * blueocean-rest:1.9.0 'REST API for Blue Ocean'
  * blueocean-web:1.9.0 'Web for Blue Ocean'
  * bouncycastle-api:2.17 'bouncycastle API Plugin'
  * branch-api:2.1.1 'Branch API Plugin'
  * build-environment:1.6 'Build Environment Plugin'
  * build-failure-analyzer:1.20.0 'Build Failure Analyzer'
  * build-history-metrics-plugin:1.2 'Build History Metrics plugin'
  * build-monitor-plugin:1.12+build.201809061734 'Build Monitor View'
  * build-name-setter:1.6.9 'build-name-setter'
  * build-pipeline-plugin:1.5.8 'Build Pipeline Plugin'
  * build-timeout:1.19 'Build Timeout'
  * build-timestamp:1.0.3 'Build Timestamp Plugin'
  * build-with-parameters:1.4 'Build With Parameters'
  * claim:2.15 'Jenkins Claim Plugin'
  * cloudbees-folder:6.7 'Folders Plugin'
  * command-launcher:1.2 'Command Agent Launcher Plugin'
  * compact-columns:1.10 'Compact Columns'
  * conditional-buildstep:1.3.6 'Conditional BuildStep'
  * config-file-provider:3.4.1 'Config File Provider Plugin'
  * copyartifact:1.41 'Copy Artifact Plugin'
  * cppcheck:1.24 'Jenkins Cppcheck Plug-in'
  * create-fingerprint:1.2 'Fingerprint Plugin'
  * credentials:2.1.18 'Credentials Plugin'
  * credentials-binding:1.17 'Credentials Binding Plugin'
  * dashboard-view:2.10 'Dashboard View'
  * disk-usage:0.28 'Jenkins disk-usage plugin'
  * display-url-api:2.3.0 'Display URL API'
  * docker-commons:1.13 'Docker Commons Plugin'
  * docker-workflow:1.17 'Docker Pipeline'
  * downstream-buildview:1.9 'Downstream build view'
  * doxygen:0.18 'Jenkins Doxygen Plug-in'
  * durable-task:1.28 'Durable Task Plugin'
  * email-ext:2.63 'Email Extension Plugin'
  * emailext-template:1.1 'Email Extension Template Plugin'
  * envinject:2.1.6 'Environment Injector Plugin'
  * envinject-api:1.5 'EnvInject API Plugin'
  * environment-script:1.2.5 'Environment Script Plugin'
  * external-monitor-job:1.7 'External Monitor Job Type Plugin'
  * fail-the-build-plugin:1.0 'Fail The Build Plugin'
  * favorite:2.3.2 'Favorite'
  * file-operations:1.7 'File Operations Plugin'
  * flexible-publish:0.15.2 'Flexible Publish Plugin'
  * git:3.9.1 'Jenkins Git plugin'
  * git-client:2.7.4 'Jenkins Git client plugin'
  * git-parameter:0.9.6 'Git Parameter Plug-In'
  * git-server:1.7 'Jenkins GIT server Plugin'
  * github:1.29.3 'GitHub plugin'
  * github-api:1.92 'GitHub API Plugin'
  * github-branch-source:2.4.1 'GitHub Branch Source Plugin'
  * github-organization-folder:1.6 'GitHub Organization Folder Plugin'
  * global-build-stats:1.5 'Hudson global-build-stats plugin'
  * gradle:1.29 'Gradle Plugin'
  * greenballs:1.15 'Green Balls'
  * handlebars:1.1.1 'JavaScript GUI Lib: Handlebars bundle plugin'
  * htmlpublisher:1.17 'HTML Publisher plugin'
  * hudson-pview-plugin:1.8 'Hudson Personal View'
  * icon-shim:2.0.3 'Icon Shim Plugin'
  * ivy:1.28 'Ivy Plugin'
  * jackson2-api:ip_last_default 'Jackson 2 API Plugin'
  * javadoc:1.4 'Javadoc Plugin'
  * jdk-tool:1.1 'JDK Tool Plugin'
  * jenkins-design-language:1.9.0 'Jenkins Design Language'
  * jenkinslint:0.14.0 'JenkinsLint Plugin'
  * jenkinswalldisplay:0.6.34 'Jenkins Wall Display Master Project'
  * jira:3.0.5 'Jenkins JIRA plugin'
  * jira-steps:1.4.4 'JIRA Pipeline Steps'
  * jobConfigHistory:2.18.3 'Jenkins Job Configuration History Plugin'
  * jquery:1.12.4-0 'jQuery plugin'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * jquery-ui:1.0.2 'Jenkins jQuery UI plugin'
  * jsch:ip_permanent_fortune 'Jenkins JSch dependency plugin'
  * junit:1.26.1 'JUnit Plugin'
  * ldap:1.20 'LDAP Plugin'
  * lockable-resources:2.3 'Lockable Resources plugin'
  * log-parser:2.0 'Log Parser Plugin'
  * mailer:1.22 'Jenkins Mailer Plugin'
  * mapdb-api:ip_complete_withdrawal 'MapDB API Plugin'
  * matrix-auth:2.3 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.13 'Matrix Project Plugin'
  * maven-plugin:3.1.2 'Maven Integration plugin'
  * measurement-plots:0.1 'Measurement Plots'
  * memory-map:2.2.1 (53614) 'Memory Map Plugin'
  * mercurial:2.4 'Jenkins Mercurial plugin'
  * metrics:ip_fat_cake 'Metrics Plugin'
  * mission-control-view:0.9.14 'Mission Control Plugin'
  * modernstatus:1.2 'Modern Status'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * monitoring:1.74.0 'Monitoring'
  * multi-branch-project-plugin:0.7 'Multi-Branch Project Plugin (DEPRECATED)'
  * naginator:1.17.2 'Naginator'
  * nodelabelparameter:1.7.2 'Node and Label parameter plugin'
  * openJDK-native-plugin:1.1 'openJDK-native-plugin'
  * pam-auth:1.4 'PAM Authentication plugin'
  * parameterized-trigger:2.35.2 'Jenkins Parameterized Trigger plugin'
  * performance:3.13 'Performance Plugin'
  * perfpublisher:8.05 'Jenkins Performance Publisher plugin'
  * pipeline-build-step:2.7 'Pipeline: Build Step'
  * pipeline-github-lib:1.0 'Pipeline: GitHub Groovy Libraries'
  * pipeline-graph-analysis:1.9 'Pipeline Graph Analysis Plugin'
  * pipeline-input-step:2.8 'Pipeline: Input Step'
  * pipeline-maven:3.6.2 'Pipeline Maven Integration Plugin'
  * pipeline-milestone-step:1.3.1 'Pipeline: Milestone Step'
  * pipeline-model-api:1.3.2 'Pipeline: Model API'
  * pipeline-model-declarative-agent:1.1.1 'Pipeline: Declarative Agent API'
  * pipeline-model-definition:1.3.2 'Pipeline: Declarative'
  * pipeline-model-extensions:1.3.2 'Pipeline: Declarative Extension Points API'
  * pipeline-rest-api:2.10 'Pipeline: REST API Plugin'
  * pipeline-stage-step:2.3 'Pipeline: Stage Step'
  * pipeline-stage-tags-metadata:1.3.2 'Pipeline: Stage Tags Metadata'
  * pipeline-stage-view:2.10 'Pipeline: Stage View Plugin'
  * pipeline-utility-steps:2.2.0 'Pipeline Utility Steps'
  * plain-credentials:1.4 'Plain Credentials Plugin'
  * plot:2.1.0 'Plot plugin'
  * pollscm:1.3.1 'Jenkins Poll SCM plugin'
  * powershell:1.3 'Jenkins PowerShell plugin'
  * preSCMbuildstep:0.3 'Pre SCM BuildStep Plugin'
  * prometheus:2.0.0 'Prometheus metrics plugin'
  * publish-over:0.22 'Infrastructure plugin for Publish Over X'
  * pubsub-light:1.12 'Jenkins Pub-Sub "light" Bus'
  * rebuild:1.29 'Rebuilder'
  * regression-report-plugin:1.5 'Regression Report Plugin'
  * resource-disposer:0.12 'Resource Disposer Plugin'
  * role-strategy:2.9.0 'Role-based Authorization Strategy'
  * run-condition:1.2 'Run Condition Plugin'
  * saferestart:0.3 'Safe Restart Plugin'
  * scm-api:2.3.0 'SCM API Plugin'
  * scm-sync-configuration:0.0.11-SNAPSHOT (private-cdb2d5d9-pjohnston) 'SCM Sync Configuration Plugin'
  * scoring-load-balancer:1.0.1 'Scoring Load Balancer'
  * script-security:1.48 'Script Security Plugin'
  * shelve-project-plugin:2.2 'Shelve Project Plugin'
  * show-build-parameters:1.0 'Show Build Parameters plugin'
  * ssh-credentials:1.14 'SSH Credentials Plugin'
  * ssh-slaves:1.29.1 'Jenkins SSH Slaves plugin'
  * stashNotifier:1.14 'Stash Notifier'
  * statistics-gatherer:2.0.3 'Statistics Gatherer Plugin'
  * structs:1.17 'Structs Plugin'
  * subversion:2.11.1 *(update available)* 'Jenkins Subversion Plug-in'
  * support-core:2.51 'Support Core Plugin'
  * svn-release-mgr:1.2 'Subversion Release Manager plugin'
  * svn-tag:1.18 'Jenkins Subversion Tagging Plugin'
  * svnpublisher:0.1 'SVN Publisher plugin'
  * tasks:4.52 'Task Scanner Plug-in'
  * template-project:1.5.2 'Template Project plugin'
  * terminal:1.4 'Jenkins Terminal Plugin'
  * text-file-operations:1.3.2 'Text File Operations'
  * text-finder:1.10 'Jenkins TextFinder plugin'
  * thinBackup:1.9 'ThinBackup'
  * timestamper:1.8.10 'Timestamper'
  * token-macro:2.5 'Token Macro Plugin'
  * trilead-api:1.0.1 'Trilead API Plugin'
  * uptime:1.0 'Uptime'
  * variant:1.1 'Variant Plugin'
  * violation-comments-to-stash:1.92 'Jenkins Violation Comments to Bitbucket Server Plugin'
  * violations:0.7.11 'Jenkins Violations plugin'
  * warnings:4.68 'Warnings Plug-in'
  * label_intellectual_deadline-slaves:1.3.1 'label_intellectual_deadline Slaves Plugin'
  * workflow-aggregator:2.6 'Pipeline'
  * workflow-api:2.33 'Pipeline: API'
  * workflow-basic-steps:2.12 'Pipeline: Basic Steps'
  * workflow-cps:2.60 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.12 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.26 'Pipeline: Nodes and Processes'
  * workflow-job:2.29 'Pipeline: Job'
  * workflow-multibranch:2.20 'Pipeline: Multibranch'
  * workflow-scm-step:2.7 'Pipeline: SCM Step'
  * workflow-step-api:2.16 'Pipeline: Step API'
  * workflow-support:2.22 'Pipeline: Supporting APIs'
  * ws-cleanup:0.36 'Jenkins Workspace Cleanup Plugin'
  * xunit:2.3.1 'xUnit plugin'
