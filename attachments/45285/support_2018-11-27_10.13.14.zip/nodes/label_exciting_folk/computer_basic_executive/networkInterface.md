-----------
 * Name Software Loopback Interface 1
 ** Index - 1
 ** InetAddress - /ip_comparable_declaration
 ** InetAddress - /ip_consistent_lady
 ** MTU - -1
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name WAN Miniport (SSTP)
 ** Index - 2
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name WAN Miniport (L2TP)
 ** Index - 3
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name WAN Miniport (PPTP)
 ** Index - 4
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name WAN Miniport (PPPOE)
 ** Index - 5
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name WAN Miniport (IPv6)
 ** Index - 6
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name WAN Miniport (Network Monitor)
 ** Index - 7
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name WAN Miniport (IP)
 ** Index - 8
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name RAS Async Adapter
 ** Index - 9
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Realtek PCIe GBE Family Controller
 ** Hardware Address - 80ee733589f8
 ** Index - 10
 ** InetAddress - /ip_steep_reproduction
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Realtek PCIe GBE Family Controller #2
 ** Hardware Address - 80ee733589f9
 ** Index - 11
 ** InetAddress - /ip_voluntary_cabin
 ** InetAddress - /ip_abundant_suffering
 ** InetAddress - /ip_convenient_worm
 ** InetAddress - /ip_frank_canvas%eth4
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Microsoft ISATAP Adapter #2
 ** Hardware Address - 00000000000000e0
 ** Index - 12
 ** InetAddress - /ip_logical_demonstrator%net3
 ** MTU - 1280
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - true
 ** Supports multicast - false
-----------
 * Name WAN Miniport (IKEv2)
 ** Index - 13
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Microsoft ISATAP Adapter
 ** Hardware Address - 00000000000000e0
 ** Index - 14
 ** InetAddress - /ip_foolish_franchise%net5
 ** MTU - 1280
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - true
 ** Supports multicast - false
-----------
 * Name Microsoft ISATAP Adapter #3
 ** Index - 15
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Teredo Tunneling Pseudo-Interface
 ** Hardware Address - 00000000000000e0
 ** Index - 16
 ** InetAddress - /ip_content_delivery%net7
 ** MTU - 1280
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - true
 ** Supports multicast - false
-----------
 * Name VirtualBox Host-Only Ethernet Adapter
 ** Hardware Address - 0a0027000011
 ** Index - 17
 ** InetAddress - /ip_stable_wording
 ** InetAddress - /ip_practical_freight%eth5
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name VirtualBox Host-Only Ethernet Adapter #2
 ** Hardware Address - 0a0027000012
 ** Index - 18
 ** InetAddress - /ip_strange_lane
 ** InetAddress - /ip_accurate_palace%eth6
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Microsoft ISATAP Adapter #4
 ** Hardware Address - 00000000000000e0
 ** Index - 19
 ** InetAddress - /ip_corporate_requirement%net8
 ** MTU - 1280
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - true
 ** Supports multicast - false
-----------
 * Name Microsoft ISATAP Adapter #5
 ** Hardware Address - 00000000000000e0
 ** Index - 20
 ** InetAddress - /ip_friendly_suit%net9
 ** MTU - 1280
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - true
 ** Supports multicast - false
-----------
 * Name Microsoft ISATAP Adapter-Symantec Endpoint Protection Firewall-0000
 ** Index - 21
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Microsoft ISATAP Adapter #2-Symantec Endpoint Protection Firewall-0000
 ** Index - 22
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Microsoft ISATAP Adapter #3-Symantec Endpoint Protection Firewall-0000
 ** Index - 23
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Microsoft ISATAP Adapter #4-Symantec Endpoint Protection Firewall-0000
 ** Index - 24
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Microsoft ISATAP Adapter #5-Symantec Endpoint Protection Firewall-0000
 ** Index - 25
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Teredo Tunneling Pseudo-Interface-Symantec Endpoint Protection Firewall-0000
 ** Index - 26
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Realtek PCIe GBE Family Controller #2-VirtualBox NDIS Light-Weight Filter-0000
 ** Index - 27
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Realtek PCIe GBE Family Controller #2-QoS Packet Scheduler-0000
 ** Index - 28
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Realtek PCIe GBE Family Controller #2-WFP LightWeight Filter-0000
 ** Index - 29
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Realtek PCIe GBE Family Controller #2-Symantec Endpoint Protection Firewall-0000
 ** Index - 30
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Realtek PCIe GBE Family Controller-VirtualBox NDIS Light-Weight Filter-0000
 ** Index - 31
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Realtek PCIe GBE Family Controller-QoS Packet Scheduler-0000
 ** Index - 32
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Realtek PCIe GBE Family Controller-WFP LightWeight Filter-0000
 ** Index - 33
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Realtek PCIe GBE Family Controller-Symantec Endpoint Protection Firewall-0000
 ** Index - 34
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name VirtualBox Host-Only Ethernet Adapter #2-QoS Packet Scheduler-0000
 ** Index - 35
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name VirtualBox Host-Only Ethernet Adapter #2-WFP LightWeight Filter-0000
 ** Index - 36
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name VirtualBox Host-Only Ethernet Adapter #2-Symantec Endpoint Protection Firewall-0000
 ** Index - 37
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name VirtualBox Host-Only Ethernet Adapter-QoS Packet Scheduler-0000
 ** Index - 38
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name VirtualBox Host-Only Ethernet Adapter-WFP LightWeight Filter-0000
 ** Index - 39
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name VirtualBox Host-Only Ethernet Adapter-Symantec Endpoint Protection Firewall-0000
 ** Index - 40
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name WAN Miniport (IPv6)-Symantec Endpoint Protection Firewall-0000
 ** Index - 41
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name WAN Miniport (IPv6)-QoS Packet Scheduler-0000
 ** Index - 42
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name WAN Miniport (IP)-Symantec Endpoint Protection Firewall-0000
 ** Index - 43
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name WAN Miniport (IP)-QoS Packet Scheduler-0000
 ** Index - 44
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name WAN Miniport (Network Monitor)-Symantec Endpoint Protection Firewall-0000
 ** Index - 45
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name WAN Miniport (Network Monitor)-QoS Packet Scheduler-0000
 ** Index - 46
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
