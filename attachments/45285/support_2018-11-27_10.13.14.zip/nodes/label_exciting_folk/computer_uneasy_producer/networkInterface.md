-----------
 * Name enp2s0
 ** Hardware Address - 50e54918d5e9
 ** Index - 2
 ** InetAddress - /ip_technical_acceptance%enp2s0
 ** InetAddress - /ip_arrogant_catalogue%enp2s0
 ** InetAddress - /ip_digital_deviation%enp2s0
 ** InetAddress - /ip_harmful_game%enp2s0
 ** InetAddress - /ip_miserable_legend%enp2s0
 ** InetAddress - /ip_raw_party%enp2s0
 ** InetAddress - /ip_terminal_retreat%enp2s0
 ** InetAddress - /ip_asleep_suspect%enp2s0
 ** InetAddress - /ip_written_fountain
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /ip_comparable_declaration
 ** MTU - 65536
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false
