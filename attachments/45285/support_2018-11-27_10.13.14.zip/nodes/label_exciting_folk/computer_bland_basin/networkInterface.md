-----------
 * Name eth2
 ** Hardware Address - 30b5c2022d05
 ** Index - 4
 ** InetAddress - /ip_financial_struggle
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name eth1
 ** Hardware Address - 00133b0f7e28
 ** Index - 3
 ** InetAddress - /ip_agile_career%eth1
 ** InetAddress - /ip_daily_deputy
 ** MTU - 1492
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name eth0
 ** Hardware Address - fcaa1467620a
 ** Index - 2
 ** InetAddress - /ip_genetic_frustration%eth0
 ** InetAddress - /ip_manual_layout
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /ip_comparable_declaration
 ** MTU - 65536
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false
