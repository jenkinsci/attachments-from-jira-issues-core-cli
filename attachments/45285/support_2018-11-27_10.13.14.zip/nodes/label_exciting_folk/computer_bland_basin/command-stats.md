# Totals
* Writes: 46240
  * sent 159.7Mb
* Reads: 60993
  * received 63.4Mb
* Responses: 6983
  * waited 16 hr

# Commands sent
* `Pipe.Chunk`: 30827
  * sent 128.9Mb
* `ProxyOutputStream.Ack`: 2982
  * sent 0.5Mb
* `ProxyOutputStream.EOF`: 1924
  * sent 4.0Mb
* `ProxyOutputStream.Unexport`: 1
  * sent 0.0Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 651
  * sent 1.7Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 15
  * sent 0.0Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResources2[java.lang.String]`: 4
  * sent 0.0Mb
* `Response:UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 48
  * sent 0.1Mb
* `Response:UserRequest:UserRPCRequest:hudson.remoting.JarLoader.writeJarTo[long,long,java.io.OutputStream]`: 1
  * sent 0.0Mb
* `Response:UserRequest:hudson.remoting.Channel$IOSyncer`: 1
  * sent 0.0Mb
* `Response:UserRequest:hudson.remoting.PingThread$Ping`: 258
  * sent 0.5Mb
* `Response:UserRequest:hudson.util.ProcessTree$DoVetoersExist`: 1
  * sent 0.0Mb
* `Unexport`: 2544
  * sent 3.7Mb
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.getIOtriplet[]`: 1
  * sent 0.0Mb
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.isAlive[]`: 1
  * sent 0.0Mb
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.join[]`: 1
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 22
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 1
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.api.CommandOutputContent$CommandLauncher`: 117
  * sent 0.3Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 22
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 22
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 22
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 22
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.FileDescriptorLimit$GetUlimit`: 22
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 22
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 21
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 44
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemConfiguration$GetDmiInfo`: 39
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 21
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 22
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.util.SystemPlatform$GetCurrentPlatform`: 78
  * sent 0.2Mb
* `UserRequest:hudson.EnvVars$GetEnvVars`: 1
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$2`: 1
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$CallableWith`: 44
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$CopyRecursiveRemoteToLocal`: 1
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$CopyTo`: 463
  * sent 1.3Mb
* `UserRequest:hudson.FilePath$CreateTextTempFile`: 1
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Delete`: 1
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Exists`: 65
  * sent 0.2Mb
* `UserRequest:hudson.FilePath$IsDirectory`: 22
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$LastModified`: 464
  * sent 1.2Mb
* `UserRequest:hudson.FilePath$Mkdirs`: 3
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Read`: 3
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Touch`: 1924
  * sent 6.1Mb
* `UserRequest:hudson.FilePath$WritePipe`: 1924
  * sent 6.2Mb
* `UserRequest:hudson.Launcher$RemoteLaunchCallable`: 1
  * sent 0.0Mb
* `UserRequest:hudson.Launcher$RemoteLauncher$KillTask`: 1
  * sent 0.0Mb
* `UserRequest:hudson.logging.LogRecorder$SetLevel`: 1
  * sent 0.0Mb
* `UserRequest:hudson.model.Computer$ListPossibleNames`: 1
  * sent 0.0Mb
* `UserRequest:hudson.model.label_exciting_folk$GetClockDifference1`: 22
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 22
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 22
  * sent 0.1Mb
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 22
  * sent 0.0Mb
* `UserRequest:hudson.plugins.PerfPublisher.PerfPublisherPublisher$ParseReportCallable`: 1
  * sent 0.0Mb
* `UserRequest:hudson.plugins.disk_usage.DiskUsageUtil$DiskUsageCallable`: 1
  * sent 0.0Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 258
  * sent 0.5Mb
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 1
  * sent 0.0Mb
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 22
  * sent 0.1Mb
* `UserRequest:hudson.tasks.ArtifactArchiver$ListFiles`: 1
  * sent 0.0Mb
* `UserRequest:hudson.tasks.Fingerprinter$FindRecords`: 1
  * sent 0.0Mb
* `UserRequest:hudson.tasks.junit.JUnitParser$ParseResultCallable`: 1
  * sent 0.0Mb
* `UserRequest:hudson.util.RemotingDiagnostics$GetSystemProperties`: 57
  * sent 0.2Mb
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 1
  * sent 0.0Mb
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 1
  * sent 0.0Mb
* `UserRequest:net.bull.javamelody.RemoteCallHelper$DelegatingTask`: 1121
  * sent 2.9Mb
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.EnvInjectComputerListener$2`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectActionSetter$MapEnvInjectExceptionMasterToSlaveCallable`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsSetter`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvironmentVariablesNodeLoader$EnvVarMasterToSlaveCallable`: 1
  * sent 0.0Mb
* `UserRequest:org.jfrog.hudson.pipeline.docker.proxy.BuildInfoProxy$1`: 1
  * sent 0.0Mb

# Commands received
* `Pipe.Chunk`: 2982
  * received 4.4Mb
* `Pipe.Flush`: 2529
  * received 0.4Mb
* `ProxyOutputStream.Ack`: 30827
  * received 4.7Mb
* `ProxyOutputStream.EOF`: 468
  * received 0.9Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 651
  * received 0.4Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 15
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResources2[java.lang.String]`: 4
  * received 0.0Mb
* `Response`: 6983
  * received 27.4Mb
* `Unexport`: 16225
  * received 24.4Mb
* `UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 48
  * received 0.3Mb
* `UserRequest:UserRPCRequest:hudson.remoting.JarLoader.writeJarTo[long,long,java.io.OutputStream]`: 1
  * received 0.0Mb
* `UserRequest:hudson.remoting.Channel$IOSyncer`: 1
  * received 0.0Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 258
  * received 0.5Mb
* `UserRequest:hudson.util.ProcessTree$DoVetoersExist`: 1
  * received 0.0Mb

# Responses received
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.getIOtriplet[]`: 1
  * waited 4 ms
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.isAlive[]`: 1
  * waited 2 ms
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.join[]`: 1
  * waited 16 hr
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 22
  * waited 62 ms
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 1
  * waited 0.65 sec
* `UserRequest:com.cloudbees.jenkins.support.api.CommandOutputContent$CommandLauncher`: 117
  * waited 1.8 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 22
  * waited 2.6 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 22
  * waited 4.7 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 22
  * waited 0.12 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 22
  * waited 82 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.FileDescriptorLimit$GetUlimit`: 22
  * waited 0.27 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 22
  * waited 97 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 21
  * waited 0.22 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 44
  * waited 0.48 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemConfiguration$GetDmiInfo`: 39
  * waited 0.29 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 21
  * waited 74 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 22
  * waited 0.37 sec
* `UserRequest:com.cloudbees.jenkins.support.util.SystemPlatform$GetCurrentPlatform`: 78
  * waited 0.22 sec
* `UserRequest:hudson.EnvVars$GetEnvVars`: 1
  * waited 27 ms
* `UserRequest:hudson.FilePath$2`: 1
  * waited 22 ms
* `UserRequest:hudson.FilePath$CallableWith`: 44
  * waited 0.51 sec
* `UserRequest:hudson.FilePath$CopyRecursiveRemoteToLocal`: 1
  * waited 0.24 sec
* `UserRequest:hudson.FilePath$CopyTo`: 463
  * waited 1.5 sec
* `UserRequest:hudson.FilePath$CreateTextTempFile`: 1
  * waited 7 ms
* `UserRequest:hudson.FilePath$Delete`: 1
  * waited 2 ms
* `UserRequest:hudson.FilePath$Exists`: 65
  * waited 0.77 sec
* `UserRequest:hudson.FilePath$IsDirectory`: 22
  * waited 0.11 sec
* `UserRequest:hudson.FilePath$LastModified`: 464
  * waited 1.2 sec
* `UserRequest:hudson.FilePath$Mkdirs`: 3
  * waited 9 ms
* `UserRequest:hudson.FilePath$Read`: 3
  * waited 61 ms
* `UserRequest:hudson.FilePath$Touch`: 1924
  * waited 4.9 sec
* `UserRequest:hudson.FilePath$WritePipe`: 1924
  * waited 6 sec
* `UserRequest:hudson.Launcher$RemoteLaunchCallable`: 1
  * waited 0.15 sec
* `UserRequest:hudson.Launcher$RemoteLauncher$KillTask`: 1
  * waited 1.7 sec
* `UserRequest:hudson.logging.LogRecorder$SetLevel`: 1
  * waited 31 ms
* `UserRequest:hudson.model.Computer$ListPossibleNames`: 1
  * waited 27 ms
* `UserRequest:hudson.model.label_exciting_folk$GetClockDifference1`: 22
  * waited 0.17 sec
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 22
  * waited 0.1 sec
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 22
  * waited 0.14 sec
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 22
  * waited 0.2 sec
* `UserRequest:hudson.plugins.PerfPublisher.PerfPublisherPublisher$ParseReportCallable`: 1
  * waited 45 ms
* `UserRequest:hudson.plugins.disk_usage.DiskUsageUtil$DiskUsageCallable`: 1
  * waited 0.47 sec
* `UserRequest:hudson.remoting.PingThread$Ping`: 258
  * waited 0.79 sec
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 1
  * waited 25 ms
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 22
  * waited 92 ms
* `UserRequest:hudson.tasks.ArtifactArchiver$ListFiles`: 1
  * waited 7 ms
* `UserRequest:hudson.tasks.Fingerprinter$FindRecords`: 1
  * waited 0.3 sec
* `UserRequest:hudson.tasks.junit.JUnitParser$ParseResultCallable`: 1
  * waited 0.48 sec
* `UserRequest:hudson.util.RemotingDiagnostics$GetSystemProperties`: 57
  * waited 0.14 sec
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 1
  * waited 0.35 sec
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 1
  * waited 0.14 sec
* `UserRequest:net.bull.javamelody.RemoteCallHelper$DelegatingTask`: 1121
  * waited 44 sec
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 1
  * waited 21 ms
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 1
  * waited 0.12 sec
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 1
  * waited 67 ms
* `UserRequest:org.jenkinsci.plugins.envinject.EnvInjectComputerListener$2`: 1
  * waited 76 ms
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectActionSetter$MapEnvInjectExceptionMasterToSlaveCallable`: 1
  * waited 8 ms
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsSetter`: 1
  * waited 18 ms
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvironmentVariablesNodeLoader$EnvVarMasterToSlaveCallable`: 1
  * waited 0.32 sec
* `UserRequest:org.jfrog.hudson.pipeline.docker.proxy.BuildInfoProxy$1`: 1
  * waited 0.1 sec

# JARs sent
* `jna-4.5.2.jar`: 1484022b
* `libpam4j-1.8.jar`: 19925b
* `support-core.jar`: 317701b
* `commons-io-2.4.jar`: 185140b
* `commons-compress-1.10.jar`: 409475b
* `ant-1.9.2.jar`: 2000557b
* `commons-fileupload-1.3.1-jenkins-2.jar`: 68803b
* `launchd-label_exciting_folk-installer-1.2.jar`: 22663b
* `label_exciting_folk-installer-1.6.jar`: 27374b
* `systemd-label_exciting_folk-installer-1.1.jar`: 11541b
* `envinject.jar`: 154483b
* `envinject-lib-1.29.jar`: 20599b
* `monitoring.jar`: 41743b
* `itext-2.1.7.jar`: 1130070b
* `spring-context-2.5.6.SEC03.jar`: 476894b
* `commons-codec-1.9.jar`: 263965b
* `json-lib-2.4-jenkins-2.jar`: 141207b
* `xpp3-1.1.4c.jar`: 120069b
* `slf4j-jdk14-1.7.25.jar`: 8460b
* `junit.jar`: 439638b
* `dom4j-1.6.1-jenkins-4.jar`: 254359b
* `perfpublisher.jar`: 166764b
* `matrix-project.jar`: 244433b
* `disk-usage.jar`: 102597b
* `mail-1.4.4.jar`: 494924b
* `artifactory.jar`: 657548b
* `mitm-2.1.1.jar`: 213956b
* `littleproxy-1.1.2.jar`: 130290b
