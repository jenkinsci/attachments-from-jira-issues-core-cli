# Totals
* Writes: 19354
  * sent 26.2Mb
* Reads: 35520
  * received 93.8Mb
* Responses: 3171
  * waited 40 min

# Commands sent
* `Pipe.Chunk`: 39
  * sent 0.3Mb
* `ProxyOutputStream.Ack`: 13281
  * sent 2.0Mb
* `ProxyOutputStream.Unexport`: 1
  * sent 0.0Mb
* `Response:RPCRequest:null.fetch3[java.lang.String]`: 1804
  * sent 11.8Mb
* `Response:RPCRequest:null.fetch[java.lang.String]`: 1
  * sent 0.0Mb
* `Response:RPCRequest:null.getResource2[java.lang.String]`: 23
  * sent 0.6Mb
* `Response:RPCRequest:null.getResources2[java.lang.String]`: 4
  * sent 0.0Mb
* `Response:UserRequest:RPCRequest`: 9
  * sent 0.0Mb
* `Response:UserRequest:hudson.remoting.Channel$IOSyncer`: 40
  * sent 0.1Mb
* `Response:UserRequest:hudson.remoting.PingThread$Ping`: 263
  * sent 0.5Mb
* `Response:UserRequest:hudson.scm.SubversionWorkspaceSelector$1`: 20
  * sent 0.0Mb
* `Response:UserRequest:hudson.util.ProcessTree$DoVetoersExist`: 1
  * sent 0.0Mb
* `Unexport`: 697
  * sent 1.3Mb
* `UserRequest:RPCRequest:hudson.Launcher$RemoteProcess.getIOtriplet[]`: 40
  * sent 0.1Mb
* `UserRequest:RPCRequest:hudson.Launcher$RemoteProcess.isAlive[]`: 40
  * sent 0.1Mb
* `UserRequest:RPCRequest:hudson.Launcher$RemoteProcess.join[]`: 40
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 23
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 1
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 23
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 23
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 23
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 23
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 23
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 22
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 44
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 22
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 22
  * sent 0.1Mb
* `UserRequest:hudson.EnvVars$GetEnvVars`: 1
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$2`: 3
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$CallableWith`: 46
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$CopyRecursiveRemoteToLocal`: 5
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$CopyTo`: 315
  * sent 1.1Mb
* `UserRequest:hudson.FilePath$CreateTextTempFile`: 40
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$Delete`: 40
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$Exists`: 93
  * sent 0.3Mb
* `UserRequest:hudson.FilePath$IsDirectory`: 25
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$LastModified`: 18
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$ListGlob`: 25
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$Mkdirs`: 5
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Read`: 30
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$ValidateAntFileMask`: 14
  * sent 0.1Mb
* `UserRequest:hudson.Launcher$RemoteLaunchCallable`: 40
  * sent 0.3Mb
* `UserRequest:hudson.Launcher$RemoteLauncher$KillTask`: 5
  * sent 0.0Mb
* `UserRequest:hudson.logging.LogRecorder$SetLevel`: 1
  * sent 0.0Mb
* `UserRequest:hudson.model.Computer$ListPossibleNames`: 1
  * sent 0.0Mb
* `UserRequest:hudson.model.label_exciting_folk$GetClockDifference1`: 23
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 23
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 23
  * sent 0.1Mb
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 23
  * sent 0.0Mb
* `UserRequest:hudson.plugins.analysis.core.AnnotationsClassifier`: 20
  * sent 0.5Mb
* `UserRequest:hudson.plugins.disk_usage.DiskUsageUtil$DiskUsageCallable`: 5
  * sent 0.0Mb
* `UserRequest:hudson.plugins.tasks.parser.WorkspaceScanner`: 5
  * sent 0.0Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 263
  * sent 0.5Mb
* `UserRequest:hudson.scm.SubversionChangeLogBuilder$GetContextForPath`: 5
  * sent 0.0Mb
* `UserRequest:hudson.scm.SubversionSCM$BuildRevisionMapTask`: 5
  * sent 0.1Mb
* `UserRequest:hudson.scm.SubversionSCM$CheckOutTask`: 5
  * sent 0.0Mb
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 1
  * sent 0.0Mb
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 23
  * sent 0.1Mb
* `UserRequest:hudson.tasks.ArtifactArchiver$ListFiles`: 5
  * sent 0.0Mb
* `UserRequest:hudson.tasks.Fingerprinter$FindRecords`: 5
  * sent 0.0Mb
* `UserRequest:hudson.util.RemotingDiagnostics$GetSystemProperties`: 315
  * sent 0.9Mb
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 1
  * sent 0.0Mb
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 1
  * sent 0.0Mb
* `UserRequest:net.bull.javamelody.RemoteCallHelper$DelegatingTask`: 1315
  * sent 3.4Mb
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.upstart_slave_installer.SlaveInstallerFactoryImpl$HasUpstart`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.windows_slave_installer.SlaveInstallerFactoryImpl$IsWindows`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.EnvInjectComputerListener$2`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectActionSetter$MapEnvInjectExceptionMasterToSlaveCallable`: 5
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsSetter`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvironmentVariablesNodeLoader$EnvVarMasterToSlaveCallable`: 5
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.PropertiesVariablesRetriever`: 5
  * sent 0.0Mb
* `UserRequest:org.jfrog.hudson.generic.FilesResolverCallable`: 3
  * sent 0.0Mb
* `UserRequest:org.jfrog.hudson.generic.GenericArtifactsDeployer$FilesDeployerCallable`: 3
  * sent 0.0Mb
* `UserRequest:org.jfrog.hudson.pipeline.docker.proxy.BuildInfoProxy$1`: 1
  * sent 0.0Mb

# Commands received
* `Pipe.Chunk`: 13281
  * received 42.3Mb
* `Pipe.Flush`: 6809
  * received 1.2Mb
* `ProxyOutputStream.Ack`: 39
  * received 0.0Mb
* `ProxyOutputStream.EOF`: 353
  * received 0.7Mb
* `ProxyOutputStream.Unexport`: 33
  * received 0.0Mb
* `RPCRequest:null.fetch3[java.lang.String]`: 1804
  * received 5.8Mb
* `RPCRequest:null.fetch[java.lang.String]`: 1
  * received 0.0Mb
* `RPCRequest:null.getResource2[java.lang.String]`: 23
  * received 0.1Mb
* `RPCRequest:null.getResources2[java.lang.String]`: 4
  * received 0.0Mb
* `Response`: 3171
  * received 19.4Mb
* `Unexport`: 9669
  * received 23.4Mb
* `UserRequest:RPCRequest`: 9
  * received 0.1Mb
* `UserRequest:hudson.remoting.Channel$IOSyncer`: 40
  * received 0.1Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 263
  * received 0.6Mb
* `UserRequest:hudson.scm.SubversionWorkspaceSelector$1`: 20
  * received 0.0Mb
* `UserRequest:hudson.util.ProcessTree$DoVetoersExist`: 1
  * received 0.0Mb

# Responses received
* `UserRequest:RPCRequest:hudson.Launcher$RemoteProcess.getIOtriplet[]`: 40
  * waited 69 ms
* `UserRequest:RPCRequest:hudson.Launcher$RemoteProcess.isAlive[]`: 40
  * waited 68 ms
* `UserRequest:RPCRequest:hudson.Launcher$RemoteProcess.join[]`: 40
  * waited 37 min
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 23
  * waited 47 ms
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 1
  * waited 1.2 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 23
  * waited 0.21 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 23
  * waited 82 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 23
  * waited 57 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 23
  * waited 53 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 23
  * waited 12 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 22
  * waited 0.12 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 44
  * waited 0.58 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 22
  * waited 51 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 22
  * waited 0.52 sec
* `UserRequest:hudson.EnvVars$GetEnvVars`: 1
  * waited 18 ms
* `UserRequest:hudson.FilePath$2`: 3
  * waited 17 ms
* `UserRequest:hudson.FilePath$CallableWith`: 46
  * waited 0.78 sec
* `UserRequest:hudson.FilePath$CopyRecursiveRemoteToLocal`: 5
  * waited 1.9 sec
* `UserRequest:hudson.FilePath$CopyTo`: 315
  * waited 1.3 sec
* `UserRequest:hudson.FilePath$CreateTextTempFile`: 40
  * waited 0.11 sec
* `UserRequest:hudson.FilePath$Delete`: 40
  * waited 77 ms
* `UserRequest:hudson.FilePath$Exists`: 93
  * waited 1.1 sec
* `UserRequest:hudson.FilePath$IsDirectory`: 25
  * waited 0.12 sec
* `UserRequest:hudson.FilePath$LastModified`: 18
  * waited 36 ms
* `UserRequest:hudson.FilePath$ListGlob`: 25
  * waited 68 ms
* `UserRequest:hudson.FilePath$Mkdirs`: 5
  * waited 12 ms
* `UserRequest:hudson.FilePath$Read`: 30
  * waited 0.11 sec
* `UserRequest:hudson.FilePath$ValidateAntFileMask`: 14
  * waited 1 sec
* `UserRequest:hudson.Launcher$RemoteLaunchCallable`: 40
  * waited 0.29 sec
* `UserRequest:hudson.Launcher$RemoteLauncher$KillTask`: 5
  * waited 8.5 sec
* `UserRequest:hudson.logging.LogRecorder$SetLevel`: 1
  * waited 15 ms
* `UserRequest:hudson.model.Computer$ListPossibleNames`: 1
  * waited 0.12 sec
* `UserRequest:hudson.model.label_exciting_folk$GetClockDifference1`: 23
  * waited 0.3 sec
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 23
  * waited 0.16 sec
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 23
  * waited 0.28 sec
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 23
  * waited 0.92 sec
* `UserRequest:hudson.plugins.analysis.core.AnnotationsClassifier`: 20
  * waited 0.6 sec
* `UserRequest:hudson.plugins.disk_usage.DiskUsageUtil$DiskUsageCallable`: 5
  * waited 4.5 sec
* `UserRequest:hudson.plugins.tasks.parser.WorkspaceScanner`: 5
  * waited 9.1 sec
* `UserRequest:hudson.remoting.PingThread$Ping`: 263
  * waited 0.57 sec
* `UserRequest:hudson.scm.SubversionChangeLogBuilder$GetContextForPath`: 5
  * waited 74 ms
* `UserRequest:hudson.scm.SubversionSCM$BuildRevisionMapTask`: 5
  * waited 0.1 sec
* `UserRequest:hudson.scm.SubversionSCM$CheckOutTask`: 5
  * waited 1 min 6 sec
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 1
  * waited 63 ms
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 23
  * waited 56 ms
* `UserRequest:hudson.tasks.ArtifactArchiver$ListFiles`: 5
  * waited 0.72 sec
* `UserRequest:hudson.tasks.Fingerprinter$FindRecords`: 5
  * waited 0.8 sec
* `UserRequest:hudson.util.RemotingDiagnostics$GetSystemProperties`: 315
  * waited 0.56 sec
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 1
  * waited 24 ms
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 1
  * waited 0.23 sec
* `UserRequest:net.bull.javamelody.RemoteCallHelper$DelegatingTask`: 1315
  * waited 17 sec
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 1
  * waited 46 ms
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 1
  * waited 89 ms
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 1
  * waited 73 ms
* `UserRequest:org.jenkinsci.modules.upstart_slave_installer.SlaveInstallerFactoryImpl$HasUpstart`: 1
  * waited 31 ms
* `UserRequest:org.jenkinsci.modules.windows_slave_installer.SlaveInstallerFactoryImpl$IsWindows`: 1
  * waited 44 ms
* `UserRequest:org.jenkinsci.plugins.envinject.EnvInjectComputerListener$2`: 1
  * waited 0.12 sec
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectActionSetter$MapEnvInjectExceptionMasterToSlaveCallable`: 5
  * waited 27 ms
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsSetter`: 1
  * waited 17 ms
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvironmentVariablesNodeLoader$EnvVarMasterToSlaveCallable`: 5
  * waited 19 ms
* `UserRequest:org.jenkinsci.plugins.envinject.service.PropertiesVariablesRetriever`: 5
  * waited 33 ms
* `UserRequest:org.jfrog.hudson.generic.FilesResolverCallable`: 3
  * waited 70 ms
* `UserRequest:org.jfrog.hudson.generic.GenericArtifactsDeployer$FilesDeployerCallable`: 3
  * waited 40 sec
* `UserRequest:org.jfrog.hudson.pipeline.docker.proxy.BuildInfoProxy$1`: 1
  * waited 21 ms

# JARs sent
* `jenkins-core-2.138.3.jar`: 11176437b
* `support-core.jar`: 317701b
* `commons-io-2.4.jar`: 185140b
* `commons-compress-1.10.jar`: 409475b
* `ant-1.9.2.jar`: 2000557b
* `guava-11.0.1.jar`: 1649781b
* `commons-fileupload-1.3.1-jenkins-2.jar`: 68803b
* `launchd-label_exciting_folk-installer-1.2.jar`: 22663b
* `systemd-label_exciting_folk-installer-1.1.jar`: 11541b
* `upstart-label_exciting_folk-installer-1.1.jar`: 10798b
* `label_intellectual_deadline-label_exciting_folk-installer-1.9.2.jar`: 165896b
* `label_exciting_folk-installer-1.6.jar`: 27374b
* `envinject.jar`: 154483b
* `envinject-lib-1.29.jar`: 20599b
* `monitoring.jar`: 41743b
* `javamelody-core-1.74.0.jar`: 1345246b
* `itext-2.1.7.jar`: 1130070b
* `spring-context-2.5.6.SEC03.jar`: 476894b
* `memory-monitor-1.9.jar`: 17292b
* `jna-4.5.2.jar`: 1484022b
* `commons-lang-2.6.jar`: 284220b
* `localizer-1.24.jar`: 7160b
* `stapler-1.255.jar`: 416164b
* `commons-codec-1.9.jar`: 263965b
* `subversion.jar`: 583959b
* `svnkit-1.9.3.jar`: 4272184b
* `credentials.jar`: 634701b
* `antlr4-runtime-4.5.jar`: 374032b
* `ssh-credentials.jar`: 68387b
* `trilead-ssh2-1.0.0-build221.jar`: 250089b
* `json-lib-2.4-jenkins-2.jar`: 141207b
* `ezmorph-1.0.6.jar`: 86487b
* `acegi-security-1.0.7.jar`: 548722b
* `winstone4028769968578715370.jar`: 2243557b
* `commons-jelly-1.1-jenkins-20120928.jar`: 170642b
* `xstream-1.4.7-jenkins-1.jar`: 533110b
* `xpp3-1.1.4c.jar`: 120069b
* `commons-beanutils-1.8.3.jar`: 232019b
* `jcl-over-slf4j-1.7.25.jar`: 16515b
* `slf4j-api-1.7.25.jar`: 41203b
* `slf4j-jdk14-1.7.25.jar`: 8460b
* `sqljet-1.1.11.jar`: 760201b
* `antlr-runtime-3.4.jar`: 164368b
* `sequence-library-1.0.3.jar`: 72068b
* `artifactory.jar`: 657548b
* `build-info-extractor-2.11.3.jar`: 168578b
* `httpcore-4.4.9.jar`: 325500b
* `build-info-client-2.11.3.jar`: 37521b
* `httpclient-4.5.5.jar`: 766123b
* `jackson-databind-2.9.7.jar`: 1350857b
* `jackson-core-2.9.7.jar`: 324036b
* `jackson-annotations-2.9.0.jar`: 66519b
* `build-info-api-2.11.3.jar`: 77736b
* `winp-1.26.jar`: 105238b
* `analysis-core.jar`: 396182b
* `warnings.jar`: 268950b
* `tasks.jar`: 78268b
* `jzlib-1.1.3-kohsuke-1.jar`: 71852b
* `disk-usage.jar`: 102597b
* `mail-1.4.4.jar`: 494924b
* `mitm-2.1.1.jar`: 213956b
* `littleproxy-1.1.2.jar`: 130290b
