-----------
 * Name eth0
 ** Hardware Address - 38d547b301e4
 ** Index - 3
 ** InetAddress - /ip_profound_paragraph%eth0
 ** InetAddress - /ip_sufficient_resolution%eth0
 ** InetAddress - /ip_left_wonder
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name eth1
 ** Hardware Address - 18d6c702ed45
 ** Index - 2
 ** InetAddress - /ip_aloof_sunshine%eth1
 ** InetAddress - /ip_deadly_abbey%eth1
 ** InetAddress - /ip_glorious_carrot
 ** InetAddress - /ip_cultural_law
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /ip_consistent_lady%lo
 ** InetAddress - /ip_comparable_declaration
 ** MTU - 65536
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false
