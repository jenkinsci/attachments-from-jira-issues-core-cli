# Totals
* Writes: 16328
  * sent 49.4Mb
* Reads: 28653
  * received 51.0Mb
* Responses: 4066
  * waited 9 hr 7 min

# Commands sent
* `Pipe.Chunk`: 8162
  * sent 35.1Mb
* `ProxyOutputStream.Ack`: 2386
  * sent 0.4Mb
* `ProxyOutputStream.EOF`: 20
  * sent 0.0Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 652
  * sent 1.7Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 15
  * sent 0.0Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResources2[java.lang.String]`: 4
  * sent 0.0Mb
* `Response:UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 48
  * sent 0.1Mb
* `Response:UserRequest:hudson.remoting.Channel$IOSyncer`: 7
  * sent 0.0Mb
* `Response:UserRequest:hudson.remoting.PingThread$Ping`: 263
  * sent 0.5Mb
* `Response:UserRequest:hudson.util.ProcessTree$DoVetoersExist`: 1
  * sent 0.0Mb
* `Unexport`: 704
  * sent 1.0Mb
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.getIOtriplet[]`: 7
  * sent 0.0Mb
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.isAlive[]`: 7
  * sent 0.0Mb
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.join[]`: 7
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 23
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 1
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.api.CommandOutputContent$CommandLauncher`: 126
  * sent 0.3Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 23
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 23
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 23
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 23
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.FileDescriptorLimit$GetUlimit`: 22
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 23
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 22
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 44
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemConfiguration$GetDmiInfo`: 42
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 22
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 22
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.util.SystemPlatform$GetCurrentPlatform`: 84
  * sent 0.2Mb
* `UserRequest:hudson.EnvVars$GetEnvVars`: 1
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$2`: 4
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$CallableWith`: 46
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$CopyRecursiveRemoteToLocal`: 7
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$CopyTo`: 511
  * sent 1.4Mb
* `UserRequest:hudson.FilePath$CreateTextTempFile`: 7
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Delete`: 7
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Exists`: 91
  * sent 0.2Mb
* `UserRequest:hudson.FilePath$IsDirectory`: 22
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$LastModified`: 514
  * sent 1.3Mb
* `UserRequest:hudson.FilePath$Mkdirs`: 23
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$Read`: 2
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$ToURI`: 5
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Touch`: 20
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$WritePipe`: 20
  * sent 0.1Mb
* `UserRequest:hudson.Launcher$RemoteLaunchCallable`: 7
  * sent 0.0Mb
* `UserRequest:hudson.Launcher$RemoteLauncher$KillTask`: 7
  * sent 0.0Mb
* `UserRequest:hudson.logging.LogRecorder$SetLevel`: 1
  * sent 0.0Mb
* `UserRequest:hudson.model.Computer$ListPossibleNames`: 1
  * sent 0.0Mb
* `UserRequest:hudson.model.label_exciting_folk$GetClockDifference1`: 23
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 23
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 23
  * sent 0.1Mb
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 23
  * sent 0.0Mb
* `UserRequest:hudson.plugins.PerfPublisher.PerfPublisherPublisher$ParseReportCallable`: 9
  * sent 0.0Mb
* `UserRequest:hudson.plugins.disk_usage.DiskUsageUtil$DiskUsageCallable`: 9
  * sent 0.0Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 263
  * sent 0.5Mb
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 1
  * sent 0.0Mb
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 23
  * sent 0.1Mb
* `UserRequest:hudson.tasks.ArtifactArchiver$ListFiles`: 9
  * sent 0.0Mb
* `UserRequest:hudson.tasks.Fingerprinter$FindRecords`: 7
  * sent 0.0Mb
* `UserRequest:hudson.tasks.junit.JUnitParser$ParseResultCallable`: 9
  * sent 0.0Mb
* `UserRequest:hudson.util.RemotingDiagnostics$GetSystemProperties`: 504
  * sent 1.4Mb
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 1
  * sent 0.0Mb
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 1
  * sent 0.0Mb
* `UserRequest:net.bull.javamelody.RemoteCallHelper$DelegatingTask`: 1274
  * sent 3.3Mb
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.EnvInjectComputerListener$2`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectActionSetter$MapEnvInjectExceptionMasterToSlaveCallable`: 9
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsSetter`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvironmentVariablesNodeLoader$EnvVarMasterToSlaveCallable`: 9
  * sent 0.0Mb
* `UserRequest:org.jfrog.hudson.pipeline.docker.proxy.BuildInfoProxy$1`: 1
  * sent 0.0Mb

# Commands received
* `Pipe.Chunk`: 2386
  * received 4.3Mb
* `Pipe.Flush`: 1905
  * received 0.3Mb
* `ProxyOutputStream.Ack`: 8162
  * received 1.3Mb
* `ProxyOutputStream.EOF`: 524
  * received 1.0Mb
* `ProxyOutputStream.Unexport`: 4
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 652
  * received 0.4Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 15
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResources2[java.lang.String]`: 4
  * received 0.0Mb
* `Response`: 4066
  * received 27.7Mb
* `Unexport`: 10616
  * received 15.2Mb
* `UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 48
  * received 0.3Mb
* `UserRequest:hudson.remoting.Channel$IOSyncer`: 7
  * received 0.0Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 263
  * received 0.5Mb
* `UserRequest:hudson.util.ProcessTree$DoVetoersExist`: 1
  * received 0.0Mb

# Responses received
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.getIOtriplet[]`: 7
  * waited 28 ms
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.isAlive[]`: 7
  * waited 19 ms
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.join[]`: 7
  * waited 9 hr 6 min
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 23
  * waited 0.1 sec
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 1
  * waited 1.3 sec
* `UserRequest:com.cloudbees.jenkins.support.api.CommandOutputContent$CommandLauncher`: 126
  * waited 2.9 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 23
  * waited 2.5 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 23
  * waited 0.29 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 23
  * waited 0.12 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 23
  * waited 99 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.FileDescriptorLimit$GetUlimit`: 22
  * waited 0.21 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 23
  * waited 0.12 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 22
  * waited 0.4 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 44
  * waited 0.44 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemConfiguration$GetDmiInfo`: 42
  * waited 0.16 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 22
  * waited 0.1 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 22
  * waited 1 sec
* `UserRequest:com.cloudbees.jenkins.support.util.SystemPlatform$GetCurrentPlatform`: 84
  * waited 0.3 sec
* `UserRequest:hudson.EnvVars$GetEnvVars`: 1
  * waited 6 ms
* `UserRequest:hudson.FilePath$2`: 4
  * waited 41 ms
* `UserRequest:hudson.FilePath$CallableWith`: 46
  * waited 1.5 sec
* `UserRequest:hudson.FilePath$CopyRecursiveRemoteToLocal`: 7
  * waited 0.15 sec
* `UserRequest:hudson.FilePath$CopyTo`: 511
  * waited 2.7 sec
* `UserRequest:hudson.FilePath$CreateTextTempFile`: 7
  * waited 23 ms
* `UserRequest:hudson.FilePath$Delete`: 7
  * waited 31 ms
* `UserRequest:hudson.FilePath$Exists`: 91
  * waited 1.4 sec
* `UserRequest:hudson.FilePath$IsDirectory`: 22
  * waited 0.12 sec
* `UserRequest:hudson.FilePath$LastModified`: 514
  * waited 1.9 sec
* `UserRequest:hudson.FilePath$Mkdirs`: 23
  * waited 94 ms
* `UserRequest:hudson.FilePath$Read`: 2
  * waited 32 ms
* `UserRequest:hudson.FilePath$ToURI`: 5
  * waited 24 ms
* `UserRequest:hudson.FilePath$Touch`: 20
  * waited 0.11 sec
* `UserRequest:hudson.FilePath$WritePipe`: 20
  * waited 0.1 sec
* `UserRequest:hudson.Launcher$RemoteLaunchCallable`: 7
  * waited 0.13 sec
* `UserRequest:hudson.Launcher$RemoteLauncher$KillTask`: 7
  * waited 1.4 sec
* `UserRequest:hudson.logging.LogRecorder$SetLevel`: 1
  * waited 88 ms
* `UserRequest:hudson.model.Computer$ListPossibleNames`: 1
  * waited 8 ms
* `UserRequest:hudson.model.label_exciting_folk$GetClockDifference1`: 23
  * waited 0.33 sec
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 23
  * waited 0.42 sec
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 23
  * waited 0.71 sec
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 23
  * waited 0.81 sec
* `UserRequest:hudson.plugins.PerfPublisher.PerfPublisherPublisher$ParseReportCallable`: 9
  * waited 44 ms
* `UserRequest:hudson.plugins.disk_usage.DiskUsageUtil$DiskUsageCallable`: 9
  * waited 0.22 sec
* `UserRequest:hudson.remoting.PingThread$Ping`: 263
  * waited 1.1 sec
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 1
  * waited 0.31 sec
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 23
  * waited 0.12 sec
* `UserRequest:hudson.tasks.ArtifactArchiver$ListFiles`: 9
  * waited 45 ms
* `UserRequest:hudson.tasks.Fingerprinter$FindRecords`: 7
  * waited 0.15 sec
* `UserRequest:hudson.tasks.junit.JUnitParser$ParseResultCallable`: 9
  * waited 0.41 sec
* `UserRequest:hudson.util.RemotingDiagnostics$GetSystemProperties`: 504
  * waited 1.9 sec
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 1
  * waited 5.6 sec
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 1
  * waited 0.1 sec
* `UserRequest:net.bull.javamelody.RemoteCallHelper$DelegatingTask`: 1274
  * waited 45 sec
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 1
  * waited 24 ms
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 1
  * waited 0.12 sec
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 1
  * waited 0.12 sec
* `UserRequest:org.jenkinsci.plugins.envinject.EnvInjectComputerListener$2`: 1
  * waited 0.12 sec
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectActionSetter$MapEnvInjectExceptionMasterToSlaveCallable`: 9
  * waited 78 ms
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsSetter`: 1
  * waited 26 ms
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvironmentVariablesNodeLoader$EnvVarMasterToSlaveCallable`: 9
  * waited 56 ms
* `UserRequest:org.jfrog.hudson.pipeline.docker.proxy.BuildInfoProxy$1`: 1
  * waited 59 ms

# JARs sent
* `jna-4.5.2.jar`: 1484022b
* `libpam4j-1.8.jar`: 19925b
* `support-core.jar`: 317701b
* `monitoring.jar`: 41743b
* `commons-io-2.4.jar`: 185140b
* `commons-compress-1.10.jar`: 409475b
* `ant-1.9.2.jar`: 2000557b
* `itext-2.1.7.jar`: 1130070b
* `spring-context-2.5.6.SEC03.jar`: 476894b
* `commons-fileupload-1.3.1-jenkins-2.jar`: 68803b
* `launchd-label_exciting_folk-installer-1.2.jar`: 22663b
* `label_exciting_folk-installer-1.6.jar`: 27374b
* `systemd-label_exciting_folk-installer-1.1.jar`: 11541b
* `envinject.jar`: 154483b
* `envinject-lib-1.29.jar`: 20599b
* `commons-codec-1.9.jar`: 263965b
* `json-lib-2.4-jenkins-2.jar`: 141207b
* `xpp3-1.1.4c.jar`: 120069b
* `slf4j-jdk14-1.7.25.jar`: 8460b
* `junit.jar`: 439638b
* `dom4j-1.6.1-jenkins-4.jar`: 254359b
* `perfpublisher.jar`: 166764b
* `matrix-project.jar`: 244433b
* `disk-usage.jar`: 102597b
* `mail-1.4.4.jar`: 494924b
* `artifactory.jar`: 657548b
* `mitm-2.1.1.jar`: 213956b
* `littleproxy-1.1.2.jar`: 130290b
