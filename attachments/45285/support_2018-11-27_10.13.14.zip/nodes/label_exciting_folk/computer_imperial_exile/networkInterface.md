-----------
 * Name eth1
 ** Hardware Address - 503eaa05b453
 ** Index - 3
 ** InetAddress - /ip_mature_designer%eth1
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name eth2
 ** Hardware Address - 704d7b2a5374
 ** Index - 4
 ** InetAddress - /ip_proportional_fund%eth2
 ** InetAddress - /ip_surprising_leaf%eth2
 ** InetAddress - /ip_philosophical_call
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name eth0
 ** Hardware Address - 503eaa05aafc
 ** Index - 2
 ** InetAddress - /ip_ample_park%eth0
 ** InetAddress - /ip_manual_layout
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /ip_consistent_lady%lo
 ** InetAddress - /ip_comparable_declaration
 ** MTU - 65536
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false
