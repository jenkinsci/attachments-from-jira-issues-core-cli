# Totals
* Writes: 16892
  * sent 22.3Mb
* Reads: 31858
  * received 118.6Mb
* Responses: 2334
  * waited 23 min

# Commands sent
* `Pipe.Chunk`: 39
  * sent 0.3Mb
* `ProxyOutputStream.Ack`: 11869
  * sent 1.8Mb
* `ProxyOutputStream.Unexport`: 1
  * sent 0.0Mb
* `Response:RPCRequest:null.fetch3[java.lang.String]`: 1787
  * sent 11.7Mb
* `Response:RPCRequest:null.fetch[java.lang.String]`: 1
  * sent 0.0Mb
* `Response:RPCRequest:null.getResource2[java.lang.String]`: 23
  * sent 0.6Mb
* `Response:RPCRequest:null.getResources2[java.lang.String]`: 4
  * sent 0.0Mb
* `Response:UserRequest:RPCRequest`: 4
  * sent 0.0Mb
* `Response:UserRequest:hudson.remoting.Channel$IOSyncer`: 6
  * sent 0.0Mb
* `Response:UserRequest:hudson.remoting.PingThread$Ping`: 263
  * sent 0.5Mb
* `Response:UserRequest:hudson.scm.SubversionWorkspaceSelector$1`: 4
  * sent 0.0Mb
* `Response:UserRequest:hudson.util.ProcessTree$DoVetoersExist`: 1
  * sent 0.0Mb
* `Unexport`: 556
  * sent 1.0Mb
* `UserRequest:RPCRequest:hudson.Launcher$RemoteProcess.getIOtriplet[]`: 6
  * sent 0.0Mb
* `UserRequest:RPCRequest:hudson.Launcher$RemoteProcess.isAlive[]`: 6
  * sent 0.0Mb
* `UserRequest:RPCRequest:hudson.Launcher$RemoteProcess.join[]`: 6
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 23
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 1
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 23
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 23
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 23
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 23
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 23
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 22
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 44
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 22
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 22
  * sent 0.1Mb
* `UserRequest:hudson.EnvVars$GetEnvVars`: 1
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$2`: 1
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$CallableWith`: 46
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$CopyRecursiveRemoteToLocal`: 1
  * sent 0.2Mb
* `UserRequest:hudson.FilePath$CopyTo`: 76
  * sent 0.3Mb
* `UserRequest:hudson.FilePath$CreateTextTempFile`: 6
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Delete`: 6
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Exists`: 65
  * sent 0.2Mb
* `UserRequest:hudson.FilePath$IsDirectory`: 23
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$LastModified`: 33
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$ListGlob`: 7
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Mkdirs`: 1
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Read`: 10
  * sent 0.0Mb
* `UserRequest:hudson.Launcher$RemoteLaunchCallable`: 6
  * sent 0.1Mb
* `UserRequest:hudson.Launcher$RemoteLauncher$KillTask`: 1
  * sent 0.0Mb
* `UserRequest:hudson.logging.LogRecorder$SetLevel`: 1
  * sent 0.0Mb
* `UserRequest:hudson.model.Computer$ListPossibleNames`: 1
  * sent 0.0Mb
* `UserRequest:hudson.model.label_exciting_folk$GetClockDifference1`: 23
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 23
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 23
  * sent 0.1Mb
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 23
  * sent 0.0Mb
* `UserRequest:hudson.plugins.PerfPublisher.PerfPublisherPublisher$ParseReportCallable`: 1
  * sent 0.0Mb
* `UserRequest:hudson.plugins.analysis.core.AnnotationsClassifier`: 2
  * sent 0.0Mb
* `UserRequest:hudson.plugins.disk_usage.DiskUsageUtil$DiskUsageCallable`: 1
  * sent 0.0Mb
* `UserRequest:hudson.plugins.tasks.parser.WorkspaceScanner`: 1
  * sent 0.0Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 263
  * sent 0.5Mb
* `UserRequest:hudson.scm.SubversionChangeLogBuilder$GetContextForPath`: 1
  * sent 0.0Mb
* `UserRequest:hudson.scm.SubversionSCM$BuildRevisionMapTask`: 1
  * sent 0.0Mb
* `UserRequest:hudson.scm.SubversionSCM$CheckOutTask`: 1
  * sent 0.0Mb
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 1
  * sent 0.0Mb
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 23
  * sent 0.1Mb
* `UserRequest:hudson.tasks.ArtifactArchiver$ListFiles`: 1
  * sent 0.0Mb
* `UserRequest:hudson.tasks.Fingerprinter$FindRecords`: 1
  * sent 0.0Mb
* `UserRequest:hudson.util.RemotingDiagnostics$GetSystemProperties`: 63
  * sent 0.2Mb
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 1
  * sent 0.0Mb
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 1
  * sent 0.0Mb
* `UserRequest:net.bull.javamelody.RemoteCallHelper$DelegatingTask`: 1315
  * sent 3.4Mb
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.upstart_slave_installer.SlaveInstallerFactoryImpl$HasUpstart`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.windows_slave_installer.SlaveInstallerFactoryImpl$IsWindows`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.EnvInjectComputerListener$2`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectActionSetter$MapEnvInjectExceptionMasterToSlaveCallable`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsSetter`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvironmentVariablesNodeLoader$EnvVarMasterToSlaveCallable`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.PropertiesVariablesRetriever`: 1
  * sent 0.0Mb
* `UserRequest:org.jfrog.hudson.generic.FilesResolverCallable`: 1
  * sent 0.0Mb
* `UserRequest:org.jfrog.hudson.generic.GenericArtifactsDeployer$FilesDeployerCallable`: 1
  * sent 0.0Mb
* `UserRequest:org.jfrog.hudson.pipeline.docker.proxy.BuildInfoProxy$1`: 1
  * sent 0.0Mb

# Commands received
* `Pipe.Chunk`: 11869
  * received 74.8Mb
* `Pipe.Flush`: 7553
  * received 1.3Mb
* `ProxyOutputStream.Ack`: 39
  * received 0.0Mb
* `ProxyOutputStream.EOF`: 88
  * received 0.2Mb
* `ProxyOutputStream.Unexport`: 9
  * received 0.0Mb
* `RPCRequest:null.fetch3[java.lang.String]`: 1787
  * received 5.7Mb
* `RPCRequest:null.fetch[java.lang.String]`: 1
  * received 0.0Mb
* `RPCRequest:null.getResource2[java.lang.String]`: 23
  * received 0.1Mb
* `RPCRequest:null.getResources2[java.lang.String]`: 4
  * received 0.0Mb
* `Response`: 2334
  * received 16.2Mb
* `Unexport`: 7873
  * received 19.6Mb
* `UserRequest:RPCRequest`: 4
  * received 0.0Mb
* `UserRequest:hudson.remoting.Channel$IOSyncer`: 6
  * received 0.0Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 263
  * received 0.6Mb
* `UserRequest:hudson.scm.SubversionWorkspaceSelector$1`: 4
  * received 0.0Mb
* `UserRequest:hudson.util.ProcessTree$DoVetoersExist`: 1
  * received 0.0Mb

# Responses received
* `UserRequest:RPCRequest:hudson.Launcher$RemoteProcess.getIOtriplet[]`: 6
  * waited 12 ms
* `UserRequest:RPCRequest:hudson.Launcher$RemoteProcess.isAlive[]`: 6
  * waited 10 ms
* `UserRequest:RPCRequest:hudson.Launcher$RemoteProcess.join[]`: 6
  * waited 20 min
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 23
  * waited 44 ms
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 1
  * waited 0.96 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 23
  * waited 0.25 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 23
  * waited 82 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 23
  * waited 68 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 23
  * waited 55 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 23
  * waited 12 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 22
  * waited 0.13 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 44
  * waited 0.42 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 22
  * waited 51 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 22
  * waited 0.41 sec
* `UserRequest:hudson.EnvVars$GetEnvVars`: 1
  * waited 8 ms
* `UserRequest:hudson.FilePath$2`: 1
  * waited 24 ms
* `UserRequest:hudson.FilePath$CallableWith`: 46
  * waited 0.32 sec
* `UserRequest:hudson.FilePath$CopyRecursiveRemoteToLocal`: 1
  * waited 7.2 sec
* `UserRequest:hudson.FilePath$CopyTo`: 76
  * waited 0.35 sec
* `UserRequest:hudson.FilePath$CreateTextTempFile`: 6
  * waited 22 ms
* `UserRequest:hudson.FilePath$Delete`: 6
  * waited 24 ms
* `UserRequest:hudson.FilePath$Exists`: 65
  * waited 0.94 sec
* `UserRequest:hudson.FilePath$IsDirectory`: 23
  * waited 86 ms
* `UserRequest:hudson.FilePath$LastModified`: 33
  * waited 0.11 sec
* `UserRequest:hudson.FilePath$ListGlob`: 7
  * waited 17 ms
* `UserRequest:hudson.FilePath$Mkdirs`: 1
  * waited 22 ms
* `UserRequest:hudson.FilePath$Read`: 10
  * waited 48 ms
* `UserRequest:hudson.Launcher$RemoteLaunchCallable`: 6
  * waited 94 ms
* `UserRequest:hudson.Launcher$RemoteLauncher$KillTask`: 1
  * waited 6.2 sec
* `UserRequest:hudson.logging.LogRecorder$SetLevel`: 1
  * waited 25 ms
* `UserRequest:hudson.model.Computer$ListPossibleNames`: 1
  * waited 0.11 sec
* `UserRequest:hudson.model.label_exciting_folk$GetClockDifference1`: 23
  * waited 0.21 sec
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 23
  * waited 0.14 sec
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 23
  * waited 0.21 sec
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 23
  * waited 0.94 sec
* `UserRequest:hudson.plugins.PerfPublisher.PerfPublisherPublisher$ParseReportCallable`: 1
  * waited 12 ms
* `UserRequest:hudson.plugins.analysis.core.AnnotationsClassifier`: 2
  * waited 0.21 sec
* `UserRequest:hudson.plugins.disk_usage.DiskUsageUtil$DiskUsageCallable`: 1
  * waited 3.8 sec
* `UserRequest:hudson.plugins.tasks.parser.WorkspaceScanner`: 1
  * waited 3.1 sec
* `UserRequest:hudson.remoting.PingThread$Ping`: 263
  * waited 0.6 sec
* `UserRequest:hudson.scm.SubversionChangeLogBuilder$GetContextForPath`: 1
  * waited 27 ms
* `UserRequest:hudson.scm.SubversionSCM$BuildRevisionMapTask`: 1
  * waited 38 ms
* `UserRequest:hudson.scm.SubversionSCM$CheckOutTask`: 1
  * waited 57 sec
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 1
  * waited 0.22 sec
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 23
  * waited 54 ms
* `UserRequest:hudson.tasks.ArtifactArchiver$ListFiles`: 1
  * waited 0.23 sec
* `UserRequest:hudson.tasks.Fingerprinter$FindRecords`: 1
  * waited 0.17 sec
* `UserRequest:hudson.util.RemotingDiagnostics$GetSystemProperties`: 63
  * waited 0.11 sec
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 1
  * waited 13 ms
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 1
  * waited 0.13 sec
* `UserRequest:net.bull.javamelody.RemoteCallHelper$DelegatingTask`: 1315
  * waited 17 sec
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 1
  * waited 32 ms
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 1
  * waited 74 ms
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 1
  * waited 37 ms
* `UserRequest:org.jenkinsci.modules.upstart_slave_installer.SlaveInstallerFactoryImpl$HasUpstart`: 1
  * waited 11 ms
* `UserRequest:org.jenkinsci.modules.windows_slave_installer.SlaveInstallerFactoryImpl$IsWindows`: 1
  * waited 36 ms
* `UserRequest:org.jenkinsci.plugins.envinject.EnvInjectComputerListener$2`: 1
  * waited 0.28 sec
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectActionSetter$MapEnvInjectExceptionMasterToSlaveCallable`: 1
  * waited 12 ms
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsSetter`: 1
  * waited 17 ms
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvironmentVariablesNodeLoader$EnvVarMasterToSlaveCallable`: 1
  * waited 15 ms
* `UserRequest:org.jenkinsci.plugins.envinject.service.PropertiesVariablesRetriever`: 1
  * waited 22 ms
* `UserRequest:org.jfrog.hudson.generic.FilesResolverCallable`: 1
  * waited 62 ms
* `UserRequest:org.jfrog.hudson.generic.GenericArtifactsDeployer$FilesDeployerCallable`: 1
  * waited 1 min 15 sec
* `UserRequest:org.jfrog.hudson.pipeline.docker.proxy.BuildInfoProxy$1`: 1
  * waited 22 ms

# JARs sent
* `jenkins-core-2.138.3.jar`: 11176437b
* `support-core.jar`: 317701b
* `ant-1.9.2.jar`: 2000557b
* `commons-compress-1.10.jar`: 409475b
* `commons-io-2.4.jar`: 185140b
* `guava-11.0.1.jar`: 1649781b
* `commons-fileupload-1.3.1-jenkins-2.jar`: 68803b
* `launchd-label_exciting_folk-installer-1.2.jar`: 22663b
* `systemd-label_exciting_folk-installer-1.1.jar`: 11541b
* `upstart-label_exciting_folk-installer-1.1.jar`: 10798b
* `label_intellectual_deadline-label_exciting_folk-installer-1.9.2.jar`: 165896b
* `label_exciting_folk-installer-1.6.jar`: 27374b
* `envinject.jar`: 154483b
* `envinject-lib-1.29.jar`: 20599b
* `monitoring.jar`: 41743b
* `javamelody-core-1.74.0.jar`: 1345246b
* `itext-2.1.7.jar`: 1130070b
* `spring-context-2.5.6.SEC03.jar`: 476894b
* `memory-monitor-1.9.jar`: 17292b
* `jna-4.5.2.jar`: 1484022b
* `commons-lang-2.6.jar`: 284220b
* `localizer-1.24.jar`: 7160b
* `stapler-1.255.jar`: 416164b
* `commons-codec-1.9.jar`: 263965b
* `subversion.jar`: 583959b
* `svnkit-1.9.3.jar`: 4272184b
* `credentials.jar`: 634701b
* `antlr4-runtime-4.5.jar`: 374032b
* `ssh-credentials.jar`: 68387b
* `trilead-ssh2-1.0.0-build221.jar`: 250089b
* `json-lib-2.4-jenkins-2.jar`: 141207b
* `ezmorph-1.0.6.jar`: 86487b
* `acegi-security-1.0.7.jar`: 548722b
* `winstone4028769968578715370.jar`: 2243557b
* `commons-jelly-1.1-jenkins-20120928.jar`: 170642b
* `xstream-1.4.7-jenkins-1.jar`: 533110b
* `xpp3-1.1.4c.jar`: 120069b
* `commons-beanutils-1.8.3.jar`: 232019b
* `jcl-over-slf4j-1.7.25.jar`: 16515b
* `slf4j-api-1.7.25.jar`: 41203b
* `slf4j-jdk14-1.7.25.jar`: 8460b
* `sqljet-1.1.11.jar`: 760201b
* `antlr-runtime-3.4.jar`: 164368b
* `sequence-library-1.0.3.jar`: 72068b
* `artifactory.jar`: 657548b
* `build-info-extractor-2.11.3.jar`: 168578b
* `httpcore-4.4.9.jar`: 325500b
* `httpclient-4.5.5.jar`: 766123b
* `build-info-client-2.11.3.jar`: 37521b
* `jackson-databind-2.9.7.jar`: 1350857b
* `jackson-core-2.9.7.jar`: 324036b
* `jackson-annotations-2.9.0.jar`: 66519b
* `build-info-api-2.11.3.jar`: 77736b
* `winp-1.26.jar`: 105238b
* `analysis-core.jar`: 396182b
* `warnings.jar`: 268950b
* `tasks.jar`: 78268b
* `jzlib-1.1.3-kohsuke-1.jar`: 71852b
* `perfpublisher.jar`: 166764b
* `disk-usage.jar`: 102597b
* `mail-1.4.4.jar`: 494924b
* `mitm-2.1.1.jar`: 213956b
* `littleproxy-1.1.2.jar`: 130290b
