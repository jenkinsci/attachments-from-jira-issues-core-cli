# Totals
* Writes: 130661
  * sent 504.0Mb
* Reads: 150492
  * received 94.4Mb
* Responses: 9386
  * waited 12 hr

# Commands sent
* `Pipe.Chunk`: 108725
  * sent 461.8Mb
* `ProxyOutputStream.Ack`: 5099
  * sent 0.8Mb
* `ProxyOutputStream.EOF`: 2916
  * sent 6.1Mb
* `ProxyOutputStream.Unexport`: 1
  * sent 0.0Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 652
  * sent 1.7Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch[java.lang.String]`: 1
  * sent 0.0Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 15
  * sent 0.0Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResources2[java.lang.String]`: 4
  * sent 0.0Mb
* `Response:UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 48
  * sent 0.1Mb
* `Response:UserRequest:UserRPCRequest:hudson.remoting.JarLoader.writeJarTo[long,long,java.io.OutputStream]`: 1
  * sent 0.0Mb
* `Response:UserRequest:hudson.remoting.Channel$IOSyncer`: 2
  * sent 0.0Mb
* `Response:UserRequest:hudson.remoting.PingThread$Ping`: 263
  * sent 0.5Mb
* `Response:UserRequest:hudson.util.ProcessTree$DoVetoersExist`: 1
  * sent 0.0Mb
* `Unexport`: 3547
  * sent 5.2Mb
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.getIOtriplet[]`: 2
  * sent 0.0Mb
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.isAlive[]`: 2
  * sent 0.0Mb
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.join[]`: 2
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 23
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 1
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.api.CommandOutputContent$CommandLauncher`: 129
  * sent 0.4Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 23
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 23
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 23
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 23
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.FileDescriptorLimit$GetUlimit`: 22
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 23
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 22
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 44
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemConfiguration$GetDmiInfo`: 43
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 22
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 22
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.util.SystemPlatform$GetCurrentPlatform`: 86
  * sent 0.2Mb
* `UserRequest:hudson.EnvVars$GetEnvVars`: 1
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$2`: 1
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$CallableWith`: 46
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$CopyRecursiveRemoteToLocal`: 2
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$CopyTo`: 512
  * sent 1.4Mb
* `UserRequest:hudson.FilePath$CreateTextTempFile`: 2
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Delete`: 2
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Exists`: 66
  * sent 0.2Mb
* `UserRequest:hudson.FilePath$IsDirectory`: 22
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$LastModified`: 518
  * sent 1.4Mb
* `UserRequest:hudson.FilePath$Mkdirs`: 6
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Read`: 2
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Touch`: 2916
  * sent 9.3Mb
* `UserRequest:hudson.FilePath$WritePipe`: 2916
  * sent 9.3Mb
* `UserRequest:hudson.Launcher$RemoteLaunchCallable`: 2
  * sent 0.0Mb
* `UserRequest:hudson.Launcher$RemoteLauncher$KillTask`: 2
  * sent 0.0Mb
* `UserRequest:hudson.logging.LogRecorder$SetLevel`: 1
  * sent 0.0Mb
* `UserRequest:hudson.model.Computer$ListPossibleNames`: 1
  * sent 0.0Mb
* `UserRequest:hudson.model.label_exciting_folk$GetClockDifference1`: 23
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 23
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 23
  * sent 0.1Mb
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 23
  * sent 0.0Mb
* `UserRequest:hudson.plugins.PerfPublisher.PerfPublisherPublisher$ParseReportCallable`: 2
  * sent 0.0Mb
* `UserRequest:hudson.plugins.disk_usage.DiskUsageUtil$DiskUsageCallable`: 2
  * sent 0.0Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 263
  * sent 0.5Mb
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 1
  * sent 0.0Mb
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 23
  * sent 0.1Mb
* `UserRequest:hudson.tasks.ArtifactArchiver$ListFiles`: 2
  * sent 0.0Mb
* `UserRequest:hudson.tasks.Fingerprinter$FindRecords`: 2
  * sent 0.0Mb
* `UserRequest:hudson.tasks.junit.JUnitParser$ParseResultCallable`: 2
  * sent 0.0Mb
* `UserRequest:hudson.util.RemotingDiagnostics$GetSystemProperties`: 112
  * sent 0.3Mb
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 1
  * sent 0.0Mb
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 1
  * sent 0.0Mb
* `UserRequest:net.bull.javamelody.RemoteCallHelper$DelegatingTask`: 1320
  * sent 3.4Mb
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.EnvInjectComputerListener$2`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectActionSetter$MapEnvInjectExceptionMasterToSlaveCallable`: 2
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsSetter`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvironmentVariablesNodeLoader$EnvVarMasterToSlaveCallable`: 2
  * sent 0.0Mb
* `UserRequest:org.jfrog.hudson.pipeline.docker.proxy.BuildInfoProxy$1`: 1
  * sent 0.0Mb

# Commands received
* `Pipe.Chunk`: 5099
  * received 9.1Mb
* `Pipe.Flush`: 4555
  * received 0.8Mb
* `ProxyOutputStream.Ack`: 108725
  * received 16.7Mb
* `ProxyOutputStream.EOF`: 517
  * received 1.0Mb
* `ProxyOutputStream.Unexport`: 1
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 652
  * received 0.4Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch[java.lang.String]`: 1
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 15
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResources2[java.lang.String]`: 4
  * received 0.0Mb
* `Response`: 9386
  * received 35.2Mb
* `Unexport`: 21222
  * received 30.4Mb
* `UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 48
  * received 0.3Mb
* `UserRequest:UserRPCRequest:hudson.remoting.JarLoader.writeJarTo[long,long,java.io.OutputStream]`: 1
  * received 0.0Mb
* `UserRequest:hudson.remoting.Channel$IOSyncer`: 2
  * received 0.0Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 263
  * received 0.5Mb
* `UserRequest:hudson.util.ProcessTree$DoVetoersExist`: 1
  * received 0.0Mb

# Responses received
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.getIOtriplet[]`: 2
  * waited 9 ms
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.isAlive[]`: 2
  * waited 4 ms
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.join[]`: 2
  * waited 12 hr
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 23
  * waited 65 ms
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 1
  * waited 1.1 sec
* `UserRequest:com.cloudbees.jenkins.support.api.CommandOutputContent$CommandLauncher`: 129
  * waited 1.7 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 23
  * waited 2.7 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 23
  * waited 0.25 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 23
  * waited 0.16 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 23
  * waited 78 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.FileDescriptorLimit$GetUlimit`: 22
  * waited 0.19 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 23
  * waited 95 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 22
  * waited 0.4 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 44
  * waited 0.29 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemConfiguration$GetDmiInfo`: 43
  * waited 0.13 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 22
  * waited 81 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 22
  * waited 0.7 sec
* `UserRequest:com.cloudbees.jenkins.support.util.SystemPlatform$GetCurrentPlatform`: 86
  * waited 0.23 sec
* `UserRequest:hudson.EnvVars$GetEnvVars`: 1
  * waited 8 ms
* `UserRequest:hudson.FilePath$2`: 1
  * waited 14 ms
* `UserRequest:hudson.FilePath$CallableWith`: 46
  * waited 1.5 sec
* `UserRequest:hudson.FilePath$CopyRecursiveRemoteToLocal`: 2
  * waited 0.11 sec
* `UserRequest:hudson.FilePath$CopyTo`: 512
  * waited 1.6 sec
* `UserRequest:hudson.FilePath$CreateTextTempFile`: 2
  * waited 10 ms
* `UserRequest:hudson.FilePath$Delete`: 2
  * waited 4 ms
* `UserRequest:hudson.FilePath$Exists`: 66
  * waited 1.2 sec
* `UserRequest:hudson.FilePath$IsDirectory`: 22
  * waited 0.1 sec
* `UserRequest:hudson.FilePath$LastModified`: 518
  * waited 1.4 sec
* `UserRequest:hudson.FilePath$Mkdirs`: 6
  * waited 20 ms
* `UserRequest:hudson.FilePath$Read`: 2
  * waited 15 ms
* `UserRequest:hudson.FilePath$Touch`: 2916
  * waited 9.6 sec
* `UserRequest:hudson.FilePath$WritePipe`: 2916
  * waited 10 sec
* `UserRequest:hudson.Launcher$RemoteLaunchCallable`: 2
  * waited 93 ms
* `UserRequest:hudson.Launcher$RemoteLauncher$KillTask`: 2
  * waited 1.1 sec
* `UserRequest:hudson.logging.LogRecorder$SetLevel`: 1
  * waited 0.76 sec
* `UserRequest:hudson.model.Computer$ListPossibleNames`: 1
  * waited 6 ms
* `UserRequest:hudson.model.label_exciting_folk$GetClockDifference1`: 23
  * waited 0.56 sec
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 23
  * waited 0.4 sec
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 23
  * waited 0.6 sec
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 23
  * waited 0.74 sec
* `UserRequest:hudson.plugins.PerfPublisher.PerfPublisherPublisher$ParseReportCallable`: 2
  * waited 25 ms
* `UserRequest:hudson.plugins.disk_usage.DiskUsageUtil$DiskUsageCallable`: 2
  * waited 0.19 sec
* `UserRequest:hudson.remoting.PingThread$Ping`: 263
  * waited 0.83 sec
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 1
  * waited 1.2 sec
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 23
  * waited 84 ms
* `UserRequest:hudson.tasks.ArtifactArchiver$ListFiles`: 2
  * waited 9 ms
* `UserRequest:hudson.tasks.Fingerprinter$FindRecords`: 2
  * waited 0.22 sec
* `UserRequest:hudson.tasks.junit.JUnitParser$ParseResultCallable`: 2
  * waited 0.3 sec
* `UserRequest:hudson.util.RemotingDiagnostics$GetSystemProperties`: 112
  * waited 0.26 sec
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 1
  * waited 6.1 sec
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 1
  * waited 0.16 sec
* `UserRequest:net.bull.javamelody.RemoteCallHelper$DelegatingTask`: 1320
  * waited 33 sec
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 1
  * waited 42 ms
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 1
  * waited 0.1 sec
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 1
  * waited 37 ms
* `UserRequest:org.jenkinsci.plugins.envinject.EnvInjectComputerListener$2`: 1
  * waited 61 ms
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectActionSetter$MapEnvInjectExceptionMasterToSlaveCallable`: 2
  * waited 12 ms
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsSetter`: 1
  * waited 19 ms
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvironmentVariablesNodeLoader$EnvVarMasterToSlaveCallable`: 2
  * waited 17 ms
* `UserRequest:org.jfrog.hudson.pipeline.docker.proxy.BuildInfoProxy$1`: 1
  * waited 42 ms

# JARs sent
* `jna-4.5.2.jar`: 1484022b
* `libpam4j-1.8.jar`: 19925b
* `support-core.jar`: 317701b
* `monitoring.jar`: 41743b
* `commons-io-2.4.jar`: 185140b
* `commons-compress-1.10.jar`: 409475b
* `itext-2.1.7.jar`: 1130070b
* `ant-1.9.2.jar`: 2000557b
* `spring-context-2.5.6.SEC03.jar`: 476894b
* `commons-fileupload-1.3.1-jenkins-2.jar`: 68803b
* `launchd-label_exciting_folk-installer-1.2.jar`: 22663b
* `label_exciting_folk-installer-1.6.jar`: 27374b
* `systemd-label_exciting_folk-installer-1.1.jar`: 11541b
* `envinject.jar`: 154483b
* `envinject-lib-1.29.jar`: 20599b
* `commons-codec-1.9.jar`: 263965b
* `json-lib-2.4-jenkins-2.jar`: 141207b
* `xpp3-1.1.4c.jar`: 120069b
* `slf4j-jdk14-1.7.25.jar`: 8460b
* `junit.jar`: 439638b
* `dom4j-1.6.1-jenkins-4.jar`: 254359b
* `perfpublisher.jar`: 166764b
* `matrix-project.jar`: 244433b
* `disk-usage.jar`: 102597b
* `mail-1.4.4.jar`: 494924b
* `artifactory.jar`: 657548b
* `mitm-2.1.1.jar`: 213956b
* `littleproxy-1.1.2.jar`: 130290b
