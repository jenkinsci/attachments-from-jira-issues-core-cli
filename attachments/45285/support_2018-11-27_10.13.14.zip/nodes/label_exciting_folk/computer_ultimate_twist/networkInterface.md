-----------
 * Name eth0
 ** Hardware Address - 708bcda3fae8
 ** Index - 3
 ** InetAddress - /ip_functional_panic%eth0
 ** InetAddress - /ip_lucky_reservoir%eth0
 ** InetAddress - /ip_confident_remark
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name eth1
 ** Hardware Address - 60e32702adb7
 ** Index - 2
 ** InetAddress - /ip_private_summary%eth1
 ** InetAddress - /ip_subjective_yard
 ** InetAddress - /ip_cultural_law
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /ip_consistent_lady%lo
 ** InetAddress - /ip_comparable_declaration
 ** MTU - 65536
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false
