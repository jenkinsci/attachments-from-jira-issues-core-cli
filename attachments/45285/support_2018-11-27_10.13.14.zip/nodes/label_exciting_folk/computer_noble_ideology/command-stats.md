# Totals
* Writes: 47931
  * sent 163.9Mb
* Reads: 64194
  * received 72.4Mb
* Responses: 7402
  * waited 12 hr

# Commands sent
* `Pipe.Chunk`: 31495
  * sent 131.7Mb
* `ProxyOutputStream.Ack`: 3571
  * sent 0.5Mb
* `ProxyOutputStream.EOF`: 1928
  * sent 4.0Mb
* `ProxyOutputStream.Unexport`: 1
  * sent 0.0Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 648
  * sent 1.7Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch[java.lang.String]`: 1
  * sent 0.0Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 15
  * sent 0.0Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResources2[java.lang.String]`: 4
  * sent 0.0Mb
* `Response:UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 47
  * sent 0.1Mb
* `Response:UserRequest:UserRPCRequest:hudson.remoting.JarLoader.writeJarTo[long,long,java.io.OutputStream]`: 1
  * sent 0.0Mb
* `Response:UserRequest:hudson.remoting.Channel$IOSyncer`: 1
  * sent 0.0Mb
* `Response:UserRequest:hudson.remoting.PingThread$Ping`: 263
  * sent 0.5Mb
* `Response:UserRequest:hudson.util.ProcessTree$DoVetoersExist`: 1
  * sent 0.0Mb
* `Unexport`: 2553
  * sent 3.7Mb
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.getIOtriplet[]`: 1
  * sent 0.0Mb
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.isAlive[]`: 1
  * sent 0.0Mb
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.join[]`: 1
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 23
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 1
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.api.CommandOutputContent$CommandLauncher`: 135
  * sent 0.4Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 23
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 23
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 23
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 23
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.FileDescriptorLimit$GetUlimit`: 22
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 23
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 22
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 44
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemConfiguration$GetDmiInfo`: 45
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 22
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 23
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.util.SystemPlatform$GetCurrentPlatform`: 90
  * sent 0.2Mb
* `UserRequest:hudson.EnvVars$GetEnvVars`: 1
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$2`: 1
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$CallableWith`: 46
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$CopyRecursiveRemoteToLocal`: 1
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$CopyTo`: 535
  * sent 1.5Mb
* `UserRequest:hudson.FilePath$CreateTextTempFile`: 1
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Delete`: 1
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Exists`: 66
  * sent 0.2Mb
* `UserRequest:hudson.FilePath$IsDirectory`: 22
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$LastModified`: 546
  * sent 1.4Mb
* `UserRequest:hudson.FilePath$Mkdirs`: 3
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Read`: 2
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Touch`: 1928
  * sent 6.2Mb
* `UserRequest:hudson.FilePath$WritePipe`: 1928
  * sent 6.2Mb
* `UserRequest:hudson.Launcher$RemoteLaunchCallable`: 1
  * sent 0.0Mb
* `UserRequest:hudson.Launcher$RemoteLauncher$KillTask`: 1
  * sent 0.0Mb
* `UserRequest:hudson.logging.LogRecorder$SetLevel`: 1
  * sent 0.0Mb
* `UserRequest:hudson.model.Computer$ListPossibleNames`: 1
  * sent 0.0Mb
* `UserRequest:hudson.model.label_exciting_folk$GetClockDifference1`: 23
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 23
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 23
  * sent 0.1Mb
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 23
  * sent 0.0Mb
* `UserRequest:hudson.plugins.PerfPublisher.PerfPublisherPublisher$ParseReportCallable`: 1
  * sent 0.0Mb
* `UserRequest:hudson.plugins.disk_usage.DiskUsageUtil$DiskUsageCallable`: 1
  * sent 0.0Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 263
  * sent 0.5Mb
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 1
  * sent 0.0Mb
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 23
  * sent 0.1Mb
* `UserRequest:hudson.tasks.ArtifactArchiver$ListFiles`: 1
  * sent 0.0Mb
* `UserRequest:hudson.tasks.Fingerprinter$FindRecords`: 1
  * sent 0.0Mb
* `UserRequest:hudson.tasks.junit.JUnitParser$ParseResultCallable`: 1
  * sent 0.0Mb
* `UserRequest:hudson.util.RemotingDiagnostics$GetSystemProperties`: 56
  * sent 0.2Mb
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 1
  * sent 0.0Mb
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 1
  * sent 0.0Mb
* `UserRequest:net.bull.javamelody.RemoteCallHelper$DelegatingTask`: 1322
  * sent 3.4Mb
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.EnvInjectComputerListener$2`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectActionSetter$MapEnvInjectExceptionMasterToSlaveCallable`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsSetter`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvironmentVariablesNodeLoader$EnvVarMasterToSlaveCallable`: 1
  * sent 0.0Mb
* `UserRequest:org.jfrog.hudson.pipeline.docker.proxy.BuildInfoProxy$1`: 1
  * sent 0.0Mb

# Commands received
* `Pipe.Chunk`: 3571
  * received 6.2Mb
* `Pipe.Flush`: 3050
  * received 0.5Mb
* `ProxyOutputStream.Ack`: 31495
  * received 4.9Mb
* `ProxyOutputStream.EOF`: 539
  * received 1.1Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 648
  * received 0.4Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch[java.lang.String]`: 1
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 15
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResources2[java.lang.String]`: 4
  * received 0.0Mb
* `Response`: 7402
  * received 32.7Mb
* `Unexport`: 17156
  * received 25.9Mb
* `UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 47
  * received 0.3Mb
* `UserRequest:UserRPCRequest:hudson.remoting.JarLoader.writeJarTo[long,long,java.io.OutputStream]`: 1
  * received 0.0Mb
* `UserRequest:hudson.remoting.Channel$IOSyncer`: 1
  * received 0.0Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 263
  * received 0.5Mb
* `UserRequest:hudson.util.ProcessTree$DoVetoersExist`: 1
  * received 0.0Mb

# Responses received
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.getIOtriplet[]`: 1
  * waited 3 ms
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.isAlive[]`: 1
  * waited 2 ms
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.join[]`: 1
  * waited 12 hr
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 23
  * waited 61 ms
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 1
  * waited 1.8 sec
* `UserRequest:com.cloudbees.jenkins.support.api.CommandOutputContent$CommandLauncher`: 135
  * waited 2.7 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 23
  * waited 3.9 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 23
  * waited 0.29 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 23
  * waited 80 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 23
  * waited 80 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.FileDescriptorLimit$GetUlimit`: 22
  * waited 0.15 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 23
  * waited 0.1 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 22
  * waited 0.65 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 44
  * waited 0.33 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemConfiguration$GetDmiInfo`: 45
  * waited 1.3 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 22
  * waited 68 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 23
  * waited 0.93 sec
* `UserRequest:com.cloudbees.jenkins.support.util.SystemPlatform$GetCurrentPlatform`: 90
  * waited 0.27 sec
* `UserRequest:hudson.EnvVars$GetEnvVars`: 1
  * waited 24 ms
* `UserRequest:hudson.FilePath$2`: 1
  * waited 62 ms
* `UserRequest:hudson.FilePath$CallableWith`: 46
  * waited 0.82 sec
* `UserRequest:hudson.FilePath$CopyRecursiveRemoteToLocal`: 1
  * waited 0.22 sec
* `UserRequest:hudson.FilePath$CopyTo`: 535
  * waited 1.5 sec
* `UserRequest:hudson.FilePath$CreateTextTempFile`: 1
  * waited 30 ms
* `UserRequest:hudson.FilePath$Delete`: 1
  * waited 23 ms
* `UserRequest:hudson.FilePath$Exists`: 66
  * waited 1.7 sec
* `UserRequest:hudson.FilePath$IsDirectory`: 22
  * waited 0.14 sec
* `UserRequest:hudson.FilePath$LastModified`: 546
  * waited 1.2 sec
* `UserRequest:hudson.FilePath$Mkdirs`: 3
  * waited 21 ms
* `UserRequest:hudson.FilePath$Read`: 2
  * waited 34 ms
* `UserRequest:hudson.FilePath$Touch`: 1928
  * waited 6.1 sec
* `UserRequest:hudson.FilePath$WritePipe`: 1928
  * waited 6.3 sec
* `UserRequest:hudson.Launcher$RemoteLaunchCallable`: 1
  * waited 0.22 sec
* `UserRequest:hudson.Launcher$RemoteLauncher$KillTask`: 1
  * waited 2.8 sec
* `UserRequest:hudson.logging.LogRecorder$SetLevel`: 1
  * waited 0.1 sec
* `UserRequest:hudson.model.Computer$ListPossibleNames`: 1
  * waited 10 ms
* `UserRequest:hudson.model.label_exciting_folk$GetClockDifference1`: 23
  * waited 0.38 sec
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 23
  * waited 0.1 sec
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 23
  * waited 0.3 sec
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 23
  * waited 0.47 sec
* `UserRequest:hudson.plugins.PerfPublisher.PerfPublisherPublisher$ParseReportCallable`: 1
  * waited 38 ms
* `UserRequest:hudson.plugins.disk_usage.DiskUsageUtil$DiskUsageCallable`: 1
  * waited 0.37 sec
* `UserRequest:hudson.remoting.PingThread$Ping`: 263
  * waited 0.93 sec
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 1
  * waited 0.43 sec
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 23
  * waited 81 ms
* `UserRequest:hudson.tasks.ArtifactArchiver$ListFiles`: 1
  * waited 9 ms
* `UserRequest:hudson.tasks.Fingerprinter$FindRecords`: 1
  * waited 0.26 sec
* `UserRequest:hudson.tasks.junit.JUnitParser$ParseResultCallable`: 1
  * waited 0.68 sec
* `UserRequest:hudson.util.RemotingDiagnostics$GetSystemProperties`: 56
  * waited 0.1 sec
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 1
  * waited 3.6 sec
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 1
  * waited 0.67 sec
* `UserRequest:net.bull.javamelody.RemoteCallHelper$DelegatingTask`: 1322
  * waited 39 sec
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 1
  * waited 75 ms
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 1
  * waited 0.9 sec
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 1
  * waited 83 ms
* `UserRequest:org.jenkinsci.plugins.envinject.EnvInjectComputerListener$2`: 1
  * waited 0.53 sec
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectActionSetter$MapEnvInjectExceptionMasterToSlaveCallable`: 1
  * waited 14 ms
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsSetter`: 1
  * waited 21 ms
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvironmentVariablesNodeLoader$EnvVarMasterToSlaveCallable`: 1
  * waited 22 ms
* `UserRequest:org.jfrog.hudson.pipeline.docker.proxy.BuildInfoProxy$1`: 1
  * waited 0.15 sec

# JARs sent
* `jna-4.5.2.jar`: 1484022b
* `libpam4j-1.8.jar`: 19925b
* `support-core.jar`: 317701b
* `ant-1.9.2.jar`: 2000557b
* `commons-io-2.4.jar`: 185140b
* `commons-compress-1.10.jar`: 409475b
* `guava-11.0.1.jar`: 1649781b
* `commons-fileupload-1.3.1-jenkins-2.jar`: 68803b
* `monitoring.jar`: 41743b
* `launchd-label_exciting_folk-installer-1.2.jar`: 22663b
* `itext-2.1.7.jar`: 1130070b
* `systemd-label_exciting_folk-installer-1.1.jar`: 11541b
* `label_exciting_folk-installer-1.6.jar`: 27374b
* `spring-context-2.5.6.SEC03.jar`: 476894b
* `envinject.jar`: 154483b
* `envinject-lib-1.29.jar`: 20599b
* `commons-codec-1.9.jar`: 263965b
* `json-lib-2.4-jenkins-2.jar`: 141207b
* `antlr-2.7.6.jar`: 443432b
* `task-reactor-1.5.jar`: 22114b
* `commons-jelly-1.1-jenkins-20120928.jar`: 170642b
* `xpp3-1.1.4c.jar`: 120069b
* `stapler-jelly-1.255.jar`: 87452b
* `slf4j-jdk14-1.7.25.jar`: 8460b
* `junit.jar`: 439638b
* `dom4j-1.6.1-jenkins-4.jar`: 254359b
* `perfpublisher.jar`: 166764b
* `disk-usage.jar`: 102597b
* `mail-1.4.4.jar`: 494924b
* `artifactory.jar`: 657548b
* `mitm-2.1.1.jar`: 213956b
* `littleproxy-1.1.2.jar`: 130290b
