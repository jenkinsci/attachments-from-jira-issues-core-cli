-----------
 * Name eth0
 ** Hardware Address - 74d43542ddaa
 ** Index - 3
 ** InetAddress - /ip_deep_rest%eth0
 ** InetAddress - /ip_graphic_supply%eth0
 ** InetAddress - /ip_medieval_absorption%eth0
 ** InetAddress - /ip_pure_cassette%eth0
 ** InetAddress - /ip_talented_destruction%eth0
 ** InetAddress - /ip_applied_future%eth0
 ** InetAddress - /ip_dependent_lecture%eth0
 ** InetAddress - /ip_gregarious_participant%eth0
 ** InetAddress - /ip_spatial_deficit
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name eth1
 ** Hardware Address - 60e32702e91d
 ** Index - 2
 ** InetAddress - /ip_mild_restriction%eth1
 ** InetAddress - /ip_racial_surgery
 ** InetAddress - /ip_cultural_law
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /ip_consistent_lady%lo
 ** InetAddress - /ip_comparable_declaration
 ** MTU - 65536
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false
