# Totals
* Writes: 114012
  * sent 433.4Mb
* Reads: 134111
  * received 94.7Mb
* Responses: 10690
  * waited 8 hr 34 min

# Commands sent
* `GC`: 1
  * sent 0.0Mb
* `Pipe.Chunk`: 91203
  * sent 385.5Mb
* `ProxyOutputStream.Ack`: 3632
  * sent 0.6Mb
* `ProxyOutputStream.EOF`: 3399
  * sent 7.1Mb
* `ProxyOutputStream.Unexport`: 1
  * sent 0.0Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 700
  * sent 1.8Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch[java.lang.String]`: 1
  * sent 0.0Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 15
  * sent 0.0Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResources2[java.lang.String]`: 4
  * sent 0.0Mb
* `Response:UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 48
  * sent 0.1Mb
* `Response:UserRequest:UserRPCRequest:hudson.remoting.JarLoader.writeJarTo[long,long,java.io.OutputStream]`: 1
  * sent 0.0Mb
* `Response:UserRequest:hudson.remoting.Channel$IOSyncer`: 6
  * sent 0.0Mb
* `Response:UserRequest:hudson.remoting.PingThread$Ping`: 263
  * sent 0.5Mb
* `Response:UserRequest:hudson.util.ProcessTree$DoVetoersExist`: 1
  * sent 0.0Mb
* `Unexport`: 4046
  * sent 5.9Mb
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.getIOtriplet[]`: 7
  * sent 0.0Mb
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.isAlive[]`: 6
  * sent 0.0Mb
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.join[]`: 7
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 23
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 1
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.api.CommandOutputContent$CommandLauncher`: 129
  * sent 0.4Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 23
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 23
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 23
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 23
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.FileDescriptorLimit$GetUlimit`: 22
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 23
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 22
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 44
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemConfiguration$GetDmiInfo`: 43
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 22
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 23
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.util.SystemPlatform$GetCurrentPlatform`: 86
  * sent 0.2Mb
* `UserRequest:hudson.EnvVars$GetEnvVars`: 1
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$2`: 4
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$CallableWith`: 46
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$CopyRecursiveRemoteToLocal`: 3
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$CopyTo`: 514
  * sent 1.4Mb
* `UserRequest:hudson.FilePath$CreateTextTempFile`: 7
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Delete`: 6
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Exists`: 89
  * sent 0.2Mb
* `UserRequest:hudson.FilePath$IsDirectory`: 22
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$LastModified`: 520
  * sent 1.4Mb
* `UserRequest:hudson.FilePath$Mkdirs`: 21
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$Read`: 3
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$ToURI`: 3
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Touch`: 3399
  * sent 10.8Mb
* `UserRequest:hudson.FilePath$WritePipe`: 3399
  * sent 10.9Mb
* `UserRequest:hudson.Launcher$RemoteLaunchCallable`: 7
  * sent 0.0Mb
* `UserRequest:hudson.Launcher$RemoteLauncher$KillTask`: 6
  * sent 0.0Mb
* `UserRequest:hudson.logging.LogRecorder$SetLevel`: 1
  * sent 0.0Mb
* `UserRequest:hudson.model.Computer$ListPossibleNames`: 1
  * sent 0.0Mb
* `UserRequest:hudson.model.label_exciting_folk$GetClockDifference1`: 23
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 23
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 23
  * sent 0.1Mb
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 23
  * sent 0.0Mb
* `UserRequest:hudson.plugins.PerfPublisher.PerfPublisherPublisher$ParseReportCallable`: 6
  * sent 0.0Mb
* `UserRequest:hudson.plugins.disk_usage.DiskUsageUtil$DiskUsageCallable`: 6
  * sent 0.0Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 263
  * sent 0.5Mb
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 1
  * sent 0.0Mb
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 23
  * sent 0.1Mb
* `UserRequest:hudson.tasks.ArtifactArchiver$ListFiles`: 6
  * sent 0.0Mb
* `UserRequest:hudson.tasks.Fingerprinter$FindRecords`: 7
  * sent 0.0Mb
* `UserRequest:hudson.tasks.junit.JUnitParser$ParseResultCallable`: 6
  * sent 0.0Mb
* `UserRequest:hudson.util.RemotingDiagnostics$GetSystemProperties`: 336
  * sent 0.9Mb
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 1
  * sent 0.0Mb
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 1
  * sent 0.0Mb
* `UserRequest:net.bull.javamelody.RemoteCallHelper$DelegatingTask`: 1321
  * sent 3.4Mb
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.EnvInjectComputerListener$2`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectActionSetter$MapEnvInjectExceptionMasterToSlaveCallable`: 7
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsSetter`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvironmentVariablesNodeLoader$EnvVarMasterToSlaveCallable`: 7
  * sent 0.0Mb
* `UserRequest:org.jfrog.hudson.pipeline.docker.proxy.BuildInfoProxy$1`: 1
  * sent 0.0Mb

# Commands received
* `Pipe.Chunk`: 3632
  * received 4.8Mb
* `Pipe.Flush`: 3139
  * received 0.5Mb
* `ProxyOutputStream.Ack`: 91203
  * received 14.0Mb
* `ProxyOutputStream.EOF`: 524
  * received 1.0Mb
* `ProxyOutputStream.Unexport`: 4
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 700
  * received 0.4Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch[java.lang.String]`: 1
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 15
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResources2[java.lang.String]`: 4
  * received 0.0Mb
* `Response`: 10690
  * received 38.9Mb
* `Unexport`: 23880
  * received 34.2Mb
* `UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 48
  * received 0.3Mb
* `UserRequest:UserRPCRequest:hudson.remoting.JarLoader.writeJarTo[long,long,java.io.OutputStream]`: 1
  * received 0.0Mb
* `UserRequest:hudson.remoting.Channel$IOSyncer`: 6
  * received 0.0Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 263
  * received 0.5Mb
* `UserRequest:hudson.util.ProcessTree$DoVetoersExist`: 1
  * received 0.0Mb

# Responses received
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.getIOtriplet[]`: 7
  * waited 28 ms
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.isAlive[]`: 6
  * waited 17 ms
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.join[]`: 6
  * waited 8 hr 33 min
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 23
  * waited 0.1 sec
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 1
  * waited 1.6 sec
* `UserRequest:com.cloudbees.jenkins.support.api.CommandOutputContent$CommandLauncher`: 129
  * waited 3.3 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 23
  * waited 3 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 23
  * waited 0.26 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 23
  * waited 0.16 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 23
  * waited 0.11 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.FileDescriptorLimit$GetUlimit`: 22
  * waited 0.2 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 23
  * waited 0.12 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 22
  * waited 0.42 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 44
  * waited 0.32 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemConfiguration$GetDmiInfo`: 43
  * waited 0.18 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 22
  * waited 0.1 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 23
  * waited 2.3 sec
* `UserRequest:com.cloudbees.jenkins.support.util.SystemPlatform$GetCurrentPlatform`: 86
  * waited 0.43 sec
* `UserRequest:hudson.EnvVars$GetEnvVars`: 1
  * waited 9 ms
* `UserRequest:hudson.FilePath$2`: 4
  * waited 47 ms
* `UserRequest:hudson.FilePath$CallableWith`: 46
  * waited 0.95 sec
* `UserRequest:hudson.FilePath$CopyRecursiveRemoteToLocal`: 3
  * waited 0.11 sec
* `UserRequest:hudson.FilePath$CopyTo`: 514
  * waited 2.3 sec
* `UserRequest:hudson.FilePath$CreateTextTempFile`: 7
  * waited 30 ms
* `UserRequest:hudson.FilePath$Delete`: 6
  * waited 16 ms
* `UserRequest:hudson.FilePath$Exists`: 89
  * waited 1.3 sec
* `UserRequest:hudson.FilePath$IsDirectory`: 22
  * waited 0.11 sec
* `UserRequest:hudson.FilePath$LastModified`: 520
  * waited 1.8 sec
* `UserRequest:hudson.FilePath$Mkdirs`: 21
  * waited 90 ms
* `UserRequest:hudson.FilePath$Read`: 3
  * waited 11 ms
* `UserRequest:hudson.FilePath$ToURI`: 3
  * waited 16 ms
* `UserRequest:hudson.FilePath$Touch`: 3399
  * waited 13 sec
* `UserRequest:hudson.FilePath$WritePipe`: 3399
  * waited 14 sec
* `UserRequest:hudson.Launcher$RemoteLaunchCallable`: 7
  * waited 0.19 sec
* `UserRequest:hudson.Launcher$RemoteLauncher$KillTask`: 6
  * waited 1.8 sec
* `UserRequest:hudson.logging.LogRecorder$SetLevel`: 1
  * waited 0.34 sec
* `UserRequest:hudson.model.Computer$ListPossibleNames`: 1
  * waited 12 ms
* `UserRequest:hudson.model.label_exciting_folk$GetClockDifference1`: 23
  * waited 0.59 sec
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 23
  * waited 0.15 sec
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 23
  * waited 0.58 sec
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 23
  * waited 0.73 sec
* `UserRequest:hudson.plugins.PerfPublisher.PerfPublisherPublisher$ParseReportCallable`: 6
  * waited 31 ms
* `UserRequest:hudson.plugins.disk_usage.DiskUsageUtil$DiskUsageCallable`: 6
  * waited 0.33 sec
* `UserRequest:hudson.remoting.PingThread$Ping`: 263
  * waited 0.97 sec
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 1
  * waited 0.32 sec
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 23
  * waited 0.1 sec
* `UserRequest:hudson.tasks.ArtifactArchiver$ListFiles`: 6
  * waited 21 ms
* `UserRequest:hudson.tasks.Fingerprinter$FindRecords`: 7
  * waited 0.27 sec
* `UserRequest:hudson.tasks.junit.JUnitParser$ParseResultCallable`: 6
  * waited 0.37 sec
* `UserRequest:hudson.util.RemotingDiagnostics$GetSystemProperties`: 336
  * waited 1.2 sec
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 1
  * waited 6.5 sec
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 1
  * waited 0.16 sec
* `UserRequest:net.bull.javamelody.RemoteCallHelper$DelegatingTask`: 1321
  * waited 20 sec
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 1
  * waited 28 ms
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 1
  * waited 0.23 sec
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 1
  * waited 0.15 sec
* `UserRequest:org.jenkinsci.plugins.envinject.EnvInjectComputerListener$2`: 1
  * waited 0.34 sec
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectActionSetter$MapEnvInjectExceptionMasterToSlaveCallable`: 7
  * waited 38 ms
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsSetter`: 1
  * waited 83 ms
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvironmentVariablesNodeLoader$EnvVarMasterToSlaveCallable`: 7
  * waited 48 ms
* `UserRequest:org.jfrog.hudson.pipeline.docker.proxy.BuildInfoProxy$1`: 1
  * waited 74 ms

# JARs sent
* `jna-4.5.2.jar`: 1484022b
* `libpam4j-1.8.jar`: 19925b
* `support-core.jar`: 317701b
* `commons-io-2.4.jar`: 185140b
* `monitoring.jar`: 41743b
* `javamelody-core-1.74.0.jar`: 1345246b
* `commons-compress-1.10.jar`: 409475b
* `itext-2.1.7.jar`: 1130070b
* `ant-1.9.2.jar`: 2000557b
* `spring-context-2.5.6.SEC03.jar`: 476894b
* `guava-11.0.1.jar`: 1649781b
* `commons-fileupload-1.3.1-jenkins-2.jar`: 68803b
* `launchd-label_exciting_folk-installer-1.2.jar`: 22663b
* `systemd-label_exciting_folk-installer-1.1.jar`: 11541b
* `label_exciting_folk-installer-1.6.jar`: 27374b
* `envinject.jar`: 154483b
* `envinject-lib-1.29.jar`: 20599b
* `commons-codec-1.9.jar`: 263965b
* `json-lib-2.4-jenkins-2.jar`: 141207b
* `task-reactor-1.5.jar`: 22114b
* `commons-jelly-1.1-jenkins-20120928.jar`: 170642b
* `xpp3-1.1.4c.jar`: 120069b
* `stapler-jelly-1.255.jar`: 87452b
* `jcl-over-slf4j-1.7.25.jar`: 16515b
* `slf4j-jdk14-1.7.25.jar`: 8460b
* `junit.jar`: 439638b
* `dom4j-1.6.1-jenkins-4.jar`: 254359b
* `perfpublisher.jar`: 166764b
* `matrix-project.jar`: 244433b
* `disk-usage.jar`: 102597b
* `mail-1.4.4.jar`: 494924b
* `artifactory.jar`: 657548b
* `mitm-2.1.1.jar`: 213956b
* `littleproxy-1.1.2.jar`: 130290b
