# Totals
* Writes: 14507
  * sent 52.3Mb
* Reads: 21294
  * received 29.6Mb
* Responses: 2711
  * waited 52 sec

# Commands sent
* `Pipe.Chunk`: 9685
  * sent 41.8Mb
* `ProxyOutputStream.Ack`: 474
  * sent 0.1Mb
* `ProxyOutputStream.EOF`: 22
  * sent 0.0Mb
* `ProxyOutputStream.Unexport`: 1
  * sent 0.0Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 603
  * sent 1.6Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 15
  * sent 0.0Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResources2[java.lang.String]`: 3
  * sent 0.0Mb
* `Response:UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 47
  * sent 0.1Mb
* `Response:UserRequest:UserRPCRequest:hudson.remoting.JarLoader.writeJarTo[long,long,java.io.OutputStream]`: 1
  * sent 0.0Mb
* `Response:UserRequest:hudson.remoting.Channel$IOSyncer`: 7
  * sent 0.0Mb
* `Response:UserRequest:hudson.remoting.PingThread$Ping`: 263
  * sent 0.5Mb
* `Response:UserRequest:hudson.util.ProcessTree$DoVetoersExist`: 1
  * sent 0.0Mb
* `Unexport`: 673
  * sent 1.0Mb
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.getIOtriplet[]`: 8
  * sent 0.0Mb
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.isAlive[]`: 7
  * sent 0.0Mb
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.join[]`: 8
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 23
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 1
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.api.CommandOutputContent$CommandLauncher`: 66
  * sent 0.2Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 23
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 23
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 23
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 23
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.FileDescriptorLimit$GetUlimit`: 22
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 23
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 22
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 44
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemConfiguration$GetDmiInfo`: 22
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 22
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 23
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.util.SystemPlatform$GetCurrentPlatform`: 43
  * sent 0.1Mb
* `UserRequest:hudson.EnvVars$GetEnvVars`: 1
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$2`: 1
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$CallableWith`: 46
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$CopyTo`: 252
  * sent 0.7Mb
* `UserRequest:hudson.FilePath$CreateTextTempFile`: 8
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Delete`: 7
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Exists`: 87
  * sent 0.2Mb
* `UserRequest:hudson.FilePath$IsDirectory`: 22
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$LastModified`: 260
  * sent 0.7Mb
* `UserRequest:hudson.FilePath$Mkdirs`: 24
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$Read`: 1
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$ToURI`: 7
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Touch`: 22
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$WritePipe`: 22
  * sent 0.1Mb
* `UserRequest:hudson.Launcher$RemoteLaunchCallable`: 8
  * sent 0.0Mb
* `UserRequest:hudson.Launcher$RemoteLauncher$KillTask`: 7
  * sent 0.0Mb
* `UserRequest:hudson.logging.LogRecorder$SetLevel`: 1
  * sent 0.0Mb
* `UserRequest:hudson.model.Computer$ListPossibleNames`: 1
  * sent 0.0Mb
* `UserRequest:hudson.model.label_exciting_folk$GetClockDifference1`: 23
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 23
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 23
  * sent 0.1Mb
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 23
  * sent 0.0Mb
* `UserRequest:hudson.plugins.PerfPublisher.PerfPublisherPublisher$ParseReportCallable`: 7
  * sent 0.0Mb
* `UserRequest:hudson.plugins.disk_usage.DiskUsageUtil$DiskUsageCallable`: 7
  * sent 0.0Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 263
  * sent 0.5Mb
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 1
  * sent 0.0Mb
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 23
  * sent 0.1Mb
* `UserRequest:hudson.tasks.ArtifactArchiver$ListFiles`: 7
  * sent 0.0Mb
* `UserRequest:hudson.tasks.Fingerprinter$FindRecords`: 8
  * sent 0.0Mb
* `UserRequest:hudson.tasks.junit.JUnitParser$ParseResultCallable`: 7
  * sent 0.0Mb
* `UserRequest:hudson.util.RemotingDiagnostics$GetSystemProperties`: 392
  * sent 1.1Mb
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 1
  * sent 0.0Mb
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 1
  * sent 0.0Mb
* `UserRequest:net.bull.javamelody.RemoteCallHelper$DelegatingTask`: 678
  * sent 1.8Mb
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.EnvInjectComputerListener$2`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectActionSetter$MapEnvInjectExceptionMasterToSlaveCallable`: 8
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsSetter`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvironmentVariablesNodeLoader$EnvVarMasterToSlaveCallable`: 8
  * sent 0.0Mb
* `UserRequest:org.jfrog.hudson.pipeline.docker.proxy.BuildInfoProxy$1`: 1
  * sent 0.0Mb

# Commands received
* `Pipe.Chunk`: 474
  * received 0.8Mb
* `Pipe.Flush`: 269
  * received 0.0Mb
* `ProxyOutputStream.Ack`: 9685
  * received 1.5Mb
* `ProxyOutputStream.EOF`: 254
  * received 0.5Mb
* `ProxyOutputStream.Unexport`: 7
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 603
  * received 0.4Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 15
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResources2[java.lang.String]`: 3
  * received 0.0Mb
* `Response`: 2711
  * received 15.6Mb
* `Unexport`: 6954
  * received 10.0Mb
* `UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 47
  * received 0.3Mb
* `UserRequest:UserRPCRequest:hudson.remoting.JarLoader.writeJarTo[long,long,java.io.OutputStream]`: 1
  * received 0.0Mb
* `UserRequest:hudson.remoting.Channel$IOSyncer`: 7
  * received 0.0Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 263
  * received 0.5Mb
* `UserRequest:hudson.util.ProcessTree$DoVetoersExist`: 1
  * received 0.0Mb

# Responses received
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.getIOtriplet[]`: 8
  * waited 39 ms
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.isAlive[]`: 7
  * waited 29 ms
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.join[]`: 7
  * waited 6.4 sec
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 23
  * waited 87 ms
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 1
  * waited 1.1 sec
* `UserRequest:com.cloudbees.jenkins.support.api.CommandOutputContent$CommandLauncher`: 66
  * waited 1.4 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 23
  * waited 2.3 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 23
  * waited 0.52 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 23
  * waited 0.17 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 23
  * waited 0.1 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.FileDescriptorLimit$GetUlimit`: 22
  * waited 0.22 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 23
  * waited 0.12 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 22
  * waited 0.44 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 44
  * waited 0.36 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemConfiguration$GetDmiInfo`: 22
  * waited 0.28 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 22
  * waited 0.1 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 23
  * waited 0.67 sec
* `UserRequest:com.cloudbees.jenkins.support.util.SystemPlatform$GetCurrentPlatform`: 43
  * waited 0.43 sec
* `UserRequest:hudson.EnvVars$GetEnvVars`: 1
  * waited 9 ms
* `UserRequest:hudson.FilePath$2`: 1
  * waited 19 ms
* `UserRequest:hudson.FilePath$CallableWith`: 46
  * waited 0.7 sec
* `UserRequest:hudson.FilePath$CopyTo`: 252
  * waited 1.4 sec
* `UserRequest:hudson.FilePath$CreateTextTempFile`: 8
  * waited 42 ms
* `UserRequest:hudson.FilePath$Delete`: 7
  * waited 27 ms
* `UserRequest:hudson.FilePath$Exists`: 87
  * waited 1.6 sec
* `UserRequest:hudson.FilePath$IsDirectory`: 22
  * waited 0.14 sec
* `UserRequest:hudson.FilePath$LastModified`: 260
  * waited 1 sec
* `UserRequest:hudson.FilePath$Mkdirs`: 24
  * waited 0.11 sec
* `UserRequest:hudson.FilePath$Read`: 1
  * waited 8 ms
* `UserRequest:hudson.FilePath$ToURI`: 7
  * waited 47 ms
* `UserRequest:hudson.FilePath$Touch`: 22
  * waited 0.12 sec
* `UserRequest:hudson.FilePath$WritePipe`: 22
  * waited 0.12 sec
* `UserRequest:hudson.Launcher$RemoteLaunchCallable`: 8
  * waited 0.24 sec
* `UserRequest:hudson.Launcher$RemoteLauncher$KillTask`: 7
  * waited 1.3 sec
* `UserRequest:hudson.logging.LogRecorder$SetLevel`: 1
  * waited 0.6 sec
* `UserRequest:hudson.model.Computer$ListPossibleNames`: 1
  * waited 15 ms
* `UserRequest:hudson.model.label_exciting_folk$GetClockDifference1`: 23
  * waited 0.45 sec
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 23
  * waited 0.19 sec
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 23
  * waited 0.5 sec
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 23
  * waited 0.59 sec
* `UserRequest:hudson.plugins.PerfPublisher.PerfPublisherPublisher$ParseReportCallable`: 7
  * waited 47 ms
* `UserRequest:hudson.plugins.disk_usage.DiskUsageUtil$DiskUsageCallable`: 7
  * waited 0.24 sec
* `UserRequest:hudson.remoting.PingThread$Ping`: 263
  * waited 1.1 sec
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 1
  * waited 0.28 sec
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 23
  * waited 96 ms
* `UserRequest:hudson.tasks.ArtifactArchiver$ListFiles`: 7
  * waited 36 ms
* `UserRequest:hudson.tasks.Fingerprinter$FindRecords`: 8
  * waited 0.25 sec
* `UserRequest:hudson.tasks.junit.JUnitParser$ParseResultCallable`: 7
  * waited 0.16 sec
* `UserRequest:hudson.util.RemotingDiagnostics$GetSystemProperties`: 392
  * waited 1.8 sec
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 1
  * waited 6.1 sec
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 1
  * waited 55 ms
* `UserRequest:net.bull.javamelody.RemoteCallHelper$DelegatingTask`: 678
  * waited 16 sec
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 1
  * waited 22 ms
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 1
  * waited 96 ms
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 1
  * waited 43 ms
* `UserRequest:org.jenkinsci.plugins.envinject.EnvInjectComputerListener$2`: 1
  * waited 0.11 sec
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectActionSetter$MapEnvInjectExceptionMasterToSlaveCallable`: 8
  * waited 44 ms
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsSetter`: 1
  * waited 29 ms
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvironmentVariablesNodeLoader$EnvVarMasterToSlaveCallable`: 8
  * waited 0.4 sec
* `UserRequest:org.jfrog.hudson.pipeline.docker.proxy.BuildInfoProxy$1`: 1
  * waited 0.12 sec

# JARs sent
* `jna-4.5.2.jar`: 1484022b
* `libpam4j-1.8.jar`: 19925b
* `support-core.jar`: 317701b
* `commons-io-2.4.jar`: 185140b
* `commons-compress-1.10.jar`: 409475b
* `ant-1.9.2.jar`: 2000557b
* `commons-fileupload-1.3.1-jenkins-2.jar`: 68803b
* `launchd-label_exciting_folk-installer-1.2.jar`: 22663b
* `label_exciting_folk-installer-1.6.jar`: 27374b
* `systemd-label_exciting_folk-installer-1.1.jar`: 11541b
* `envinject.jar`: 154483b
* `commons-lang-2.6.jar`: 284220b
* `envinject-lib-1.29.jar`: 20599b
* `monitoring.jar`: 41743b
* `itext-2.1.7.jar`: 1130070b
* `spring-context-2.5.6.SEC03.jar`: 476894b
* `commons-codec-1.9.jar`: 263965b
* `json-lib-2.4-jenkins-2.jar`: 141207b
* `xpp3-1.1.4c.jar`: 120069b
* `slf4j-jdk14-1.7.25.jar`: 8460b
* `junit.jar`: 439638b
* `dom4j-1.6.1-jenkins-4.jar`: 254359b
* `perfpublisher.jar`: 166764b
* `matrix-project.jar`: 244433b
* `disk-usage.jar`: 102597b
* `mail-1.4.4.jar`: 494924b
* `artifactory.jar`: 657548b
* `mitm-2.1.1.jar`: 213956b
* `littleproxy-1.1.2.jar`: 130290b
