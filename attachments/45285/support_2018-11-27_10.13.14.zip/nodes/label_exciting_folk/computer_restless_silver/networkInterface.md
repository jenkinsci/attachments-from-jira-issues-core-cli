-----------
 * Name eth0
 ** Hardware Address - 38d5471afaf4
 ** Index - 3
 ** InetAddress - /ip_lost_wrist%eth0
 ** InetAddress - /ip_premature_captain%eth0
 ** InetAddress - /ip_white_overview
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name eth1
 ** Hardware Address - 18d6c7031a8a
 ** Index - 2
 ** InetAddress - /ip_structural_departure%eth1
 ** InetAddress - /ip_adequate_friendship%eth1
 ** InetAddress - /ip_cultural_law
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /ip_consistent_lady%lo
 ** InetAddress - /ip_comparable_declaration
 ** MTU - 65536
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false
