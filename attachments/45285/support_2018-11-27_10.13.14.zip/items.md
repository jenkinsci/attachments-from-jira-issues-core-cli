Item statistics
===============

  * `hudson.model.FreeStyleProject`
    - Number of items: 59
    - Number of builds per job: 84.22033898305085 [n=59, s=200.0]

Total job statistics
======================

  * Number of jobs: 59
  * Number of builds per job: 84.22033898305085 [n=59, s=200.0]
