Loggers currently view_economic_stamp
=========================
hudson.plugins.scm_sync_configuration - ALL
com.mongodb - WARNING
org.apache.sshd - WARNING
winstone - INFO
 - INFO
