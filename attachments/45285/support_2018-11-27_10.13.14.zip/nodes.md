Node statistics
===============

  * Total number of nodes
      - Sample size:        5236
      - Average (mean):     13.0
      - Average (median):   13.0
      - Standard deviation: 0.0
      - Minimum:            13
      - Maximum:            13
      - 95th percentile:    13.0
      - 99th percentile:    13.0
  * Total number of nodes online
      - Sample size:        5236
      - Average (mean):     11.000000000002949
      - Average (median):   11.0
      - Standard deviation: 1.7166226164451627E-6
      - Minimum:            11
      - Maximum:            12
      - 95th percentile:    11.0
      - 99th percentile:    11.0
  * Total number of executors
      - Sample size:        5236
      - Average (mean):     14.000000000002943
      - Average (median):   14.0
      - Standard deviation: 1.7166226164451627E-6
      - Minimum:            14
      - Maximum:            15
      - 95th percentile:    14.0
      - 99th percentile:    14.0
  * Total number of executors in use
      - Sample size:        5236
      - Average (mean):     1.9999999999999845
      - Average (median):   2.0
      - Standard deviation: 1.248285233241847E-7
      - Minimum:            1
      - Maximum:            4
      - 95th percentile:    2.0
      - 99th percentile:    2.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      1
      - FS root:        `C:\Program Files (x86)\Jenkins`
      - Labels:         label_intermediate_win label_irrelevant_rejection label_painful_businessman label_colourful_kite label_fair_outfit label_similar_debate label_express_story label_violent_forehead label_particular_stream MASTER
      - Usage:          `EXCLUSIVE`
      - label_exciting_folk Version:  3.25
      - Java
          + Home:           `C:\Program Files\Java\jre1.8.0_181`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_181
          + Maximum memory:   3.98 GB (4277665792)
          + Allocated memory: 3.98 GB (4277665792)
          + Free memory:      1.88 GB (2020339680)
          + In-use memory:    2.10 GB (2257326112)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.181-b13
      - Operating system
          + Name:         label_intellectual_deadline 7
          + Architecture: amd64
          + Version:      6.1
      - Process ID: 5876 (0x16f4)
      - Process started: 2018-11-26 12:33:27.687+0000
      - Process uptime: 21 hr
      - JVM startup parameters:
          + Boot classpath: `C:\Program Files\Java\jre1.8.0_181\lib\resources.jar;C:\Program Files\Java\jre1.8.0_181\lib\rt.jar;C:\Program Files\Java\jre1.8.0_181\lib\sunrsasign.jar;C:\Program Files\Java\jre1.8.0_181\lib\jsse.jar;C:\Program Files\Java\jre1.8.0_181\lib\jce.jar;C:\Program Files\Java\jre1.8.0_181\lib\charsets.jar;C:\Program Files\Java\jre1.8.0_181\lib\jfr.jar;C:\Program Files\Java\jre1.8.0_181\classes`
          + Classpath: `C:\Program Files (x86)\Jenkins\jenkins.war`
C:\Program Files\Microsoft SQL Server\120\Tools\Binn\;C:\tools\gnuwin32\bin;C:\Program Files (x86)\Msc-generator;C:\Program Files\doxygen\bin;C:\Program Files (x86)\label_intellectual_deadline Kits\8.1\label_intellectual_deadline Performance Toolkit\;C:\Program Files\Microsoft\Web Platform Installer\;C:\Program Files\Microsoft label_intellectual_deadline Performance Toolkit\;C:\Program Files (x86)\Skype\Phone\;C:\Program Files (x86)\QuickTime\QTSystem\;C:\tools\svn1.9.3\bin;C:\Python27;C:\Program Files\Microsoft SQL Server\130\Tools\Binn\;C:\Program Files\TortoiseSVN\bin;C:\Program Files\Git\cmd;C:\Program Files\Git\mingw64\bin;C:\Program Files\Git\usr\bin;C:\Program Files (x86)\Mscgen;C:\Program Files\dotnet\;C:\Program Files\TortoiseGit\bin;;.`
          + arg[0]: `-Xrs`
          + arg[1]: `-Xms4096M`
          + arg[2]: `-Xmx4096M`
          + arg[3]: `-XX:MaxGCPauseMillis=500`
          + arg[4]: `-Dhudson.lifecycle=hudson.lifecycle.WindowsServiceLifecycle`
          + arg[5]: `-Dhudson.model.DirectoryBrowserSupport.CSP=`

  * computer_basic_executive (`hudson.slaves.DumbSlave`)
      - Description:    _Slave build PC (shuttle) - label_expensive_burn builds_
      - Executors:      2
      - Remote FS root: `c:\CI`
      - Labels:         label_unfair_statistics label_intellectual_deadline label_exciting_folk label_usual_bullet label_expensive_burn label_inner_kick label_electronic_offence label_vertical_order
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.7
      - Java
          + Home:           `C:\Program Files\Java\jre1.8.0_181`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_181
          + Maximum memory:   455.50 MB (477626368)
          + Allocated memory: 166.50 MB (174587904)
          + Free memory:      74.28 MB (77883392)
          + In-use memory:    92.22 MB (96704512)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.181-b13
      - Operating system
          + Name:         label_intellectual_deadline 7
          + Architecture: amd64
          + Version:      6.1
      - Process ID: 4120 (0x1018)
      - Process started: 2018-11-19 11:49:19.766+0000
      - Process uptime: 7 days 22 hr
      - JVM startup parameters:
          + Boot classpath: `C:\Program Files\Java\jre1.8.0_181\lib\resources.jar;C:\Program Files\Java\jre1.8.0_181\lib\rt.jar;C:\Program Files\Java\jre1.8.0_181\lib\sunrsasign.jar;C:\Program Files\Java\jre1.8.0_181\lib\jsse.jar;C:\Program Files\Java\jre1.8.0_181\lib\jce.jar;C:\Program Files\Java\jre1.8.0_181\lib\charsets.jar;C:\Program Files\Java\jre1.8.0_181\lib\jfr.jar;C:\Program Files\Java\jre1.8.0_181\classes`
          + Classpath: `C:\Program Files (x86)\Jenkins\label_exciting_folk.jar`
          + Library path: `C:\Program Files (x86)\Common Files\Oracle\Java\javapath;C:\label_intellectual_deadline\Sun\Java\bin;C:\label_intellectual_deadline\system32;C:\label_intellectual_deadline;C:\Python27\;C:\Python27\Scripts;C:\Program Files (x86)\Common Files\Oracle\Java\javapath;C:\ProgramData\Oracle\Java\javapath;C:\label_intellectual_deadline\system32;C:\label_intellectual_deadline;C:\label_intellectual_deadline\System32\Wbem;C:\label_intellectual_deadline\System32\WindowsPowerShell\v1.0\;C:\label_unfair_statistics-ide-new\toolchain\bin;C:\label_unfair_statistics-ide-new\cygwin\bin;C:\label_unfair_statistics-ide\toolchain\bin;C:\label_unfair_statistics-ide\cygwin\bin;G:\Program Files (x86)\WinMerge;G:\Program Files\TortoiseSVN\bin;C:\tools\svn1.9.3\bin;G:\Program Files\PuTTY\;G:\Program Files\doxygen\bin;C:\Program Files\Microsoft SQL Server\130\Tools\Binn\;C:\Program Files (x86)\label_intellectual_deadline Kits\8.1\label_intellectual_deadline Performance Toolkit\;C:\Program Files\dotnet\;c:\Program Files\Microsoft\Web Platform Installer\;C:\Program Files (x86)\Microsoft SQL Server\110\DTS\Binn\;C:\Program Files (x86)\Microsoft SQL Server\120\DTS\Binn\;C:\Program Files (x86)\Microsoft SQL Server\130\DTS\Binn\;G:\Program Files\Git\cmd;G:\Program Files\Git\mingw64\bin;G:\Program Files\Git\usr\bin;C:\Program Files (x86)\Microsoft SQL Server\110\Tools\Binn\;C:\Program Files\Microsoft SQL Server\110\Tools\Binn\;C:\Program Files\Microsoft SQL Server\110\DTS\Binn\;G:\Strawberry\c\bin;G:\Strawberry\perl\site\bin;G:\Strawberry\perl\bin;C:\Program Files\doxygen\bin;C:\Program Files (x86)\Microchip\xc32\v2.10\bin;.`
          + arg[0]: `-Xmx512m`

  * computer_educational_idea (`hudson.slaves.DumbSlave`)
      - Description:    _Slave build PC (shuttle) label_civilian_wilderness builds_
      - Executors:      2
      - Remote FS root: `c:\CI2`
      - Labels:         label_unfair_statistics label_intellectual_deadline label_exciting_folk label_usual_bullet label_civilian_wilderness label_inner_kick label_electronic_offence label_vertical_order
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.7
      - Java
          + Home:           `C:\Program Files\Java\jre1.8.0_181`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_181
          + Maximum memory:   455.50 MB (477626368)
          + Allocated memory: 169.50 MB (177733632)
          + Free memory:      65.33 MB (68506840)
          + In-use memory:    104.17 MB (109226792)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.181-b13
      - Operating system
          + Name:         label_intellectual_deadline 7
          + Architecture: amd64
          + Version:      6.1
      - Process ID: 4128 (0x1020)
      - Process started: 2018-11-19 11:49:19.766+0000
      - Process uptime: 7 days 22 hr
      - JVM startup parameters:
          + Boot classpath: `C:\Program Files\Java\jre1.8.0_181\lib\resources.jar;C:\Program Files\Java\jre1.8.0_181\lib\rt.jar;C:\Program Files\Java\jre1.8.0_181\lib\sunrsasign.jar;C:\Program Files\Java\jre1.8.0_181\lib\jsse.jar;C:\Program Files\Java\jre1.8.0_181\lib\jce.jar;C:\Program Files\Java\jre1.8.0_181\lib\charsets.jar;C:\Program Files\Java\jre1.8.0_181\lib\jfr.jar;C:\Program Files\Java\jre1.8.0_181\classes`
          + Classpath: `C:\Program Files (x86)\Jenkins\label_exciting_folk.jar`
          + Library path: `C:\Program Files (x86)\Common Files\Oracle\Java\javapath;C:\label_intellectual_deadline\Sun\Java\bin;C:\label_intellectual_deadline\system32;C:\label_intellectual_deadline;C:\Python27\;C:\Python27\Scripts;C:\Program Files (x86)\Common Files\Oracle\Java\javapath;C:\ProgramData\Oracle\Java\javapath;C:\label_intellectual_deadline\system32;C:\label_intellectual_deadline;C:\label_intellectual_deadline\System32\Wbem;C:\label_intellectual_deadline\System32\WindowsPowerShell\v1.0\;C:\label_unfair_statistics-ide-new\toolchain\bin;C:\label_unfair_statistics-ide-new\cygwin\bin;C:\label_unfair_statistics-ide\toolchain\bin;C:\label_unfair_statistics-ide\cygwin\bin;G:\Program Files (x86)\WinMerge;G:\Program Files\TortoiseSVN\bin;C:\tools\svn1.9.3\bin;G:\Program Files\PuTTY\;G:\Program Files\doxygen\bin;C:\Program Files\Microsoft SQL Server\130\Tools\Binn\;C:\Program Files (x86)\label_intellectual_deadline Kits\8.1\label_intellectual_deadline Performance Toolkit\;C:\Program Files\dotnet\;c:\Program Files\Microsoft\Web Platform Installer\;C:\Program Files (x86)\Microsoft SQL Server\110\DTS\Binn\;C:\Program Files (x86)\Microsoft SQL Server\120\DTS\Binn\;C:\Program Files (x86)\Microsoft SQL Server\130\DTS\Binn\;G:\Program Files\Git\cmd;G:\Program Files\Git\mingw64\bin;G:\Program Files\Git\usr\bin;C:\Program Files (x86)\Microsoft SQL Server\110\Tools\Binn\;C:\Program Files\Microsoft SQL Server\110\Tools\Binn\;C:\Program Files\Microsoft SQL Server\110\DTS\Binn\;G:\Strawberry\c\bin;G:\Strawberry\perl\site\bin;G:\Strawberry\perl\bin;C:\Program Files\doxygen\bin;C:\Program Files (x86)\Microchip\xc32\v2.10\bin;.`
          + arg[0]: `-Xmx512m`

  * computer_hungry_monopoly (`hudson.slaves.DumbSlave`)
      - Description:    _Slave build PC (shuttle) label_civilian_wilderness builds_
      - Executors:      2
      - Remote FS root: `c:\CI3`
      - Labels:         label_unfair_statistics label_intellectual_deadline label_exciting_folk label_usual_bullet label_inner_kick label_electronic_offence label_valid_stone label_separate_regard label_oral_option label_satisfied_cylinder label_vertical_order label_secular_whisky
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.7
      - Java
          + Home:           `C:\Program Files\Java\jre1.8.0_181`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_181
          + Maximum memory:   455.50 MB (477626368)
          + Allocated memory: 222.50 MB (233308160)
          + Free memory:      88.97 MB (93288912)
          + In-use memory:    133.53 MB (140019248)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.181-b13
      - Operating system
          + Name:         label_intellectual_deadline 7
          + Architecture: amd64
          + Version:      6.1
      - Process ID: 4136 (0x1028)
      - Process started: 2018-11-19 11:49:19.766+0000
      - Process uptime: 7 days 22 hr
      - JVM startup parameters:
          + Boot classpath: `C:\Program Files\Java\jre1.8.0_181\lib\resources.jar;C:\Program Files\Java\jre1.8.0_181\lib\rt.jar;C:\Program Files\Java\jre1.8.0_181\lib\sunrsasign.jar;C:\Program Files\Java\jre1.8.0_181\lib\jsse.jar;C:\Program Files\Java\jre1.8.0_181\lib\jce.jar;C:\Program Files\Java\jre1.8.0_181\lib\charsets.jar;C:\Program Files\Java\jre1.8.0_181\lib\jfr.jar;C:\Program Files\Java\jre1.8.0_181\classes`
          + Classpath: `C:\Program Files (x86)\Jenkins\label_exciting_folk.jar`
          + Library path: `C:\Program Files (x86)\Common Files\Oracle\Java\javapath;C:\label_intellectual_deadline\Sun\Java\bin;C:\label_intellectual_deadline\system32;C:\label_intellectual_deadline;C:\Python27\;C:\Python27\Scripts;C:\Program Files (x86)\Common Files\Oracle\Java\javapath;C:\ProgramData\Oracle\Java\javapath;C:\label_intellectual_deadline\system32;C:\label_intellectual_deadline;C:\label_intellectual_deadline\System32\Wbem;C:\label_intellectual_deadline\System32\WindowsPowerShell\v1.0\;C:\label_unfair_statistics-ide-new\toolchain\bin;C:\label_unfair_statistics-ide-new\cygwin\bin;C:\label_unfair_statistics-ide\toolchain\bin;C:\label_unfair_statistics-ide\cygwin\bin;G:\Program Files (x86)\WinMerge;G:\Program Files\TortoiseSVN\bin;C:\tools\svn1.9.3\bin;G:\Program Files\PuTTY\;G:\Program Files\doxygen\bin;C:\Program Files\Microsoft SQL Server\130\Tools\Binn\;C:\Program Files (x86)\label_intellectual_deadline Kits\8.1\label_intellectual_deadline Performance Toolkit\;C:\Program Files\dotnet\;c:\Program Files\Microsoft\Web Platform Installer\;C:\Program Files (x86)\Microsoft SQL Server\110\DTS\Binn\;C:\Program Files (x86)\Microsoft SQL Server\120\DTS\Binn\;C:\Program Files (x86)\Microsoft SQL Server\130\DTS\Binn\;G:\Program Files\Git\cmd;G:\Program Files\Git\mingw64\bin;G:\Program Files\Git\usr\bin;C:\Program Files (x86)\Microsoft SQL Server\110\Tools\Binn\;C:\Program Files\Microsoft SQL Server\110\Tools\Binn\;C:\Program Files\Microsoft SQL Server\110\DTS\Binn\;G:\Strawberry\c\bin;G:\Strawberry\perl\site\bin;G:\Strawberry\perl\bin;C:\Program Files\doxygen\bin;C:\Program Files (x86)\Microchip\xc32\v2.10\bin;.`
          + arg[0]: `-Xmx512m`

  * computer_nervous_problem (`hudson.slaves.DumbSlave`)
      - Description:    _Slave build PC (shuttle) label_civilian_wilderness builds_
      - Executors:      1
      - Remote FS root: `c:\CI2`
      - Labels:         label_exciting_folk label_unfair_statistics label_intellectual_deadline label_inevitable_reflection label_colourful_kite label_close_regulation label_usual_bullet label_express_story label_violent_forehead label_particular_stream
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * computer_restless_silver (`hudson.slaves.DumbSlave`)
      - Description:    _elysrvbasil - with Sam54 wilc 1000 linux_
      - Executors:      1
      - Remote FS root: `/home/wifi/jenkins`
      - Labels:         label_rotten_recording label_notorious_officer label_impossible_joy
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.25
      - Java
          + Home:           `/usr/lib/jvm/java-9-openjdk-amd64`
          + Vendor:           Oracle Corporation
          + Version:          9-internal
          + Maximum memory:   1.92 GB (2059403264)
          + Allocated memory: 124.00 MB (130023424)
          + Free memory:      49.23 MB (51620192)
          + In-use memory:    74.77 MB (78403232)
          + GC strategy:      G1
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 9
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 9
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 9-internal+0-2016-04-14-195246.buildd.src
      - Operating system
          + Name:         label_cheerful_date
          + Architecture: amd64
          + Version:      4.15.0-36-generic
          + Distribution: Ubuntu 16.04.3 LTS
      - Process ID: 30191 (0x75ef)
      - Process started: 2018-11-26 12:34:19.870+0000
      - Process uptime: 21 hr
      - JVM startup parameters:
          + Classpath: `remoting.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib/x86_64-label_cheerful_date-gnu/jni:/lib/x86_64-label_cheerful_date-gnu:/usr/lib/x86_64-label_cheerful_date-gnu:/usr/lib/jni:/lib:/usr/lib`

  * computer_ultimate_twist (`hudson.slaves.DumbSlave`)
      - Description:    _elysrvflashheart - with SamD21 AT CMD app rev 16658._
      - Executors:      1
      - Remote FS root: `/home/wifi/jenkins`
      - Labels:         label_revolutionary_wedding label_nice_start label_immune_recession
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.25
      - Java
          + Home:           `/usr/lib/jvm/java-9-openjdk-amd64`
          + Vendor:           Oracle Corporation
          + Version:          9-internal
          + Maximum memory:   1.93 GB (2067791872)
          + Allocated memory: 149.00 MB (156237824)
          + Free memory:      98.90 MB (103705088)
          + In-use memory:    50.10 MB (52532736)
          + GC strategy:      G1
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 9
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 9
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 9-internal+0-2016-04-14-195246.buildd.src
      - Operating system
          + Name:         label_cheerful_date
          + Architecture: amd64
          + Version:      4.4.0-130-generic
          + Distribution: Ubuntu 16.04.2 LTS
      - Process ID: 19372 (0x4bac)
      - Process started: 2018-11-26 12:34:19.820+0000
      - Process uptime: 21 hr
      - JVM startup parameters:
          + Classpath: `remoting.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib/x86_64-label_cheerful_date-gnu/jni:/lib/x86_64-label_cheerful_date-gnu:/usr/lib/x86_64-label_cheerful_date-gnu:/usr/lib/jni:/lib:/usr/lib`

  * computer_bland_basin (`hudson.slaves.DumbSlave`)
      - Description:    _elysrvjarvis - Ely IOP rig_
      - Executors:      1
      - Remote FS root: `/home/atmel/jenkins`
      - Labels:         label_unpleasant_fluctuation label_certain_justice
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.25
      - Java
          + Home:           `/usr/lib/jvm/java-8-oracle/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_191
          + Maximum memory:   1.26 GB (1357381632)
          + Allocated memory: 58.00 MB (60817408)
          + Free memory:      40.59 MB (42561072)
          + In-use memory:    17.41 MB (18256336)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.191-b12
      - Operating system
          + Name:         label_cheerful_date
          + Architecture: amd64
          + Version:      4.4.0-135-generic
          + Distribution: Ubuntu 16.04.5 LTS
      - Process ID: 2412 (0x96c)
      - Process started: 2018-11-26 12:56:44.859+0000
      - Process uptime: 21 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-8-oracle/jre/lib/resources.jar:/usr/lib/jvm/java-8-oracle/jre/lib/rt.jar:/usr/lib/jvm/java-8-oracle/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jsse.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jce.jar:/usr/lib/jvm/java-8-oracle/jre/lib/charsets.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jfr.jar:/usr/lib/jvm/java-8-oracle/jre/classes`
          + Classpath: `remoting.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * computer_elegant_constellation (`hudson.slaves.DumbSlave`)
      - Description:    _multi purpose chamber_
      - Executors:      1
      - Remote FS root: `/home/wifi/jenkins`
      - Labels:         label_immune_recession  label_uncomfortable_bride label_impossible_joy
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.25
      - Java
          + Home:           `/usr/lib/jvm/java-9-openjdk-amd64`
          + Vendor:           Oracle Corporation
          + Version:          9-internal
          + Maximum memory:   1.92 GB (2059403264)
          + Allocated memory: 124.00 MB (130023424)
          + Free memory:      100.81 MB (105709624)
          + In-use memory:    23.19 MB (24313800)
          + GC strategy:      G1
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 9
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 9
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 9-internal+0-2016-04-14-195246.buildd.src
      - Operating system
          + Name:         label_cheerful_date
          + Architecture: amd64
          + Version:      4.13.0-43-generic
          + Distribution: Ubuntu 16.04.3 LTS
      - Process ID: 18509 (0x484d)
      - Process started: 2018-11-26 12:34:24.436+0000
      - Process uptime: 21 hr
      - JVM startup parameters:
          + Classpath: `remoting.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib/x86_64-label_cheerful_date-gnu/jni:/lib/x86_64-label_cheerful_date-gnu:/usr/lib/x86_64-label_cheerful_date-gnu:/usr/lib/jni:/lib:/usr/lib`

  * computer_imperial_exile (`hudson.slaves.DumbSlave`)
      - Description:    _elysrvjarvis - Ely IOP rig_
      - Executors:      1
      - Remote FS root: `/home/wifi/jenkins`
      - Labels:         label_unpleasant_fluctuation label_ethnic_opponent
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.25
      - Java
          + Home:           `/usr/lib/jvm/java-8-oracle/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_191
          + Maximum memory:   1.71 GB (1836580864)
          + Allocated memory: 106.50 MB (111673344)
          + Free memory:      91.06 MB (95483320)
          + In-use memory:    15.44 MB (16190024)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.191-b12
      - Operating system
          + Name:         label_cheerful_date
          + Architecture: amd64
          + Version:      4.15.0-39-generic
          + Distribution: Ubuntu 16.04.5 LTS
      - Process ID: 5017 (0x1399)
      - Process started: 2018-11-26 12:34:19.697+0000
      - Process uptime: 21 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-8-oracle/jre/lib/resources.jar:/usr/lib/jvm/java-8-oracle/jre/lib/rt.jar:/usr/lib/jvm/java-8-oracle/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jsse.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jce.jar:/usr/lib/jvm/java-8-oracle/jre/lib/charsets.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jfr.jar:/usr/lib/jvm/java-8-oracle/jre/classes`
          + Classpath: `remoting.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * computer_noble_ideology (`hudson.slaves.DumbSlave`)
      - Description:    _elysvrmelchett_
      - Executors:      1
      - Remote FS root: `/home/wifi/jenkins`
      - Labels:         label_uncomfortable_bride label_emotional_flesh label_blonde_curtain label_immune_recession
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.25
      - Java
          + Home:           `/usr/lib/jvm/java-9-oracle`
          + Vendor:           Oracle Corporation
          + Version:          9.0.4
          + Maximum memory:   962.00 MB (1008730112)
          + Allocated memory: 90.00 MB (94371840)
          + Free memory:      35.83 MB (37574376)
          + In-use memory:    54.17 MB (56797464)
          + GC strategy:      G1
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 9
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 9
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 9.0.4+11
      - Operating system
          + Name:         label_cheerful_date
          + Architecture: amd64
          + Version:      4.4.0-138-generic
          + Distribution: Ubuntu 16.04.5 LTS
      - Process ID: 26433 (0x6741)
      - Process started: 2018-11-26 12:34:19.979+0000
      - Process uptime: 21 hr
      - JVM startup parameters:
          + Classpath: `remoting.jar`
          + Library path: `/usr/java/packages/lib:/usr/lib64:/lib64:/lib:/usr/lib`

  * computer_rich_moon (`hudson.slaves.DumbSlave`)
      - Description:    _multi purpose chamber_
      - Executors:      1
      - Remote FS root: `/home/wifi/jenkins`
      - Labels:         label_immune_recession  label_uncomfortable_bride label_impossible_joy
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.25
      - Java
          + Home:           `/usr/lib/jvm/java-9-openjdk-amd64`
          + Vendor:           Oracle Corporation
          + Version:          9-internal
          + Maximum memory:   1.92 GB (2059403264)
          + Allocated memory: 59.00 MB (61865984)
          + Free memory:      28.84 MB (30240992)
          + In-use memory:    30.16 MB (31624992)
          + GC strategy:      G1
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 9
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 9
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 9-internal+0-2016-04-14-195246.buildd.src
      - Operating system
          + Name:         label_cheerful_date
          + Architecture: amd64
          + Version:      4.13.0-43-generic
          + Distribution: Ubuntu 16.04.3 LTS
      - Process ID: 18429 (0x47fd)
      - Process started: 2018-11-26 12:34:20.098+0000
      - Process uptime: 21 hr
      - JVM startup parameters:
          + Classpath: `remoting.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib/x86_64-label_cheerful_date-gnu/jni:/lib/x86_64-label_cheerful_date-gnu:/usr/lib/x86_64-label_cheerful_date-gnu:/usr/lib/jni:/lib:/usr/lib`

  * computer_uneasy_producer (`hudson.slaves.DumbSlave`)
      - Description:    _Builder node for jenkins_
      - Executors:      1
      - Remote FS root: `/home/jenkins`
      - Labels:         label_unfair_statistics label_cheerful_date
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.25
      - Java
          + Home:           `/usr/lib/jvm/java-8-oracle/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_181
          + Maximum memory:   1.71 GB (1834483712)
          + Allocated memory: 107.50 MB (112721920)
          + Free memory:      90.05 MB (94428776)
          + In-use memory:    17.45 MB (18293144)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.181-b13
      - Operating system
          + Name:         label_cheerful_date
          + Architecture: amd64
          + Version:      4.15.0-36-generic
          + Distribution: Ubuntu 18.04.1 LTS
      - Process ID: 30441 (0x76e9)
      - Process started: 2018-11-26 12:34:20.192+0000
      - Process uptime: 21 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-8-oracle/jre/lib/resources.jar:/usr/lib/jvm/java-8-oracle/jre/lib/rt.jar:/usr/lib/jvm/java-8-oracle/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jsse.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jce.jar:/usr/lib/jvm/java-8-oracle/jre/lib/charsets.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jfr.jar:/usr/lib/jvm/java-8-oracle/jre/classes`
          + Classpath: `remoting.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

