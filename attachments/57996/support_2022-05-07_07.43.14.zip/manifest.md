Support Bundle Manifest
=======================

Generated on 2022-05-07 07:43:14.643+0000

Requested components:

  * About browser

      - `browser.md`

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `identity.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `nodes/slave/BoBo/checksums.md5`

      - `nodes/slave/PC Art/checksums.md5`

      - `nodes/slave/PC130/checksums.md5`

      - `nodes/slave/PC147/checksums.md5`

      - `nodes/slave/PC159/checksums.md5`

      - `nodes/slave/PC167/checksums.md5`

      - `nodes/slave/PC53/checksums.md5`

      - `nodes/slave/PC69/checksums.md5`

      - `nodes/slave/PC_Might/checksums.md5`

      - `nodes/slave/Slave/checksums.md5`

      - `nodes/slave/VRLAB-DC-01/checksums.md5`

      - `nodes/slave/VRLAB320/checksums.md5`

      - `nodes/slave/VRLAB901/checksums.md5`

      - `nodes/slave/dev_t/checksums.md5`

      - `nodes/slave/mickeyck/checksums.md5`

      - `plugins/active.txt`

      - `plugins/backup.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * About user (basic authentication details only)

      - `user.md`

  * Administrative monitors

      - `admin-monitors.md`

  * Agent Protocols

      - `agent-protocols.md`

  * Build queue

      - `buildqueue.md`

  * Controller Custom Log Recorders

  * Environment variables

      - `nodes/master/environment.txt`

      - `nodes/slave/BoBo/environment.txt`

      - `nodes/slave/PC Art/environment.txt`

      - `nodes/slave/PC130/environment.txt`

      - `nodes/slave/PC147/environment.txt`

      - `nodes/slave/PC159/environment.txt`

      - `nodes/slave/PC167/environment.txt`

      - `nodes/slave/PC53/environment.txt`

      - `nodes/slave/PC69/environment.txt`

      - `nodes/slave/PC_Might/environment.txt`

      - `nodes/slave/Slave/environment.txt`

      - `nodes/slave/VRLAB-DC-01/environment.txt`

      - `nodes/slave/VRLAB320/environment.txt`

      - `nodes/slave/VRLAB901/environment.txt`

      - `nodes/slave/dev_t/environment.txt`

      - `nodes/slave/mickeyck/environment.txt`

  * Controller Log Recorders

      - `nodes/master/logs/all_2022-05-07_07.39.31.log`

      - `nodes/master/logs/all_2022-05-07_07.41.26.log`

      - `nodes/master/logs/all_memory_buffer.log`

      - `nodes/master/logs/jenkins.log`

  * Load Statistics

      - `load-stats/label/BoBo/gnuplot`

      - `load-stats/label/BoBo/hour.csv`

      - `load-stats/label/BoBo/min.csv`

      - `load-stats/label/BoBo/sec10.csv`

      - `load-stats/label/PC+Art/gnuplot`

      - `load-stats/label/PC+Art/hour.csv`

      - `load-stats/label/PC+Art/min.csv`

      - `load-stats/label/PC+Art/sec10.csv`

      - `load-stats/label/PC130/gnuplot`

      - `load-stats/label/PC130/hour.csv`

      - `load-stats/label/PC130/min.csv`

      - `load-stats/label/PC130/sec10.csv`

      - `load-stats/label/PC147/gnuplot`

      - `load-stats/label/PC147/hour.csv`

      - `load-stats/label/PC147/min.csv`

      - `load-stats/label/PC147/sec10.csv`

      - `load-stats/label/PC159/gnuplot`

      - `load-stats/label/PC159/hour.csv`

      - `load-stats/label/PC159/min.csv`

      - `load-stats/label/PC159/sec10.csv`

      - `load-stats/label/PC167/gnuplot`

      - `load-stats/label/PC167/hour.csv`

      - `load-stats/label/PC167/min.csv`

      - `load-stats/label/PC167/sec10.csv`

      - `load-stats/label/PC53/gnuplot`

      - `load-stats/label/PC53/hour.csv`

      - `load-stats/label/PC53/min.csv`

      - `load-stats/label/PC53/sec10.csv`

      - `load-stats/label/PC69/gnuplot`

      - `load-stats/label/PC69/hour.csv`

      - `load-stats/label/PC69/min.csv`

      - `load-stats/label/PC69/sec10.csv`

      - `load-stats/label/PC_Might/gnuplot`

      - `load-stats/label/PC_Might/hour.csv`

      - `load-stats/label/PC_Might/min.csv`

      - `load-stats/label/PC_Might/sec10.csv`

      - `load-stats/label/Slave/gnuplot`

      - `load-stats/label/Slave/hour.csv`

      - `load-stats/label/Slave/min.csv`

      - `load-stats/label/Slave/sec10.csv`

      - `load-stats/label/VRLAB-DC-01/gnuplot`

      - `load-stats/label/VRLAB-DC-01/hour.csv`

      - `load-stats/label/VRLAB-DC-01/min.csv`

      - `load-stats/label/VRLAB-DC-01/sec10.csv`

      - `load-stats/label/VRLAB320/gnuplot`

      - `load-stats/label/VRLAB320/hour.csv`

      - `load-stats/label/VRLAB320/min.csv`

      - `load-stats/label/VRLAB320/sec10.csv`

      - `load-stats/label/VRLAB901/gnuplot`

      - `load-stats/label/VRLAB901/hour.csv`

      - `load-stats/label/VRLAB901/min.csv`

      - `load-stats/label/VRLAB901/sec10.csv`

      - `load-stats/label/built-in/gnuplot`

      - `load-stats/label/built-in/hour.csv`

      - `load-stats/label/built-in/min.csv`

      - `load-stats/label/built-in/sec10.csv`

      - `load-stats/label/dev_t/gnuplot`

      - `load-stats/label/dev_t/hour.csv`

      - `load-stats/label/dev_t/min.csv`

      - `load-stats/label/dev_t/sec10.csv`

      - `load-stats/label/master/gnuplot`

      - `load-stats/label/master/hour.csv`

      - `load-stats/label/master/min.csv`

      - `load-stats/label/master/sec10.csv`

      - `load-stats/label/mickeyck/gnuplot`

      - `load-stats/label/mickeyck/hour.csv`

      - `load-stats/label/mickeyck/min.csv`

      - `load-stats/label/mickeyck/sec10.csv`

      - `load-stats/no-label/gnuplot`

      - `load-stats/no-label/hour.csv`

      - `load-stats/no-label/min.csv`

      - `load-stats/no-label/sec10.csv`

      - `load-stats/overall/gnuplot`

      - `load-stats/overall/hour.csv`

      - `load-stats/overall/min.csv`

      - `load-stats/overall/sec10.csv`

  * All loggers currently enabled

      - `loggers.md`

  * Metrics

      - `nodes/master/metrics.json`

  * Networking Interface

      - `nodes/master/networkInterface.md`

      - `nodes/slave/BoBo/networkInterface.md`

      - `nodes/slave/PC Art/networkInterface.md`

      - `nodes/slave/PC130/networkInterface.md`

      - `nodes/slave/PC147/networkInterface.md`

      - `nodes/slave/PC159/networkInterface.md`

      - `nodes/slave/PC167/networkInterface.md`

      - `nodes/slave/PC53/networkInterface.md`

      - `nodes/slave/PC69/networkInterface.md`

      - `nodes/slave/PC_Might/networkInterface.md`

      - `nodes/slave/Slave/networkInterface.md`

      - `nodes/slave/VRLAB-DC-01/networkInterface.md`

      - `nodes/slave/VRLAB320/networkInterface.md`

      - `nodes/slave/VRLAB901/networkInterface.md`

      - `nodes/slave/dev_t/networkInterface.md`

      - `nodes/slave/mickeyck/networkInterface.md`

  * Node monitors

      - `node-monitors.md`

  * Reverse Proxy

      - `reverse-proxy.md`

  * Running Builds

      - `running-builds.txt`

  * Agent Command Statistics

      - `nodes/slave/PC159/command-stats.md`

      - `nodes/slave/Slave/command-stats.md`

  * Controller system configuration (Linux only)

  * System properties

      - `nodes/master/system.properties`

      - `nodes/slave/BoBo/system.properties`

      - `nodes/slave/PC Art/system.properties`

      - `nodes/slave/PC130/system.properties`

      - `nodes/slave/PC147/system.properties`

      - `nodes/slave/PC159/system.properties`

      - `nodes/slave/PC167/system.properties`

      - `nodes/slave/PC53/system.properties`

      - `nodes/slave/PC69/system.properties`

      - `nodes/slave/PC_Might/system.properties`

      - `nodes/slave/Slave/system.properties`

      - `nodes/slave/VRLAB-DC-01/system.properties`

      - `nodes/slave/VRLAB320/system.properties`

      - `nodes/slave/VRLAB901/system.properties`

      - `nodes/slave/dev_t/system.properties`

      - `nodes/slave/mickeyck/system.properties`

  * Controller Task Log Recorders

      - `task-logs/Connection Activity monitoring to agents.log`

      - `task-logs/Connection Activity monitoring to agents.log.1`

      - `task-logs/Connection Activity monitoring to agents.log.2`

      - `task-logs/Connection Activity monitoring to agents.log.3`

      - `task-logs/Connection Activity monitoring to agents.log.4`

      - `task-logs/Connection Activity monitoring to agents.log.5`

      - `task-logs/DockerContainerWatchdog Asynchronous Periodic Work.log`

      - `task-logs/DockerContainerWatchdog Asynchronous Periodic Work.log.1`

      - `task-logs/DockerContainerWatchdog Asynchronous Periodic Work.log.2`

      - `task-logs/DockerContainerWatchdog Asynchronous Periodic Work.log.3`

      - `task-logs/DockerContainerWatchdog Asynchronous Periodic Work.log.4`

      - `task-logs/DockerContainerWatchdog Asynchronous Periodic Work.log.5`

      - `task-logs/Download metadata.log`

      - `task-logs/Download metadata.log.1`

      - `task-logs/Download metadata.log.2`

      - `task-logs/Download metadata.log.3`

      - `task-logs/Download metadata.log.4`

      - `task-logs/Download metadata.log.5`

      - `task-logs/Fingerprint cleanup.log`

      - `task-logs/Fingerprint cleanup.log.1`

      - `task-logs/Fingerprint cleanup.log.2`

      - `task-logs/Fingerprint cleanup.log.3`

      - `task-logs/Fingerprint cleanup.log.4`

      - `task-logs/Fingerprint cleanup.log.5`

      - `task-logs/Periodic background build discarder.log`

      - `task-logs/Periodic background build discarder.log.1`

      - `task-logs/Periodic background build discarder.log.2`

      - `task-logs/Periodic background build discarder.log.3`

      - `task-logs/Periodic background build discarder.log.4`

      - `task-logs/Periodic background build discarder.log.5`

      - `task-logs/Workspace clean-up.log`

      - `task-logs/Workspace clean-up.log.1`

      - `task-logs/Workspace clean-up.log.2`

      - `task-logs/Workspace clean-up.log.3`

      - `task-logs/Workspace clean-up.log.4`

      - `task-logs/Workspace clean-up.log.5`

      - `task-logs/health-checker.log`

      - `task-logs/jobAnalytics.log`

      - `task-logs/jobAnalytics.log.1`

      - `task-logs/jobAnalytics.log.2`

      - `task-logs/jobAnalytics.log.3`

      - `task-logs/jobAnalytics.log.4`

      - `task-logs/jobAnalytics.log.5`

      - `task-logs/telemetry collection.log`

      - `task-logs/telemetry collection.log.1`

      - `task-logs/telemetry collection.log.2`

      - `task-logs/telemetry collection.log.3`

      - `task-logs/telemetry collection.log.4`

      - `task-logs/telemetry collection.log.5`

  * Thread dumps

      - `nodes/master/thread-dump.txt`

      - `nodes/slave/BoBo/thread-dump.txt`

      - `nodes/slave/PC Art/thread-dump.txt`

      - `nodes/slave/PC130/thread-dump.txt`

      - `nodes/slave/PC147/thread-dump.txt`

      - `nodes/slave/PC159/thread-dump.txt`

      - `nodes/slave/PC167/thread-dump.txt`

      - `nodes/slave/PC53/thread-dump.txt`

      - `nodes/slave/PC69/thread-dump.txt`

      - `nodes/slave/PC_Might/thread-dump.txt`

      - `nodes/slave/Slave/thread-dump.txt`

      - `nodes/slave/VRLAB-DC-01/thread-dump.txt`

      - `nodes/slave/VRLAB320/thread-dump.txt`

      - `nodes/slave/VRLAB901/thread-dump.txt`

      - `nodes/slave/dev_t/thread-dump.txt`

      - `nodes/slave/mickeyck/thread-dump.txt`

  * Update Center

      - `update-center.md`

  * User Count

      - `users/count.md`

  * Slow Request Records

  * Thread dumps on high CPU usage

  * Deadlock Records

  * Timing data about recently completed Pipeline builds

      - `nodes/master/pipeline-timings.txt`

  * Thread dumps of running Pipeline builds

      - `nodes/master/pipeline-thread-dump.txt`

