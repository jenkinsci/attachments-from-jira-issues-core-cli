User
====

Authentication
--------------

  * Authenticated: true
  * Name: bobo.sm
  * Authorities 
      - `authenticated`

