Active protocols
================

 * `Ping`: Ping protocol
    * Deprecated: false
    * Required: true
    * Opt In: false
 * `JNLP4-connect`: Inbound TCP Agent Protocol/4 (TLS encryption)
    * Deprecated: false
    * Required: false
    * Opt In: false

Inactive protocols
==================

