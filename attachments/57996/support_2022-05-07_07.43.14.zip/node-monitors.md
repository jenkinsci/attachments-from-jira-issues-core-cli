Node monitors
=============
Architecture
----
 - Is Ignored: false
 - Computers:
   * Built-In Node: Windows 10 (x86)
   * BoBo: null
   * PC Art: null
   * PC130: null
   * PC147: null
   * PC159: Windows 10 (x86)
   * PC167: null
   * PC53: null
   * PC69: null
   * PC_Might: null
   * Slave: Windows 10 (amd64)
   * VRLAB-DC-01: null
   * VRLAB320: null
   * VRLAB901: null
   * dev_t: null
   * mickeyck: null
Clock Difference
----
 - Is Ignored: false
 - Computers:
   * Built-In Node: In sync
   * BoBo: null
   * PC Art: null
   * PC130: null
   * PC147: null
   * PC159: 1.3 sec behind
   * PC167: null
   * PC53: null
   * PC69: null
   * PC_Might: null
   * Slave: In sync
   * VRLAB-DC-01: null
   * VRLAB320: null
   * VRLAB901: null
   * dev_t: null
   * mickeyck: null
Free Disk Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * Built-In Node: 49.995GB left on C:\Program Files (x86)\Jenkins.
   * BoBo: null
   * PC Art: null
   * PC130: null
   * PC147: null
   * PC159: 452.031GB left on C:\PC159.
   * PC167: null
   * PC53: null
   * PC69: null
   * PC_Might: null
   * Slave: 295.807GB left on E:\Slave.
   * VRLAB-DC-01: null
   * VRLAB320: null
   * VRLAB901: null
   * dev_t: null
   * mickeyck: null
Free Swap Space
----
 - Is Ignored: false
 - Computers:
   * Built-In Node: Memory:24351/32703MB  Swap:28236/37567MB
   * BoBo: null
   * PC Art: null
   * PC130: null
   * PC147: null
   * PC159: Memory:24639/32698MB  Swap:28141/37562MB
   * PC167: null
   * PC53: null
   * PC69: null
   * PC_Might: null
   * Slave: Memory:24348/32703MB  Swap:28231/37567MB
   * VRLAB-DC-01: null
   * VRLAB320: null
   * VRLAB901: null
   * dev_t: null
   * mickeyck: null
Free Temp Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * Built-In Node: 49.995GB left on C:\Windows\Temp.
   * BoBo: null
   * PC Art: null
   * PC130: null
   * PC147: null
   * PC159: 452.031GB left on C:\Users\VRLAB341\AppData\Local\Temp.
   * PC167: null
   * PC53: null
   * PC69: null
   * PC_Might: null
   * Slave: 49.995GB left on C:\Users\T001\AppData\Local\Temp.
   * VRLAB-DC-01: null
   * VRLAB320: null
   * VRLAB901: null
   * dev_t: null
   * mickeyck: null
Response Time
----
 - Is Ignored: false
 - Computers:
   * Built-In Node: 0ms
   * BoBo: null
   * PC Art: null
   * PC130: null
   * PC147: null
   * PC159: 68ms
   * PC167: null
   * PC53: null
   * PC69: null
   * PC_Might: null
   * Slave: 65ms
   * VRLAB-DC-01: null
   * VRLAB320: null
   * VRLAB901: null
   * dev_t: null
   * mickeyck: null
