Jenkins
=======

Version details
---------------

  * Version: `2.319.2`
  * Instance ID: `b0fd81c8097493d4b226d414e9c17733`
  * Mode:    WAR
  * Url:     http://192.168.148.26:8080/
  * Servlet container
      - Specification: 3.1
      - Name:          `jetty/9.4.43.v20210629`
  * Java
      - Home:           `C:\Program Files (x86)\Jenkins\jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0&#95;144
      - Maximum memory:   989.88 MB (1037959168)
      - Allocated memory: 247.62 MB (259653632)
      - Free memory:      73.47 MB (77036592)
      - In-use memory:    174.16 MB (182617040)
      - GC strategy:      SerialGC
      - Available CPUs:   6
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    Java HotSpot(TM) Client VM
      - Vendor:  Oracle Corporation
      - Version: 25.144-b01
  * Operating system
      - Name:         Windows 10
      - Architecture: x86
      - Version:      10.0
  * Process ID: 5460 (0x1554)
  * Process started: 2022-05-07 07:41:23.311+0000
  * Process uptime: 1 min 51 sec
  * JVM startup parameters:
      - Boot classpath: `C:\Program Files (x86)\Jenkins\jre\lib\resources.jar;C:\Program Files (x86)\Jenkins\jre\lib\rt.jar;C:\Program Files (x86)\Jenkins\jre\lib\sunrsasign.jar;C:\Program Files (x86)\Jenkins\jre\lib\jsse.jar;C:\Program Files (x86)\Jenkins\jre\lib\jce.jar;C:\Program Files (x86)\Jenkins\jre\lib\charsets.jar;C:\Program Files (x86)\Jenkins\jre\lib\jfr.jar;C:\Program Files (x86)\Jenkins\jre\classes`
      - Classpath: `C:\Program Files (x86)\Jenkins\jenkins.war`
      - Library path: `C:\Program Files (x86)\Jenkins\jre\bin;C:\WINDOWS\Sun\Java\bin;C:\WINDOWS\system32;C:\WINDOWS;C:\Program Files (x86)\SCE\ORBIS\Tools\Publishing Tools\bin;M:\agent\PS4\SCE\ORBIS SDKs\7.000\host_tools\bin;C:\Program Files (x86)\SCE\Common\SceVSI-VS15\bin;C:\Program Files (x86)\SCE\ORBIS\Tools\Target Manager Server\bin;C:\Program Files\Oculus\Support\oculus-runtime;C:\Program Files (x86)\Common Files\Oracle\Java\javapath;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;C:\Program Files (x86)\NVIDIA Corporation\PhysX\Common;C:\WINDOWS\system32;C:\WINDOWS;C:\WINDOWS\System32\Wbem;C:\WINDOWS\System32\WindowsPowerShell\v1.0\;C:\WINDOWS\System32\OpenSSH\;C:\Program Files\Microsoft VS Code\bin;C:\Program Files (x86)\Windows Kits\10\Windows Performance Toolkit\;C:\Program Files (x86)\Windows Kits\10\Microsoft Application Virtualization\Sequencer\;C:\Program Files\dotnet\;C:\Program Files\Git LFS;C:\Program Files\nodejs\;C:\Program Files\Microsoft SQL Server\130\Tools\Binn\;C:\ProgramData\chocolatey\bin;C:\Program Files\Amazon\ECSCLI;C:\Program Files\Amazon\AWSCLI\bin\;C:\Program Files\k6\;C:\cygwin64\bin\;C:\WINDOWS\system32;C:\WINDOWS;C:\WINDOWS\System32\Wbem;C:\WINDOWS\System32\WindowsPowerShell\v1.0\;C:\WINDOWS\System32\OpenSSH\;C:\TDM-GCC-64\bin;C:\Program Files\Go\bin;C:\Program Files\Docker\Docker\resources\bin;C:\ProgramData\DockerDesktop\version-bin;C:\Program Files\Git\cmd;C:\WINDOWS\system32\config\systemprofile\AppData\Local\Microsoft\WindowsApps;.`
      - arg[0]: `-Xms256m`
      - arg[1]: `-Xmx1024m`
      - arg[2]: `-Xss4m`
      - arg[3]: `-Dhudson.lifecycle=hudson.lifecycle.WindowsServiceLifecycle`
      - arg[4]: `-Dfile.encoding=UTF-8`
      - arg[5]: `-Dpermissive-script-security.enabled=true`

Remoting details
---------------

  * Embedded Version: `4.11.2`
  * Minimum Supported Version: `3.14`

Important configuration
---------------

  * Security realm: `hudson.security.HudsonPrivateSecurityRealm`
  * Authorization strategy: `hudson.security.FullControlOnceLoggedInAuthorizationStrategy`
  * CSRF Protection: true
  * Initialization Milestone: Completed initialization
  * Support bundle anonymization: false

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * amazon-ecr:1.6 *(update available)* 'Amazon ECR plugin'
  * ant:1.11 *(update available)* 'Ant Plugin'
  * antisamy-markup-formatter:2.1 *(update available)* 'OWASP Markup Formatter Plugin'
  * apache-httpcomponents-client-4-api:4.5.13-1.0 'Jenkins Apache HttpComponents Client 4.x API Plugin'
  * authentication-tokens:1.4 'Authentication Tokens API Plugin'
  * aws-credentials:1.29 *(update available)* 'CloudBees AWS Credentials Plugin'
  * aws-java-sdk:1.11.995 *(update available)* 'Amazon Web Services SDK'
  * blueocean:1.24.6 *(update available)* 'Blue Ocean'
  * blueocean-autofavorite:1.2.4 *(update available)* 'Autofavorite for Blue Ocean'
  * blueocean-bitbucket-pipeline:1.24.6 *(update available)* 'Bitbucket Pipeline for Blue Ocean'
  * blueocean-commons:1.24.7 *(update available)* 'Common API for Blue Ocean'
  * blueocean-config:1.24.6 *(update available)* 'Config API for Blue Ocean'
  * blueocean-core-js:1.24.7 *(update available)* 'Blue Ocean Core JS'
  * blueocean-dashboard:1.24.6 *(update available)* 'Dashboard for Blue Ocean'
  * blueocean-display-url:2.4.1 'Display URL for Blue Ocean'
  * blueocean-events:1.24.6 *(update available)* 'Events API for Blue Ocean'
  * blueocean-git-pipeline:1.24.6 *(update available)* 'Git Pipeline for Blue Ocean'
  * blueocean-github-pipeline:1.24.6 *(update available)* 'GitHub Pipeline for Blue Ocean'
  * blueocean-i18n:1.24.6 *(update available)* 'i18n for Blue Ocean'
  * blueocean-jira:1.24.6 *(update available)* 'JIRA Integration for Blue Ocean'
  * blueocean-jwt:1.24.6 *(update available)* 'JWT for Blue Ocean'
  * blueocean-personalization:1.24.6 *(update available)* 'Personalization for Blue Ocean'
  * blueocean-pipeline-api-impl:1.24.6 *(update available)* 'Pipeline implementation for Blue Ocean'
  * blueocean-pipeline-editor:1.24.6 *(update available)* 'Blue Ocean Pipeline Editor'
  * blueocean-pipeline-scm-api:1.24.6 *(update available)* 'Pipeline SCM API for Blue Ocean'
  * blueocean-rest:1.24.6 *(update available)* 'REST API for Blue Ocean'
  * blueocean-rest-impl:1.24.6 *(update available)* 'REST Implementation for Blue Ocean'
  * blueocean-web:1.24.6 *(update available)* 'Web for Blue Ocean'
  * bootstrap4-api:4.6.0-3 *(update available)* 'Bootstrap 4 API Plugin'
  * bouncycastle-api:2.20 *(update available)* 'bouncycastle API Plugin'
  * branch-api:2.6.4 *(update available)* 'Branch API Plugin'
  * build-blocker-plugin:1.7.7 *(update available)* 'Build Blocker Plugin'
  * build-timeout:1.20 'Build Timeout'
  * caffeine-api:2.9.1-23.v51c4e2c879c8 *(update available)* 'Caffeine API Plugin'
  * checks-api:1.7.0 *(update available)* 'Checks API plugin'
  * cloudbees-bitbucket-branch-source:2.9.8 *(update available)* 'Bitbucket Branch Source Plugin'
  * cloudbees-folder:6.15 *(update available)* 'Folders Plugin'
  * command-launcher:1.6 *(update available)* 'Command Agent Launcher Plugin'
  * config-file-provider:3.8.0 *(update available)* 'Config File Provider Plugin'
  * convert-to-pipeline:1.0 'Convert To Pipeline'
  * credentials:1087.1089.v2f1b_9a_b_040e4 'Credentials Plugin'
  * credentials-binding:1.24 *(update available)* 'Credentials Binding Plugin'
  * declarative-pipeline-migration-assistant:1.5.1 *(update available)* 'Declarative Pipeline Migration Assistant'
  * declarative-pipeline-migration-assistant-api:1.5.1 *(update available)* 'Declarative Pipeline Migration Assistant API'
  * display-url-api:2.3.4 *(update available)* 'Display URL API'
  * docker-commons:1.17 *(update available)* 'Docker Commons Plugin'
  * docker-java-api:3.1.5.2 *(update available)* 'Docker API Plugin'
  * docker-plugin:1.2.2 *(update available)* 'Docker plugin'
  * docker-workflow:1.26 *(update available)* 'Docker Pipeline'
  * durable-task:1.36 *(update available)* 'Durable Task Plugin'
  * echarts-api:5.1.0-2 *(update available)* 'ECharts API Plugin'
  * email-ext:2.82 *(update available)* 'Email Extension Plugin'
  * extended-choice-parameter:0.82 *(update available)* 'Extended Choice Parameter Plug-In'
  * external-monitor-job:1.7 *(update available)* 'External Monitor Job Type Plugin'
  * favorite:2.3.3 *(update available)* 'Favorite'
  * font-awesome-api:5.15.3-2 *(update available)* 'Font Awesome API Plugin'
  * generic-webhook-trigger:1.72 *(update available)* 'Generic Webhook Trigger Plugin'
  * git:4.7.1 *(update available)* 'Jenkins Git plugin'
  * git-client:3.7.1 *(update available)* 'Jenkins Git client plugin'
  * git-server:1.9 *(update available)* 'Jenkins GIT server Plugin'
  * github:1.33.1 *(update available)* 'GitHub plugin'
  * github-api:1.123 *(update available)* 'GitHub API Plugin'
  * github-branch-source:2.10.4 *(update available)* 'GitHub Branch Source Plugin'
  * gradle:1.36 *(update available)* 'Gradle Plugin'
  * handlebars:3.0.8 'JavaScript GUI Lib: Handlebars bundle plugin'
  * handy-uri-templates-2-api:2.1.8-1.0 *(update available)* 'Handy Uri Templates 2.x API Plugin'
  * htmlpublisher:1.25 *(update available)* 'HTML Publisher plugin'
  * http_request:1.9.0 *(update available)* 'HTTP Request Plugin'
  * jackson2-api:2.13.2.20220328-273.v11d70a_b_a_1a_52 'Jackson 2 API Plugin'
  * javadoc:1.6 *(update available)* 'Javadoc Plugin'
  * jdk-tool:1.5 'Oracle Java SE Development Kit Installer Plugin'
  * jenkins-design-language:1.24.7 *(update available)* 'Jenkins Design Language'
  * jenkins-discord:1.4.0 'Discord Notifier'
  * jira:3.3 *(update available)* 'Jenkins Jira plugin'
  * jjwt-api:0.11.2-9.c8b45b8bb173 *(update available)* 'Java JSON Web Token (JJWT) Plugin'
  * jquery:1.12.4-1 'jQuery plugin'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * jquery3-api:3.6.0-1 *(update available)* 'JQuery3 API Plugin'
  * jsch:0.1.55.2 'Jenkins JSch dependency plugin'
  * junit:1.49 *(update available)* 'JUnit Plugin'
  * kubernetes-cli:1.10.3 'Kubernetes CLI Plugin'
  * kubernetes-client-api:5.4.1 *(update available)* 'Kubernetes Client API Plugin'
  * kubernetes-credentials:0.9.0 'Kubernetes Credentials Plugin'
  * ldap:2.7 *(update available)* 'LDAP Plugin'
  * lockable-resources:2.10 *(update available)* 'Lockable Resources plugin'
  * mailer:1.34 *(update available)* 'Jenkins Mailer Plugin'
  * manage-permission:1.0.1 'Overall/Manage permission enabler plugin'
  * mapdb-api:1.0.9.0 'MapDB API Plugin'
  * matrix-auth:2.6.7 *(update available)* 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.18 *(update available)* 'Matrix Project Plugin'
  * mercurial:2.15 *(update available)* 'Jenkins Mercurial plugin'
  * metrics:4.1.6.1 'Metrics Plugin'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * nodelabelparameter:1.8.1 *(update available)* 'Node and Label parameter plugin'
  * okhttp-api:3.14.9 *(update available)* 'OkHttp Plugin'
  * pam-auth:1.6 *(update available)* 'PAM Authentication plugin'
  * permissive-script-security:0.6 *(update available)* 'Permissive Script Security Plugin'
  * pipeline-build-step:2.13 *(update available)* 'Pipeline: Build Step'
  * pipeline-github-lib:1.0 *(update available)* 'Pipeline: GitHub Groovy Libraries'
  * pipeline-graph-analysis:1.10 *(update available)* 'Pipeline Graph Analysis Plugin'
  * pipeline-input-step:2.12 *(update available)* 'Pipeline: Input Step'
  * pipeline-milestone-step:1.3.2 *(update available)* 'Pipeline: Milestone Step'
  * pipeline-model-api:1.8.4 *(update available)* 'Pipeline: Model API'
  * pipeline-model-definition:1.8.4 *(update available)* 'Pipeline: Declarative'
  * pipeline-model-extensions:1.8.4 *(update available)* 'Pipeline: Declarative Extension Points API'
  * pipeline-rest-api:2.19 *(update available)* 'Pipeline: REST API Plugin'
  * pipeline-stage-step:2.5 *(update available)* 'Pipeline: Stage Step'
  * pipeline-stage-tags-metadata:1.8.4 *(update available)* 'Pipeline: Stage Tags Metadata'
  * pipeline-stage-view:2.19 *(update available)* 'Pipeline: Stage View Plugin'
  * pipeline-utility-steps:2.7.1 *(update available)* 'Pipeline Utility Steps'
  * plain-credentials:1.7 *(update available)* 'Plain Credentials Plugin'
  * plugin-util-api:2.2.0 *(update available)* 'Plugin Utilities API Plugin'
  * popper-api:1.16.1-2 *(update available)* 'Popper.js API Plugin'
  * postbuild-task:1.9 'Post build task'
  * powershell:1.5 *(update available)* 'Jenkins PowerShell plugin'
  * pubsub-light:1.14 *(update available)* 'Jenkins Pub-Sub "light" Bus'
  * purge-build-queue-plugin:1.0 'Purge Build Queue Plugin'
  * resource-disposer:0.15 *(update available)* 'Resource Disposer Plugin'
  * rich-text-publisher-plugin:1.4 'Rich Text Publisher Plugin'
  * scm-api:2.6.4 *(update available)* 'SCM API Plugin'
  * script-security:1.77 *(update available)* 'Script Security Plugin'
  * scriptler:3.1 *(update available)* 'Scriptler'
  * simple-queue:1.4.1 'Simple Queue Plugin'
  * snakeyaml-api:1.30.1 'SnakeYAML API Plugin'
  * sse-gateway:1.24 *(update available)* 'Server Sent Events (SSE) Gateway Plugin'
  * ssh-credentials:1.18.1 *(update available)* 'SSH Credentials Plugin'
  * ssh-slaves:1.31.5 *(update available)* 'SSH Build Agents plugin'
  * sshd:3.0.3 *(update available)* 'SSH server'
  * structs:318.va_f3ccb_729b_71 'Structs Plugin'
  * subversion:2.14.1 *(update available)* 'Jenkins Subversion Plug-in'
  * support-core:2.80 'Support Core Plugin'
  * text-finder:1.16 *(update available)* 'Text Finder'
  * throttle-concurrents:2.2 *(update available)* 'Jenkins Throttle Concurrent Builds Plug-in'
  * timestamper:1.13 *(update available)* 'Timestamper'
  * token-macro:2.15 *(update available)* 'Token Macro Plugin'
  * translation:1.16 'Jenkins Translation Assistance plugin'
  * trilead-api:1.0.13 *(update available)* 'Trilead API Plugin'
  * uno-choice:2.5.6 *(update available)* 'Active Choices Plug-in'
  * variant:1.4 'Variant Plugin'
  * windows-slaves:1.8 'WMI Windows Agents Plugin'
  * workflow-aggregator:2.6 *(update available)* 'Pipeline'
  * workflow-api:2.42 *(update available)* 'Pipeline: API'
  * workflow-basic-steps:2.23 *(update available)* 'Pipeline: Basic Steps'
  * workflow-cps:2.92 *(update available)* 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.19 *(update available)* 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.39 *(update available)* 'Pipeline: Nodes and Processes'
  * workflow-job:2.40 *(update available)* 'Pipeline: Job'
  * workflow-multibranch:2.24 *(update available)* 'Pipeline: Multibranch'
  * workflow-scm-step:2.12 *(update available)* 'Pipeline: SCM Step'
  * workflow-step-api:2.23 *(update available)* 'Pipeline: Step API'
  * workflow-support:3.8 *(update available)* 'Pipeline: Supporting APIs'
  * ws-cleanup:0.39 *(update available)* 'Jenkins Workspace Cleanup Plugin'
