 * Name Software Loopback Interface 1
 ** Index - 1
 ** InetAddress - /127.0.0.1
 ** InetAddress - /0:0:0:0:0:0:0:1
 ** MTU - -1
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name Bluetooth Device (Personal Area Network)
 ** Hardware Address - e82a44c28ee8
 ** Index - 2
 ** InetAddress - /fe80:0:0:0:6c8e:983e:7a84:9b%eth0
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name Microsoft 6to4 Adapter
 ** Index - 3
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name WAN Miniport (PPPOE)
 ** Index - 4
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name Realtek 8822BE Wireless LAN 802.11ac PCI-E NIC
 ** Hardware Address - e82a44c28ee7
 ** Index - 5
 ** InetAddress - /fe80:0:0:0:1456:e265:19ae:d4a0%wlan0
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name WAN Miniport (IP)
 ** Index - 6
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name WAN Miniport (L2TP)
 ** Index - 7
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name Microsoft IP-HTTPS Platform Adapter
 ** Index - 8
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name Microsoft Wi-Fi Direct Virtual Adapter #2
 ** Hardware Address - fa2a44c28ee7
 ** Index - 9
 ** InetAddress - /fe80:0:0:0:b1d6:d7d4:b563:5259%wlan1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name Realtek 8822BE Wireless LAN 802.11ac PCI-E NIC-WFP Native MAC Layer LightWeight Filter-0000
 ** Index - 10
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name Intel(R) Ethernet Connection (2) I219-V
 ** Hardware Address - 2cfda1b95212
 ** Index - 11
 ** InetAddress - /192.168.148.26
 ** InetAddress - /fe80:0:0:0:9485:1a1e:e4fc:a6ee%eth2
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name WAN Miniport (Network Monitor)
 ** Index - 12
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name WAN Miniport (SSTP)
 ** Index - 13
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name Microsoft Wi-Fi Direct Virtual Adapter
 ** Hardware Address - ea2a44c28ee7
 ** Index - 14
 ** InetAddress - /fe80:0:0:0:b46e:9183:7b09:13f2%wlan3
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name Microsoft Teredo Tunneling Adapter
 ** Index - 15
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name Microsoft Kernel Debug Network Adapter
 ** Index - 16
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name WAN Miniport (IKEv2)
 ** Index - 17
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name WAN Miniport (PPTP)
 ** Index - 18
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name WAN Miniport (IPv6)
 ** Index - 19
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name Realtek 8822BE Wireless LAN 802.11ac PCI-E NIC-Virtual WiFi Filter Driver-0000
 ** Index - 20
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name Realtek 8822BE Wireless LAN 802.11ac PCI-E NIC-Native WiFi Filter Driver-0000
 ** Index - 21
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name Realtek 8822BE Wireless LAN 802.11ac PCI-E NIC-QoS Packet Scheduler-0000
 ** Index - 22
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name Realtek 8822BE Wireless LAN 802.11ac PCI-E NIC-WFP 802.3 MAC Layer LightWeight Filter-0000
 ** Index - 23
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name Hyper-V Virtual Switch Extension Adapter
 ** Index - 24
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name Intel(R) Ethernet Connection (2) I219-V-WFP Native MAC Layer LightWeight Filter-0000
 ** Index - 25
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name Intel(R) Ethernet Connection (2) I219-V-QoS Packet Scheduler-0000
 ** Index - 26
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name Intel(R) Ethernet Connection (2) I219-V-WFP 802.3 MAC Layer LightWeight Filter-0000
 ** Index - 27
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name Microsoft Wi-Fi Direct Virtual Adapter-WFP Native MAC Layer LightWeight Filter-0000
 ** Index - 28
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name Microsoft Wi-Fi Direct Virtual Adapter-Native WiFi Filter Driver-0000
 ** Index - 29
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name Microsoft Wi-Fi Direct Virtual Adapter-QoS Packet Scheduler-0000
 ** Index - 30
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name Microsoft Wi-Fi Direct Virtual Adapter-WFP 802.3 MAC Layer LightWeight Filter-0000
 ** Index - 31
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name Hyper-V Virtual Switch Extension Adapter-Hyper-V Virtual Switch Extension Filter-0000
 ** Index - 32
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name WAN Miniport (IP)-WFP Native MAC Layer LightWeight Filter-0000
 ** Index - 33
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name WAN Miniport (IP)-QoS Packet Scheduler-0000
 ** Index - 34
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name WAN Miniport (IPv6)-WFP Native MAC Layer LightWeight Filter-0000
 ** Index - 35
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name WAN Miniport (IPv6)-QoS Packet Scheduler-0000
 ** Index - 36
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name Hyper-V Virtual Ethernet Adapter
 ** Hardware Address - 00155dba7e61
 ** Index - 37
 ** InetAddress - /172.29.112.1
 ** InetAddress - /fe80:0:0:0:907c:fc53:548b:2a62%eth15
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name WAN Miniport (Network Monitor)-WFP Native MAC Layer LightWeight Filter-0000
 ** Index - 38
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name WAN Miniport (Network Monitor)-QoS Packet Scheduler-0000
 ** Index - 39
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name Hyper-V Virtual Ethernet Adapter-WFP Native MAC Layer LightWeight Filter-0000
 ** Index - 40
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name Hyper-V Virtual Ethernet Adapter-QoS Packet Scheduler-0000
 ** Index - 41
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name Hyper-V Virtual Ethernet Adapter-WFP 802.3 MAC Layer LightWeight Filter-0000
 ** Index - 42
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name Microsoft Wi-Fi Direct Virtual Adapter #2-WFP Native MAC Layer LightWeight Filter-0000
 ** Index - 43
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name Microsoft Wi-Fi Direct Virtual Adapter #2-Native WiFi Filter Driver-0000
 ** Index - 44
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name Microsoft Wi-Fi Direct Virtual Adapter #2-QoS Packet Scheduler-0000
 ** Index - 45
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

 * Name Microsoft Wi-Fi Direct Virtual Adapter #2-WFP 802.3 MAC Layer LightWeight Filter-0000
 ** Index - 46
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
