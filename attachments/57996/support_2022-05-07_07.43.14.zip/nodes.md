Node statistics
===============

  * Total number of nodes
      - Sample size:        6
      - Average (mean):     15.999999999999998
      - Average (median):   16.0
      - Standard deviation: 1.7763568394002503E-15
      - Minimum:            16
      - Maximum:            16
      - 95th percentile:    16.0
      - 99th percentile:    16.0
  * Total number of nodes online
      - Sample size:        6
      - Average (mean):     3.0
      - Average (median):   3.0
      - Standard deviation: 0.0
      - Minimum:            3
      - Maximum:            3
      - 95th percentile:    3.0
      - 99th percentile:    3.0
  * Total number of executors
      - Sample size:        6
      - Average (mean):     36.0
      - Average (median):   36.0
      - Standard deviation: 0.0
      - Minimum:            36
      - Maximum:            36
      - 95th percentile:    36.0
      - 99th percentile:    36.0
  * Total number of executors in use
      - Sample size:        6
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the Jenkins controller's built-in node_
      - Executors:      20
      - FS root:        `C:\Program Files (x86)\Jenkins`
      - Labels:         master
      - Usage:          `NORMAL`
      - Slave Version:  4.11.2
      - Java
          + Home:           `C:\Program Files (x86)\Jenkins\jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0&#95;144
          + Maximum memory:   989.88 MB (1037959168)
          + Allocated memory: 247.62 MB (259653632)
          + Free memory:      65.39 MB (68568112)
          + In-use memory:    182.23 MB (191085520)
          + GC strategy:      SerialGC
          + Available CPUs:   6
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) Client VM
          + Vendor:  Oracle Corporation
          + Version: 25.144-b01
      - Operating system
          + Name:         Windows 10
          + Architecture: x86
          + Version:      10.0
      - Process ID: 5460 (0x1554)
      - Process started: 2022-05-07 07:41:23.311+0000
      - Process uptime: 1 min 51 sec
      - JVM startup parameters:
          + Boot classpath: `C:\Program Files (x86)\Jenkins\jre\lib\resources.jar;C:\Program Files (x86)\Jenkins\jre\lib\rt.jar;C:\Program Files (x86)\Jenkins\jre\lib\sunrsasign.jar;C:\Program Files (x86)\Jenkins\jre\lib\jsse.jar;C:\Program Files (x86)\Jenkins\jre\lib\jce.jar;C:\Program Files (x86)\Jenkins\jre\lib\charsets.jar;C:\Program Files (x86)\Jenkins\jre\lib\jfr.jar;C:\Program Files (x86)\Jenkins\jre\classes`
          + Classpath: `C:\Program Files (x86)\Jenkins\jenkins.war`
          + Library path: `C:\Program Files (x86)\Jenkins\jre\bin;C:\WINDOWS\Sun\Java\bin;C:\WINDOWS\system32;C:\WINDOWS;C:\Program Files (x86)\SCE\ORBIS\Tools\Publishing Tools\bin;M:\agent\PS4\SCE\ORBIS SDKs\7.000\host_tools\bin;C:\Program Files (x86)\SCE\Common\SceVSI-VS15\bin;C:\Program Files (x86)\SCE\ORBIS\Tools\Target Manager Server\bin;C:\Program Files\Oculus\Support\oculus-runtime;C:\Program Files (x86)\Common Files\Oracle\Java\javapath;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;C:\Program Files (x86)\NVIDIA Corporation\PhysX\Common;C:\WINDOWS\system32;C:\WINDOWS;C:\WINDOWS\System32\Wbem;C:\WINDOWS\System32\WindowsPowerShell\v1.0\;C:\WINDOWS\System32\OpenSSH\;C:\Program Files\Microsoft VS Code\bin;C:\Program Files (x86)\Windows Kits\10\Windows Performance Toolkit\;C:\Program Files (x86)\Windows Kits\10\Microsoft Application Virtualization\Sequencer\;C:\Program Files\dotnet\;C:\Program Files\Git LFS;C:\Program Files\nodejs\;C:\Program Files\Microsoft SQL Server\130\Tools\Binn\;C:\ProgramData\chocolatey\bin;C:\Program Files\Amazon\ECSCLI;C:\Program Files\Amazon\AWSCLI\bin\;C:\Program Files\k6\;C:\cygwin64\bin\;C:\WINDOWS\system32;C:\WINDOWS;C:\WINDOWS\System32\Wbem;C:\WINDOWS\System32\WindowsPowerShell\v1.0\;C:\WINDOWS\System32\OpenSSH\;C:\TDM-GCC-64\bin;C:\Program Files\Go\bin;C:\Program Files\Docker\Docker\resources\bin;C:\ProgramData\DockerDesktop\version-bin;C:\Program Files\Git\cmd;C:\WINDOWS\system32\config\systemprofile\AppData\Local\Microsoft\WindowsApps;.`
          + arg[0]: `-Xms256m`
          + arg[1]: `-Xmx1024m`
          + arg[2]: `-Xss4m`
          + arg[3]: `-Dhudson.lifecycle=hudson.lifecycle.WindowsServiceLifecycle`
          + arg[4]: `-Dfile.encoding=UTF-8`
          + arg[5]: `-Dpermissive-script-security.enabled=true`

  * `BoBo` (`hudson.slaves.DumbSlave`)
      - Description:    _BoBo computer with ip: 192.168.148.71_
      - Executors:      2
      - Remote FS root: `E:\JenkinAgentWorkspace`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - WebSocket:      false
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * `PC Art` (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      3
      - Remote FS root: `E:\`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - WebSocket:      false
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * `PC130` (`hudson.slaves.DumbSlave`)
      - Description:    _Tourist-Worker_
      - Executors:      5
      - Remote FS root: `D:/`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - WebSocket:      false
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * `PC147` (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      3
      - Remote FS root: `G:\PC147\`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - WebSocket:      false
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * `PC159` (`hudson.slaves.DumbSlave`)
      - Description:    _slave for in-house_
      - Executors:      6
      - Remote FS root: `C:\PC159`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - WebSocket:      false
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        4.11.2
      - Java
          + Home:           `C:\Program Files (x86)\Java\jre1.8.0_321`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0&#95;321
          + Maximum memory:   247.50 MB (259522560)
          + Allocated memory: 17.68 MB (18542592)
          + Free memory:      6.56 MB (6878904)
          + In-use memory:    11.12 MB (11663688)
          + GC strategy:      SerialGC
          + Available CPUs:   12
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) Client VM
          + Vendor:  Oracle Corporation
          + Version: 25.321-b07
      - Operating system
          + Name:         Windows 10
          + Architecture: x86
          + Version:      10.0
      - Process ID: 11980 (0x2ecc)
      - Process started: 2022-05-06 10:19:47.972+0000
      - Process uptime: 21 hr
      - JVM startup parameters:
          + Boot classpath: `C:\Program Files (x86)\Java\jre1.8.0_321\lib\resources.jar;C:\Program Files (x86)\Java\jre1.8.0_321\lib\rt.jar;C:\Program Files (x86)\Java\jre1.8.0_321\lib\sunrsasign.jar;C:\Program Files (x86)\Java\jre1.8.0_321\lib\jsse.jar;C:\Program Files (x86)\Java\jre1.8.0_321\lib\jce.jar;C:\Program Files (x86)\Java\jre1.8.0_321\lib\charsets.jar;C:\Program Files (x86)\Java\jre1.8.0_321\lib\jfr.jar;C:\Program Files (x86)\Java\jre1.8.0_321\classes`
          + Classpath: `agent.jar`
          + Library path: `C:\Program Files (x86)\Common Files\Oracle\Java\javapath;C:\WINDOWS\Sun\Java\bin;C:\WINDOWS\system32;C:\WINDOWS;C:\Program Files (x86)\SCE\Common\SceVSI-VS15\bin;M:\agent\PS4\SCE\ORBIS SDKs\7.000\host_tools\bin;C:\Program Files (x86)\SCE\ORBIS\Tools\Target Manager Server\bin;C:\Program Files (x86)\SCE\ORBIS\Tools\Publishing Tools\bin;C:\Program Files (x86)\Common Files\Oracle\Java\javapath;C:\Program Files (x86)\Common Files\Intel\Shared Libraries\redist\intel64\compiler;C:\Program Files\Oculus\Support\oculus-runtime;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;C:\Windows\System32\OpenSSH\;C:\Program Files\Git\cmd;C:\Program Files\TortoiseSVN\bin;C:\TDM-GCC-64\bin;C:\Program Files\Amazon\AWSCLI\bin\;C:\WINDOWS\system32;C:\WINDOWS;C:\WINDOWS\System32\Wbem;C:\WINDOWS\System32\WindowsPowerShell\v1.0\;C:\WINDOWS\System32\OpenSSH\;C:\Program Files\dotnet\;C:\Program Files\Go\bin;C:\Program Files\Docker\Docker\resources\bin;C:\ProgramData\DockerDesktop\version-bin;C:\NVPACK\android-sdk-windows\build-tools;C:\NVPACK\android-sdk-windows\extras\android\support;C:\NVPACK\android-sdk-windows\platform-tools;C:\NVPACK\android-sdk-windows\tools;C:\NVPACK\gradle-4.1\bin;C:\NVPACK\apache-ant-1.8.2\bin;C:\NVPACK\jdk1.8.0_77\bin;C:\NVPACK\android-sdk-windows\ndk\21.4.7075529;C:\Program Files\Arm\Mali Developer Tools\Mali Offline Compiler v6.4.0\;C:\Users\VRLAB341\AppData\Local\Microsoft\WindowsApps;C:\Users\VRLAB341\go\bin;C:\kubectl;C:\Users\VRLAB341\AppData\Local\Microsoft\WindowsApps;C:\Users\VRLAB341\.dotnet\tools;C:\Users\VRLAB341\AppData\Local\Programs\Microsoft VS Code\bin;C:\Users\VRLAB341\go\bin;C:\Program Files\Git\usr\bin;;.`

  * `PC167` (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      3
      - Remote FS root: `M:\agent`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - WebSocket:      false
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * `PC53` (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      5
      - Remote FS root: `D:\PC53`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - WebSocket:      false
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * `PC69` (`hudson.slaves.DumbSlave`)
      - Description:    _slave for in-house_
      - Executors:      6
      - Remote FS root: `F:\PC69`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - WebSocket:      false
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * `PC_Might` (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      3
      - Remote FS root: `D:\jenkins`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - WebSocket:      false
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * `Slave` (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      10
      - Remote FS root: `E:\Slave`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - WebSocket:      false
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        4.11.2
      - Java
          + Home:           `C:\Program Files\Java\jre1.8.0_241`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0&#95;241
          + Maximum memory:   7.10 GB (7621050368)
          + Allocated memory: 1.58 GB (1695547392)
          + Free memory:      1.50 GB (1611979376)
          + In-use memory:    79.70 MB (83568016)
          + GC strategy:      ParallelGC
          + Available CPUs:   6
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.241-b07
      - Operating system
          + Name:         Windows 10
          + Architecture: amd64
          + Version:      10.0
      - Process ID: 14724 (0x3984)
      - Process started: 2022-05-07 06:06:28.877+0000
      - Process uptime: 1 hr 36 min
      - JVM startup parameters:
          + Boot classpath: `C:\Program Files\Java\jre1.8.0_241\lib\resources.jar;C:\Program Files\Java\jre1.8.0_241\lib\rt.jar;C:\Program Files\Java\jre1.8.0_241\lib\sunrsasign.jar;C:\Program Files\Java\jre1.8.0_241\lib\jsse.jar;C:\Program Files\Java\jre1.8.0_241\lib\jce.jar;C:\Program Files\Java\jre1.8.0_241\lib\charsets.jar;C:\Program Files\Java\jre1.8.0_241\lib\jfr.jar;C:\Program Files\Java\jre1.8.0_241\classes`
          + Classpath: `agent.jar`
          + Library path: `C:\Program Files (x86)\Common Files\Oracle\Java\javapath;C:\WINDOWS\Sun\Java\bin;C:\WINDOWS\system32;C:\WINDOWS;C:\Program Files (x86)\SCE\ORBIS\Tools\Publishing Tools\bin;M:\agent\PS4\SCE\ORBIS SDKs\7.000\host_tools\bin;C:\Program Files (x86)\SCE\Common\SceVSI-VS15\bin;C:\Program Files (x86)\SCE\ORBIS\Tools\Target Manager Server\bin;C:\Program Files\Oculus\Support\oculus-runtime;C:\Program Files (x86)\Common Files\Oracle\Java\javapath;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;C:\Program Files (x86)\NVIDIA Corporation\PhysX\Common;C:\WINDOWS\system32;C:\WINDOWS;C:\WINDOWS\System32\Wbem;C:\WINDOWS\System32\WindowsPowerShell\v1.0\;C:\WINDOWS\System32\OpenSSH\;C:\Program Files\Microsoft VS Code\bin;C:\Program Files (x86)\Windows Kits\10\Windows Performance Toolkit\;C:\Program Files (x86)\Windows Kits\10\Microsoft Application Virtualization\Sequencer\;C:\Program Files\dotnet\;C:\Program Files\Git LFS;C:\Program Files\nodejs\;C:\Program Files\Microsoft SQL Server\130\Tools\Binn\;C:\ProgramData\chocolatey\bin;C:\Program Files\Amazon\ECSCLI;C:\Program Files\Amazon\AWSCLI\bin\;C:\Program Files\k6\;C:\cygwin64\bin\;C:\WINDOWS\system32;C:\WINDOWS;C:\WINDOWS\System32\Wbem;C:\WINDOWS\System32\WindowsPowerShell\v1.0\;C:\WINDOWS\System32\OpenSSH\;C:\TDM-GCC-64\bin;C:\Program Files\Go\bin;C:\Program Files\Docker\Docker\resources\bin;C:\ProgramData\DockerDesktop\version-bin;C:\Program Files\Git\cmd;C:\NVPACK\android-sdk-windows\build-tools;C:\NVPACK\android-sdk-windows\extras\android\support;C:\NVPACK\android-sdk-windows\platform-tools;C:\NVPACK\android-sdk-windows\tools;C:\NVPACK\gradle-4.1\bin;C:\NVPACK\apache-ant-1.8.2\bin;C:\NVPACK\jdk1.8.0_77\bin;C:\NVPACK\android-ndk-r14b;;C:\Users\T001\AppData\Local\Microsoft\WindowsApps;;C:\Users\T001\AppData\Local\Programs\Microsoft VS Code\bin;C:\Users\T001\go\bin;.`

  * `VRLAB-DC-01` (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      10
      - Remote FS root: `C:\Jenkins_VRLAB-DC-01`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - WebSocket:      false
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * `VRLAB320` (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      6
      - Remote FS root: `D:\VRLAB320`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - WebSocket:      false
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * `VRLAB901` (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      6
      - Remote FS root: `E:\VRLAB901\`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - WebSocket:      false
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * `dev_t` (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      3
      - Remote FS root: `D:/`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - WebSocket:      false
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * `mickeyck` (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      6
      - Remote FS root: `D:\mickeyck`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - WebSocket:      false
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

