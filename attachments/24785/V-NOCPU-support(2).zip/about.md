Jenkins
=======

Version details
---------------

  * Version: `1.509.4`
  * Mode:    WAR
  * Servlet container
      - Specification: 2.5
      - Name:          `Winstone Servlet Engine v0.9.10`
  * Java
      - Home:           `E:\Java\jdk1.6.0_39\jre`
      - Vendor:           Sun Microsystems Inc.
      - Version:          1.6.0_39
      - Maximum memory:   251.25 MB (263454720)
      - Allocated memory: 251.25 MB (263454720)
      - Free memory:      48.77 MB (51138816)
      - In-use memory:    202.48 MB (212315904)
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Sun Microsystems Inc.
      - Version: 1.6
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Sun Microsystems Inc.
      - Version: 1.0
  * JVM Implementation
      - Name:    Java HotSpot(TM) Server VM
      - Vendor:  Sun Microsystems Inc.
      - Version: 20.14-b01
  * Operating system
      - Name:         Windows Server 2008 R2
      - Architecture: x86
      - Version:      6.1
  * Process ID: 5580 (0x15cc)
  * Process started: 2013-12-11 11:03:56.758-0500
  * Process uptime: 50 min
  * JVM startup parameters:
      - Boot classpath: `E:\Java\jdk1.6.0_39\jre\lib\resources.jar;E:\Java\jdk1.6.0_39\jre\lib\rt.jar;E:\Java\jdk1.6.0_39\jre\lib\sunrsasign.jar;E:\Java\jdk1.6.0_39\jre\lib\jsse.jar;E:\Java\jdk1.6.0_39\jre\lib\jce.jar;E:\Java\jdk1.6.0_39\jre\lib\charsets.jar;E:\Java\jdk1.6.0_39\jre\lib\modules\jdk.boot.jar;E:\Java\jdk1.6.0_39\jre\classes`
      - Classpath: `E:\Jenkins\jenkins.war`
      - Library path: `E:\Java\jdk1.6.0_39\bin;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;C:\Program Files\System Center Operations Manager 2007\;E:\Java\jdk1.6.0_39\bin;E:\AccuRev\601\bin;E:\BuildTools\cygwin-1.7.17\bin;.`
      - arg[0]: `-Dcom.sun.management.jmxremote.authenticate=false`
      - arg[1]: `-Dcom.sun.management.jmxremote.port=1101`
      - arg[2]: `-Dcom.sun.management.jmxremote.ssl=false`
      - arg[3]: `-Xrs`
      - arg[4]: `-Xms256m`
      - arg[5]: `-Xmx256m`
      - arg[6]: `-XX:MaxPermSize=128m`
      - arg[7]: `-XX:+HeapDumpOnOutOfMemoryError`
      - arg[8]: `-Xloggc:E:\Jenkins/verbosegc.log`
      - arg[9]: `-XX:+UseGCLogFileRotation`
      - arg[10]: `-XX:NumberOfGCLogFiles=3`
      - arg[11]: `-XX:GCLogFileSize=5M`
      - arg[12]: `-XX:+PrintGCDetails`
      - arg[13]: `-XX:+PrintGCDateStamps`
      - arg[14]: `-XX:-TraceClassUnloading`
      - arg[15]: `-Dorg.kohsuke.stapler.compression.CompressionFilter.disabled=true`
      - arg[16]: `-Dhudson.DNSMultiCast.disabled=true`
      - arg[17]: `-Dhudson.model.DownloadService.never=true`
      - arg[18]: `-Dhudson.model.UpdateCenter.never=true`
      - arg[19]: `-Dhudson.security.ExtendedReadPermission=true`
      - arg[20]: `-Dhudson.Util.noSymLink=true`
      - arg[21]: `-Djava.io.tmpdir=E:\TEMP`
      - arg[22]: `-Dhudson.lifecycle=hudson.lifecycle.WindowsServiceLifecycle`


Important configuration
---------------

  * Security realm: LDAP
  * Authorization strategy: Role-Based Strategy

Active Plugins
--------------

  * accurev:0.6.18 'Jenkins Accurev plugin'
  * active-directory:1.33 'Jenkins Active Directory plugin'
  * ant:1.1 'ant'
  * any-buildstep:0.1 'Any Build Step Plugin'
  * build-failure-analyzer:1.5.1 'Build Failure Analyzer'
  * build-name-setter:1.3 'build-name-setter'
  * build-user-vars-plugin:1.1 'Jenkins user build vars plugin'
  * buildtriggerbadge:1.1 'Build Trigger Badge Plugin'
  * bulk-builder:1.5 'Bulk Builder'
  * compact-columns:1.10 'Compact Columns'
  * conditional-buildstep:1.3.3 'conditional-buildstep'
  * config-autorefresh-plugin:1.0 'Config AutoRefresh Plugin'
  * configurationslicing:1.38.3 'Configuration Slicing plugin'
  * credentials:1.9.3 'Credentials Plugin'
  * cron_column:1.003 'Hudson Cron Column Plugin'
  * disk-usage:0.23 'Jenkins disk-usage plugin'
  * email-ext:2.36 'Jenkins Email Extension Plugin'
  * envinject:1.89 'Environment Injector Plugin'
  * external-monitor-job:1.1 'External Monitor Job Type Plugin'
  * extra-columns:1.12 'Extra Columns Plugin'
  * flexible-publish:0.12 'Flexible Publish Plugin'
  * git:2.0 'Jenkins GIT plugin'
  * git-client:1.4.6 'Jenkins GIT client plugin'
  * global-build-stats:1.3 'Hudson global-build-stats plugin'
  * groovy:1.14 'Hudson Groovy builder'
  * hp-application-automation-tools-plugin:1.0.2 'HP Application Automation Tools'
  * javadoc:1.0 'javadoc'
  * jobConfigHistory:2.5 'Jenkins Job Configuration History Plugin'
  * ldap:1.6 'LDAP Plugin'
  * log-parser:1.0.8 'Log Parser Plugin'
  * mailer:1.6 'Jenkins Mailer Plugin'
  * maven-plugin:1.509.4 'Maven Integration plugin'
  * monitoring:1.48.0 'Monitoring'
  * next-executions:1.0.5 'next-executions'
  * parameterized-trigger:2.21 'Jenkins Parameterized Trigger plugin'
  * postbuild-task:1.8 'Hudson Post build task'
  * powershell:1.2 'Hudson PowerShell plugin'
  * PrioritySorter:1.3 'Priority Sorter'
  * publish-over-ssh:1.10 'Publish Over SSH'
  * rebuild:1.20 'Rebuilder'
  * role-strategy:1.1.3 'Role-based Authorization Strategy'
  * run-condition:1.0 'Run Condition Plugin'
  * scm-api:0.2 'SCM API Plugin'
  * show-build-parameters:1.0 'Show Build Parameters plugin'
  * sidebar-link:1.6 'Sidebar Link'
  * ssh-credentials:1.6 'SSH Credentials Plugin'
  * ssh-slaves:1.5 'Jenkins SSH Slaves plugin'
  * support-core:1.6 'Support Core Plugin'
  * throttle-concurrents:1.8.1 'Jenkins Throttle Concurrent Builds Plug-in'
  * timestamper:1.5.7 'Timestamper'
  * tmpcleaner:1.1 'Jenkins java.io.tmpdir cleaner plugin'
  * token-macro:1.9 'Token Macro Plugin'
  * versioncolumn:0.2 'Jenkins Version Column plugin'
  * view-job-filters:1.26 'View Job Filters'
  * was-builder:1.6.1 'WAS Builder Plugin'
  * ws-cleanup:0.19 'Jenkins Workspace Cleanup Plugin'

Node statistics
---------------

  * Total number of nodes
      - Sample size:        200
      - Average:            3.0
      - Standard deviation: 0.0
      - Minimum:            3.0
      - Maximum:            3.0
      - 95th percentile:    3.0
      - 99th percentile:    3.0
  * Total number of nodes online
      - Sample size:        200
      - Average:            2.99
      - Standard deviation: 0.14142135623730953
      - Minimum:            1.0
      - Maximum:            3.0
      - 95th percentile:    3.0
      - 99th percentile:    3.0
  * Total number of executors
      - Sample size:        200
      - Average:            6.99
      - Standard deviation: 0.1414213562373094
      - Minimum:            5.0
      - Maximum:            7.0
      - 95th percentile:    7.0
      - 99th percentile:    7.0
  * Total number of executors in use
      - Sample size:        200
      - Average:            0.405
      - Standard deviation: 0.6952639497334773
      - Minimum:            0.0
      - Maximum:            4.0
      - 95th percentile:    2.0
      - 99th percentile:    2.990000000000009


Job statistics
--------------

  * All jobs
      - Number of jobs: 878
      - Number of builds per job: 1.9612756264236901 [n=878, s=4.7]
  * Jobs that `Build a maven2/3 project`
      - Number of jobs: 0
      - Number of builds per job: N/A
  * Jobs that `Build multi-configuration project`
      - Number of jobs: 6
      - Number of builds per job: 4.5 [n=6, s=1.0]
  * Jobs that `Monitor an external job`
      - Number of jobs: 0
      - Number of builds per job: N/A
  * Jobs that `Build a free-style software project`
      - Number of jobs: 866
      - Number of builds per job: 1.9237875288683604 [n=866, s=4.7]

Container statistics
--------------------

  * All containers
      - Number of containers: 6
      - Number of items per container: 1.0 [n=6, s=0.0]
  * Container type: `Build a maven2/3 project`
      - Number of containers: 0
      - Number of items per container: N/A
  * Container type: `Build multi-configuration project`
      - Number of containers: 6
      - Number of items per container: 1.0 [n=6, s=0.0]
