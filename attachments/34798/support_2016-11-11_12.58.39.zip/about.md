Jenkins
=======

Version details
---------------

  * Version: `2.27`
  * Mode:    WAR
  * Url:     http://szhm25662:8080/
  * Servlet container
      - Specification: 3.1
      - Name:          `jetty/9.2.z-SNAPSHOT`
  * Java
      - Home:           `D:\Software\Jenkins\jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0_66
      - Maximum memory:   247.50 MB (259522560)
      - Allocated memory: 130.34 MB (136675328)
      - Free memory:      25.94 MB (27202576)
      - In-use memory:    104.40 MB (109472752)
      - GC strategy:      SerialGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    Java HotSpot(TM) Client VM
      - Vendor:  Oracle Corporation
      - Version: 25.66-b18
  * Operating system
      - Name:         Windows Server 2012 R2
      - Architecture: x86
      - Version:      6.3
  * Process ID: 3968 (0xf80)
  * Process started: 2016-11-09 09:49:21.025+0100
  * Process uptime: 2 Tage 4 Stunden
  * JVM startup parameters:
      - Boot classpath: `D:\Software\Jenkins\jre\lib\resources.jar;D:\Software\Jenkins\jre\lib\rt.jar;D:\Software\Jenkins\jre\lib\sunrsasign.jar;D:\Software\Jenkins\jre\lib\jsse.jar;D:\Software\Jenkins\jre\lib\jce.jar;D:\Software\Jenkins\jre\lib\charsets.jar;D:\Software\Jenkins\jre\lib\jfr.jar;D:\Software\Jenkins\jre\classes`
      - Classpath: `D:\Software\Jenkins\jenkins.war`
      - Library path: `D:\Software\Jenkins\jre\bin;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;.`
      - arg[0]: `-Xrs`
      - arg[1]: `-Xmx256m`
      - arg[2]: `-Dhudson.lifecycle=hudson.lifecycle.WindowsServiceLifecycle`

Important configuration
---------------

  * Security realm: `hudson.plugins.active_directory.ActiveDirectorySecurityRealm`
  * Authorization strategy: `hudson.security.ProjectMatrixAuthorizationStrategy`
  * CSRF Protection: false

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * active-directory:2.0 'Jenkins Active Directory plugin'
  * analysis-core:1.79 'Static Analysis Utilities'
  * ant:1.4 'Ant Plugin'
  * antisamy-markup-formatter:1.5 'OWASP Markup Formatter Plugin'
  * bouncycastle-api:2.16.0 'bouncycastle API Plugin'
  * branch-api:1.11.1 'Branch API Plugin'
  * categorized-view:1.8 'categorized-view'
  * chucknorris:1.0 'ChuckNorris Plugin'
  * cloudbees-folder:5.13 'Folders Plugin'
  * conditional-buildstep:1.3.5 'Conditional BuildStep'
  * copyartifact:1.38.1 'Copy Artifact Plugin'
  * credentials:2.1.8 'Credentials Plugin'
  * cvs:2.12 'Jenkins CVS Plug-in'
  * display-url-api:0.5 'Display URL API'
  * durable-task:1.12 'Durable Task Plugin'
  * external-monitor-job:1.6 'External Monitor Job Type Plugin'
  * git:3.0.0 'Jenkins Git plugin'
  * git-client:2.1.0 'Jenkins Git client plugin'
  * git-server:1.7 'Jenkins GIT server Plugin'
  * github:1.22.4 'GitHub plugin'
  * github-api:1.79 'GitHub API Plugin'
  * github-branch-source:1.10 'GitHub Branch Source Plugin'
  * github-organization-folder:1.5 'GitHub Organization Folder Plugin'
  * global-variable-string-parameter:1.2 'Global Variable String Parameter'
  * handlebars:1.1.1 'JavaScript GUI Lib: Handlebars bundle plugin'
  * htmlpublisher:1.11 'HTML Publisher plugin'
  * icon-shim:2.0.3 'Icon Shim Plugin'
  * image-gallery:1.4 'Image Gallery Plug-in'
  * jackson2-api:2.7.3 'Jackson 2 API Plugin'
  * javadoc:1.4 'Javadoc Plugin'
  * jobConfigHistory:2.15 'Jenkins Job Configuration History Plugin'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * junit:1.19 'JUnit Plugin'
  * ldap:1.13 'LDAP Plugin'
  * mailer:1.18 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.9.0 'MapDB API Plugin'
  * mask-passwords:2.8 'Mask Passwords Plugin'
  * matrix-auth:1.4 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.7.1 'Matrix Project Plugin'
  * maven-plugin:2.14 'Maven Integration plugin'
  * metrics:3.1.2.9 'Metrics Plugin'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * msbuild:1.26 'Jenkins MSBuild Plugin'
  * nunit:0.18 'Jenkins NUnit plugin'
  * pam-auth:1.3 'PAM Authentication plugin'
  * parameterized-trigger:2.32 'Jenkins Parameterized Trigger plugin'
  * periodicbackup:1.3 'Periodic Backup'
  * pipeline-build-step:2.3 'Pipeline: Build Step'
  * pipeline-graph-analysis:1.2 'Pipeline Graph Analysis Plugin'
  * pipeline-input-step:2.3 *(update available)* 'Pipeline: Input Step'
  * pipeline-milestone-step:1.1 'Pipeline: Milestone Step'
  * pipeline-rest-api:2.2 'Pipeline: REST API Plugin'
  * pipeline-stage-step:2.2 'Pipeline: Stage Step'
  * pipeline-stage-view:2.2 'Pipeline: Stage View Plugin'
  * plain-credentials:1.3 'Plain Credentials Plugin'
  * role-strategy:2.3.2 'Role-based Authorization Strategy'
  * run-condition:1.0 'Run Condition Plugin'
  * scm-api:1.3 'SCM API Plugin'
  * script-security:1.24 'Script Security Plugin'
  * ssh-credentials:1.12 'SSH Credentials Plugin'
  * ssh-slaves:1.11 'Jenkins SSH Slaves plugin'
  * structs:1.5 'Structs Plugin'
  * subversion:2.7.1 'Jenkins Subversion Plug-in'
  * summary_report:1.15 'Summary Display Plugin'
  * support-core:2.33 'Support Core Plugin'
  * token-macro:2.0 'Token Macro Plugin'
  * translation:1.15 'Jenkins Translation Assistance plugin'
  * warnings:4.57 'Warnings Plug-in'
  * windows-slaves:1.2 'Windows Slaves Plugin'
  * workflow-aggregator:2.4 'Pipeline'
  * workflow-api:2.6 'Pipeline: API'
  * workflow-basic-steps:2.3 'Pipeline: Basic Steps'
  * workflow-cps:2.23 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.4 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.5 'Pipeline: Nodes and Processes'
  * workflow-job:2.8 'Pipeline: Job'
  * workflow-multibranch:2.9 *(update available)* 'Pipeline: Multibranch'
  * workflow-scm-step:2.2 'Pipeline: SCM Step'
  * workflow-step-api:2.5 'Pipeline: Step API'
  * workflow-support:2.10 'Pipeline: Supporting APIs'
