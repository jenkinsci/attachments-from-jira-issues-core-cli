User
====

Authentication
--------------

  * Authenticated: true
  * Name: afsulm
  * Authorities 
      - `AFS-SBC2-RedlineViewerPK2-GS`
      - `AFS-GKZ-BuildServer-Admins-GS`
      - `AFS-GKZ-Admins-GS`
      - `AFS-IAPP-HTTP-GS`
      - `AFS-IAPP-FTP-GS`
      - `AFS-AFSD0631-Plotter-GS`
      - `AFS-DDPlus-Users-GS`
      - `ZRH-GPO-U-AFS-GS`
      - `AFS-SBC2-AskSamPK3-GS`
      - `AFS-SBC2-Sokrates-TimesheetPK2-GS`
      - `AFS-SBC2-AutoDesk-DWG-TrueViewPK5-GS`
      - `GEO-GeoServerNews`
      - `AFS-SBC2-AutoDesk-Design-ReviewPK8-GS`
      - `AFS-SBC2-mapUrgeschichtePK2-GS`
      - `SZH-SP-Intra-AFS-P-M`
      - `AFS-SBC2-USB-Mapping-GS`
      - `AFS-SBC2-IrfanviewPK8-GS`
      - `AFS-SBC2-SAPPK9-GS`
      - `AFS-SBC2-OpenScape-WebClientPK4-GS`
      - `AFS-SBC2-OfficePro-VisioStdPK4-GS`
      - `AFS-SBC2-Desktop-Users-GS`
      - `HBD-FAX-alle-MA`
      - `SZH-MSCRM-ReportingGroup-13-EI-LS`
      - `SZH-MSCRM-ReportingGroup-13-ED-LS`
      - `ZRH-SIBAP2-AppLockerMozilla-GS`
      - `ZRH-SIBAP2-AppLockerRare-GS`
      - `ZRH-SIBAP2-AppLockerGoogle-GS`
      - `AFS-Srv-FME-Data-Modify-GS`
      - `AFS-Srv-FME-Users-GS`
      - `AFS-Srv-FME-Admins-GS`
      - `AFS-ArcGIS-UrgeschichteDB-RW-GS`
      - `AFS-GIS-Kompetenzzentrum-GS`
      - `AFS-Fotoarchiv-C-GS`
      - `AFS-AGB-GS`
      - `HBD-Appl-AdobeProf`
      - `HBD-Appl-AdobeIllust`
      - `AFS-agsadmin-gkz-entw-GS`
      - `AFS-agsadmin-gkz-int-prod-GS`
      - `HBD-Exc-GLOBUS-SiZi-107-BookingAllowed`
      - `HBD-Appl-ABIS`
      - `HBD-TestraumRemote-GS`
      - `AFS-Plotter-AFSD0631-GS`
      - `AFS-Plotter-Globus-GS`
      - `HBD-Changemanagement-AVFach-GS`
      - `HBD-Augeo-MA-GS`
      - `AFS-TSUsers-GS`
      - `HBD-PKI-Secure-Email-GS`
      - `AFS-GKZ-GS`
      - `HBD-Appl-ArcGIS`
      - `HBD-Appl-ArcView`
      - `AFS-DTP-GS`
      - `HBD-DEV-GS`
      - `HBD-AFS-KPZ`
      - `AFS-GIS-Users-GS`
      - `HBD-AFS-Alle`
      - `AFS-RECLAM-GS`
      - `HBD-ABIS-GS`
      - `HBD-Users-GS`
      - `AFS-Users-GS`
      - `authenticated`
  * Raw: `org.acegisecurity.providers.rememberme.RememberMeAuthenticationToken@beeedfb7: Username: hudson.plugins.active_directory.ActiveDirectoryUserDetail@0: Username: afsulm; Password: [PROTECTED]; Enabled: true; AccountNonExpired: true; credentialsNonExpired: true; AccountNonLocked: true; Granted Authorities: AFS-SBC2-RedlineViewerPK2-GS, AFS-GKZ-BuildServer-Admins-GS, AFS-GKZ-Admins-GS, AFS-IAPP-HTTP-GS, AFS-IAPP-FTP-GS, AFS-AFSD0631-Plotter-GS, AFS-DDPlus-Users-GS, ZRH-GPO-U-AFS-GS, AFS-SBC2-AskSamPK3-GS, AFS-SBC2-Sokrates-TimesheetPK2-GS, AFS-SBC2-AutoDesk-DWG-TrueViewPK5-GS, GEO-GeoServerNews, AFS-SBC2-AutoDesk-Design-ReviewPK8-GS, AFS-SBC2-mapUrgeschichtePK2-GS, SZH-SP-Intra-AFS-P-M, AFS-SBC2-USB-Mapping-GS, AFS-SBC2-IrfanviewPK8-GS, AFS-SBC2-SAPPK9-GS, AFS-SBC2-OpenScape-WebClientPK4-GS, AFS-SBC2-OfficePro-VisioStdPK4-GS, AFS-SBC2-Desktop-Users-GS, HBD-FAX-alle-MA, SZH-MSCRM-ReportingGroup-13-EI-LS, SZH-MSCRM-ReportingGroup-13-ED-LS, ZRH-SIBAP2-AppLockerMozilla-GS, ZRH-SIBAP2-AppLockerRare-GS, ZRH-SIBAP2-AppLockerGoogle-GS, AFS-Srv-FME-Data-Modify-GS, AFS-Srv-FME-Users-GS, AFS-Srv-FME-Admins-GS, AFS-ArcGIS-UrgeschichteDB-RW-GS, AFS-GIS-Kompetenzzentrum-GS, AFS-Fotoarchiv-C-GS, AFS-AGB-GS, HBD-Appl-AdobeProf, HBD-Appl-AdobeIllust, AFS-agsadmin-gkz-entw-GS, AFS-agsadmin-gkz-int-prod-GS, HBD-Exc-GLOBUS-SiZi-107-BookingAllowed, HBD-Appl-ABIS, HBD-TestraumRemote-GS, AFS-Plotter-AFSD0631-GS, AFS-Plotter-Globus-GS, HBD-Changemanagement-AVFach-GS, HBD-Augeo-MA-GS, AFS-TSUsers-GS, HBD-PKI-Secure-Email-GS, AFS-GKZ-GS, HBD-Appl-ArcGIS, HBD-Appl-ArcView, AFS-DTP-GS, HBD-DEV-GS, HBD-AFS-KPZ, AFS-GIS-Users-GS, HBD-AFS-Alle, AFS-RECLAM-GS, HBD-ABIS-GS, HBD-Users-GS, AFS-Users-GS, authenticated: Username: afsulm; Password: [PROTECTED]; Enabled: true; AccountNonExpired: true; credentialsNonExpired: true; AccountNonLocked: true; Granted Authorities: AFS-SBC2-RedlineViewerPK2-GS, AFS-GKZ-BuildServer-Admins-GS, AFS-GKZ-Admins-GS, AFS-IAPP-HTTP-GS, AFS-IAPP-FTP-GS, AFS-AFSD0631-Plotter-GS, AFS-DDPlus-Users-GS, ZRH-GPO-U-AFS-GS, AFS-SBC2-AskSamPK3-GS, AFS-SBC2-Sokrates-TimesheetPK2-GS, AFS-SBC2-AutoDesk-DWG-TrueViewPK5-GS, GEO-GeoServerNews, AFS-SBC2-AutoDesk-Design-ReviewPK8-GS, AFS-SBC2-mapUrgeschichtePK2-GS, SZH-SP-Intra-AFS-P-M, AFS-SBC2-USB-Mapping-GS, AFS-SBC2-IrfanviewPK8-GS, AFS-SBC2-SAPPK9-GS, AFS-SBC2-OpenScape-WebClientPK4-GS, AFS-SBC2-OfficePro-VisioStdPK4-GS, AFS-SBC2-Desktop-Users-GS, HBD-FAX-alle-MA, SZH-MSCRM-ReportingGroup-13-EI-LS, SZH-MSCRM-ReportingGroup-13-ED-LS, ZRH-SIBAP2-AppLockerMozilla-GS, ZRH-SIBAP2-AppLockerRare-GS, ZRH-SIBAP2-AppLockerGoogle-GS, AFS-Srv-FME-Data-Modify-GS, AFS-Srv-FME-Users-GS, AFS-Srv-FME-Admins-GS, AFS-ArcGIS-UrgeschichteDB-RW-GS, AFS-GIS-Kompetenzzentrum-GS, AFS-Fotoarchiv-C-GS, AFS-AGB-GS, HBD-Appl-AdobeProf, HBD-Appl-AdobeIllust, AFS-agsadmin-gkz-entw-GS, AFS-agsadmin-gkz-int-prod-GS, HBD-Exc-GLOBUS-SiZi-107-BookingAllowed, HBD-Appl-ABIS, HBD-TestraumRemote-GS, AFS-Plotter-AFSD0631-GS, AFS-Plotter-Globus-GS, HBD-Changemanagement-AVFach-GS, HBD-Augeo-MA-GS, AFS-TSUsers-GS, HBD-PKI-Secure-Email-GS, AFS-GKZ-GS, HBD-Appl-ArcGIS, HBD-Appl-ArcView, AFS-DTP-GS, HBD-DEV-GS, HBD-AFS-KPZ, AFS-GIS-Users-GS, HBD-AFS-Alle, AFS-RECLAM-GS, HBD-ABIS-GS, HBD-Users-GS, AFS-Users-GS, authenticated; Password: [PROTECTED]; Authenticated: true; Details: org.acegisecurity.ui.WebAuthenticationDetails@957e: RemoteIpAddress: 10.82.51.88; SessionId: null; Granted Authorities: AFS-SBC2-RedlineViewerPK2-GS, AFS-GKZ-BuildServer-Admins-GS, AFS-GKZ-Admins-GS, AFS-IAPP-HTTP-GS, AFS-IAPP-FTP-GS, AFS-AFSD0631-Plotter-GS, AFS-DDPlus-Users-GS, ZRH-GPO-U-AFS-GS, AFS-SBC2-AskSamPK3-GS, AFS-SBC2-Sokrates-TimesheetPK2-GS, AFS-SBC2-AutoDesk-DWG-TrueViewPK5-GS, GEO-GeoServerNews, AFS-SBC2-AutoDesk-Design-ReviewPK8-GS, AFS-SBC2-mapUrgeschichtePK2-GS, SZH-SP-Intra-AFS-P-M, AFS-SBC2-USB-Mapping-GS, AFS-SBC2-IrfanviewPK8-GS, AFS-SBC2-SAPPK9-GS, AFS-SBC2-OpenScape-WebClientPK4-GS, AFS-SBC2-OfficePro-VisioStdPK4-GS, AFS-SBC2-Desktop-Users-GS, HBD-FAX-alle-MA, SZH-MSCRM-ReportingGroup-13-EI-LS, SZH-MSCRM-ReportingGroup-13-ED-LS, ZRH-SIBAP2-AppLockerMozilla-GS, ZRH-SIBAP2-AppLockerRare-GS, ZRH-SIBAP2-AppLockerGoogle-GS, AFS-Srv-FME-Data-Modify-GS, AFS-Srv-FME-Users-GS, AFS-Srv-FME-Admins-GS, AFS-ArcGIS-UrgeschichteDB-RW-GS, AFS-GIS-Kompetenzzentrum-GS, AFS-Fotoarchiv-C-GS, AFS-AGB-GS, HBD-Appl-AdobeProf, HBD-Appl-AdobeIllust, AFS-agsadmin-gkz-entw-GS, AFS-agsadmin-gkz-int-prod-GS, HBD-Exc-GLOBUS-SiZi-107-BookingAllowed, HBD-Appl-ABIS, HBD-TestraumRemote-GS, AFS-Plotter-AFSD0631-GS, AFS-Plotter-Globus-GS, HBD-Changemanagement-AVFach-GS, HBD-Augeo-MA-GS, AFS-TSUsers-GS, HBD-PKI-Secure-Email-GS, AFS-GKZ-GS, HBD-Appl-ArcGIS, HBD-Appl-ArcView, AFS-DTP-GS, HBD-DEV-GS, HBD-AFS-KPZ, AFS-GIS-Users-GS, HBD-AFS-Alle, AFS-RECLAM-GS, HBD-ABIS-GS, HBD-Users-GS, AFS-Users-GS, authenticated`

