pipelineJob( 'test-job' ) {
  displayName( 'test-job' )
  description( 'Test job' )

  definition {
    cpsScm {
      scriptPath( 'Jenkinsfile.groovy' )
      scm {
        git {
          remote {
            url( 'ssh://git@github.com/test/test-job.git' )
            credentials( 'jenkins-git' )
          }
          branch( 'refs/heads/master' )
          extensions {
            pruneBranches()
          }
        }
      }
    }
  }
}
