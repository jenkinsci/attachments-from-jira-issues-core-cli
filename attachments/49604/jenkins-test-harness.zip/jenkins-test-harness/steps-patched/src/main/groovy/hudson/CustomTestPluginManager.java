package hudson;

import java.io.IOException;
import java.util.logging.Logger;

import org.jvnet.hudson.test.TestPluginManager;

public class CustomTestPluginManager extends TestPluginManager {
  private static final Logger LOGGER = Logger.getLogger( CustomTestPluginManager.class.getName() );

  public CustomTestPluginManager() throws IOException {
    super();
  }

  // Skip loading all detached plugins as they conflict with our explicit build.gradle jenkinsPlugins dependencies
  @Override
  void considerDetachedPlugin( String shortName ) {
    LOGGER.fine( "Skipping load of detached plugin: " + shortName );
  }
}
