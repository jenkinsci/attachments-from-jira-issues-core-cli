package jenkins.testing

import com.google.common.util.concurrent.Uninterruptibles

import hudson.CustomTestPluginManager

import java.awt.*
import java.util.concurrent.TimeUnit
import java.util.logging.Level
import java.util.logging.Logger

import org.junit.runner.Description
import org.junit.runners.model.Statement
import org.jvnet.hudson.test.JenkinsRule

import javaposse.jobdsl.dsl.DslScriptLoader
import javaposse.jobdsl.plugin.JenkinsJobManagement

class TestJenkinsInstance {

  static void main( String... fileArgs ) {
    def files = Arrays.asList( fileArgs )

    JenkinsRule jenkinsRule = new JenkinsRule()
    jenkinsRule.timeout = 3600
    jenkinsRule.contextPath = '/jenkins'
    jenkinsRule.pluginManager = new CustomTestPluginManager()

    // Only print severe logs from Jenkins
    Logger.getLogger( '' ).handlers.each {
      it.level = Level.SEVERE
    }

    Statement statement = new Statement() {
      @Override
      void evaluate() throws Throwable {
        def plugins = jenkinsRule.pluginManager.plugins.collect { "${it.shortName}:${it.version}" }
        println( "Installed plugins: $plugins" )

        DslScriptLoader loader = new DslScriptLoader( new JenkinsJobManagement( System.out, [ : ], new File( '.' ) ) )

        files.each { file ->
          loader.runScript( new File( file ).getText( 'UTF-8' ) )
        }

        println "Test Jenkins is running, navigate to ${jenkinsRule.jenkins.getRootUrl()} to view expected deployment"

        if ( Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported( Desktop.Action.BROWSE ) ) {
          println 'Opening in browser...'
          Desktop.getDesktop().browse( new URI( jenkinsRule.jenkins.getRootUrl() ) )
        } else {
          println 'Browser not supported, not auto-opening'
        }

        println 'Test Jenkins instance running, press CTRL+C to stop...'

        Uninterruptibles.sleepUninterruptibly( 1, TimeUnit.HOURS )
      }
    }

    jenkinsRule.apply( statement, Description.createSuiteDescription( 'Test and View Job DSL Task' ) ).evaluate()
  }
}
