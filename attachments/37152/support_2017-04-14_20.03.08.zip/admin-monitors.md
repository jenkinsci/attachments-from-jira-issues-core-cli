Monitors
========

`jenkins.diagnostics.URICheckEncodingMonitor`
--------------
(active and enabled)

`jenkins.security.UpdateSiteWarningsMonitor`
--------------
(active and enabled)
