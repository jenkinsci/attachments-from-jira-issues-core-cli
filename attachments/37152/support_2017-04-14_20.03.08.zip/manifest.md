Support Bundle Manifest
=======================

Generated on 2017-04-14 20:03:08.338+0000

Requested components:

  * Master Log Recorders

      - `nodes/master/logs/all_2017-04-10_17.39.58.log`

      - `nodes/master/logs/all_2017-04-11_20.06.24.log`

      - `nodes/master/logs/all_2017-04-12_15.58.25.log`

      - `nodes/master/logs/all_2017-04-12_17.34.41.log`

      - `nodes/master/logs/all_2017-04-12_19.12.25.log`

      - `nodes/master/logs/all_2017-04-13_17.36.36.log`

      - `nodes/master/logs/all_2017-04-14_15.51.52.log`

      - `nodes/master/logs/all_2017-04-14_15.59.12.log`

      - `nodes/master/logs/all_memory_buffer.log`

      - `nodes/master/logs/jenkins.log`

      - `other-logs/health-checker.log`

  * Slave Log Recorders

      - `nodes/slave/CL7-DOCKER-A/jenkins.log`

      - `nodes/slave/CL7-DOCKER-A/logs/all_2017-04-11_16.45.40.log`

      - `nodes/slave/CL7-DOCKER-A/logs/all_2017-04-12_15.58.08.log`

      - `nodes/slave/CL7-DOCKER-A/logs/all_2017-04-12_17.34.40.log`

      - `nodes/slave/CL7-DOCKER-A/logs/all_2017-04-12_19.12.21.log`

      - `nodes/slave/CL7-DOCKER-A/logs/all_2017-04-14_15.51.39.log`

      - `nodes/slave/CL7-DOCKER-A/logs/all_2017-04-14_15.59.01.log`

      - `nodes/slave/CL7-DOCKER-A/logs/all_memory_buffer.log`

  * Garbage Collection Logs

  * Agents config files (Encrypted secrets are redacted)

      - `nodes/slave/CL7-DOCKER-A/config.xml`

  * Jenkins Global Configuration File (Encrypted secrets are redacted)

      - `jenkins-root-configuration-files/config.xml`

  * Other Jenkins Configuration Files (Encrypted secrets are redacted)

      - `jenkins-root-configuration-files/com.michelin.cio.hudson.plugins.maskpasswords.MaskPasswordsConfig.xml`

      - `jenkins-root-configuration-files/com.smartcodeltd.jenkinsci.plugins.buildmonitor.BuildMonitorView.xml`

      - `jenkins-root-configuration-files/com.sonyericsson.rebuild.RebuildDescriptor.xml`

      - `jenkins-root-configuration-files/com.synopsys.arc.jenkinsci.plugins.cygwinprocesskiller.CygwinKillerInstallation.xml`

      - `jenkins-root-configuration-files/cygwin-process-killer.xml`

      - `jenkins-root-configuration-files/envInject.xml`

      - `jenkins-root-configuration-files/envinject-plugin-configuration.xml`

      - `jenkins-root-configuration-files/github-plugin-configuration.xml`

      - `jenkins-root-configuration-files/hudson.maven.MavenModuleSet.xml`

      - `jenkins-root-configuration-files/hudson.model.UpdateCenter.xml`

      - `jenkins-root-configuration-files/hudson.plugins.ansicolor.AnsiColorBuildWrapper.xml`

      - `jenkins-root-configuration-files/hudson.plugins.copyartifact.TriggeredBuildSelector.xml`

      - `jenkins-root-configuration-files/hudson.plugins.git.GitSCM.xml`

      - `jenkins-root-configuration-files/hudson.plugins.git.GitTool.xml`

      - `jenkins-root-configuration-files/hudson.plugins.groovy.Groovy.xml`

      - `jenkins-root-configuration-files/hudson.plugins.ircbot.IrcPublisher.xml`

      - `jenkins-root-configuration-files/hudson.plugins.promoted_builds.GlobalBuildPromotedBuilds.xml`

      - `jenkins-root-configuration-files/hudson.plugins.s3.S3BucketPublisher.xml`

      - `jenkins-root-configuration-files/hudson.plugins.timestamper.TimestamperConfig.xml`

      - `jenkins-root-configuration-files/hudson.scm.CVSSCM.xml`

      - `jenkins-root-configuration-files/hudson.scm.SubversionSCM.xml`

      - `jenkins-root-configuration-files/hudson.tasks.Ant.xml`

      - `jenkins-root-configuration-files/hudson.tasks.Mailer.xml`

      - `jenkins-root-configuration-files/hudson.tasks.Maven.xml`

      - `jenkins-root-configuration-files/hudson.tasks.Shell.xml`

      - `jenkins-root-configuration-files/hudson.triggers.SCMTrigger.xml`

      - `jenkins-root-configuration-files/javaposse.jobdsl.plugin.ExecuteDslScripts.xml`

      - `jenkins-root-configuration-files/javaposse.jobdsl.plugin.GlobalJobDslSecurityConfiguration.xml`

      - `jenkins-root-configuration-files/jenkins.model.ArtifactManagerConfiguration.xml`

      - `jenkins-root-configuration-files/jenkins.model.DownloadSettings.xml`

      - `jenkins-root-configuration-files/jenkins.model.JenkinsLocationConfiguration.xml`

      - `jenkins-root-configuration-files/jenkins.mvn.GlobalMavenConfig.xml`

      - `jenkins-root-configuration-files/jenkins.security.QueueItemAuthenticatorConfiguration.xml`

      - `jenkins-root-configuration-files/jenkins.security.UpdateSiteWarningsConfiguration.xml`

      - `jenkins-root-configuration-files/nodeMonitors.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.conditionalbuildstep.singlestep.SingleConditionalBuilder.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.customviewtabs.CustomViewsTabBar.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.docker.commons.tools.DockerTool.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.gitclient.JGitApacheTool.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.gitclient.JGitTool.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.pipeline.modeldefinition.config.GlobalConfig.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.workflow.flow.FlowExecutionList.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.workflow.libs.GlobalLibraries.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.workflow.support.steps.StageStep.xml`

      - `jenkins-root-configuration-files/scriptApproval.xml`

      - `jenkins-root-configuration-files/support-core.xml`

  * About browser

      - `browser.md`

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `items.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `nodes/slave/CL7-DOCKER-A/checksums.md5`

      - `plugins/active.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * About user (basic authentication details only)

      - `user.md`

  * Administrative monitors

      - `admin-monitors.md`

  * Build queue

      - `buildqueue.md`

  * Dump slave export tables (could reveal some memory leaks)

      - `nodes/slave/CL7-DOCKER-A/exportTable.txt`

  * Environment variables

      - `nodes/master/environment.txt`

      - `nodes/slave/CL7-DOCKER-A/environment.txt`

  * File descriptors (Unix only)

      - `nodes/master/file-descriptors.txt`

      - `nodes/slave/CL7-DOCKER-A/file-descriptors.txt`

  * JVM process system metrics (Linux only)

      - `nodes/master/proc/meminfo.txt`

      - `nodes/master/proc/self/cmdline`

      - `nodes/master/proc/self/environ`

      - `nodes/master/proc/self/limits.txt`

      - `nodes/master/proc/self/status.txt`

      - `nodes/slave/CL7-DOCKER-A/proc/meminfo.txt`

      - `nodes/slave/CL7-DOCKER-A/proc/self/cmdline`

      - `nodes/slave/CL7-DOCKER-A/proc/self/environ`

      - `nodes/slave/CL7-DOCKER-A/proc/self/limits.txt`

      - `nodes/slave/CL7-DOCKER-A/proc/self/status.txt`

  * Load Statistics

      - `load-stats/label/CL7-DOCKER-A/gnuplot`

      - `load-stats/label/CL7-DOCKER-A/hour.csv`

      - `load-stats/label/CL7-DOCKER-A/min.csv`

      - `load-stats/label/CL7-DOCKER-A/sec10.csv`

      - `load-stats/label/master/gnuplot`

      - `load-stats/label/master/hour.csv`

      - `load-stats/label/master/min.csv`

      - `load-stats/label/master/sec10.csv`

      - `load-stats/no-label/gnuplot`

      - `load-stats/no-label/hour.csv`

      - `load-stats/no-label/min.csv`

      - `load-stats/no-label/sec10.csv`

      - `load-stats/overall/gnuplot`

      - `load-stats/overall/hour.csv`

      - `load-stats/overall/min.csv`

      - `load-stats/overall/sec10.csv`

  * All loggers currently enabled.

      - `loggers.md`

  * Metrics

      - `nodes/master/metrics.json`

      - `nodes/slave/CL7-DOCKER-A/metrics.json`

  * Networking Interface

      - `nodes/master/networkInterface.md`

      - `nodes/slave/CL7-DOCKER-A/networkInterface.md`

  * Node monitors

      - `node-monitors.md`

  * System configuration (Linux only)

      - `nodes/master/dmesg.txt`

      - `nodes/master/dmi.txt`

      - `nodes/master/proc/cpuinfo.txt`

      - `nodes/master/proc/mounts.txt`

      - `nodes/master/proc/swaps.txt`

      - `nodes/master/proc/system-uptime.txt`

      - `nodes/master/sysctl.txt`

      - `nodes/master/userid.txt`

      - `nodes/slave/CL7-DOCKER-A/dmesg.txt`

      - `nodes/slave/CL7-DOCKER-A/dmi.txt`

      - `nodes/slave/CL7-DOCKER-A/proc/cpuinfo.txt`

      - `nodes/slave/CL7-DOCKER-A/proc/mounts.txt`

      - `nodes/slave/CL7-DOCKER-A/proc/swaps.txt`

      - `nodes/slave/CL7-DOCKER-A/proc/system-uptime.txt`

      - `nodes/slave/CL7-DOCKER-A/sysctl.txt`

      - `nodes/slave/CL7-DOCKER-A/userid.txt`

  * System properties

      - `nodes/master/system.properties`

      - `nodes/slave/CL7-DOCKER-A/system.properties`

  * Update Center

      - `update-center.md`

  * Slow Request Records

      - `slow-requests/20170410-174044.267.txt`

      - `slow-requests/20170412-173206.334.txt`

      - `slow-requests/20170412-173526.281.txt`

      - `slow-requests/20170412-173532.285.txt`

      - `slow-requests/20170412-173629.286.txt`

      - `slow-requests/20170412-173635.284.txt`

      - `slow-requests/20170412-191313.759.txt`

      - `slow-requests/20170413-204049.751.txt`

      - `slow-requests/20170413-205010.752.txt`

      - `slow-requests/20170413-205028.751.txt`

      - `slow-requests/20170413-220001.757.txt`

      - `slow-requests/20170414-155240.350.txt`

      - `slow-requests/20170414-155240.351.txt`

      - `slow-requests/20170414-155957.024.txt`

  * Deadlock Records

  * Thread dumps of running Pipeline builds

      - `nodes/master/pipeline-thread-dump.txt`

  * Thread dumps

      - `nodes/master/thread-dump.txt`

      - `nodes/slave/CL7-DOCKER-A/thread-dump.txt`

