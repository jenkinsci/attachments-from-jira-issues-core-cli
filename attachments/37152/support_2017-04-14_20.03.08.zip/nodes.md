Node statistics
===============

  * Total number of nodes
      - Sample size:        973
      - Average (mean):     1.0
      - Average (median):   1.0
      - Standard deviation: 0.0
      - Minimum:            1
      - Maximum:            1
      - 95th percentile:    1.0
      - 99th percentile:    1.0
  * Total number of nodes online
      - Sample size:        973
      - Average (mean):     0.9999999999999998
      - Average (median):   1.0
      - Standard deviation: 2.2204460492503128E-16
      - Minimum:            0
      - Maximum:            1
      - 95th percentile:    1.0
      - 99th percentile:    1.0
  * Total number of executors
      - Sample size:        973
      - Average (mean):     12.000000000000002
      - Average (median):   12.0
      - Standard deviation: 1.7763568394002505E-15
      - Minimum:            0
      - Maximum:            12
      - 95th percentile:    12.0
      - 99th percentile:    12.0
  * Total number of executors in use
      - Sample size:        973
      - Average (mean):     1.0969017869859916E-87
      - Average (median):   0.0
      - Standard deviation: 3.311950765011448E-44
      - Minimum:            0
      - Maximum:            1
      - 95th percentile:    0.0
      - 99th percentile:    0.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      0
      - FS root:        `/var/lib/jenkins`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Slave Version:  3.7
      - Java
          + Home:           `/usr/lib/jvm/java-7-openjdk-amd64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_121
          + Maximum memory:   906.75 MB (950796288)
          + Allocated memory: 187.44 MB (196546560)
          + Free memory:      85.19 MB (89323032)
          + In-use memory:    102.26 MB (107223528)
          + PermGen used:     97.86 MB (102617384)
          + PermGen max:      166.00 MB (174063616)
          + GC strategy:      SerialGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.121-b00
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.13.0-110-generic
          + Distribution: Ubuntu 14.04.5 LTS
      - Process ID: 12942 (0x328e)
      - Process started: 2017-04-14 15:59:01.000+0000
      - Process uptime: 4 hr 4 min
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/resources.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/rt.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/jsse.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/jce.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/charsets.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/rhino.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/jfr.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/classes`
          + Classpath: `/usr/share/jenkins/jenkins.war`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`
          + arg[0]: `-Djava.awt.headless=true`
          + arg[1]: `-Dorg.apache.commons.jelly.tags.fmt.timeZone=America/Los_Angeles`

  * CL7-DOCKER-A (`hudson.slaves.DumbSlave`)
      - Description:    _CL7-DOCKER-A_
      - Executors:      12
      - Remote FS root: `/home/jenkins`
      - Labels:         CL7-DOCKER-A
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.7
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-1.b15.el7_2.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_111
          + Maximum memory:   910.62 MB (954859520)
          + Allocated memory: 58.00 MB (60817408)
          + Free memory:      46.23 MB (48470696)
          + In-use memory:    11.77 MB (12346712)
          + GC strategy:      SerialGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.111-b15
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-327.36.3.el7.x86_64
      - Process ID: 24870 (0x6126)
      - Process started: 2017-04-14 15:58:47.193+0000
      - Process uptime: 4 hr 3 min
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-1.b15.el7_2.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-1.b15.el7_2.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-1.b15.el7_2.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-1.b15.el7_2.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-1.b15.el7_2.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-1.b15.el7_2.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-1.b15.el7_2.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-1.b15.el7_2.x86_64/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

