User
====

Authentication
--------------

  * Authenticated: true
  * Name: sdonner@mozilla.com
  * Authorities 
      - `ROLE_CLOUDSERVICES_DEV_TEMP`
      - `ROLE_IRCCLOUD`
      - `ROLE_VCENTER_QA_SELENIUM`
      - `ROLE_VPN_TESTRAIL`
      - `ROLE_SECURITYWIKI`
      - `ROLE_STATSDASHBOARD`
      - `ROLE_CORP-VPN`
      - `vpn_webqa_docker`
      - `phonebook_access`
      - `SoftVisionWiki`
      - `ROLE_VPN_QA_VM`
      - `mptvpn`
      - `ROLE_VPN_SERVICES_QA_JENKINS`
      - `ROLE_INTRANETWIKI`
      - `IntranetWiki`
      - `ROLE_OKTA_MFA`
      - `ROLE_VPN_CORP`
      - `ROLE_VPN_DEFAULT`
      - `team_ffxios`
      - `ROLE_CLOUDSERVICES_DEV`
      - `ROLE_VPN_QA_MTV2`
      - `service_yammer`
      - `ROLE_B2G_OTORO`
      - `QAWiki`
      - `ROLE_VPN_MPT`
      - `ROLE_VPN_SHIELD_STAGE`
      - `ROLE_VPN_WEBQA`
      - `ROLE_VPN_SHIELD_PROD`
      - `SecurityWiki`
      - `svn_mozilla`
      - `ROLE_SOFTVISIONWIKI`
      - `ROLE_VPN_CLOUDOPS_JENKINS`
      - `ROLE_TABLEAU_USERS`
      - `ROLE_PHONEBOOK_ACCESS`
      - `StatsDashboard`
      - `vpn_default`
      - `ROLE_CRASHREPORTSRAWDUMPACCESS`
      - `team_services_qa`
      - `corp-vpn`
      - `cloudservices_dev_temp`
      - `vpn_services_qa_jenkins`
      - `ROLE_VPN_WEBQA_DOCKER`
      - `vpn_qa_mtv2`
      - `ROLE_TEAM_SERVICES_QA`
      - `vpn_shield_prod`
      - `ROLE_QA`
      - `ROLE_TEAM_MOCO`
      - `vpn_cloudops_jenkins`
      - `vpn_shield_stage`
      - `cloudservices_dev`
      - `vpn_testrail`
      - `ROLE_MPTVPN`
      - `ROLE_VPN_CLOUDOPS_WEBPAGETEST`
      - `vpn_qa_vm`
      - `vcenter_qa_selenium`
      - `ROLE_CRASHREPORTSADMIN`
      - `ROLE_TEAM_FFXIOS`
      - `CrashReportsRawDumpAccess`
      - `authenticated`
      - `vpn_corp`
      - `vpn_mpt`
      - `ROLE_SERVICE_YAMMER`
      - `vpn_webqa`
      - `CrashReportsAdmin`
      - `tableau_users`
      - `qa`
      - `team_moco`
      - `irccloud`
      - `ROLE_QAWIKI`
      - `ROLE_SVN_MOZILLA`
      - `b2g_otoro`
      - `okta_mfa`
      - `vpn_cloudops_webpagetest`
  * Raw: `org.acegisecurity.providers.UsernamePasswordAuthenticationToken@fb05b3a4: Username: org.acegisecurity.userdetails.ldap.LdapUserDetailsImpl@48f93172; Password: [PROTECTED]; Authenticated: true; Details: org.acegisecurity.ui.WebAuthenticationDetails@1de6: RemoteIpAddress: 63.245.214.169; SessionId: 14asxkur9xscphueapdfuz76; Granted Authorities: ROLE_CLOUDSERVICES_DEV_TEMP, ROLE_IRCCLOUD, ROLE_VCENTER_QA_SELENIUM, ROLE_VPN_TESTRAIL, ROLE_SECURITYWIKI, ROLE_STATSDASHBOARD, ROLE_CORP-VPN, vpn_webqa_docker, phonebook_access, SoftVisionWiki, ROLE_VPN_QA_VM, mptvpn, ROLE_VPN_SERVICES_QA_JENKINS, ROLE_INTRANETWIKI, IntranetWiki, ROLE_OKTA_MFA, ROLE_VPN_CORP, ROLE_VPN_DEFAULT, team_ffxios, ROLE_CLOUDSERVICES_DEV, ROLE_VPN_QA_MTV2, service_yammer, ROLE_B2G_OTORO, QAWiki, ROLE_VPN_MPT, ROLE_VPN_SHIELD_STAGE, ROLE_VPN_WEBQA, ROLE_VPN_SHIELD_PROD, SecurityWiki, svn_mozilla, ROLE_SOFTVISIONWIKI, ROLE_VPN_CLOUDOPS_JENKINS, ROLE_TABLEAU_USERS, ROLE_PHONEBOOK_ACCESS, StatsDashboard, vpn_default, ROLE_CRASHREPORTSRAWDUMPACCESS, team_services_qa, corp-vpn, cloudservices_dev_temp, vpn_services_qa_jenkins, ROLE_VPN_WEBQA_DOCKER, vpn_qa_mtv2, ROLE_TEAM_SERVICES_QA, vpn_shield_prod, ROLE_QA, ROLE_TEAM_MOCO, vpn_cloudops_jenkins, vpn_shield_stage, cloudservices_dev, vpn_testrail, ROLE_MPTVPN, ROLE_VPN_CLOUDOPS_WEBPAGETEST, vpn_qa_vm, vcenter_qa_selenium, ROLE_CRASHREPORTSADMIN, ROLE_TEAM_FFXIOS, CrashReportsRawDumpAccess, authenticated, vpn_corp, vpn_mpt, ROLE_SERVICE_YAMMER, vpn_webqa, CrashReportsAdmin, tableau_users, qa, team_moco, irccloud, ROLE_QAWIKI, ROLE_SVN_MOZILLA, b2g_otoro, okta_mfa, vpn_cloudops_webpagetest`

