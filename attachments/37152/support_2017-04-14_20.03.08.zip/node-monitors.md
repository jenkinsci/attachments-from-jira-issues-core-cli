Node monitors
=============
Architecture
----
 - Is Ignored: false
 - Computers:
   * master: Linux (amd64)
   * CL7-DOCKER-A: Linux (amd64)
Clock Difference
----
 - Is Ignored: false
 - Computers:
   * master: In sync
   * CL7-DOCKER-A: 1 min 9 sec behind
Free Disk Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 4.853GB left on /var/lib/jenkins.
   * CL7-DOCKER-A: Disk space is too low. Only 22.468GB left on /home/jenkins.
Free Swap Space
----
 - Is Ignored: false
 - Computers:
   * master: Memory:474/3748MB  Swap:0/0MB
   * CL7-DOCKER-A: Memory:796/3763MB  Swap:0/0MB
Free Temp Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 4.853GB left on /tmp.
   * CL7-DOCKER-A: Disk space is too low. Only 22.468GB left on /tmp.
Response Time
----
 - Is Ignored: false
 - Computers:
   * master: 0ms
   * CL7-DOCKER-A: 11ms
