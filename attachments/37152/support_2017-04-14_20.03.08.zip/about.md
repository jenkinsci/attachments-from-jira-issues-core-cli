Jenkins
=======

Version details
---------------

  * Version: `2.46.1`
  * Mode:    WAR
  * Url:     https://fx-test-jenkins-dev.stage.mozaws.net:8443/
  * Servlet container
      - Specification: 3.1
      - Name:          `jetty/9.2.z-SNAPSHOT`
  * Java
      - Home:           `/usr/lib/jvm/java-7-openjdk-amd64/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.7.0_121
      - Maximum memory:   906.75 MB (950796288)
      - Allocated memory: 187.44 MB (196546560)
      - Free memory:      87.51 MB (91762664)
      - In-use memory:    99.93 MB (104783896)
      - PermGen used:     97.86 MB (102617352)
      - PermGen max:      166.00 MB (174063616)
      - GC strategy:      SerialGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.7
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.7
  * JVM Implementation
      - Name:    OpenJDK 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 24.121-b00
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      3.13.0-110-generic
      - Distribution: Ubuntu 14.04.5 LTS
  * Process ID: 12942 (0x328e)
  * Process started: 2017-04-14 15:59:01.000+0000
  * Process uptime: 4 hr 4 min
  * JVM startup parameters:
      - Boot classpath: `/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/resources.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/rt.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/jsse.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/jce.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/charsets.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/rhino.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/jfr.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/classes`
      - Classpath: `/usr/share/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`
      - arg[0]: `-Djava.awt.headless=true`
      - arg[1]: `-Dorg.apache.commons.jelly.tags.fmt.timeZone=America/Los_Angeles`

Important configuration
---------------

  * Security realm: `hudson.security.LDAPSecurityRealm`
  * Authorization strategy: `hudson.security.GlobalMatrixAuthorizationStrategy`
  * CSRF Protection: false
  * Initialization Milestone: Completed initialization

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * ansicolor:0.5.0 'AnsiColor'
  * ant:1.4 'Ant Plugin'
  * antisamy-markup-formatter:1.5 'OWASP Markup Formatter Plugin'
  * authentication-tokens:1.3 'Authentication Tokens API Plugin'
  * aws-java-sdk:1.11.68.1 'Amazon Web Services SDK'
  * blueocean:1.0.1 'Blue Ocean'
  * blueocean-autofavorite:0.6 'blueocean-autofavorite'
  * blueocean-commons:1.0.1 'Common API for Blue Ocean'
  * blueocean-config:1.0.1 'Config API for Blue Ocean'
  * blueocean-dashboard:1.0.1 'Dashboard for Blue Ocean'
  * blueocean-display-url:2.0 'BlueOcean Display URL plugin'
  * blueocean-events:1.0.1 'Events API for Blue Ocean'
  * blueocean-git-pipeline:1.0.1 'Git Pipeline for Blue Ocean'
  * blueocean-github-pipeline:1.0.1 'GitHub Pipeline for Blue Ocean'
  * blueocean-i18n:1.0.1 'i18n for Blue Ocean'
  * blueocean-jwt:1.0.1 'JWT for Blue Ocean'
  * blueocean-personalization:1.0.1 'Personalization for Blue Ocean'
  * blueocean-pipeline-api-impl:1.0.1 'Pipeline REST API for Blue Ocean'
  * blueocean-pipeline-editor:0.2.0 'Blue Ocean Pipeline Editor'
  * blueocean-rest:1.0.1 'REST API for Blue Ocean'
  * blueocean-rest-impl:1.0.1 'REST Implementation for Blue Ocean'
  * blueocean-web:1.0.1 'Web for Blue Ocean'
  * bouncycastle-api:2.16.1 'bouncycastle API Plugin'
  * branch-api:2.0.8 'Branch API Plugin'
  * build-monitor-plugin:1.11+build.201701152243 'Build Monitor View'
  * buildresult-trigger:0.17 'Jenkins BuildResultTrigger Plug-in'
  * cloudbees-folder:6.0.3 'Folders Plugin'
  * conditional-buildstep:1.3.5 'Conditional BuildStep'
  * config-file-provider:2.15.7 'Config File Provider Plugin'
  * copyartifact:1.38.1 'Copy Artifact Plugin'
  * credentials:2.1.13 'Credentials Plugin'
  * credentials-binding:1.11 'Credentials Binding Plugin'
  * custom-view-tabs:1.3 'Custom View Tabs Plugin'
  * cvs:2.13 'Jenkins CVS Plug-in'
  * cygpath:1.5 'Jenkins Cygpath plugin'
  * cygwin-process-killer:0.1 'Cygwin Process Killer'
  * display-url-api:2.0 'Display URL API'
  * docker-commons:1.6 'Docker Commons Plugin'
  * docker-custom-build-environment:1.6.5 'CloudBees Docker Custom Build Environment Plugin'
  * docker-workflow:1.10 'Docker Pipeline'
  * durable-task:1.13 'Durable Task Plugin'
  * envinject:2.0 'Environment Injector Plugin'
  * external-monitor-job:1.7 'External Monitor Job Type Plugin'
  * extra-columns:1.18 'Extra Columns Plugin'
  * favorite:2.0.4 'Favorite'
  * flaky-test-handler:1.0.4 'Flaky Test Handler plugin'
  * git:3.2.0 'Jenkins Git plugin'
  * git-client:2.4.1 'Jenkins Git client plugin'
  * git-server:1.7 'Jenkins GIT server Plugin'
  * github:1.26.2 'GitHub plugin'
  * github-api:1.85 'GitHub API Plugin'
  * github-branch-source:2.0.5 'GitHub Branch Source Plugin'
  * github-organization-folder:1.6 'GitHub Organization Folder Plugin'
  * greenballs:1.15 'Green Balls'
  * groovy:2.0 'Groovy'
  * groovy-postbuild:2.3.1 'Groovy Postbuild'
  * handlebars:1.1.1 'JavaScript GUI Lib: Handlebars bundle plugin'
  * htmlpublisher:1.12 'HTML Publisher plugin'
  * icon-shim:2.0.3 'Icon Shim Plugin'
  * instant-messaging:1.35 'Jenkins instant-messaging plugin'
  * ircbot:2.27 'Jenkins IRC Plugin'
  * jackson2-api:2.7.3 'Jackson 2 API Plugin'
  * javadoc:1.4 'Javadoc Plugin'
  * job-dsl:1.60 'Job DSL'
  * job-restrictions:0.6 'Jenkins Job Restrictions Plugin'
  * jquery:1.11.2-0 'Jenkins jQuery plugin'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * junit:1.20 'JUnit Plugin'
  * ldap:1.14 'LDAP Plugin'
  * mailer:1.20 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.9.0 'MapDB API Plugin'
  * mask-passwords:2.10.1 'Mask Passwords Plugin'
  * matrix-auth:1.5 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.9 'Matrix Project Plugin'
  * maven-plugin:2.15.1 'Maven Integration plugin'
  * metrics:3.1.2.9 'Metrics Plugin'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * nested-view:1.14 'Nested View Plugin'
  * node-iterator-api:1.5 'Node Iterator API Plugin'
  * nodelabelparameter:1.7.2 'Node and Label parameter plugin'
  * notification:1.11 'Jenkins Notification plugin'
  * pam-auth:1.3 'PAM Authentication plugin'
  * parameterized-trigger:2.33 'Jenkins Parameterized Trigger plugin'
  * pipeline-build-step:2.5 'Pipeline: Build Step'
  * pipeline-github-lib:1.0 'Pipeline: GitHub Groovy Libraries'
  * pipeline-graph-analysis:1.3 'Pipeline Graph Analysis Plugin'
  * pipeline-input-step:2.5 'Pipeline: Input Step'
  * pipeline-milestone-step:1.3.1 'Pipeline: Milestone Step'
  * pipeline-model-api:1.1.2 'Pipeline: Model API'
  * pipeline-model-declarative-agent:1.1.1 'Pipeline: Declarative Agent API'
  * pipeline-model-definition:1.1.2 'Pipeline: Model Definition'
  * pipeline-model-extensions:1.1.2 'Pipeline: Declarative Extension Points API'
  * pipeline-rest-api:2.6 'Pipeline: REST API Plugin'
  * pipeline-stage-step:2.2 'Pipeline: Stage Step'
  * pipeline-stage-tags-metadata:1.1.2 'Pipeline: Stage Tags Metadata'
  * pipeline-stage-view:2.6 'Pipeline: Stage View Plugin'
  * pipeline-utility-steps:1.3.0 'Pipeline Utility Steps'
  * plain-credentials:1.4 'Plain Credentials Plugin'
  * promoted-builds:2.28.1 'Jenkins promoted builds plugin'
  * pubsub-light:1.7 'Jenkins Pub-Sub "light" Bus'
  * rebuild:1.25 'Rebuilder'
  * resource-disposer:0.6 'Resource Disposer Plugin'
  * run-condition:1.0 'Run Condition Plugin'
  * s3:0.10.11 'Jenkins S3 publisher plugin'
  * scm-api:2.1.1 'SCM API Plugin'
  * script-security:1.27 'Script Security Plugin'
  * scriptler:2.9 'Scriptler'
  * sse-gateway:1.15 'Server Sent Events (SSE) Gateway Plugin'
  * ssh-credentials:1.13 'SSH Credentials Plugin'
  * ssh-slaves:1.17 'Jenkins SSH Slaves plugin'
  * structs:1.6 'Structs Plugin'
  * subversion:2.7.2 'Jenkins Subversion Plug-in'
  * support-core:2.40 'Support Core Plugin'
  * swarm:3.4 'Jenkins Self-Organizing Swarm Plug-in Modules'
  * timestamper:1.8.8 'Timestamper'
  * token-macro:2.1 'Token Macro Plugin'
  * translation:1.15 'Jenkins Translation Assistance plugin'
  * variant:1.1 'Variant Plugin'
  * vsphere-cloud:2.15 'vSphere Plugin'
  * windows-slaves:1.3.1 'Windows Slaves Plugin'
  * workflow-aggregator:2.5 'Pipeline'
  * workflow-api:2.13 'Pipeline: API'
  * workflow-basic-steps:2.4 'Pipeline: Basic Steps'
  * workflow-cps:2.29 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.7 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.10 'Pipeline: Nodes and Processes'
  * workflow-job:2.10 'Pipeline: Job'
  * workflow-multibranch:2.14 'Pipeline: Multibranch'
  * workflow-scm-step:2.4 'Pipeline: SCM Step'
  * workflow-step-api:2.9 'Pipeline: Step API'
  * workflow-support:2.14 'Pipeline: Supporting APIs'
  * ws-cleanup:0.32 'Jenkins Workspace Cleanup Plugin'
