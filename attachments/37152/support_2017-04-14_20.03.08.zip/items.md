Item statistics
===============

  * `hudson.model.FreeStyleProject`
    - Number of items: 23
    - Number of builds per job: 44.30434782608695 [n=23, s=100.0]
  * `org.jenkinsci.plugins.workflow.job.WorkflowJob`
    - Number of items: 17
    - Number of builds per job: 17.941176470588236 [n=17, s=10.0]

Total job statistics
======================

  * Number of jobs: 40
  * Number of builds per job: 33.1 [n=40, s=80.0]
