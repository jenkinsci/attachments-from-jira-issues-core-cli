-----------
 * Name eth0
 ** Hardware Address - 125f2c62e4b1
 ** Index - 2
 ** InetAddress - /fe80:0:0:0:105f:2cff:fe62:e4b1%2
 ** InetAddress - /172.31.58.216
 ** MTU - 9001
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /0:0:0:0:0:0:0:1%1
 ** InetAddress - /127.0.0.1
 ** MTU - 65536
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false
