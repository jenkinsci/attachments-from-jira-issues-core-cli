Loggers currently enabled
=========================
org.apache.sshd - WARNING
winstone - INFO
 - INFO
