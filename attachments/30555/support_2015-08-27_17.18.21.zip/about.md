Jenkins
=======

Version details
---------------

  * Version: `1.626`
  * Mode:    WAR
  * Servlet container
      - Specification: 3.0
      - Name:          `jetty/winstone-2.8`
  * Java
      - Home:           `/usr/lib/jvm/java-7-openjdk-amd64/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.7.0_79
      - Maximum memory:   882.00 MB (924844032)
      - Allocated memory: 382.50 MB (401080320)
      - Free memory:      282.00 MB (295697048)
      - In-use memory:    100.50 MB (105383272)
      - PermGen used:     56.68 MB (59429808)
      - PermGen max:      166.00 MB (174063616)
      - GC strategy:      ParallelGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.7
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.7
  * JVM Implementation
      - Name:    OpenJDK 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 24.79-b02
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      3.16.0-4-amd64
      - Distribution: Debian GNU/Linux 8.1 (jessie)
  * Process ID: 3213 (0xc8d)
  * Process started: 2015-08-27 13:13:30.316-0400
  * Process uptime: 4 min 51 sec
  * JVM startup parameters:
      - Boot classpath: `/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/resources.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/rt.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/jsse.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/jce.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/charsets.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/rhino.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/jfr.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/classes`
      - Classpath: `/usr/share/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`
      - arg[0]: `-Djava.awt.headless=true`

Important configuration
---------------

  * Security realm: `hudson.security.HudsonPrivateSecurityRealm`
  * Authorization strategy: `hudson.security.GlobalMatrixAuthorizationStrategy`

Active Plugins
--------------

  * analysis-core:1.72 'Static Analysis Utilities'
  * antisamy-markup-formatter:1.3 'OWASP Markup Formatter Plugin'
  * credentials:1.22 'Credentials Plugin'
  * email-ext:2.40.5 'Email Extension Plugin'
  * email-ext-recipients-column:1.0 'Email Ext Recipients Column Plugin'
  * emailext-template:0.4 'Email Extension Template Plugin'
  * external-monitor-job:1.4 'External Monitor Job Type Plugin'
  * git:2.4.0 'Jenkins GIT plugin'
  * git-client:1.18.0 *(update available)* 'Jenkins GIT client plugin'
  * greenballs:1.14 'Green Balls'
  * htmlpublisher:1.4 *(update available)* 'HTML Publisher plugin'
  * javadoc:1.3 'Javadoc Plugin'
  * junit:1.6 *(update available)* 'JUnit Plugin'
  * ldap:1.11 'LDAP Plugin'
  * mailer:1.15 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.6.0 'MapDB API Plugin'
  * matrix-auth:1.2 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.6 'Matrix Project Plugin'
  * metrics:3.0.11 'Metrics Plugin'
  * pam-auth:1.2 'PAM Authentication plugin'
  * publish-over-ssh:1.13 'Publish Over SSH'
  * saferestart:0.3 'Safe Restart Plugin'
  * scm-api:0.2 'SCM API Plugin'
  * scp:1.8 'Hudson SCP publisher plugin'
  * script-security:1.14 *(update available)* 'Script Security Plugin'
  * simple-parameterized-builds-report:1.4 'Simple Parameterized Builds Report Plugin'
  * ssh-credentials:1.11 'SSH Credentials Plugin'
  * ssh-slaves:1.9 *(update available)* 'Jenkins SSH Slaves plugin'
  * subversion:2.5.1 *(update available)* 'Jenkins Subversion Plug-in'
  * summary_report:1.13 'Summary Display Plugin'
  * support-core:2.27 'Support Core Plugin'
  * thinBackup:1.7.4 'ThinBackup'
  * token-macro:1.10 'Token Macro Plugin'
  * translation:1.12 'Jenkins Translation Assistance plugin'
  * warnings:4.48 'Warnings Plug-in'
  * windows-slaves:1.1 'Windows Slaves Plugin'
