User
====

Authentication
--------------

  * Authenticated: true
  * Name: admin
  * Authorities 
      - `authenticated`
  * Raw: `org.acegisecurity.providers.UsernamePasswordAuthenticationToken@7be781e3: Username: hudson.security.HudsonPrivateSecurityRealm$Details@10bc03d7; Password: [PROTECTED]; Authenticated: true; Details: org.acegisecurity.ui.WebAuthenticationDetails@255f8: RemoteIpAddress: 10.5.2.66; SessionId: g0am4b7yau0l1fkv5374an10u; Granted Authorities: authenticated`

