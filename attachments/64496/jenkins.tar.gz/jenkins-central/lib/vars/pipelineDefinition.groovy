//This is the generic pipeline, when heavily different requirements are needed
//implement a new version of this function

// config will contain the full environment we are already using
// body are the steps that will be specified when the "pipelineDefinition" is
// called in a Jenkinsfile

/**
 * Defines a standard declarative Jenkins pipeline structure,
 * allowing extensive configuration via a map.
 *
 * @param config A map for global pipeline configuration.
 * - `agentLabel`: (Optional) The Jenkins agent label to use. Defaults to 'jenkins-el8-drv'.
 * @param body A closure containing the definitions of the pipeline stages.
 */
def call(Map config = [:], Closure body = null) {
    // Various checks on basic config consistency
    if (!(config.agentLabel instanceof String) || config.agentLabel.isEmpty()) {
        throw new IllegalArgumentException("Agent label must be a non-empty string")
    }


    pipeline {
//        agent {
//            label config.agentLabel
//        }
        agent any
        options {
            timestamps()
            disableConcurrentBuilds()
            buildDiscarder logRotator(artifactDaysToKeepStr: '0', artifactNumToKeepStr: '0', daysToKeepStr: '60', numToKeepStr: '100')
        }

        stages {
            stage('Startup') {
                steps {
                    script {
                        body.resolveStrategy = Closure.DELEGATE_FIRST
                        body.delegate = this

                        body()
                    }
                }
            }
        }

        post {
            always {
                script { echo "Pipeline finished."}
            }
            success {
                script { echo "Pipeline succeeded!" }
            }
            failure {
                script { echo "Pipeline failed!" }
            }
        }

    }
}
