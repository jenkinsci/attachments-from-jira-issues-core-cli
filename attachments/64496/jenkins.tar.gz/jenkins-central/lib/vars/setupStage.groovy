import org.jma.pipelines.stages.Setup

def call(Map config = [:]) {
    def setupStage = new Setup(this)

    setupStage.execute(config)
}