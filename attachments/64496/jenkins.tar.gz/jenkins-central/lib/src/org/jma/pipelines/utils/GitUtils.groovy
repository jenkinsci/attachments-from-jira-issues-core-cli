package org.jma.pipelines.utils

import com.cloudbees.groovy.cps.NonCPS
import org.jma.base.ScriptDelegate

class GitUtils extends ScriptDelegate {

    GitUtils(Script script) {
        super(script)
    }

    String getLastCommitHash() {
        return sh(script: 'git rev-parse HEAD', returnStdout: true).trim()
    }

    @NonCPS
    String getBuildCommitId(build) {
        def changeSets = build.changeSets

        if (changeSets == null) {
            return ""
        }

        if (changeSets.isEmpty()) {
            return ""
        }

        def changeSet = build.changeSets[0]

        def items = changeSet.items

        if (items.length == 0) {
            return ""
        }

        // Commits are ordered by date in the changeset
        def lastCommitId = items[items.length - 1].commitId

        return lastCommitId
    }
}