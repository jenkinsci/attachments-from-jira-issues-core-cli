package org.jma.pipelines.stages

import org.jma.base.ScriptDelegate
import org.jma.pipelines.utils.GitUtils


class Setup extends ScriptDelegate implements Serializable {

    private final static long serialVersionUID = 1L

    private final GitUtils gitUtils

    Setup(Script script) {
        super(script)
        this.gitUtils = new GitUtils(script)
    }
	
	void execute(Map config = [:]) {
        stage('Setup') {
            def files = findFiles(glob: 'dir/file*')

            if (files) {
                echo("Found files: ${files.collect { it.name }.join(', ')}")
            } else {
                echo("No files found matching the pattern.")
            }

            echo("Setting up with config: ${config}")

            echo("Last commit hash: ${gitUtils.getLastCommitHash()}")

            echo("Build commit ID: ${gitUtils.getBuildCommitId(config.build)}")
        }
	}
}
