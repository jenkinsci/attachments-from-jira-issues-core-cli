package org.jma.base

class ScriptDelegate {
    protected final Script script

    ScriptDelegate(Script script) {
        this.script = script
    }

    // Delegate method calls not found in this class to the script object
    def methodMissing(String name, args) {
        return script.invokeMethod(name, args)
    }

    // Delegate property access not found in this class to the script object
    def propertyMissing(String name) {
        return script[name]
    }
}