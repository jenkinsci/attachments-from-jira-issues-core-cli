Node statistics
===============

  * Total number of nodes
      - Sample size:        0
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0
  * Total number of nodes online
      - Sample size:        0
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0
  * Total number of executors
      - Sample size:        0
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0
  * Total number of executors in use
      - Sample size:        0
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      2
      - FS root:        `C:\Windows\system32\config\systemprofile\.jenkins`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Slave Version:  3.5
      - Java
          + Home:           `C:\Program Files\Java\jre1.8.0_121`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_121
          + Maximum memory:   247.50 MB (259522560)
          + Allocated memory: 156.77 MB (164388864)
          + Free memory:      45.54 MB (47754728)
          + In-use memory:    111.23 MB (116634136)
          + GC strategy:      SerialGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.121-b13
      - Operating system
          + Name:         Windows 10
          + Architecture: amd64
          + Version:      10.0
      - Process ID: 3380 (0xd34)
      - Process started: 2017-03-12 11:14:56.246+0000
      - Process uptime: 2 min 50 sec
      - JVM startup parameters:
          + Boot classpath: `C:\Program Files\Java\jre1.8.0_121\lib\resources.jar;C:\Program Files\Java\jre1.8.0_121\lib\rt.jar;C:\Program Files\Java\jre1.8.0_121\lib\sunrsasign.jar;C:\Program Files\Java\jre1.8.0_121\lib\jsse.jar;C:\Program Files\Java\jre1.8.0_121\lib\jce.jar;C:\Program Files\Java\jre1.8.0_121\lib\charsets.jar;C:\Program Files\Java\jre1.8.0_121\lib\jfr.jar;C:\Program Files\Java\jre1.8.0_121\classes`
          + Classpath: `C:\Program Files\Apache Software Foundation\Tomcat 7.0\bin\bootstrap.jar;C:\Program Files\Apache Software Foundation\Tomcat 7.0\bin\tomcat-juli.jar`
          + Library path: `C:\Program Files\Apache Software Foundation\Tomcat 7.0\bin;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;C:\Program Files\Java\jdk1.8.0_121\bin;C:\ProgramData\Oracle\Java\javapath;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;C:\Program Files\Git\cmd;C:\Program Files\Git\bin;;.`
          + arg[0]: `-Dcatalina.home=C:\Program Files\Apache Software Foundation\Tomcat 7.0`
          + arg[1]: `-Dcatalina.base=C:\Program Files\Apache Software Foundation\Tomcat 7.0`
          + arg[2]: `-Djava.endorsed.dirs=C:\Program Files\Apache Software Foundation\Tomcat 7.0\endorsed`
          + arg[3]: `-Djava.io.tmpdir=C:\Program Files\Apache Software Foundation\Tomcat 7.0\temp`
          + arg[4]: `-Djava.util.logging.manager=org.apache.juli.ClassLoaderLogManager`
          + arg[5]: `-Djava.util.logging.config.file=C:\Program Files\Apache Software Foundation\Tomcat 7.0\conf\logging.properties`
          + arg[6]: `exit`
          + arg[7]: `-Xms128m`
          + arg[8]: `-Xmx256m`

