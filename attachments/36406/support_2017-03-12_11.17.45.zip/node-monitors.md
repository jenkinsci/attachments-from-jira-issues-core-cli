Node monitors
=============
Architecture
----
 - Is Ignored: false
 - Computers:
   * master: Windows 10 (amd64)
Clock Difference
----
 - Is Ignored: false
 - Computers:
   * master: In sync
Free Disk Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 15.127GB left on C:\Windows\System32\config\systemprofile\.jenkins.
Free Swap Space
----
 - Is Ignored: false
 - Computers:
   * master: Memory:833/2047MB  Swap:2027/3199MB
Free Temp Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 15.127GB left on C:\Program Files\Apache Software Foundation\Tomcat 7.0\temp.
Response Time
----
 - Is Ignored: false
 - Computers:
   * master: 0ms
