Support Bundle Manifest
=======================

Generated on 2017-03-12 11:17:45.083+0000

Requested components:

  * Master Log Recorders

      - `nodes/master/logs/all_2017-03-12_11.17.00.log`

      - `nodes/master/logs/all_memory_buffer.log`

      - `nodes/master/logs/jenkins.log`

  * Slave Log Recorders

  * Garbage Collection Logs

  * Agents config files (Encrypted secrets are redacted)

  * Jenkins Global Configuration File (Encrypted secrets are redacted)

      - `jenkins-root-configuration-files/config.xml`

  * Other Jenkins Configuration Files (Encrypted secrets are redacted)

      - `jenkins-root-configuration-files/hudson.model.UpdateCenter.xml`

      - `jenkins-root-configuration-files/hudson.plugins.git.GitTool.xml`

      - `jenkins-root-configuration-files/hudson.tasks.Ant.xml`

      - `jenkins-root-configuration-files/hudson.tasks.Maven.xml`

      - `jenkins-root-configuration-files/jenkins.mvn.GlobalMavenConfig.xml`

      - `jenkins-root-configuration-files/nodeMonitors.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.gitclient.JGitApacheTool.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.gitclient.JGitTool.xml`

      - `jenkins-root-configuration-files/support-core.xml`

  * About browser

      - `browser.md`

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `items.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `plugins/active.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * About user (basic authentication details only)

      - `user.md`

  * Administrative monitors

      - `admin-monitors.md`

  * Build queue

      - `buildqueue.md`

  * Dump slave export tables (could reveal some memory leaks)

  * Environment variables

      - `nodes/master/environment.txt`

  * File descriptors (Unix only)

  * JVM process system metrics (Linux only)

  * Load Statistics

      - `load-stats/label/master/hour.csv`

      - `load-stats/label/master/hour.png`

      - `load-stats/label/master/min.csv`

      - `load-stats/label/master/min.png`

      - `load-stats/label/master/sec10.csv`

      - `load-stats/label/master/sec10.png`

      - `load-stats/no-label/hour.csv`

      - `load-stats/no-label/hour.png`

      - `load-stats/no-label/min.csv`

      - `load-stats/no-label/min.png`

      - `load-stats/no-label/sec10.csv`

      - `load-stats/no-label/sec10.png`

      - `load-stats/overall/hour.csv`

      - `load-stats/overall/hour.png`

      - `load-stats/overall/min.csv`

      - `load-stats/overall/min.png`

      - `load-stats/overall/sec10.csv`

      - `load-stats/overall/sec10.png`

  * All loggers currently enabled.

      - `loggers.md`

  * Metrics

      - `nodes/master/metrics.json`

  * Networking Interface

      - `nodes/master/networkInterface.md`

  * Node monitors

      - `node-monitors.md`

  * Root CAs

      - `nodes/master/RootCA.txt`

  * System configuration (Linux only)

  * System properties

      - `nodes/master/system.properties`

  * Update Center

      - `update-center.md`

  * Slow Request Records

  * Deadlock Records

  * Thread dumps

      - `nodes/master/thread-dump.txt`

