Item statistics
===============

  * `hudson.model.FreeStyleProject`
    - Number of items: 4
    - Number of builds per job: 2.5 [n=4, s=1.0]

Total job statistics
======================

  * Number of jobs: 4
  * Number of builds per job: 2.5 [n=4, s=1.0]
