Monitors
========

`hudson.PluginWrapper$PluginWrapperAdministrativeMonitor`
--------------
(active and enabled)

`jenkins.diagnostics.URICheckEncodingMonitor`
--------------
(active and enabled)
