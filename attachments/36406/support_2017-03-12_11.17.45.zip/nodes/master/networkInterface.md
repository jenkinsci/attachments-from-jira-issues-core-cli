-----------
 * Name Software Loopback Interface 1
 ** Index - 1
 ** InetAddress - /127.0.0.1
 ** InetAddress - /0:0:0:0:0:0:0:1
 ** MTU - -1
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Microsoft ISATAP Adapter
 ** Hardware Address - 00000000000000e0
 ** Index - 2
 ** InetAddress - /fe80:0:0:0:0:5efe:a00:20f%net0
 ** MTU - 1280
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - true
 ** Supports multicast - false
-----------
 * Name Intel(R) PRO/1000 MT Desktop Adapter
 ** Hardware Address - 0800273806aa
 ** Index - 3
 ** InetAddress - /10.0.2.15
 ** InetAddress - /fe80:0:0:0:7d0d:9d41:20ea:4156%eth0
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Microsoft Kernel Debug Network Adapter
 ** Index - 4
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Microsoft Teredo Tunneling Adapter
 ** Hardware Address - 00000000000000e0
 ** Index - 5
 ** InetAddress - /2001:0:9d38:6abd:4f7:3c38:509a:f639
 ** InetAddress - /fe80:0:0:0:4f7:3c38:509a:f639%net1
 ** MTU - 1280
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - true
 ** Supports multicast - false
-----------
 * Name Intel(R) PRO/1000 MT Desktop Adapter-WFP Native MAC Layer LightWeight Filter-0000
 ** Index - 6
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Intel(R) PRO/1000 MT Desktop Adapter-QoS Packet Scheduler-0000
 ** Index - 7
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Intel(R) PRO/1000 MT Desktop Adapter-WFP 802.3 MAC Layer LightWeight Filter-0000
 ** Index - 8
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
