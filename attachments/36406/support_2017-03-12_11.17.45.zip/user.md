User
====

Authentication
--------------

  * Authenticated: true
  * Name: admin
  * Authorities 
      - `authenticated`
  * Raw: `org.acegisecurity.providers.UsernamePasswordAuthenticationToken@64373637: Username: hudson.security.HudsonPrivateSecurityRealm$Details@36a0525e; Password: [PROTECTED]; Authenticated: true; Details: org.acegisecurity.ui.WebAuthenticationDetails@fffd148a: RemoteIpAddress: 127.0.0.1; SessionId: D47D4C324DBB637BA09395E2C2C42132; Granted Authorities: authenticated`

