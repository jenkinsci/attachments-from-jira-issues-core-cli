User
====

Authentication
--------------

  * Authenticated: true
  * Name: E010517
  * Authorities 
      - `ROLE_DL.IT.WEBADMINS`
      - `ROLE_SG-WEBSPHEREADMINS`
      - `SG-APPSAuto`
      - `ROLE_DL.IT.AOWASDEPLOYMENTJAR`
      - `ROLE_SG-APPS`
      - `ROLE_SG-ITINFRASTRUCTUREPLANNING`
      - `SG-NoProblemClaimsVendorRead`
      - `SG-ITInfrastructurePlanning`
      - `SG-AppsDeploy`
      - `DL.IT.TeamUp.Notify`
      - `ROLE_SG-ECM WAS ADMINS`
      - `WG-IT Division`
      - `DL.IT.RDz.Users`
      - `HOLAN`
      - `DL.SourceOneRollout`
      - `DL.Wiki.Users`
      - `ROLE_SG-WEBINFRA`
      - `SG-APPSWRKB`
      - `DL.IT.JAVA.DEV`
      - `ROLE_HOLAN`
      - `SG-Data Center`
      - `ROLE_SG-DEPT-808329`
      - `ROLE_SG-DATA CENTER SYS SUPPORT`
      - `SG-WebAdmins`
      - `RG-DRM WebSphere Admins Observers`
      - `ROLE_DL.IT.ARM.PRODUCT.OWNER.TEAM`
      - `RG-DRDOCWeb-ReadAll`
      - `ROLE_SG-SECURITYASSESSMENT`
      - `DL.WebSeal.Team`
      - `DL.AO.VB.TEAM`
      - `ROLE_DL.SOURCEONEROLLOUT`
      - `ROLE_SG-PVCS JAVA`
      - `ROLE_DL.IT.FILENET.ADMINS`
      - `DL.IT.WebAdmins`
      - `DL.IT.TADDM.Users`
      - `ROLE_DL.WIKI.USERS`
      - `ROLE_DL.AO.VB.TEAM`
      - `ROLE_DL.IT.TEAMUP.NOTIFY`
      - `DL.IT.CICSCommandTesters`
      - `ROLE_SG-DUCKCREEK`
      - `ROLE_DL.IT.CICSCOMMANDTESTERS`
      - `DL.JIRA.USERS`
      - `ROLE_SG-IT SYSTEMS SUPPORT`
      - `SG-IT Systems Support`
      - `ROLE_RG-SOURCEONE_ON`
      - `ROLE_RG-DRDOCWEB-READALL`
      - `DL.it.bigip.status.updates`
      - `SG-WebSphereAdmins`
      - `ROLE_DL.IT.JAVA.DEV`
      - `ROLE_SG-JENKINSADMINS`
      - `SG-Apps`
      - `ROLE_SG-OWAACCESS`
      - `SG-DuckCreek`
      - `ROLE_SG-DATA CENTER`
      - `DL.it.filenet.admins`
      - `SG-Data Center Sys Support`
      - `SG-WebInfra`
      - `RG-SourceOne_On`
      - `SG-VDRNETS-GDECS`
      - `ROLE_SG-APPSAUTO`
      - `ROLE_DL.IT.BIGIP.STATUS.UPDATES`
      - `SG-OWAAccess`
      - `SG-ECM WAS Admins`
      - `ROLE_SG-WEBADMINS`
      - `ROLE_DL.IT.RDZ.USERS`
      - `ROLE_DL.TUESDAY.BURRITO.DAY`
      - `SG-SecurityAssessment`
      - `SG-PVCS Java`
      - `ROLE_SG-NOPROBLEMCLAIMSVENDORREAD`
      - `ROLE_DL.IT.TADDM.USERS`
      - `authenticated`
      - `ROLE_RG-DRM WEBSPHERE ADMINS OBSERVERS`
      - `ROLE_SAPG-PRODUCTION PORTAL USER`
      - `ROLE_SG-APPSWRKB`
      - `DL.Tuesday.Burrito.Day`
      - `DL.IT.ARM.Product.Owner.Team`
      - `ROLE_WG-IT DIVISION`
      - `DL.IT.AOWASDeploymentJAR`
      - `SG-Dept-808329`
      - `ROLE_SG-VDRNETS-GDECS`
      - `SAPG-Production Portal User`
      - `ROLE_DL.WEBSEAL.TEAM`
      - `ROLE_SG-APPSDEPLOY`
      - `ROLE_RG-UNICENTER SYSTEMS`
      - `ROLE_DL.JIRA.USERS`
      - `SG-JenkinsAdmins`
      - `RG-Unicenter Systems`
  * Raw: `org.acegisecurity.providers.rememberme.RememberMeAuthenticationToken@5c4c7318: Username: org.acegisecurity.userdetails.ldap.LdapUserDetailsImpl@59e710; Password: [PROTECTED]; Authenticated: true; Details: org.acegisecurity.ui.WebAuthenticationDetails@0: RemoteIpAddress: 10.3.54.223; SessionId: null; Granted Authorities: ROLE_DL.IT.WEBADMINS, ROLE_SG-WEBSPHEREADMINS, SG-APPSAuto, ROLE_DL.IT.AOWASDEPLOYMENTJAR, ROLE_SG-APPS, ROLE_SG-ITINFRASTRUCTUREPLANNING, SG-NoProblemClaimsVendorRead, SG-ITInfrastructurePlanning, SG-AppsDeploy, DL.IT.TeamUp.Notify, ROLE_SG-ECM WAS ADMINS, WG-IT Division, DL.IT.RDz.Users, HOLAN, DL.SourceOneRollout, DL.Wiki.Users, ROLE_SG-WEBINFRA, SG-APPSWRKB, DL.IT.JAVA.DEV, ROLE_HOLAN, SG-Data Center, ROLE_SG-DEPT-808329, ROLE_SG-DATA CENTER SYS SUPPORT, SG-WebAdmins, RG-DRM WebSphere Admins Observers, ROLE_DL.IT.ARM.PRODUCT.OWNER.TEAM, RG-DRDOCWeb-ReadAll, ROLE_SG-SECURITYASSESSMENT, DL.WebSeal.Team, DL.AO.VB.TEAM, ROLE_DL.SOURCEONEROLLOUT, ROLE_SG-PVCS JAVA, ROLE_DL.IT.FILENET.ADMINS, DL.IT.WebAdmins, DL.IT.TADDM.Users, ROLE_DL.WIKI.USERS, ROLE_DL.AO.VB.TEAM, ROLE_DL.IT.TEAMUP.NOTIFY, DL.IT.CICSCommandTesters, ROLE_SG-DUCKCREEK, ROLE_DL.IT.CICSCOMMANDTESTERS, DL.JIRA.USERS, ROLE_SG-IT SYSTEMS SUPPORT, SG-IT Systems Support, ROLE_RG-SOURCEONE_ON, ROLE_RG-DRDOCWEB-READALL, DL.it.bigip.status.updates, SG-WebSphereAdmins, ROLE_DL.IT.JAVA.DEV, ROLE_SG-JENKINSADMINS, SG-Apps, ROLE_SG-OWAACCESS, SG-DuckCreek, ROLE_SG-DATA CENTER, DL.it.filenet.admins, SG-Data Center Sys Support, SG-WebInfra, RG-SourceOne_On, SG-VDRNETS-GDECS, ROLE_SG-APPSAUTO, ROLE_DL.IT.BIGIP.STATUS.UPDATES, SG-OWAAccess, SG-ECM WAS Admins, ROLE_SG-WEBADMINS, ROLE_DL.IT.RDZ.USERS, ROLE_DL.TUESDAY.BURRITO.DAY, SG-SecurityAssessment, SG-PVCS Java, ROLE_SG-NOPROBLEMCLAIMSVENDORREAD, ROLE_DL.IT.TADDM.USERS, authenticated, ROLE_RG-DRM WEBSPHERE ADMINS OBSERVERS, ROLE_SAPG-PRODUCTION PORTAL USER, ROLE_SG-APPSWRKB, DL.Tuesday.Burrito.Day, DL.IT.ARM.Product.Owner.Team, ROLE_WG-IT DIVISION, DL.IT.AOWASDeploymentJAR, SG-Dept-808329, ROLE_SG-VDRNETS-GDECS, SAPG-Production Portal User, ROLE_DL.WEBSEAL.TEAM, ROLE_SG-APPSDEPLOY, ROLE_RG-UNICENTER SYSTEMS, ROLE_DL.JIRA.USERS, SG-JenkinsAdmins, RG-Unicenter Systems`

