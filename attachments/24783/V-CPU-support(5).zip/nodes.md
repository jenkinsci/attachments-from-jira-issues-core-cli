Build Nodes
===========

  * master (Jenkins)
      - Description:    `the master Jenkins node`
      - Executors:      5
      - Remote FS root: `E:\Jenkins`
      - Labels:         (none)
      - Usage:          Utilize this slave as much as possible
      - Java
          + Home:           `E:\Java\jdk1.6.0_39\jre`
          + Vendor:           Sun Microsystems Inc.
          + Version:          1.6.0_39
          + Maximum memory:   253.44 MB (265748480)
          + Allocated memory: 253.44 MB (265748480)
          + Free memory:      72.07 MB (75569200)
          + In-use memory:    181.37 MB (190179280)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.6
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.0
      - JVM Implementation
          + Name:    Java HotSpot(TM) Server VM
          + Vendor:  Sun Microsystems Inc.
          + Version: 20.14-b01
      - Operating system
          + Name:         Windows Server 2008 R2
          + Architecture: x86
          + Version:      6.1
      - Process ID: 5580 (0x15cc)
      - Process started: 2013-12-11 11:03:56.758-0500
      - Process uptime: 35 min
      - JVM startup parameters:
          + Boot classpath: `E:\Java\jdk1.6.0_39\jre\lib\resources.jar;E:\Java\jdk1.6.0_39\jre\lib\rt.jar;E:\Java\jdk1.6.0_39\jre\lib\sunrsasign.jar;E:\Java\jdk1.6.0_39\jre\lib\jsse.jar;E:\Java\jdk1.6.0_39\jre\lib\jce.jar;E:\Java\jdk1.6.0_39\jre\lib\charsets.jar;E:\Java\jdk1.6.0_39\jre\lib\modules\jdk.boot.jar;E:\Java\jdk1.6.0_39\jre\classes`
          + Classpath: `E:\Jenkins\jenkins.war`
          + Library path: `E:\Java\jdk1.6.0_39\bin;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;C:\Program Files\System Center Operations Manager 2007\;E:\Java\jdk1.6.0_39\bin;E:\AccuRev\601\bin;E:\BuildTools\cygwin-1.7.17\bin;.`
          + arg[0]: `-Dcom.sun.management.jmxremote.authenticate=false`
          + arg[1]: `-Dcom.sun.management.jmxremote.port=1101`
          + arg[2]: `-Dcom.sun.management.jmxremote.ssl=false`
          + arg[3]: `-Xrs`
          + arg[4]: `-Xms256m`
          + arg[5]: `-Xmx256m`
          + arg[6]: `-XX:MaxPermSize=128m`
          + arg[7]: `-XX:+HeapDumpOnOutOfMemoryError`
          + arg[8]: `-Xloggc:E:\Jenkins/verbosegc.log`
          + arg[9]: `-XX:+UseGCLogFileRotation`
          + arg[10]: `-XX:NumberOfGCLogFiles=3`
          + arg[11]: `-XX:GCLogFileSize=5M`
          + arg[12]: `-XX:+PrintGCDetails`
          + arg[13]: `-XX:+PrintGCDateStamps`
          + arg[14]: `-XX:-TraceClassUnloading`
          + arg[15]: `-Dorg.kohsuke.stapler.compression.CompressionFilter.disabled=true`
          + arg[16]: `-Dhudson.DNSMultiCast.disabled=true`
          + arg[17]: `-Dhudson.model.DownloadService.never=true`
          + arg[18]: `-Dhudson.model.UpdateCenter.never=true`
          + arg[19]: `-Dhudson.security.ExtendedReadPermission=true`
          + arg[20]: `-Dhudson.Util.noSymLink=true`
          + arg[21]: `-Djava.io.tmpdir=E:\TEMP`
          + arg[22]: `-Dhudson.lifecycle=hudson.lifecycle.WindowsServiceLifecycle`

  * VDIQTPTaskW704 (Dumb Slave)
      - Description:    ``
      - Executors:      1
      - Remote FS root: `C:\Users\qtptaskuser\Desktop\Jenkins`
      - Labels:         QTP
      - Usage:          Leave this machine for tied jobs only
      - Launch method:  Launch slave agents via Java Web Start
      - Availability:   Keep this slave on-line as much as possible
      - Status:         on-line
      - Version:        2.23
      - Java
          + Home:           `C:\Program Files (x86)\Java\jre6`
          + Vendor:           Sun Microsystems Inc.
          + Version:          1.6.0_39
          + Maximum memory:   247.50 MB (259522560)
          + Allocated memory: 15.56 MB (16318464)
          + Free memory:      7.52 MB (7889424)
          + In-use memory:    8.04 MB (8429040)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.6
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.0
      - JVM Implementation
          + Name:    Java HotSpot(TM) Client VM
          + Vendor:  Sun Microsystems Inc.
          + Version: 20.14-b01
      - Operating system
          + Name:         Windows 7
          + Architecture: x86
          + Version:      6.1
      - Process ID: 1588 (0x634)
      - Process started: 2013-10-11 12:09:01.913-0400
      - Process uptime: 2 mo 1 day
      - JVM startup parameters:
          + Boot classpath: `C:\Program Files (x86)\Java\jre6\lib\resources.jar;C:\Program Files (x86)\Java\jre6\lib\rt.jar;C:\Program Files (x86)\Java\jre6\lib\sunrsasign.jar;C:\Program Files (x86)\Java\jre6\lib\jsse.jar;C:\Program Files (x86)\Java\jre6\lib\jce.jar;C:\Program Files (x86)\Java\jre6\lib\charsets.jar;C:\Program Files (x86)\Java\jre6\lib\modules\jdk.boot.jar;C:\Program Files (x86)\Java\jre6\classes`
          + Classpath: `C:\Users\qtptaskuser\Desktop\Jenkins\slave.jar`
          + Library path: `C:\Program Files (x86)\Java\jre6\bin;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;;.`
          + arg[0]: `-Xrs`

  * PRDJENK201 (Dumb Slave)
      - Description:    `SSA Deploy`
      - Executors:      1
      - Remote FS root: `E:\PRDJENK101`
      - Labels:         SQL
      - Usage:          Leave this machine for tied jobs only
      - Launch method:  Launch slave agents via Java Web Start
      - Availability:   Keep this slave on-line as much as possible
      - Status:         on-line
      - Version:        2.32
      - Java
          + Home:           `E:\Java\jdk1.6.0_39\jre`
          + Vendor:           Sun Microsystems Inc.
          + Version:          1.6.0_39
          + Maximum memory:   247.50 MB (259522560)
          + Allocated memory: 15.56 MB (16318464)
          + Free memory:      10.02 MB (10503504)
          + In-use memory:    5.55 MB (5814960)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.6
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.0
      - JVM Implementation
          + Name:    Java HotSpot(TM) Client VM
          + Vendor:  Sun Microsystems Inc.
          + Version: 20.14-b01
      - Operating system
          + Name:         Windows Server 2008 R2
          + Architecture: x86
          + Version:      6.1
      - Process ID: 2016 (0x7e0)
      - Process started: 2013-12-05 16:49:30.494-0500
      - Process uptime: 5 days 18 hr
      - JVM startup parameters:
          + Boot classpath: `E:\Java\jdk1.6.0_39\jre\lib\resources.jar;E:\Java\jdk1.6.0_39\jre\lib\rt.jar;E:\Java\jdk1.6.0_39\jre\lib\sunrsasign.jar;E:\Java\jdk1.6.0_39\jre\lib\jsse.jar;E:\Java\jdk1.6.0_39\jre\lib\jce.jar;E:\Java\jdk1.6.0_39\jre\lib\charsets.jar;E:\Java\jdk1.6.0_39\jre\lib\modules\jdk.boot.jar;E:\Java\jdk1.6.0_39\jre\classes`
          + Classpath: `E:\PRDJENK101\slave.jar`
          + Library path: `E:\Java\jdk1.6.0_39\bin;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;E:\Java\jdk1.6.0_39\bin;E:\AccuRev\601\bin;C:\Program Files\Microsoft SQL Server\110\DTS\Binn\;C:\Program Files (x86)\Microsoft SQL Server\110\Tools\Binn\ManagementStudio\;C:\Program Files (x86)\Microsoft SQL Server\110\Tools\Binn\;C:\Program Files\Microsoft SQL Server\110\Tools\Binn\;C:\Program Files (x86)\Microsoft Visual Studio 10.0\Common7\IDE\PrivateAssemblies\;C:\Program Files (x86)\Microsoft SQL Server\110\DTS\Binn\;.`
          + arg[0]: `-Xrs`
          + arg[1]: `-Djava.io.tmpdir=E:\TEMP`

