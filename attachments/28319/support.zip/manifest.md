Support Bundle Manifest
=======================

Generated on 2015-01-05 05:49:57 -0500

Requested components:

  * Log Recorders

      - `nodes/master/logs/all_2015-01-05_10.42.53.log`

      - `nodes/master/logs/all_memory_buffer.log`

      - `nodes/master/logs/jenkins.log`

      - `nodes/slave/CDLTSBUILDCHSL-slave/jenkins.log`

      - `nodes/slave/CDLTSBUILDCHSL-slave/launchLogs/slave.log`

      - `nodes/slave/CDLTSBUILDCHSL-slave/launchLogs/slave.log.1`

      - `nodes/slave/CDLTSBUILDCHSL-slave/launchLogs/slave.log.10`

      - `nodes/slave/CDLTSBUILDCHSL-slave/launchLogs/slave.log.2`

      - `nodes/slave/CDLTSBUILDCHSL-slave/launchLogs/slave.log.3`

      - `nodes/slave/CDLTSBUILDCHSL-slave/launchLogs/slave.log.4`

      - `nodes/slave/CDLTSBUILDCHSL-slave/launchLogs/slave.log.5`

      - `nodes/slave/CDLTSBUILDCHSL-slave/launchLogs/slave.log.6`

      - `nodes/slave/CDLTSBUILDCHSL-slave/launchLogs/slave.log.7`

      - `nodes/slave/CDLTSBUILDCHSL-slave/launchLogs/slave.log.8`

      - `nodes/slave/CDLTSBUILDCHSL-slave/launchLogs/slave.log.9`

      - `nodes/slave/CDLTSBUILDCHSL-slave/logs/all_2015-01-05_10.43.30.log`

      - `nodes/slave/CDLTSBUILDCHSL-slave/logs/all_memory_buffer.log`

      - `nodes/slave/CDLTSQTPWIN03/jenkins.log`

      - `nodes/slave/CDLTSQTPWIN03/launchLogs/slave.log`

      - `nodes/slave/CDLTSQTPWIN03/launchLogs/slave.log.1`

      - `nodes/slave/CDLTSQTPWIN03/launchLogs/slave.log.10`

      - `nodes/slave/CDLTSQTPWIN03/launchLogs/slave.log.2`

      - `nodes/slave/CDLTSQTPWIN03/launchLogs/slave.log.3`

      - `nodes/slave/CDLTSQTPWIN03/launchLogs/slave.log.4`

      - `nodes/slave/CDLTSQTPWIN03/launchLogs/slave.log.5`

      - `nodes/slave/CDLTSQTPWIN03/launchLogs/slave.log.6`

      - `nodes/slave/CDLTSQTPWIN03/launchLogs/slave.log.7`

      - `nodes/slave/CDLTSQTPWIN03/launchLogs/slave.log.8`

      - `nodes/slave/CDLTSQTPWIN03/launchLogs/slave.log.9`

      - `nodes/slave/CDLTSQTPWIN03/logs/all_memory_buffer.log`

      - `nodes/slave/CDLTSQTPWIN04/jenkins.log`

      - `nodes/slave/CDLTSQTPWIN04/launchLogs/slave.log`

      - `nodes/slave/CDLTSQTPWIN04/launchLogs/slave.log.1`

      - `nodes/slave/CDLTSQTPWIN04/launchLogs/slave.log.10`

      - `nodes/slave/CDLTSQTPWIN04/launchLogs/slave.log.2`

      - `nodes/slave/CDLTSQTPWIN04/launchLogs/slave.log.3`

      - `nodes/slave/CDLTSQTPWIN04/launchLogs/slave.log.4`

      - `nodes/slave/CDLTSQTPWIN04/launchLogs/slave.log.5`

      - `nodes/slave/CDLTSQTPWIN04/launchLogs/slave.log.6`

      - `nodes/slave/CDLTSQTPWIN04/launchLogs/slave.log.7`

      - `nodes/slave/CDLTSQTPWIN04/launchLogs/slave.log.8`

      - `nodes/slave/CDLTSQTPWIN04/launchLogs/slave.log.9`

      - `nodes/slave/CDLTSQTPWIN04/logs/all_2015-01-05_10.43.32.log`

      - `nodes/slave/CDLTSQTPWIN04/logs/all_memory_buffer.log`

      - `nodes/slave/Dedicated-Selenium-slave/launchLogs/slave.log`

      - `nodes/slave/Dedicated-Selenium-slave/launchLogs/slave.log.1`

      - `nodes/slave/Dedicated-Selenium-slave/launchLogs/slave.log.10`

      - `nodes/slave/Dedicated-Selenium-slave/launchLogs/slave.log.2`

      - `nodes/slave/Dedicated-Selenium-slave/launchLogs/slave.log.3`

      - `nodes/slave/Dedicated-Selenium-slave/launchLogs/slave.log.4`

      - `nodes/slave/Dedicated-Selenium-slave/launchLogs/slave.log.5`

      - `nodes/slave/Dedicated-Selenium-slave/launchLogs/slave.log.6`

      - `nodes/slave/Dedicated-Selenium-slave/launchLogs/slave.log.7`

      - `nodes/slave/Dedicated-Selenium-slave/launchLogs/slave.log.8`

      - `nodes/slave/Dedicated-Selenium-slave/launchLogs/slave.log.9`

      - `nodes/slave/QTP-Slave/launchLogs/slave.log`

      - `nodes/slave/QTP-Slave/launchLogs/slave.log.1`

      - `nodes/slave/selenium/launchLogs/slave.log`

      - `nodes/slave/selenium/launchLogs/slave.log.1`

      - `nodes/slave/selenium/launchLogs/slave.log.2`

      - `nodes/slave/selenium/launchLogs/slave.log.3`

      - `nodes/slave/selenium/launchLogs/slave.log.4`

      - `nodes/slave/selenium/launchLogs/slave.log.5`

      - `nodes/slave/selenium/launchLogs/slave.log.6`

      - `nodes/slave/selenium/launchLogs/slave.log.7`

      - `nodes/slave/selenium/launchLogs/slave.log.8`

      - `nodes/slave/selenium/launchLogs/slave.log.9`

      - `other-logs/Fingerprint cleanup.log`

      - `other-logs/Out of order build detection.log`

      - `other-logs/Workspace clean-up.log`

      - `other-logs/backup.log`

      - `other-logs/jenkins.metrics.api.Metrics$HealthChecker.log`

  * About browser

      - `browser.md`

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `items.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `nodes/slave/CDLTSBUILDCHSL-slave/checksums.md5`

      - `nodes/slave/CDLTSQTPWIN03/checksums.md5`

      - `nodes/slave/CDLTSQTPWIN04/checksums.md5`

      - `plugins/active.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * Administrative monitors

      - `admin-monitors.md`

  * Environment variables

      - `nodes/master/environment.txt`

      - `nodes/slave/CDLTSBUILDCHSL-slave/environment.txt`

      - `nodes/slave/CDLTSQTPWIN03/environment.txt`

      - `nodes/slave/CDLTSQTPWIN04/environment.txt`

  * File descriptors (Unix only)

      - `nodes/master/file-descriptors.txt`

      - `nodes/slave/CDLTSBUILDCHSL-slave/file-descriptors.txt`

  * Metrics

      - `nodes/master/metrics.json`

      - `nodes/slave/CDLTSBUILDCHSL-slave/metrics.json`

      - `nodes/slave/CDLTSQTPWIN03/metrics.json`

      - `nodes/slave/CDLTSQTPWIN04/metrics.json`

  * System properties

      - `nodes/master/system.properties`

      - `nodes/slave/CDLTSBUILDCHSL-slave/system.properties`

      - `nodes/slave/CDLTSQTPWIN03/system.properties`

      - `nodes/slave/CDLTSQTPWIN04/system.properties`

  * Slow Request Records

      - `slow-requests/20150105-054425.511.txt`

  * Deadlock Records

  * Thread dumps

      - `nodes/master/thread-dump.txt`

      - `nodes/slave/CDLTSBUILDCHSL-slave/thread-dump.txt`

      - `nodes/slave/CDLTSQTPWIN03/thread-dump.txt`

      - `nodes/slave/CDLTSQTPWIN04/thread-dump.txt`

