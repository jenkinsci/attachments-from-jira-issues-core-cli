Node statistics
===============

  * Total number of nodes
      - Sample size:        27
      - Average (mean):     4.0
      - Average (median):   4.0
      - Standard deviation: 0.0
      - Minimum:            4
      - Maximum:            4
      - 95th percentile:    4.0
      - 99th percentile:    4.0
  * Total number of nodes online
      - Sample size:        27
      - Average (mean):     2.0
      - Average (median):   2.0
      - Standard deviation: 0.0
      - Minimum:            2
      - Maximum:            2
      - 95th percentile:    2.0
      - 99th percentile:    2.0
  * Total number of executors
      - Sample size:        27
      - Average (mean):     10.0
      - Average (median):   10.0
      - Standard deviation: 0.0
      - Minimum:            10
      - Maximum:            10
      - 95th percentile:    10.0
      - 99th percentile:    10.0
  * Total number of executors in use
      - Sample size:        27
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      5
      - FS root:        `/jenkins/.jenkins`
      - Labels:         master
      - Usage:          `NORMAL`
      - Java
          + Home:           `/usr/java/jdk1.6.0_45/jre`
          + Vendor:           Sun Microsystems Inc.
          + Version:          1.6.0_45
          + Maximum memory:   1.34 GB (1433534464)
          + Allocated memory: 757.62 MB (794427392)
          + Free memory:      377.15 MB (395467216)
          + In-use memory:    380.48 MB (398960176)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.6
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.0
      - JVM Implementation
          + Name:    Java HotSpot(TM) Server VM
          + Vendor:  Sun Microsystems Inc.
          + Version: 20.45-b01
      - Operating system
          + Name:         Linux
          + Architecture: i386
          + Version:      3.0.80-0.7-default
          + Distribution: "SUSE Linux Enterprise Server 11 (x86_64)"
          + LSB Modules:  `core-2.0-noarch:core-3.2-noarch:core-4.0-noarch:core-2.0-x86_64:core-3.2-x86_64:core-4.0-x86_64:desktop-4.0-amd64:desktop-4.0-noarch:graphics-2.0-amd64:graphics-2.0-noarch:graphics-3.2-amd64:graphics-3.2-noarch:graphics-4.0-amd64:graphics-4.0-noarch`
      - Process ID: 21686 (0x54b6)
      - Process started: 2015-01-05 05:42:07.488-0500
      - Process uptime: 7 min 56 sec
      - JVM startup parameters:
          + Boot classpath: `/usr/java/jdk1.6.0_45/jre/lib/resources.jar:/usr/java/jdk1.6.0_45/jre/lib/rt.jar:/usr/java/jdk1.6.0_45/jre/lib/sunrsasign.jar:/usr/java/jdk1.6.0_45/jre/lib/jsse.jar:/usr/java/jdk1.6.0_45/jre/lib/jce.jar:/usr/java/jdk1.6.0_45/jre/lib/charsets.jar:/usr/java/jdk1.6.0_45/jre/lib/modules/jdk.boot.jar:/usr/java/jdk1.6.0_45/jre/classes`
          + Classpath: `/home/appuser/apache-tomcat-7.0.47/bin/bootstrap.jar:/home/appuser/apache-tomcat-7.0.47/bin/tomcat-juli.jar`
          + Library path: `/usr/java/jdk1.6.0_45/jre/lib/i386/server:/usr/java/jdk1.6.0_45/jre/lib/i386:/usr/java/jdk1.6.0_45/jre/../lib/i386:/usr/java/packages/lib/i386:/lib:/usr/lib`
          + arg[0]: `-Djava.util.logging.config.file=/home/appuser/apache-tomcat-7.0.47/conf/logging.properties`
          + arg[1]: `-Djava.util.logging.manager=org.apache.juli.ClassLoaderLogManager`
          + arg[2]: `-Xms512m`
          + arg[3]: `-Xmx1538m`
          + arg[4]: `-XX:PermSize=256m`
          + arg[5]: `-XX:MaxPermSize=512m`
          + arg[6]: `-XX:+CMSClassUnloadingEnabled`
          + arg[7]: `-XX:+CMSPermGenSweepingEnabled`
          + arg[8]: `-XX:+HeapDumpOnOutOfMemoryError`
          + arg[9]: `-XX:ErrorFile=/home/appuser/apache-tomcat-7.0.47/bin/hs_err_pid%p.log`
          + arg[10]: `-Djava.endorsed.dirs=/home/appuser/apache-tomcat-7.0.47/endorsed`
          + arg[11]: `-Dcatalina.base=/home/appuser/apache-tomcat-7.0.47`
          + arg[12]: `-Dcatalina.home=/home/appuser/apache-tomcat-7.0.47`
          + arg[13]: `-Djava.io.tmpdir=/home/appuser/apache-tomcat-7.0.47/temp`

  * CDLTSBUILDCHSL-slave (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      5
      - Remote FS root: `/jenkins/.jenkins`
      - Labels:         slave npm grunt
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.47
      - Java
          + Home:           `/usr/java/jdk1.6.0_45/jre`
          + Vendor:           Sun Microsystems Inc.
          + Version:          1.6.0_45
          + Maximum memory:   867.56 MB (909705216)
          + Allocated memory: 58.44 MB (61276160)
          + Free memory:      42.90 MB (44985960)
          + In-use memory:    15.54 MB (16290200)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.6
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.0
      - JVM Implementation
          + Name:    Java HotSpot(TM) Server VM
          + Vendor:  Sun Microsystems Inc.
          + Version: 20.45-b01
      - Operating system
          + Name:         Linux
          + Architecture: i386
          + Version:      3.0.80-0.7-default
          + Distribution: "SUSE Linux Enterprise Server 11 (x86_64)"
          + LSB Modules:  `core-2.0-noarch:core-3.2-noarch:core-4.0-noarch:core-2.0-x86_64:core-3.2-x86_64:core-4.0-x86_64:desktop-4.0-amd64:desktop-4.0-noarch:graphics-2.0-amd64:graphics-2.0-noarch:graphics-3.2-amd64:graphics-3.2-noarch:graphics-4.0-amd64:graphics-4.0-noarch`
      - Process ID: 14670 (0x394e)
      - Process started: 2015-01-05 05:43:26.859-0500
      - Process uptime: 6 min 36 sec
      - JVM startup parameters:
          + Boot classpath: `/usr/java/jdk1.6.0_45/jre/lib/resources.jar:/usr/java/jdk1.6.0_45/jre/lib/rt.jar:/usr/java/jdk1.6.0_45/jre/lib/sunrsasign.jar:/usr/java/jdk1.6.0_45/jre/lib/jsse.jar:/usr/java/jdk1.6.0_45/jre/lib/jce.jar:/usr/java/jdk1.6.0_45/jre/lib/charsets.jar:/usr/java/jdk1.6.0_45/jre/lib/modules/jdk.boot.jar:/usr/java/jdk1.6.0_45/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/jdk1.6.0_45/jre/lib/i386/server:/usr/java/jdk1.6.0_45/jre/lib/i386:/usr/java/jdk1.6.0_45/jre/../lib/i386:/usr/java/packages/lib/i386:/lib:/usr/lib`

  * CDLTSQTPWIN04 (`hudson.slaves.DumbSlave`)
      - Description:    _selenium slave_
      - Executors:      5
      - Remote FS root: `C:\Users\Administrator\jenkinsSlave`
      - Labels:         (none)
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.33
      - Java
          + Home:           `C:\Program Files\Java\jre7`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_55
          + Maximum memory:   910.50 MB (954728448)
          + Allocated memory: 61.00 MB (63963136)
          + Free memory:      40.39 MB (42354464)
          + In-use memory:    20.61 MB (21608672)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.55-b03
      - Operating system
          + Name:         Windows Server 2008 R2
          + Architecture: amd64
          + Version:      6.1
      - Process ID: 1588 (0x634)
      - Process started: 2014-12-28 00:52:17.625-0500
      - Process uptime: 8 days 4 hr
      - JVM startup parameters:
          + Boot classpath: `C:\Program Files\Java\jre7\lib\resources.jar;C:\Program Files\Java\jre7\lib\rt.jar;C:\Program Files\Java\jre7\lib\sunrsasign.jar;C:\Program Files\Java\jre7\lib\jsse.jar;C:\Program Files\Java\jre7\lib\jce.jar;C:\Program Files\Java\jre7\lib\charsets.jar;C:\Program Files\Java\jre7\lib\jfr.jar;C:\Program Files\Java\jre7\classes;C:\Program Files (x86)\HP\Unified Functional Testing\bin\java_shared\classes;C:\Program Files (x86)\HP\Unified Functional Testing\bin\java_shared\classes\jasmine.jar`
          + Classpath: `C:\jenkinsSlave\slave.jar`
          + Library path: `C:\Program Files\Java\jre7\bin;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;C:\Perl64\site\bin;C:\Perl64\bin;C:\app\Administrator\product\11.2.0\client_1;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;D:\BMCSOF~1\common\globalc\bin\Windows-x86;D:\BMCSOF~1\common\globalc\bin\Windows-x86-64;D:\BMC Software\Patrol3\BEST1\7.4.00\bgs\bin;C:\Program Files (x86)\HP\Unified Functional Testing\bin;C:\Program Files\Java\jdk1.7.0_55\bin;C:\Program Files\Apache Software Foundation\apache-maven-3.2.1\bin;C:\Program Files\TortoiseSVN\bin;C:\Windows\System32;.`
          + arg[0]: `-agentlib:jvmhook`
          + arg[1]: `-Xrs`
          + arg[2]: `-Xrunjvmhook`
          + arg[3]: `-Xbootclasspath/a:C:\Program Files (x86)\HP\Unified Functional Testing\bin\java_shared\classes;C:\Program Files (x86)\HP\Unified Functional Testing\bin\java_shared\classes\jasmine.jar`

  * CDLTSQTPWIN03 (`hudson.slaves.DumbSlave`)
      - Description:    _selenium slave_
      - Executors:      5
      - Remote FS root: `C:\jenkinsSlave`
      - Labels:         (none)
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

