Jenkins
=======

Version details
---------------

  * Version: `1.580.1`
  * Mode:    Webapp Directory
  * Servlet container
      - Specification: 3.0
      - Name:          `Apache Tomcat/7.0.47`
  * Java
      - Home:           `/usr/java/jdk1.6.0_45/jre`
      - Vendor:           Sun Microsystems Inc.
      - Version:          1.6.0_45
      - Maximum memory:   1.34 GB (1433534464)
      - Allocated memory: 757.62 MB (794427392)
      - Free memory:      421.71 MB (442189800)
      - In-use memory:    335.92 MB (352237592)
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Sun Microsystems Inc.
      - Version: 1.6
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Sun Microsystems Inc.
      - Version: 1.0
  * JVM Implementation
      - Name:    Java HotSpot(TM) Server VM
      - Vendor:  Sun Microsystems Inc.
      - Version: 20.45-b01
  * Operating system
      - Name:         Linux
      - Architecture: i386
      - Version:      3.0.80-0.7-default
      - Distribution: "SUSE Linux Enterprise Server 11 (x86_64)"
      - LSB Modules:  `core-2.0-noarch:core-3.2-noarch:core-4.0-noarch:core-2.0-x86_64:core-3.2-x86_64:core-4.0-x86_64:desktop-4.0-amd64:desktop-4.0-noarch:graphics-2.0-amd64:graphics-2.0-noarch:graphics-3.2-amd64:graphics-3.2-noarch:graphics-4.0-amd64:graphics-4.0-noarch`
  * Process ID: 21686 (0x54b6)
  * Process started: 2015-01-05 05:42:07.488-0500
  * Process uptime: 7 min 55 sec
  * JVM startup parameters:
      - Boot classpath: `/usr/java/jdk1.6.0_45/jre/lib/resources.jar:/usr/java/jdk1.6.0_45/jre/lib/rt.jar:/usr/java/jdk1.6.0_45/jre/lib/sunrsasign.jar:/usr/java/jdk1.6.0_45/jre/lib/jsse.jar:/usr/java/jdk1.6.0_45/jre/lib/jce.jar:/usr/java/jdk1.6.0_45/jre/lib/charsets.jar:/usr/java/jdk1.6.0_45/jre/lib/modules/jdk.boot.jar:/usr/java/jdk1.6.0_45/jre/classes`
      - Classpath: `/home/appuser/apache-tomcat-7.0.47/bin/bootstrap.jar:/home/appuser/apache-tomcat-7.0.47/bin/tomcat-juli.jar`
      - Library path: `/usr/java/jdk1.6.0_45/jre/lib/i386/server:/usr/java/jdk1.6.0_45/jre/lib/i386:/usr/java/jdk1.6.0_45/jre/../lib/i386:/usr/java/packages/lib/i386:/lib:/usr/lib`
      - arg[0]: `-Djava.util.logging.config.file=/home/appuser/apache-tomcat-7.0.47/conf/logging.properties`
      - arg[1]: `-Djava.util.logging.manager=org.apache.juli.ClassLoaderLogManager`
      - arg[2]: `-Xms512m`
      - arg[3]: `-Xmx1538m`
      - arg[4]: `-XX:PermSize=256m`
      - arg[5]: `-XX:MaxPermSize=512m`
      - arg[6]: `-XX:+CMSClassUnloadingEnabled`
      - arg[7]: `-XX:+CMSPermGenSweepingEnabled`
      - arg[8]: `-XX:+HeapDumpOnOutOfMemoryError`
      - arg[9]: `-XX:ErrorFile=/home/appuser/apache-tomcat-7.0.47/bin/hs_err_pid%p.log`
      - arg[10]: `-Djava.endorsed.dirs=/home/appuser/apache-tomcat-7.0.47/endorsed`
      - arg[11]: `-Dcatalina.base=/home/appuser/apache-tomcat-7.0.47`
      - arg[12]: `-Dcatalina.home=/home/appuser/apache-tomcat-7.0.47`
      - arg[13]: `-Djava.io.tmpdir=/home/appuser/apache-tomcat-7.0.47/temp`

Important configuration
---------------

  * Security realm: `hudson.plugins.active_directory.ActiveDirectorySecurityRealm`
  * Authorization strategy: `hudson.security.ProjectMatrixAuthorizationStrategy`

Active Plugins
--------------

  * active-directory:1.33 *(update available)* 'Jenkins Active Directory plugin'
  * all-changes:1.3 'All changes plugin'
  * analysis-collector:1.41 'Static Analysis Collector Plug-in'
  * analysis-core:1.65 'Static Analysis Utilities'
  * ant:1.2 'Ant Plugin'
  * antisamy-markup-formatter:1.3 'OWASP Markup Formatter Plugin'
  * backup:1.6.1 'Backup plugin'
  * build-flow-plugin:0.10 *(update available)* 'CloudBees Build Flow plugin'
  * build-pipeline-plugin:1.4.5 'Build Pipeline Plugin'
  * buildgraph-view:1.1.1 'buildgraph-view'
  * checkstyle:3.40 'Checkstyle Plug-in'
  * conditional-buildstep:1.3.3 'conditional-buildstep'
  * credentials:1.20 'Credentials Plugin'
  * cucumber-reports:0.0.23 'cucumber-reports'
  * cvs:2.12 'Jenkins CVS Plug-in'
  * dashboard-view:2.9.4 'Dashboard View'
  * delivery-pipeline-plugin:0.8.8 'Delivery Pipeline Plugin'
  * dry:2.40 'Duplicate Code Scanner Plug-in'
  * email-ext:2.39 'Email Extension Plugin'
  * envinject:1.90 'Environment Injector Plugin'
  * external-monitor-job:1.4 'External Monitor Job Type Plugin'
  * findbugs:4.57 'FindBugs Plug-in'
  * git:2.3.2 'Jenkins GIT plugin'
  * git-client:1.14.0 'Jenkins GIT client plugin'
  * gradle:1.24 'Jenkins Gradle plugin'
  * greenballs:1.14 'Green Balls'
  * groovy:1.24 'Hudson Groovy builder'
  * hp-application-automation-tools-plugin:3.0.6 'HP Application Automation Tools'
  * htmlpublisher:1.3 'HTML Publisher plugin'
  * javadoc:1.3 'Javadoc Plugin'
  * jenkins-multijob-plugin:1.16 'Jenkins Multijob plugin'
  * jobConfigHistory:2.10 'Jenkins Job Configuration History Plugin'
  * jquery:1.7.2-1 'Jenkins jQuery plugin'
  * jshint-checkstyle:3.36 'JSHint Report Plug-in'
  * jslint-checkstyle:3.35 'JSLint Report Plug-in'
  * junit:1.3 'JUnit Plugin'
  * ldap:1.6 *(update available)* 'LDAP Plugin'
  * ldapemail:0.8 'LDAP Email Plugin'
  * mailer:1.12 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.6.0 'MapDB API Plugin'
  * matrix-auth:1.2 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.4 'Matrix Project Plugin'
  * maven-plugin:2.8 'Maven Integration plugin'
  * metrics:3.0.9 'Metrics Plugin'
  * nodelabelparameter:1.5.1 'Node and Label parameter plugin'
  * pam-auth:1.2 'PAM Authentication plugin'
  * parameterized-trigger:2.25 'Jenkins Parameterized Trigger plugin'
  * patch-parameter:1.2 'patch-parameter'
  * pmd:3.39 'PMD Plug-in'
  * role-strategy:2.2.0 'Role-based Authorization Strategy'
  * run-condition:1.0 'Run Condition Plugin'
  * rundeck:3.3 'Jenkins Rundeck plugin'
  * scm-api:0.2 'SCM API Plugin'
  * scp:1.8 'Hudson SCP publisher plugin'
  * script-security:1.12 'Script Security Plugin'
  * seleniumhtmlreport:0.94 'Selenium HTML report'
  * ssh:2.4 'Jenkins SSH plugin'
  * ssh-agent:1.4.1 *(update available)* 'SSH Agent Plugin'
  * ssh-credentials:1.10 'SSH Credentials Plugin'
  * ssh-slaves:1.9 'Jenkins SSH Slaves plugin'
  * subversion:2.4.5 'Jenkins Subversion Plug-in'
  * support-core:2.19 'Support Core Plugin'
  * tasks:4.43 'Task Scanner Plug-in'
  * testng-plugin:1.9.1 'TestNG Results Plugin'
  * token-macro:1.10 'Token Macro Plugin'
  * translation:1.12 'Jenkins Translation Assistance plugin'
  * view-job-filters:1.26 'View Job Filters'
  * violations:0.7.11 'Jenkins Violations plugin'
  * warnings:4.44 'Warnings Plug-in'
  * websphere-deployer:1.2 'WebSphere Deployer Plugin'
  * windows-slaves:1.0 'Windows Slaves Plugin'
