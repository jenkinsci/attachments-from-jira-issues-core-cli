Monitors
========

`hudson.model.UpdateCenter$CoreUpdateMonitor`
--------------
(active and enabled)

`jenkins.diagnosis.HsErrPidList`
--------------
(active and enabled)

`jenkins.security.s2m.MasterKillSwitchWarning`
--------------
(active and enabled)
