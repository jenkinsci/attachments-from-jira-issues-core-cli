Item statistics
===============

  * `com.tikal.jenkins.plugins.multijob.MultiJobProject`
    - Number of items: 37
    - Number of builds per job: 54.91891891891892 [n=37, s=100.0]
  * `hudson.maven.MavenModule`
    - Number of items: 290
    - Number of builds per job: 15.337931034482759 [n=290, s=53.0]
  * `hudson.maven.MavenModuleSet`
    - Number of items: 50
    - Number of builds per job: 47.6 [n=50, s=100.0]
    - Number of items per container: 5.8 [n=50, s=7.0]
  * `hudson.model.FreeStyleProject`
    - Number of items: 33
    - Number of builds per job: 192.57575757575756 [n=33, s=400.0]

Total job statistics
======================

  * Number of jobs: 410
  * Number of builds per job: 37.109756097560975 [n=410, s=150.0]
