package org.example;

import hudson.cli.CLI;
import hudson.model.FreeStyleProject;
import hudson.remoting.Callable;
import hudson.remoting.Channel;

import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.net.URL;
import java.security.KeyPair;
import java.security.PublicKey;
import java.util.Collections;

import jenkins.model.Jenkins;
import junit.framework.TestCase;

public class ChannelClientTest extends TestCase implements Serializable {

	public void testChannel() throws Exception{
		CLI cli = new CLI(new URL("http://localhost:8090"));
		
		try {
			KeyPair key = cli.loadKey(new File("channel-key"));
			PublicKey server = cli.authenticate(Collections.singleton(key));
			cli.upgrade();
			
			Channel channel = cli.getChannel();
			
			String version = channel.call(new Callable<String,IOException>() {
				public String call() throws IOException {
					Jenkins jenkins = Jenkins.getInstance();
					FreeStyleProject prj = jenkins.createProject(FreeStyleProject.class,Long.toString(System.currentTimeMillis()));
					return Jenkins.getVersion().toString();
				}
			});
			
			System.out.println("*** version = "+version);
		}finally{
			cli.close();
		}
	}
}
