#!/bin/sh

mvn clean package -Dmaven.test.skip=true hpi:run -Djetty.port=8090
