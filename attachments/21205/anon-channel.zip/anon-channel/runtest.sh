#!/bin/bash

mvn test
