Support Bundle Manifest
=======================

Generated on 2013-12-11 11:38:04 -0500

Requested components:

  * About browser

      - `browser.md`

  * About Jenkins

      - `about.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `nodes/slave/PRDJENK201/checksums.md5`

      - `nodes/slave/VDIQTPTaskW704/checksums.md5`

      - `plugins/active.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * About user (basic authentication details only)

      - `user.md`

  * Environment variables

      - `nodes/master/environment.txt`

      - `nodes/slave/PRDJENK201/environment.txt`

      - `nodes/slave/VDIQTPTaskW704/environment.txt`

  * Metrics

      - `nodes/master/metrics.json`

      - `nodes/slave/PRDJENK201/metrics.json`

      - `nodes/slave/VDIQTPTaskW704/metrics.json`

  * System properties

      - `nodes/master/system.properties`

      - `nodes/slave/PRDJENK201/system.properties`

      - `nodes/slave/VDIQTPTaskW704/system.properties`

  * Thread dumps

      - `nodes/master/thread-dump.txt`

      - `nodes/slave/PRDJENK201/thread-dump.txt`

      - `nodes/slave/VDIQTPTaskW704/thread-dump.txt`

