﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Diagnostics;
using System.Security;
using System.Reflection;

namespace LF2CharRefXmlEncoder {
    class CustomXmlWriter : XmlWrappingWriter {
        public CustomXmlWriter(string file, XmlWriterSettings settings)
            : base(XmlWriter.Create(file, settings)) {
        }

        public override void WriteString(string text) {
            if(text.Contains("\n")) {
                text = SecurityElement.Escape(text).Replace("\r\n", "\n").Replace("\n", "&#xA;");
                base.WriteRaw(text);
            }
            else {
                base.WriteString(text);
            }
        }
    }

    class Program {
        static int Main(string[] args) {
            try {
                var an = Assembly.GetExecutingAssembly().GetName();
                Console.WriteLine(an.Name + " v" + an.Version);
                Console.WriteLine(
                        "\r\nReplaces with the char reference '&#xA' all occurences of"
                        + " '\\r\\n' or '\\n' found in\r\nelements' text from a specified XML file."
                        + " The result is written back to the same file.\r\n"
                    );
                Console.WriteLine("Processing: " + args[0]);

                Console.WriteLine("Loading the file...");
                XmlDocument xd = new XmlDocument();
                xd.Load(args[0]);

                // Preparing XmlWriterSettings
                var xws = new XmlWriterSettings();
                xws.CheckCharacters = true;
                xws.CloseOutput = true;
                xws.ConformanceLevel = ConformanceLevel.Document;
                xws.Encoding = Encoding.UTF8;
                xws.Indent = true;
                xws.IndentChars = "  ";
                xws.NewLineChars = "\r\n";
                xws.NewLineHandling = NewLineHandling.None;
                xws.OmitXmlDeclaration = false;

                Console.WriteLine("Replacing and overwriting the file with the result...");
                var xw = new CustomXmlWriter(args[0], xws);
                xd.WriteTo(xw);
                xw.Close();

                Console.WriteLine("Testing the result...");
                xd.Load(args[0]);
            }
            catch(Exception ex) {
                Console.WriteLine("ERROR: " + ex.Message);
                return 20;
            }
            Console.WriteLine("File processed successfully");
            if(Debugger.IsAttached) Console.ReadLine();
            return 0;
        }
    }
}