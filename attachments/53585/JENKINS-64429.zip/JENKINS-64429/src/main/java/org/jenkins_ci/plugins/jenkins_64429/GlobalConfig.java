package org.jenkins_ci.plugins.jenkins_64429;

import org.kohsuke.stapler.QueryParameter;

import hudson.Extension;
import hudson.model.AbstractDescribableImpl;
import hudson.model.Descriptor;
import hudson.util.FormValidation;

public class GlobalConfig extends AbstractDescribableImpl<GlobalConfig> {


    @Extension
    public static class DesriptorImpl extends Descriptor<GlobalConfig> {

        private int myField = -1;

        public int getMyField() {
            return myField;
        }

        public void setMyField(int myField) {
            this.myField = myField;
        }

        public FormValidation doCheckMyField(@QueryParameter String value) {
            return FormValidation.validatePositiveInteger(value);
        }

    }

}
