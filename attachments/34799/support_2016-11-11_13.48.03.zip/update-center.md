=== Sites ===
 - Url: http://updates.jenkins-ci.org/update-center.json
 - Connection Url: http://www.google.com/
 - Implementation Type: hudson.model.UpdateSite
======
Last updated: 40 Sekunden
=== Proxy ===
