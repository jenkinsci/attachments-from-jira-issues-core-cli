Node statistics
===============

  * Total number of nodes
      - Sample size:        2
      - Average (mean):     1.0
      - Average (median):   1.0
      - Standard deviation: 0.0
      - Minimum:            1
      - Maximum:            1
      - 95th percentile:    1.0
      - 99th percentile:    1.0
  * Total number of nodes online
      - Sample size:        2
      - Average (mean):     1.0
      - Average (median):   1.0
      - Standard deviation: 0.0
      - Minimum:            1
      - Maximum:            1
      - 95th percentile:    1.0
      - 99th percentile:    1.0
  * Total number of executors
      - Sample size:        2
      - Average (mean):     2.0
      - Average (median):   2.0
      - Standard deviation: 0.0
      - Minimum:            2
      - Maximum:            2
      - 95th percentile:    2.0
      - 99th percentile:    2.0
  * Total number of executors in use
      - Sample size:        2
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _Jenkins Master-Knoten_
      - Executors:      2
      - FS root:        `D:\Software\Jenkins`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Slave Version:  3.0
      - Java
          + Home:           `D:\Software\Jenkins\jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_66
          + Maximum memory:   247.50 MB (259522560)
          + Allocated memory: 119.04 MB (124817408)
          + Free memory:      59.46 MB (62348040)
          + In-use memory:    59.58 MB (62469368)
          + GC strategy:      SerialGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) Client VM
          + Vendor:  Oracle Corporation
          + Version: 25.66-b18
      - Operating system
          + Name:         Windows Server 2012 R2
          + Architecture: x86
          + Version:      6.3
      - Process ID: 5564 (0x15bc)
      - Process started: 2016-11-11 14:46:34.824+0100
      - Process uptime: 1 Minute 30 Sekunden
      - JVM startup parameters:
          + Boot classpath: `D:\Software\Jenkins\jre\lib\resources.jar;D:\Software\Jenkins\jre\lib\rt.jar;D:\Software\Jenkins\jre\lib\sunrsasign.jar;D:\Software\Jenkins\jre\lib\jsse.jar;D:\Software\Jenkins\jre\lib\jce.jar;D:\Software\Jenkins\jre\lib\charsets.jar;D:\Software\Jenkins\jre\lib\jfr.jar;D:\Software\Jenkins\jre\classes`
          + Classpath: `D:\Software\Jenkins\jenkins.war`
          + Library path: `D:\Software\Jenkins\jre\bin;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;.`
          + arg[0]: `-Xrs`
          + arg[1]: `-Xmx256m`
          + arg[2]: `-Dhudson.lifecycle=hudson.lifecycle.WindowsServiceLifecycle`

