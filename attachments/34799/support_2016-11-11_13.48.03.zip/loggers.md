Loggers currently enabled
=========================
com4j.EventProxy - OFF
org.jenkinsci.plugins.periodicbackup - ALL
winstone - INFO
org.apache.sshd - WARNING
 - INFO
