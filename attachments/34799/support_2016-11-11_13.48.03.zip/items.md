Item statistics
===============

  * `hudson.model.FreeStyleProject`
    - Number of items: 17
    - Number of builds per job: 80.17647058823529 [n=17, s=70.0]

Total job statistics
======================

  * Number of jobs: 17
  * Number of builds per job: 80.17647058823529 [n=17, s=70.0]
