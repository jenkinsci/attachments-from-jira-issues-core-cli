Loggers currently enabled
=========================
hudson.plugins.scm_sync_configuration - ALL
winstone - INFO
hudson.plugins.active_directory - ALL
org.apache.sshd - WARNING
 - INFO
