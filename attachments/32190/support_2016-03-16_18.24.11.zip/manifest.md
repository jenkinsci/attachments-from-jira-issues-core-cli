Support Bundle Manifest
=======================

Generated on 2016-03-16 14:24:11.567-0400

Requested components:

  * Log Recorders

      - `nodes/master/logs/all_2016-03-16_18.22.41.log`

      - `nodes/master/logs/all_memory_buffer.log`

      - `nodes/master/logs/custom/SCM_Sync.log`

      - `nodes/master/logs/custom/active_directory.log`

      - `nodes/master/logs/jenkins.log`

      - `nodes/slave/ATL7ACC1195Q/jenkins.log`

      - `nodes/slave/ATL7ACC1195Q/logs/all_memory_buffer.log`

      - `nodes/slave/ATL7ACC1196Q/jenkins.log`

      - `nodes/slave/ATL7ACC1196Q/logs/all_memory_buffer.log`

      - `nodes/slave/ATL7ACC1197Q/jenkins.log`

      - `nodes/slave/ATL7ACC1197Q/logs/all_memory_buffer.log`

      - `nodes/slave/ATL7ACC1198Q/jenkins.log`

      - `nodes/slave/ATL7ACC1198Q/logs/all_memory_buffer.log`

      - `nodes/slave/ATL7ACC1199Q/jenkins.log`

      - `nodes/slave/ATL7ACC1199Q/logs/all_memory_buffer.log`

      - `nodes/slave/ATL7ACC1200Q/jenkins.log`

      - `nodes/slave/ATL7ACC1200Q/logs/all_memory_buffer.log`

      - `nodes/slave/ATL7ACC1201Q/jenkins.log`

      - `nodes/slave/ATL7ACC1201Q/logs/all_memory_buffer.log`

      - `nodes/slave/ATL7ACC1202Q/jenkins.log`

      - `nodes/slave/ATL7ACC1202Q/logs/all_memory_buffer.log`

      - `nodes/slave/ATL7ACC1203Q/jenkins.log`

      - `nodes/slave/ATL7ACC1203Q/logs/all_memory_buffer.log`

      - `nodes/slave/ATL7ACC1204Q/jenkins.log`

      - `nodes/slave/ATL7ACC1204Q/logs/all_memory_buffer.log`

      - `other-logs/jenkins.log`

      - `other-logs/jenkins.metrics.api.Metrics$HealthChecker.log`

      - `other-logs/scm-sync-configuration.success.log`

  * About browser

      - `browser.md`

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `items.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `nodes/slave/ATL7ACC1195Q/checksums.md5`

      - `nodes/slave/ATL7ACC1196Q/checksums.md5`

      - `nodes/slave/ATL7ACC1197Q/checksums.md5`

      - `nodes/slave/ATL7ACC1198Q/checksums.md5`

      - `nodes/slave/ATL7ACC1199Q/checksums.md5`

      - `nodes/slave/ATL7ACC1200Q/checksums.md5`

      - `nodes/slave/ATL7ACC1201Q/checksums.md5`

      - `nodes/slave/ATL7ACC1202Q/checksums.md5`

      - `nodes/slave/ATL7ACC1203Q/checksums.md5`

      - `nodes/slave/ATL7ACC1204Q/checksums.md5`

      - `plugins/active.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * About user (basic authentication details only)

      - `user.md`

  * Administrative monitors

      - `admin-monitors.md`

  * Build queue

      - `buildqueue.md`

  * Dump slave export tables (could reveal some memory leaks)

      - `nodes/slave/ATL7ACC1195Q/exportTable.txt`

      - `nodes/slave/ATL7ACC1196Q/exportTable.txt`

      - `nodes/slave/ATL7ACC1197Q/exportTable.txt`

      - `nodes/slave/ATL7ACC1198Q/exportTable.txt`

      - `nodes/slave/ATL7ACC1199Q/exportTable.txt`

      - `nodes/slave/ATL7ACC1200Q/exportTable.txt`

      - `nodes/slave/ATL7ACC1201Q/exportTable.txt`

      - `nodes/slave/ATL7ACC1202Q/exportTable.txt`

      - `nodes/slave/ATL7ACC1203Q/exportTable.txt`

      - `nodes/slave/ATL7ACC1204Q/exportTable.txt`

  * Environment variables

      - `nodes/master/environment.txt`

      - `nodes/slave/ATL7ACC1195Q/environment.txt`

      - `nodes/slave/ATL7ACC1196Q/environment.txt`

      - `nodes/slave/ATL7ACC1197Q/environment.txt`

      - `nodes/slave/ATL7ACC1198Q/environment.txt`

      - `nodes/slave/ATL7ACC1199Q/environment.txt`

      - `nodes/slave/ATL7ACC1200Q/environment.txt`

      - `nodes/slave/ATL7ACC1201Q/environment.txt`

      - `nodes/slave/ATL7ACC1202Q/environment.txt`

      - `nodes/slave/ATL7ACC1203Q/environment.txt`

      - `nodes/slave/ATL7ACC1204Q/environment.txt`

  * File descriptors (Unix only)

      - `nodes/master/file-descriptors.txt`

  * JVM process system metrics (Linux only)

      - `nodes/master/proc/meminfo.txt`

      - `nodes/master/proc/self/cmdline`

      - `nodes/master/proc/self/environ`

      - `nodes/master/proc/self/limits.txt`

      - `nodes/master/proc/self/status.txt`

  * Load Statistics

      - `load-stats/label/ATL7ACC1195Q/gnuplot`

      - `load-stats/label/ATL7ACC1195Q/hour.csv`

      - `load-stats/label/ATL7ACC1195Q/min.csv`

      - `load-stats/label/ATL7ACC1195Q/sec10.csv`

      - `load-stats/label/ATL7ACC1196Q/gnuplot`

      - `load-stats/label/ATL7ACC1196Q/hour.csv`

      - `load-stats/label/ATL7ACC1196Q/min.csv`

      - `load-stats/label/ATL7ACC1196Q/sec10.csv`

      - `load-stats/label/ATL7ACC1197Q/gnuplot`

      - `load-stats/label/ATL7ACC1197Q/hour.csv`

      - `load-stats/label/ATL7ACC1197Q/min.csv`

      - `load-stats/label/ATL7ACC1197Q/sec10.csv`

      - `load-stats/label/ATL7ACC1198Q/gnuplot`

      - `load-stats/label/ATL7ACC1198Q/hour.csv`

      - `load-stats/label/ATL7ACC1198Q/min.csv`

      - `load-stats/label/ATL7ACC1198Q/sec10.csv`

      - `load-stats/label/ATL7ACC1199Q/gnuplot`

      - `load-stats/label/ATL7ACC1199Q/hour.csv`

      - `load-stats/label/ATL7ACC1199Q/min.csv`

      - `load-stats/label/ATL7ACC1199Q/sec10.csv`

      - `load-stats/label/ATL7ACC1200Q/gnuplot`

      - `load-stats/label/ATL7ACC1200Q/hour.csv`

      - `load-stats/label/ATL7ACC1200Q/min.csv`

      - `load-stats/label/ATL7ACC1200Q/sec10.csv`

      - `load-stats/label/ATL7ACC1201Q/gnuplot`

      - `load-stats/label/ATL7ACC1201Q/hour.csv`

      - `load-stats/label/ATL7ACC1201Q/min.csv`

      - `load-stats/label/ATL7ACC1201Q/sec10.csv`

      - `load-stats/label/ATL7ACC1202Q/gnuplot`

      - `load-stats/label/ATL7ACC1202Q/hour.csv`

      - `load-stats/label/ATL7ACC1202Q/min.csv`

      - `load-stats/label/ATL7ACC1202Q/sec10.csv`

      - `load-stats/label/ATL7ACC1203Q/gnuplot`

      - `load-stats/label/ATL7ACC1203Q/hour.csv`

      - `load-stats/label/ATL7ACC1203Q/min.csv`

      - `load-stats/label/ATL7ACC1203Q/sec10.csv`

      - `load-stats/label/ATL7ACC1204Q/gnuplot`

      - `load-stats/label/ATL7ACC1204Q/hour.csv`

      - `load-stats/label/ATL7ACC1204Q/min.csv`

      - `load-stats/label/ATL7ACC1204Q/sec10.csv`

      - `load-stats/label/Any/gnuplot`

      - `load-stats/label/Any/hour.csv`

      - `load-stats/label/Any/min.csv`

      - `load-stats/label/Any/sec10.csv`

      - `load-stats/label/Jalenium/gnuplot`

      - `load-stats/label/Jalenium/hour.csv`

      - `load-stats/label/Jalenium/min.csv`

      - `load-stats/label/Jalenium/sec10.csv`

      - `load-stats/label/Linux/gnuplot`

      - `load-stats/label/Linux/hour.csv`

      - `load-stats/label/Linux/min.csv`

      - `load-stats/label/Linux/sec10.csv`

      - `load-stats/label/Turbot/gnuplot`

      - `load-stats/label/Turbot/hour.csv`

      - `load-stats/label/Turbot/min.csv`

      - `load-stats/label/Turbot/sec10.csv`

      - `load-stats/label/Windows/gnuplot`

      - `load-stats/label/Windows/hour.csv`

      - `load-stats/label/Windows/min.csv`

      - `load-stats/label/Windows/sec10.csv`

      - `load-stats/label/master/gnuplot`

      - `load-stats/label/master/hour.csv`

      - `load-stats/label/master/min.csv`

      - `load-stats/label/master/sec10.csv`

      - `load-stats/no-label/gnuplot`

      - `load-stats/no-label/hour.csv`

      - `load-stats/no-label/min.csv`

      - `load-stats/no-label/sec10.csv`

      - `load-stats/overall/gnuplot`

      - `load-stats/overall/hour.csv`

      - `load-stats/overall/min.csv`

      - `load-stats/overall/sec10.csv`

  * All loggers currently enabled.

      - `loggers.md`

  * Metrics

      - `nodes/master/metrics.json`

      - `nodes/slave/ATL7ACC1195Q/metrics.json`

      - `nodes/slave/ATL7ACC1196Q/metrics.json`

      - `nodes/slave/ATL7ACC1197Q/metrics.json`

      - `nodes/slave/ATL7ACC1198Q/metrics.json`

      - `nodes/slave/ATL7ACC1199Q/metrics.json`

      - `nodes/slave/ATL7ACC1200Q/metrics.json`

      - `nodes/slave/ATL7ACC1201Q/metrics.json`

      - `nodes/slave/ATL7ACC1202Q/metrics.json`

      - `nodes/slave/ATL7ACC1203Q/metrics.json`

      - `nodes/slave/ATL7ACC1204Q/metrics.json`

  * Networking Interface

      - `nodes/master/networkInterface.md`

      - `nodes/slave/ATL7ACC1195Q/networkInterface.md`

      - `nodes/slave/ATL7ACC1196Q/networkInterface.md`

      - `nodes/slave/ATL7ACC1197Q/networkInterface.md`

      - `nodes/slave/ATL7ACC1198Q/networkInterface.md`

      - `nodes/slave/ATL7ACC1199Q/networkInterface.md`

      - `nodes/slave/ATL7ACC1200Q/networkInterface.md`

      - `nodes/slave/ATL7ACC1201Q/networkInterface.md`

      - `nodes/slave/ATL7ACC1202Q/networkInterface.md`

      - `nodes/slave/ATL7ACC1203Q/networkInterface.md`

      - `nodes/slave/ATL7ACC1204Q/networkInterface.md`

  * System configuration (Linux only)

      - `nodes/master/dmesg.txt`

      - `nodes/master/dmi.txt`

      - `nodes/master/proc/cpuinfo.txt`

      - `nodes/master/proc/mounts.txt`

      - `nodes/master/proc/swaps.txt`

      - `nodes/master/proc/system-uptime.txt`

      - `nodes/master/sysctl.txt`

      - `nodes/master/userid.txt`

  * System properties

      - `nodes/master/system.properties`

      - `nodes/slave/ATL7ACC1195Q/system.properties`

      - `nodes/slave/ATL7ACC1196Q/system.properties`

      - `nodes/slave/ATL7ACC1197Q/system.properties`

      - `nodes/slave/ATL7ACC1198Q/system.properties`

      - `nodes/slave/ATL7ACC1199Q/system.properties`

      - `nodes/slave/ATL7ACC1200Q/system.properties`

      - `nodes/slave/ATL7ACC1201Q/system.properties`

      - `nodes/slave/ATL7ACC1202Q/system.properties`

      - `nodes/slave/ATL7ACC1203Q/system.properties`

      - `nodes/slave/ATL7ACC1204Q/system.properties`

  * Update Center

      - `update-center.md`

  * Slow Request Records

  * Deadlock Records

  * Thread dumps

      - `nodes/master/thread-dump.txt`

      - `nodes/slave/ATL7ACC1195Q/thread-dump.txt`

      - `nodes/slave/ATL7ACC1196Q/thread-dump.txt`

      - `nodes/slave/ATL7ACC1197Q/thread-dump.txt`

      - `nodes/slave/ATL7ACC1198Q/thread-dump.txt`

      - `nodes/slave/ATL7ACC1199Q/thread-dump.txt`

      - `nodes/slave/ATL7ACC1200Q/thread-dump.txt`

      - `nodes/slave/ATL7ACC1201Q/thread-dump.txt`

      - `nodes/slave/ATL7ACC1202Q/thread-dump.txt`

      - `nodes/slave/ATL7ACC1203Q/thread-dump.txt`

      - `nodes/slave/ATL7ACC1204Q/thread-dump.txt`

