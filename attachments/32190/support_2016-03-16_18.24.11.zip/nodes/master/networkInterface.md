-----------
 * Name eth1
 ** Hardware Address - 00505698414d
 ** Index - 3
 ** InetAddress - /10.231.76.157
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name eth0
 ** Hardware Address - 00505698414b
 ** Index - 2
 ** InetAddress - /10.229.28.157
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /127.0.0.1
 ** MTU - 16436
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false
