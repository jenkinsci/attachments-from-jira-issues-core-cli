Node statistics
===============

  * Total number of nodes
      - Sample size:        5
      - Average (mean):     10.999999999999998
      - Average (median):   11.0
      - Standard deviation: 1.7763568394002503E-15
      - Minimum:            11
      - Maximum:            11
      - 95th percentile:    11.0
      - 99th percentile:    11.0
  * Total number of nodes online
      - Sample size:        5
      - Average (mean):     0.9999999999999999
      - Average (median):   1.0
      - Standard deviation: 1.1102230246251564E-16
      - Minimum:            1
      - Maximum:            1
      - 95th percentile:    1.0
      - 99th percentile:    1.0
  * Total number of executors
      - Sample size:        5
      - Average (mean):     3.0
      - Average (median):   3.0
      - Standard deviation: 0.0
      - Minimum:            3
      - Maximum:            3
      - 95th percentile:    3.0
      - 99th percentile:    3.0
  * Total number of executors in use
      - Sample size:        5
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      3
      - FS root:        `/data/jenkins`
      - Labels:         Any Linux Turbot
      - Usage:          `NORMAL`
      - Slave Version:  2.53.3
      - Java
          + Home:           `/data/utils/jdk1.8.0_66/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_66
          + Maximum memory:   878.50 MB (921174016)
          + Allocated memory: 398.50 MB (417857536)
          + Free memory:      249.41 MB (261528376)
          + In-use memory:    149.09 MB (156329160)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.66-b17
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.18-402.el5
          + Distribution: "Red Hat Enterprise Linux Server release 5.11 (Tikanga)"
          + LSB Modules:  `:atc_cs_phase-0.5:atc_imagever-1.3.5-dev:client-config-overrides.txt:client_config_update.py:core-4.0-amd64:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-noarch`
      - Process ID: 29705 (0x7409)
      - Process started: 2016-03-16 14:22:37.547-0400
      - Process uptime: 1 min 34 sec
      - JVM startup parameters:
          + Boot classpath: `/data/utils/jdk1.8.0_66/jre/lib/resources.jar:/data/utils/jdk1.8.0_66/jre/lib/rt.jar:/data/utils/jdk1.8.0_66/jre/lib/sunrsasign.jar:/data/utils/jdk1.8.0_66/jre/lib/jsse.jar:/data/utils/jdk1.8.0_66/jre/lib/jce.jar:/data/utils/jdk1.8.0_66/jre/lib/charsets.jar:/data/utils/jdk1.8.0_66/jre/lib/jfr.jar:/data/utils/jdk1.8.0_66/jre/classes`
          + Classpath: `jenkins.war`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * ATL7ACC1195Q (`hudson.slaves.DumbSlave`)
      - Description:    _Jalenium windows slave server_
      - Executors:      3
      - Remote FS root: `C:\Jenkins`
      - Labels:         Jalenium Windows
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * ATL7ACC1196Q (`hudson.slaves.DumbSlave`)
      - Description:    _Jalenium windows slave server_
      - Executors:      3
      - Remote FS root: `C:\Jenkins`
      - Labels:         Jalenium Windows
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * ATL7ACC1197Q (`hudson.slaves.DumbSlave`)
      - Description:    _Jalenium windows slave server_
      - Executors:      3
      - Remote FS root: `C:\Jenkins`
      - Labels:         Jalenium Windows
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * ATL7ACC1198Q (`hudson.slaves.DumbSlave`)
      - Description:    _Jalenium windows slave server_
      - Executors:      3
      - Remote FS root: `C:\Jenkins`
      - Labels:         Jalenium Windows
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * ATL7ACC1199Q (`hudson.slaves.DumbSlave`)
      - Description:    _Jalenium windows slave server_
      - Executors:      3
      - Remote FS root: `C:\Jenkins`
      - Labels:         Jalenium Windows
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * ATL7ACC1200Q (`hudson.slaves.DumbSlave`)
      - Description:    _Jalenium windows slave server_
      - Executors:      3
      - Remote FS root: `C:\Jenkins`
      - Labels:         Jalenium Windows
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * ATL7ACC1201Q (`hudson.slaves.DumbSlave`)
      - Description:    _Jalenium windows slave server_
      - Executors:      3
      - Remote FS root: `C:\Jenkins`
      - Labels:         Jalenium Windows
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * ATL7ACC1202Q (`hudson.slaves.DumbSlave`)
      - Description:    _Jalenium windows slave server_
      - Executors:      3
      - Remote FS root: `C:\Jenkins`
      - Labels:         Jalenium Windows
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * ATL7ACC1203Q (`hudson.slaves.DumbSlave`)
      - Description:    _Jalenium windows slave server_
      - Executors:      3
      - Remote FS root: `C:\Jenkins`
      - Labels:         Jalenium Windows
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * ATL7ACC1204Q (`hudson.slaves.DumbSlave`)
      - Description:    _Jalenium windows slave server_
      - Executors:      3
      - Remote FS root: `C:\Jenkins`
      - Labels:         Jalenium Windows
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

