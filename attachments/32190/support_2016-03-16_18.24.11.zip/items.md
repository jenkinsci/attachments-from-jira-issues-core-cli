Item statistics
===============

  * `hudson.model.FreeStyleProject`
    - Number of items: 5
    - Number of builds per job: 0.0 [n=5, s=0.0]

Total job statistics
======================

  * Number of jobs: 5
  * Number of builds per job: 0.0 [n=5, s=0.0]
