Browser
=======

  * Screen size: 1920x1080
  * User Agent
      - Type:     Browser
      - Name:     Chrome
      - Family:   CHROME
      - Producer: Google Inc.
      - Version:  49.0.2623.87
      - Raw:      `Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.87 Safari/537.36`
  * Operating System
      - Name:     Windows 7
      - Family:   WINDOWS
      - Producer: Microsoft Corporation.
      - Version:  6.1

