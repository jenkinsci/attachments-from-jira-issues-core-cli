User
====

Authentication
--------------

  * Authenticated: true
  * Name: bswilson
  * Authorities 
      - `authenticated`
      - `MIQ_Provision_ATC_TAXI`
      - `VPNG_JNPPHUB`
      - `authenticated`
      - `AT - AppDev - Quality Assurance`
      - `VPNG_JNPSNOW`
      - `~ATG - IT Diagrams`
      - `BOXG_ATGITDIAGRAMS_R`
      - `ATL_Accelerator`
      - `AT - NewServerChecklist`
      - `Users`
      - `ATLG_QATEAM`
      - `CAR_FL_FINANCIAL_REPORTING_CPR_V3`
      - `SMS_REPORTVIEWER`
      - `SPSG_StratOppsCCGV`
      - `SPSG_ITProjectsV`
      - `CAR_FL_FINANCIAL_REPORTING_CPR`
      - `CORG_CONTRACTORS`
      - `AT - AppDev-Employees&Contractors`
      - `SPSG_MOSSTechV`
      - `SPSG_StratOppsInterV`
      - `ATL_MICORPUSERS`
      - `SPL_search_all`
      - `VPNG_COLOUSER`
      - `SPSG_SalesV`
      - `SPSG_StratOppsPartV`
      - `ATLG_CDRPITRWork_R`
      - `ATL_QATEAM`
      - `SPSG_DealerSiteV`
      - `SPSG_BusinessSysV`
      - `SPSG_ITBusinessOpsV`
      - `CAR_FL_CUSTOMER_MASTER`
      - `PITG_CONUSERS`
      - `VPNG_JNPBASE`
      - `ATLG_Accelerator`
      - `CARG_FL_FINANCIAL_REPORTING`
      - `CARG_FL_FINANCIAL_RPT_NEWS`
      - `ATLG_DATAUSERS`
      - `CAI_Contractors`
      - `CARG_FL_CUSTOMER_MASTER`
      - `CAR_FL_FINANCIAL_REPORTING`
      - `CAI_6TALK`
      - `ATL_EDMUNDS`
      - `CF_QA_ACCELERATOR`
      - `AWSG_LABS2-PowerUser`
      - `VPNG_SVN`
      - `SPSG_ITOpsAvailMgmtV`
      - `SPSG_TechOpsWSGV`
      - `SPSG_ITOpsV`
      - `AT - Preprod Users`
      - `ATL_ProteusR`
      - `ATLG_MICORPUSERS`
      - `Allowed RODC Password Replication Group`
      - `ATL_CDRPITRWork_R`
      - `SMSG_REPORTVIEWER`
      - `SPSG_ReleaseManV`
      - `AT - Mail Users`
      - `AT - Quality Assurance`
      - `ATL_MIO365`
      - `AT - Automation`
      - `CARG_FL_ESO_ORDER_VIEW`
      - `OWA`
      - `ATL_CRMReportingGroup`
      - `ATLG_EDMUNDS`
      - `SPSG_InfoTechV`
      - `BOXG_ATCSALES_LMV_TEST`
      - `BSM_CMDBoperator`
      - `BOXG_EVERYONE_R`
      - `BSM_Viewers`
      - `AT - PreProd`
      - `SPSG_UnixV`
      - `AWSG_OneDay`
      - `ATL_CRMUserGroup`
      - `ATLG_QA-AcceleratorVM`
      - `ATLMailUsers`
      - `JIV_USERS_ALL`
      - `VPNG_CONTRACTOR`
      - `AT - Atlanta Mail Users`
      - `SPSG_stm`
      - `CARG_FL_FINANCIAL_REPORTING_CPR`
      - `Domain Users`
      - `SPSG_StratOppsV`
      - `VPNG_QA-AUTOMATION-FRAMEWORK`
      - `AT - ProductDev-SVN`
      - `ATLG_MIO365`
      - `BSM_OOviewer`
      - `CARG_FL_FINANCIAL_REPORTING_CPR_V3`
  * Raw: `org.acegisecurity.providers.rememberme.RememberMeAuthenticationToken@7e3e02c4: Username: org.acegisecurity.userdetails.User@0: Username: bswilson; Password: [PROTECTED]; Enabled: true; AccountNonExpired: true; credentialsNonExpired: true; AccountNonLocked: true; Granted Authorities: authenticated, MIQ_Provision_ATC_TAXI, VPNG_JNPPHUB, authenticated, AT - AppDev - Quality Assurance, VPNG_JNPSNOW, ~ATG - IT Diagrams, BOXG_ATGITDIAGRAMS_R, ATL_Accelerator, AT - NewServerChecklist, Users, ATLG_QATEAM, CAR_FL_FINANCIAL_REPORTING_CPR_V3, SMS_REPORTVIEWER, SPSG_StratOppsCCGV, SPSG_ITProjectsV, CAR_FL_FINANCIAL_REPORTING_CPR, CORG_CONTRACTORS, AT - AppDev-Employees&Contractors, SPSG_MOSSTechV, SPSG_StratOppsInterV, ATL_MICORPUSERS, SPL_search_all, VPNG_COLOUSER, SPSG_SalesV, SPSG_StratOppsPartV, ATLG_CDRPITRWork_R, ATL_QATEAM, SPSG_DealerSiteV, SPSG_BusinessSysV, SPSG_ITBusinessOpsV, CAR_FL_CUSTOMER_MASTER, PITG_CONUSERS, VPNG_JNPBASE, ATLG_Accelerator, CARG_FL_FINANCIAL_REPORTING, CARG_FL_FINANCIAL_RPT_NEWS, ATLG_DATAUSERS, CAI_Contractors, CARG_FL_CUSTOMER_MASTER, CAR_FL_FINANCIAL_REPORTING, CAI_6TALK, ATL_EDMUNDS, CF_QA_ACCELERATOR, AWSG_LABS2-PowerUser, VPNG_SVN, SPSG_ITOpsAvailMgmtV, SPSG_TechOpsWSGV, SPSG_ITOpsV, AT - Preprod Users, ATL_ProteusR, ATLG_MICORPUSERS, Allowed RODC Password Replication Group, ATL_CDRPITRWork_R, SMSG_REPORTVIEWER, SPSG_ReleaseManV, AT - Mail Users, AT - Quality Assurance, ATL_MIO365, AT - Automation, CARG_FL_ESO_ORDER_VIEW, OWA, ATL_CRMReportingGroup, ATLG_EDMUNDS, SPSG_InfoTechV, BOXG_ATCSALES_LMV_TEST, BSM_CMDBoperator, BOXG_EVERYONE_R, BSM_Viewers, AT - PreProd, SPSG_UnixV, AWSG_OneDay, ATL_CRMUserGroup, ATLG_QA-AcceleratorVM, ATLMailUsers, JIV_USERS_ALL, VPNG_CONTRACTOR, AT - Atlanta Mail Users, SPSG_stm, CARG_FL_FINANCIAL_REPORTING_CPR, Domain Users, SPSG_StratOppsV, VPNG_QA-AUTOMATION-FRAMEWORK, AT - ProductDev-SVN, ATLG_MIO365, BSM_OOviewer, CARG_FL_FINANCIAL_REPORTING_CPR_V3; Password: [PROTECTED]; Authenticated: true; Details: org.acegisecurity.ui.WebAuthenticationDetails@fffe9938: RemoteIpAddress: 10.226.9.210; SessionId: 1pt18972zxly1upzazjzmbl7r; Granted Authorities: authenticated, MIQ_Provision_ATC_TAXI, VPNG_JNPPHUB, authenticated, AT - AppDev - Quality Assurance, VPNG_JNPSNOW, ~ATG - IT Diagrams, BOXG_ATGITDIAGRAMS_R, ATL_Accelerator, AT - NewServerChecklist, Users, ATLG_QATEAM, CAR_FL_FINANCIAL_REPORTING_CPR_V3, SMS_REPORTVIEWER, SPSG_StratOppsCCGV, SPSG_ITProjectsV, CAR_FL_FINANCIAL_REPORTING_CPR, CORG_CONTRACTORS, AT - AppDev-Employees&Contractors, SPSG_MOSSTechV, SPSG_StratOppsInterV, ATL_MICORPUSERS, SPL_search_all, VPNG_COLOUSER, SPSG_SalesV, SPSG_StratOppsPartV, ATLG_CDRPITRWork_R, ATL_QATEAM, SPSG_DealerSiteV, SPSG_BusinessSysV, SPSG_ITBusinessOpsV, CAR_FL_CUSTOMER_MASTER, PITG_CONUSERS, VPNG_JNPBASE, ATLG_Accelerator, CARG_FL_FINANCIAL_REPORTING, CARG_FL_FINANCIAL_RPT_NEWS, ATLG_DATAUSERS, CAI_Contractors, CARG_FL_CUSTOMER_MASTER, CAR_FL_FINANCIAL_REPORTING, CAI_6TALK, ATL_EDMUNDS, CF_QA_ACCELERATOR, AWSG_LABS2-PowerUser, VPNG_SVN, SPSG_ITOpsAvailMgmtV, SPSG_TechOpsWSGV, SPSG_ITOpsV, AT - Preprod Users, ATL_ProteusR, ATLG_MICORPUSERS, Allowed RODC Password Replication Group, ATL_CDRPITRWork_R, SMSG_REPORTVIEWER, SPSG_ReleaseManV, AT - Mail Users, AT - Quality Assurance, ATL_MIO365, AT - Automation, CARG_FL_ESO_ORDER_VIEW, OWA, ATL_CRMReportingGroup, ATLG_EDMUNDS, SPSG_InfoTechV, BOXG_ATCSALES_LMV_TEST, BSM_CMDBoperator, BOXG_EVERYONE_R, BSM_Viewers, AT - PreProd, SPSG_UnixV, AWSG_OneDay, ATL_CRMUserGroup, ATLG_QA-AcceleratorVM, ATLMailUsers, JIV_USERS_ALL, VPNG_CONTRACTOR, AT - Atlanta Mail Users, SPSG_stm, CARG_FL_FINANCIAL_REPORTING_CPR, Domain Users, SPSG_StratOppsV, VPNG_QA-AUTOMATION-FRAMEWORK, AT - ProductDev-SVN, ATLG_MIO365, BSM_OOviewer, CARG_FL_FINANCIAL_REPORTING_CPR_V3`

