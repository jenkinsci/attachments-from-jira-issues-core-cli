Jenkins
=======

Version details
---------------

  * Version: `1.652`
  * Mode:    WAR
  * Url:     http://taxi49427:8080/
  * Servlet container
      - Specification: 3.0
      - Name:          `jetty/winstone-2.9`
  * Java
      - Home:           `/data/utils/jdk1.8.0_66/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0_66
      - Maximum memory:   878.50 MB (921174016)
      - Allocated memory: 398.50 MB (417857536)
      - Free memory:      250.98 MB (263170616)
      - In-use memory:    147.52 MB (154686920)
      - GC strategy:      ParallelGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    Java HotSpot(TM) 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 25.66-b17
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      2.6.18-402.el5
      - Distribution: "Red Hat Enterprise Linux Server release 5.11 (Tikanga)"
      - LSB Modules:  `:atc_cs_phase-0.5:atc_imagever-1.3.5-dev:client-config-overrides.txt:client_config_update.py:core-4.0-amd64:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-noarch`
  * Process ID: 29705 (0x7409)
  * Process started: 2016-03-16 14:22:37.547-0400
  * Process uptime: 1 min 34 sec
  * JVM startup parameters:
      - Boot classpath: `/data/utils/jdk1.8.0_66/jre/lib/resources.jar:/data/utils/jdk1.8.0_66/jre/lib/rt.jar:/data/utils/jdk1.8.0_66/jre/lib/sunrsasign.jar:/data/utils/jdk1.8.0_66/jre/lib/jsse.jar:/data/utils/jdk1.8.0_66/jre/lib/jce.jar:/data/utils/jdk1.8.0_66/jre/lib/charsets.jar:/data/utils/jdk1.8.0_66/jre/lib/jfr.jar:/data/utils/jdk1.8.0_66/jre/classes`
      - Classpath: `jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

Important configuration
---------------

  * Security realm: `hudson.plugins.active_directory.ActiveDirectorySecurityRealm`
  * Authorization strategy: `hudson.security.ProjectMatrixAuthorizationStrategy`

Active Plugins
--------------

  * active-directory:1.42 'Jenkins Active Directory plugin'
  * allure-jenkins-plugin:2.10 'Allure Jenkins Plugin'
  * ant:1.2 'Ant Plugin'
  * antisamy-markup-formatter:1.3 'OWASP Markup Formatter Plugin'
  * appdynamics-dashboard:1.0.7 'AppDynamics Dashboard Plugin for Jenkins'
  * avatar:1.2 'Avatar Plugin'
  * build-environment:1.6 'Build Environment Plugin'
  * build-flow-plugin:0.18 'CloudBees Build Flow plugin'
  * build-timeout:1.16 'Jenkins build timeout plugin'
  * buildgraph-view:1.1.1 'buildgraph-view'
  * buildtriggerbadge:2.2 'Build Trigger Badge Plugin'
  * chromedriver:1.2 'chromedriver'
  * cobertura:1.9.7 'Jenkins Cobertura Plugin'
  * configurationslicing:1.45 'Configuration Slicing plugin'
  * copy-to-slave:1.4.4 'Copy To Slave Plugin'
  * credentials:1.25 'Credentials Plugin'
  * cvs:2.12 'Jenkins CVS Plug-in'
  * disk-usage:0.28 'Jenkins disk-usage plugin'
  * email-ext:2.41.3 'Email Extension Plugin'
  * external-monitor-job:1.4 'External Monitor Job Type Plugin'
  * git:2.4.2 'Jenkins Git plugin'
  * git-client:1.19.6 'Jenkins Git client plugin'
  * github:1.17.1 'GitHub plugin'
  * github-api:1.72.1 'GitHub API Plugin'
  * greenballs:1.15 'Green Balls'
  * hp-application-automation-tools-plugin:4.0.1 'HP Application Automation Tools'
  * icon-shim:2.0.3 'Icon Shim Plugin'
  * jackson2-api:2.5.4 'Jackson 2 API Plugin'
  * javadoc:1.3 'Javadoc Plugin'
  * JDK_Parameter_Plugin:1.0 'JDK Parameter Plugin'
  * jqs-monitoring:1.4 'Job/Queue/Slaves Monitoring Plugin'
  * junit:1.11 'JUnit Plugin'
  * label-linked-jobs:4.0.3 'Label Linked Jobs Plugin'
  * ldap:1.11 'LDAP Plugin'
  * mailer:1.16 'Jenkins Mailer Plugin'
  * mailmap-resolver:0.2 'Mail Map Resolver'
  * mapdb-api:1.0.6.0 'MapDB API Plugin'
  * matrix-auth:1.3.2 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.6 'Matrix Project Plugin'
  * maven-plugin:2.12.1 'Maven Integration plugin'
  * metrics:3.1.2.7 'Metrics Plugin'
  * metrics-diskusage:3.0.0 'Metrics Disk Usage Plugin'
  * nodejs:0.2.1 'NodeJS Plugin'
  * pam-auth:1.2 'PAM Authentication plugin'
  * Parameterized-Remote-Trigger:2.2.2 'Parameterized Remote Trigger Plugin'
  * performance:1.13 'Performance plugin'
  * plain-credentials:1.1 'Plain Credentials Plugin'
  * postbuild-task:1.8 'Hudson Post build task'
  * postbuildscript:0.17 'Jenkins Post-Build Script Plug-in'
  * publish-over-ftp:1.11 'Publish Over FTP'
  * scm-api:1.1 'SCM API Plugin'
  * scm-sync-configuration:0.0.8 *(update available)* 'SCM Sync Configuration Plugin'
  * script-security:1.17 'Script Security Plugin'
  * show-build-parameters:1.0 'Show Build Parameters plugin'
  * sidebar-link:1.7 'Sidebar Link'
  * slack:1.8.1 *(update available)* 'Slack Notification Plugin'
  * slave-status:1.6 'slave-status'
  * sonar:2.3 'Jenkins SonarQube Plugin'
  * ssh-credentials:1.11 'SSH Credentials Plugin'
  * ssh-slaves:1.10 'Jenkins SSH Slaves plugin'
  * ssh2easy:1.3 'SSH2 Easy Plugin'
  * subversion:1.54 *(update available)* 'Jenkins Subversion Plug-in'
  * support-core:2.31 'Support Core Plugin'
  * svn-release-mgr:1.2 'Subversion Release Manager plugin'
  * test-results-analyzer:0.3.3 'Test Results Analyzer Plugin'
  * testng-plugin:1.10 'TestNG Results Plugin'
  * text-finder:1.10 'Jenkins TextFinder plugin'
  * timestamper:1.7.4 'Timestamper'
  * token-macro:1.12.1 'Token Macro Plugin'
  * translation:1.12 'Jenkins Translation Assistance plugin'
  * validating-string-parameter:2.3 'Validating String Parameter Plugin'
  * versioncolumn:0.2 'Jenkins Version Column plugin'
  * windows-slaves:1.1 'Windows Slaves Plugin'
  * xvfb:1.1.2 'Jenkins Xvfb plugin'
