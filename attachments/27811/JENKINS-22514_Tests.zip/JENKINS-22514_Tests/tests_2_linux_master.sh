#!/bin/bash
JENKINS_URL="http://localhost:8080"

#rm -f log.txt
rm -rf temp
mkdir temp
cd temp

echo "6. Linux master workspace:" >> ../log.txt
echo "" >> ../log.txt
wget $JENKINS_URL/job/linux/ws/out/*zip*/out.zip
mkdir unzip
cd unzip
unzip ../out.zip
echo "> ls -l out" >> ../../log.txt
ls -l out >> ../../log.txt
echo "" >> ../../log.txt
echo "> ls -l out/directory" >> ../../log.txt
ls -l out/directory >> ../../log.txt
echo "" >> ../../log.txt
echo "" >> ../../log.txt
cd ..
rm out.zip
rm -rf unzip

echo "7. Linux master artifact:" >> ../log.txt
echo "" >> ../log.txt
wget $JENKINS_URL/job/linux/lastSuccessfulBuild/artifact/out/*zip*/out.zip
mkdir unzip
cd unzip
unzip ../out.zip
echo "> ls -l out" >> ../../log.txt
ls -l out >> ../../log.txt
echo "" >> ../../log.txt
echo "> ls -l out/directory" >> ../../log.txt
ls -l out/directory >> ../../log.txt
echo "" >> ../../log.txt
echo "" >> ../../log.txt
cd ..
rm out.zip
rm -rf unzip

echo "8. Linux master userContent:" >> ../log.txt
echo "" >> ../log.txt
wget $JENKINS_URL/userContent/out/*zip*/out.zip
mkdir unzip
cd unzip
unzip ../out.zip
echo "> ls -l out" >> ../../log.txt
ls -l out >> ../../log.txt
echo "" >> ../../log.txt
echo "> ls -l out/directory" >> ../../log.txt
ls -l out/directory >> ../../log.txt
echo "" >> ../../log.txt
echo "" >> ../../log.txt
cd ..
rm out.zip
rm -rf unzip

echo "9. Linux master windows node workspace:" >> ../log.txt
echo "" >> ../log.txt
wget $JENKINS_URL/job/win/ws/out/*zip*/out.zip
mkdir unzip
cd unzip
unzip ../out.zip
echo "> ls -l out" >> ../../log.txt
ls -l out >> ../../log.txt
echo "" >> ../../log.txt
echo "> ls -l out/directory" >> ../../log.txt
ls -l out/directory >> ../../log.txt
echo "" >> ../../log.txt
echo "" >> ../../log.txt
cd ..
rm out.zip
rm -rf unzip

echo "10. Linux master windows node artifact:" >> ../log.txt
echo "" >> ../log.txt
wget $JENKINS_URL/view/All/job/win/lastSuccessfulBuild/artifact/out/*zip*/out.zip
mkdir unzip
cd unzip
unzip ../out.zip
echo "> ls -l out" >> ../../log.txt
ls -l out >> ../../log.txt
echo "" >> ../../log.txt
echo "> ls -l out/directory" >> ../../log.txt
ls -l out/directory >> ../../log.txt
echo "" >> ../../log.txt
echo "" >> ../../log.txt
cd ..
rm out.zip
rm -rf unzip
