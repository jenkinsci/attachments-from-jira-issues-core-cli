#!/bin/bash
JENKINS_URL="http://not-localhost:8080"

rm -f log.txt
rm -rf temp
mkdir temp
cd temp

echo "1. Windows master workspace:" >> ../log.txt 
echo "" >> ../log.txt 
wget $JENKINS_URL/job/win/ws/out/*zip*/out.zip
mkdir unzip
cd unzip
unzip ../out.zip
echo "> ls -l out" >> ../../log.txt
ls -l out >> ../../log.txt
echo "" >> ../../log.txt
echo "> ls -l out/directory" >> ../../log.txt
ls -l out/directory >> ../../log.txt
echo "" >> ../../log.txt
echo "" >> ../../log.txt
cd ..
rm out.zip
rm -rf unzip

echo "2. Windows master artifact:" >> ../log.txt 
echo "" >> ../log.txt 
wget $JENKINS_URL/job/win/lastSuccessfulBuild/artifact/out/*zip*/out.zip
mkdir unzip
cd unzip
unzip ../out.zip
echo "> ls -l out" >> ../../log.txt
ls -l out >> ../../log.txt
echo "" >> ../../log.txt
echo "> ls -l out/directory" >> ../../log.txt
ls -l out/directory >> ../../log.txt
echo "" >> ../../log.txt
echo "" >> ../../log.txt
cd ..
rm out.zip
rm -rf unzip

echo "3. Windows master userContent:" >> ../log.txt 
echo "" >> ../log.txt 
wget $JENKINS_URL/userContent/out/*zip*/out.zip
mkdir unzip
cd unzip
unzip ../out.zip
echo "> ls -l out" >> ../../log.txt
ls -l out >> ../../log.txt
echo "" >> ../../log.txt
echo "> ls -l out/directory" >> ../../log.txt
ls -l out/directory >> ../../log.txt
echo "" >> ../../log.txt
echo "" >> ../../log.txt
cd ..
rm out.zip
rm -rf unzip

echo "4. Windows master linux node workspace:" >> ../log.txt 
echo "" >> ../log.txt 
wget $JENKINS_URL/job/linux/ws/out/*zip*/out.zip
mkdir unzip
cd unzip
unzip ../out.zip
echo "> ls -l out" >> ../../log.txt
ls -l out >> ../../log.txt
echo "" >> ../../log.txt
echo "> ls -l out/directory" >> ../../log.txt
ls -l out/directory >> ../../log.txt
echo "" >> ../../log.txt
echo "" >> ../../log.txt
cd ..
rm out.zip
rm -rf unzip

echo "5. Windows master linux node artifact:" >> ../log.txt 
echo "" >> ../log.txt 
wget $JENKINS_URL/view/All/job/linux/lastSuccessfulBuild/artifact/out/*zip*/out.zip
mkdir unzip
cd unzip
unzip ../out.zip
echo "> ls -l out" >> ../../log.txt
ls -l out >> ../../log.txt
echo "" >> ../../log.txt
echo "> ls -l out/directory" >> ../../log.txt
ls -l out/directory >> ../../log.txt
echo "" >> ../../log.txt
echo "" >> ../../log.txt
cd ..
rm out.zip
rm -rf unzip
